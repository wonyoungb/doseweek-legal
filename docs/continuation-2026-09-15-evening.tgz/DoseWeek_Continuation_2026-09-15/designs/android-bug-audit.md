# Android bug audit — verified findings (2026-09-15)

Scope: read-only hunt on Android main `79bb210` at `/private/tmp/doseweek-v11-20260913/android`, plus the Play-shipped build `04fe817` (Play versionCode 9, the build the owner runs; versionCode 10 = main candidate, not on Play). Every finding below passed an adversarial verdict pass; severities are the *corrected* ones. Paths: `and:` = `android/app/src/main/java/com/wonyoungchoi/doseweek/`, `docs:` = `android/docs/`.

Duplicates merged: DRIVE-AUTH-01 ≡ SECREL-01, DRIVE-AUTH-02 ≡ SECREL-03, RW-01 ≡ LIFECYCLE-01 (same defect found by two lanes; the stronger verdict is kept, the weaker one is cited as corroboration).

Legend: `sev` = corrected severity, `conf` = verdict confidence, `owner?` = needs owner action outside the repo (Cloud/Play Console), `ships?` = fix already on main but not on Play.

## 1. Real findings (real=true), ordered by severity then user impact

| # | ID | sev | conf | Area | Defect (one line) | Key evidence | Fix direction | Owner? |
|---|---|---|---|---|---|---|---|---|
| 1 | LIFECYCLE-01 (+RW-01) | high | high | app lock / dialog windows | Any sheet window created **after** the shield sits **above** it (Compose Dialog z-order = creation order). Reminder route while shield visible (resumed, cancelled prompt), cold-start route replay, and SavedState draft restore all open record/edit sheets over the lock; sheet is fully interactive, Save commits without unlock. | `and:app/AppLockOverlay.kt:36-39,46-54` (own comment admits invariant), `and:designsystem/components/FullScreenSheet.kt:51-60`, `and:app/MainActivity.kt:184,189,245-268,273-280`, `and:app/DoseWeekViewModel.kt:599-621,3227,3251-3311,3999`, `and:features/navigation/DoseWeekApp.kt:207-262` (no lock gate), `and:data/ReminderScheduling.kt:68-69` (ROUTE_RECORD). WMS: [WindowToken.isFirstChildWindowGreaterThanSecond](https://android.googlesource.com/platform/frameworks/base/+/refs/heads/main/services/core/java/com/android/server/wm/WindowToken.java). Deterministic path: shield visible + resumed → tap dose banner → onNewIntent → sheet above shield. Cold-start path racy (IO load vs first frame). Backgrounded→banner path likely safe (same-frame). | Hold `onReminderRoute` / `replayPendingReminderRoute` / `restorePendingDrafts` while `lockMachine.requiresAuthentication`; replay after `authenticationSucceeded`. Belt-and-braces: compose DoseWeekApp sheets only when `!lock.isShieldVisible` (forces sheet window re-creation after shield). androidTest: lock + route → shield covers, save not clickable. | no |
| 2 | DRIVE-AUTH-01 (+SECREL-01) | high | medium | Drive auth / OAuth client config | Quantum-ready Play signing = **three** keys (Android ≤16 classical, hybrid classical, ML-DSA-65). Repo registered only **two** Play certs, both copied from the two Console buttons; the third (likely the ≤16 deployment cert) has no Android OAuth client → Drive cannot authorize on that Android range. Never observed working on any real device. | [Play App Signing help](https://support.google.com/googleplay/android-developer/answer/9842756): "three distinct keys … register each of them with your API providers". Repo: `docs:PLAY_CONSOLE_ANSWER_SHEET.md:106-121`, `docs:PLAY_STORE.md:145-147,172-175` ("register **both**"), `docs:CURRENT_HANDOFF.md:527,1779-1790,1849-1856`. App ships no client id: `and:data/drive/DriveAuthorizationController.kt:84-87,225` ([authorization guide](https://developer.android.com/identity/authorization)). Differential: debug cert + emulator uploads fine `docs:INTEGRATION_PATCH_VERIFICATION.md:334-352`. Corroboration (secondary): [dev.to hidden SHA-1](https://dev.to/sanjaysah/google-sign-in-works-in-debug-but-fails-in-production-on-android-check-this-hidden-sha-1-18nn). **Caveat:** cert mismatch is documented as code 10, not 8 ([CommonStatusCodes](https://developers.google.com/android/reference/com/google/android/gms/common/api/CommonStatusCodes)); link to the owner's 8 is hypothesis. | Owner: Play Console → App integrity/App signing → **Download certificates** → `keytool -printcert -file deployment_cert.der` (+ hybrid certs) → SHA-1 of all three → ensure each is an Android OAuth client for `com.wonyoungchoi.doseweek` in `doseweek-507313`; wait propagation; retest. Repo: `docs:PLAY_STORE.md:172-175` "both" → "all three (deployment_cert.der + hybrid pair)"; record fingerprint origin in ANSWER_SHEET. | **yes** |
| 3 | HC-01 | medium | high | Health Connect / launch trigger (Play code 9) | Play build `04fe817` never auto-imports: `onForegrounded` has no `importHealthConnectNow`; HC read only on manual "Import now"/"Reimport all". Importer also had no post-page catch-up. Main fixes both (17ed662 onStart import, 1962106 catch-up). Likely the owner's HEALTH-20260913-06 if the owner did not tap Import now; if they did tap and still saw the gap, cause is elsewhere (see §4). | `04fe817 DoseWeekViewModel.kt:511-523,1035-1044,1361-1385`, `04fe817 HealthConnectImporter.kt:395,412`; main `and:app/DoseWeekViewModel.kt:522-527`, `and:data/health/HealthConnectImporter.kt:407-417`, `MainActivity.kt:284`. Ledger `scripts/check_invariants.py:287`. [sync-data doc](https://developer.android.com/health-and-fitness/health-connect/sync-data): "check for new data … each time your app becomes active in the foreground". | Ship code 10. Until then only the manual tap fetches. | ships? yes |
| 4 | DRIVE-AUTH-03 | medium | high | Drive auth / token lifecycle | 401 on list/download/delete/refresh never calls `clearToken`; "reconnect" → `authorizeSilently` → GMS serves the same cached (rejected) token → 401 again. Loop until GMS cache TTL (~1h). Only `backupNow` clears. Workaround: disconnect (revokeAccess) then connect. | `and:data/drive/CloudBackupService.kt:232-249,298-299,376-378`, `and:app/DoseWeekViewModel.kt:1763-1850,2290-2312`, `and:data/drive/DriveAppDataApi.kt:305`, `DriveAuthorizationController.kt:213-235`. [authorization guide](https://developer.android.com/identity/authorization): clear the local cache when a token is rejected. | On `DriveAuthorizationRequiredException` in every `requireGrantedToken` caller call `authorization.clearToken(token)` before publishing NEEDS_RECONNECT; in `reauthorizeCloudBackup` clear last token before `authorizeSilently`. JVM test: fake controller returns same token twice, 401 once → `clearToken` seen. | no |
| 5 | DI-01 | medium | high | backup validator vs soft-delete timestamps | Soft delete under wall-clock rollback writes `deleted_at=observedAt` raw but `updated_at=max(observedAt, createdAt)` → `deleted_at < updated_at`; validator rejects → **every** later file export and Drive backup (incl. daily periodic work) fails; file path shows misleading "not a valid backup file". Persists until that tombstone is restored. | `and:data/DoseWeekRepository.kt:969,1032-1033,1070-1072,2876-2891`, `and:data/backup/BackupModels.kt:981`, `and:data/backup/DoseWeekBackupService.kt:22,55`, `CloudBackupService.kt:412-413,538`, `CloudBackupWork.kt:95`, `DoseWeekViewModel.kt:7282`. Test gap: `DoseWeekRepositoryV2Test.kt:538-575` restores before validating. | `softDelete`/`restore`: `deleted_at = updated_at = max(observedAt, existing.updatedAt, existing.createdAt)`; also clamp at `:971`. Regression: rolled-back Clock, delete, `createBackupSnapshot`+validate passes. | no |
| 6 | DI-02 | medium | medium | Health Connect merge / natural-key adoption | `adopted = storedByExternalId ?: storedByNaturalKey` re-keys a **live** row to a duplicate HC record id; later `DeletionChange` of that duplicate deletes the local row while the original still exists in HC; incremental feed never re-emits it. Contract rule 9 breached in spirit. Possible (unproven) contributor to HEALTH-20260913-06. | `and:domain/ExternalMeasurementMerge.kt:79`, `DoseWeekRepository.kt:1524-1530,1554,1558-1563,1573-1579,2444-2475`, `HealthConnectClientGateway.kt:94-95`, `HealthConnectImporter.kt:486-492`, `AGENTS.md:114-120`. Tests cover restored rows only (`ExternalMeasurementMergeTest.kt:64-85`). [write-data](https://developer.android.com/health-and-fitness/guides/health-connect/develop/write-data) (fresh id per insert w/o clientRecordId), [sync-data](https://developer.android.com/health-and-fitness/guides/health-connect/develop/sync-data) (DeletionChange carries id only). | Adopt by natural key only for backup-restored rows: device-local flag set by `insertBackupExternalMeasurement`, cleared on first match; live rows never re-keyed. | no |
| 7 | RW-02 | medium | high | reminders / supply nudge | `supplyAt = max(dayOf-48h, now+1h)` re-derived on every app open (`onForegrounded` → `loadPersistedState` → `syncReminders`) → new supply banner ~1h after each open until dose; tapping the banner re-arms it. Receiver path deliberately avoids this; foreground path bypasses. Ignores `inventoryTrackingEnabled`. iOS has same rule. | `and:domain/ReminderPlan.kt:11-13,72-74`, `DoseWeekViewModel.kt:266-270,522-537,2755-2785,3226`, `data/ReminderScheduling.kt:70,91-96`, `app/ReminderNotifications.kt:181-185`, `strings.xml:188`. [AlarmManager.set](https://developer.android.com/reference/android/app/AlarmManager#set(int,%20long,%20android.app.PendingIntent)) (same PI replaces, so no accumulation but re-book). iOS `NotificationService.swift:149-153,266-280`. | Persist non-PHI marker `supplyNudgeFiredForOccurrence=<id>`; `supplyAt=null` when marker matches; reset on new occurrence/restock; severity null when tracking off. JVM test. Cross-platform. | no |
| 8 | RW-03 | medium | high | reminders / Doze | `setWindow` without `*AllowWhileIdle` → deferred to next Doze maintenance window (hours) on idle screen-off phone; comment claims "a few minutes". Restricted-bucket sub-claim overstated (slots ≥24h apart, no competition; widget users exempt). | `data/ReminderScheduling.kt:55-58,91-96`; manifest:7 + `check_invariants.py:74-84` forbid exact alarms. [Doze](https://developer.android.com/training/monitoring-device-state/doze-standby): "Defers standard AlarmManager alarms, including setExact() and setWindow(), to the next maintenance window". | `alarmManager.setAndAllowWhileIdle(RTC_WAKEUP, fireAt, pi)` (API 23+, inexact, no permission; 3 slots well under the 9-min cap). Keep no-exact-alarm stance. | no |
| 9 | LIFECYCLE-02 | medium | high | FLAG_SECURE / recovery code | With app lock OFF, the recovery-code Dialog window (FullScreenSheet / AlertDialog, `securePolicy=Inherit`) copies the activity flag in `SideEffect` **before** the `LaunchedEffect` sets FLAG_SECURE → dialog window unsecured until its next recomposition; screenshot/cast captures the code. Lock ON is fine (flag pre-set). | `MainActivity.kt:198-208`, `FullScreenSheet.kt:51-59`, `features/backup/BackupDialogs.kt:72-118`, `CloudBackupSheet.kt:146,190-207`, `DoseWeekUiModels.kt:1173-1178`. [AndroidDialog.android.kt](https://android.googlesource.com/platform/frameworks/support/+/refs/heads/androidx-main/compose/ui/ui/src/androidMain/kotlin/androidx/compose/ui/window/AndroidDialog.android.kt), [SecureFlagPolicy](https://developer.android.com/reference/kotlin/androidx/compose/ui/window/SecureFlagPolicy), [side-effects](https://developer.android.com/develop/ui/compose/side-effects), [FLAG_SECURE per window](https://developer.android.com/reference/android/view/WindowManager.LayoutParams#FLAG_SECURE). No test greps FLAG_SECURE. | `DialogProperties(securePolicy = SecureFlagPolicy.SecureOn)` on recovery-code dialogs (param on FullScreenSheet; BackupExport/Restore dialogs). androidTest asserting dialog window flags. | no |
| 10 | DRIVE-AUTH-02 (+SECREL-03) | medium (SECREL-03 verdict: low) | high | Drive diagnostics / status-8 origin | Status 8 has ≥2 origins (GMS-internal on silent `authorize()` Task vs SDK-synthesised in `getAuthorizationResultFromIntent` on consent return; also worker/list/download/refresh paths) but the app stores only the code, not the stage; the owner's report cannot be attributed. Code-9 build had no 8 branch → UNKNOWN → "다시 연결해야 합니다 / Google 응답 코드 8" (exact screenshot). Diagnostic gap, not wrong runtime behaviour. | `DriveAuthorizationController.kt:218-239,245,252-261,312-330`, `DoseWeekViewModel.kt:1741,1787,1820-1823,2116,2194,2251,2279,2343-2372,2630-2631`, `DoseWeekUiModels.kt:1169`, `CloudBackupSheet.kt:86-97`, `04fe817 classifyStatus:317-325`, `strings.xml:625,627`. javap of play-services-auth 22.0.0 `zbad.getAuthorizationResultFromIntent`. [AuthorizationClient](https://developers.google.com/android/reference/com/google/android/gms/auth/api/identity/AuthorizationClient), [CommonStatusCodes](https://developers.google.com/android/reference/com/google/android/gms/common/api/CommonStatusCodes). | Add `stage` (SILENT / CONSENT / WORKER / LIST…) to `Failed` and to `CloudBackupUiState`, render beside the code; keep 8 → retryable copy plus "if it repeats, this build's signing certificate may not be registered". Do not attempt CONSENT_INCOMPLETE split (not distinguishable via public SDK). | no (owner question in §3) |
| 11 | HC-03 | low | high | Health Connect / foreground rule | Import launched at onStart keeps running after onStop; platform HC (API 34+) throws SecurityException for background reads without `READ_HEALTH_DATA_IN_BACKGROUND`; gateway maps every SecurityException → "permission revoked", deniedTypes, persisted phase "권한 없음" while grant intact. Self-healing on next foreground; no data loss. Needs import running >5s after Home (large DB11 backfill). | `MainActivity.kt:282-299`, `DoseWeekViewModel.kt:1269-1299,3324-3325,6600,6998`, `HealthConnectClientGateway.kt:60-84,210-211`, `HealthConnectImporter.kt:207-208,283-287,326-330`, `AndroidManifest.xml:24-28`. AOSP `HealthConnectServiceImpl.java` readRecords/getChangeLogs foreground enforcement; [read-data](https://developer.android.com/health-and-fitness/health-connect/read-data) ("consider using a foreground service …"). | Cancel `healthImportJob` on onStop (or ProcessLifecycle), or re-check `grantedPermissions()` before classifying SecurityException as revoked; else PROVIDER_FAILED. | no |
| 12 | HC-04 | low | high | Health Connect / gateway exception mapping | `android.os.RemoteException` (checked) escapes `guarded`/`runStep` (they catch ISE/SecurityException/IOException/RuntimeException only) → whole import aborts, later types skipped, no `lastImportPhase`, sheet shows FAILED with zero rows. SDK emits it for ERROR_REMOTE / IPC failures. "Permanent stall via 10008" sub-claim refuted (expiry surfaces as `changesTokenExpired`, handled). | `HealthConnectClientGateway.kt:92,204-219`, `HealthConnectImporter.kt:160-168,283-309,450-476`, `DoseWeekViewModel.kt:1286,2339-2340`. javap connect-client 1.1.0 `ExceptionConverterKt`. [HealthConnectClient](https://developer.android.com/reference/kotlin/androidx/health/connect/client/HealthConnectClient) ("Throws android.os.RemoteException For any IPC transportation failures"), [HealthConnectException.ERROR_REMOTE](https://developer.android.com/reference/android/health/connect/HealthConnectException). | `guarded`: catch `Exception` → `HealthConnectUnavailableException`; `runStep`: catch `Exception` → PROVIDER_FAILED. Drop the N-failure token reset idea. | no |
| 13 | SECREL-02 | low | medium | Drive config | Google Drive API enablement on `doseweek-507313` never re-checked. Masked today because auth fails first; once auth works a disabled API yields a clean, non-retried, localized "API not enabled" (already handled). | `docs:PLAY_CONSOLE_ANSWER_SHEET.md:88,247-250`, `docs:PLAY_STORE.md:176`, `DriveAppDataApi.kt:275,309`, `CloudBackupService.kt:393`, `CloudBackupWork.kt:81`. [enable-drive-api](https://developers.google.com/workspace/drive/api/guides/enable-drive-api). | Owner: Cloud Console → APIs & Services → Library → Google Drive API → confirm Enabled; record date in ANSWER_SHEET. | **yes** |

## 2. Refuted / downgraded to not-real

| ID | Original sev | Verdict | Why |
|---|---|---|---|
| HC-02 | medium | **real=false** (residual low) | Mechanics confirmed (`TimeRangeFilter.before(end)` exclusive; token taken after `now`; changelog only "post the time this token was generated"), but the trigger cannot occur: platform HC (Android 14+) rejects future-dated InstantRecords at the writer — `InstantRecord.java:47` "Record time must not be in the future" ([AOSP](https://android.googlesource.com/platform/packages/modules/HealthFitness/+/refs/heads/android14-release/framework/java/android/health/connect/datatypes/InstantRecord.java)); `buildWithoutValidation` is @hide; androidx converters use `.build()`. Same phone clock drives both writer and DoseWeek `now`. Residual: seconds-wide race between `:175 now` and `:265` token take, or phone clock rollback; HC APK provider on API ≤33 unverified. Cheap hardening still OK (capture `end` after the changes token). |

Sub-claims refuted inside real findings: RW-01 warm/stopped path (shield not composed while stopped; both windows created in one frame, shield last → safe); RW-03 restricted-bucket "compete for the single daily alarm" (slots ≥24h apart); HC-04 "foreground path silent" (sheet shows FAILED) and "permanent stall on Android ≤13"; DRIVE-AUTH-02 `data==null` branch (unreachable, `:245 data?.let`); HC-01 "explains owner symptom" (hypothesis; depends on whether Import now was tapped).

## 3. Google Drive status 8 — ranked hypotheses

Facts: owner's Play-installed code 9 shows "다시 연결해야 합니다 / Google 응답 코드 8" on the Drive backup sheet. 8 = `INTERNAL_ERROR` "An internal error occurred. Retrying should resolve the problem." ([CommonStatusCodes](https://developers.google.com/android/reference/com/google/android/gms/common/api/CommonStatusCodes)). PR3 only relabelled the message. No real device/account has ever connected. Debug build + registered debug cert on a Play emulator works end-to-end.

| Rank | Hypothesis | Prior | Predicts | Confirm | Refute |
|---|---|---|---|---|---|
| H1 | Installed signer's cert has no Android OAuth client (third Play key unregistered; or the 9/8 "classical" client used the wrong button cert) — DRIVE-AUTH-01 | medium-high (documented gap; only variable vs the working emulator run) | No Google UI at all, same code on every tap, same on every Play user; `apksigner --print-certs` SHA-1 ∉ registered set | signer SHA-1 not among the 4 clients; logcat `UNREGISTERED_ON_API_CONSOLE` / `INVALID_AUDIENCE` / `DEVELOPER_ERROR` / `Unknown calling package`; owner's Download-certificates SHA-1s ≠ registered | signer SHA-1 is registered **and** logcat shows a non-cert GMS failure |
| H2 | GMS core mishandles the hybrid v3.2 / ML-DSA-65 signer set (Android 17 phone) or the v3.1 rotation and reports it as internal error rather than 10 | medium (explains 8 instead of 10) | `ro.build.version.sdk` ≥ 37 (or `apkSigningVersion` 3.x with 2 signers); consistent 8; GMS logcat stack trace around AppCert/GetToken | phone is API 37 + hybrid signer + GMS stack trace mentioning signature/cert verification | phone ≤16 with plain classical signer, or logcat shows plain NeedPermission flow |
| H3 | Consent-stage SDK-synthesised 8: GMS UI shown, returned status success but no `authorization_result` parcel | low-medium | Owner saw an account chooser / consent screen before the message; logcat shows `AuthorizationActivity`/`GLSActivity` result | owner says a Google screen appeared; `dumpsys activity` shows a `com.google.android.gms` activity resumed during the attempt | owner says no Google screen appeared |
| H4 | First-attempt-after-install transient (GMS warm-up) — [google-services#381](https://github.com/googlesamples/google-services/issues/381) | low (owner + one Play user, persistent) | Second tap succeeds | immediate retry connects | same 8 on retry |
| H5 | Account-level: Workspace / supervised / Family-Link account, Drive service disabled, account needs re-sign-in | low | Other Google apps also fail; `dumpsys account` shows non-consumer account type or "needs attention" | Drive app itself cannot sign in with that account | consumer @gmail.com account, Drive app fine |
| H6 | Stale / broken GMS core or Play Store | low (would rather give 2 / 17) | old `com.google.android.gms` versionName; Play Protect prompts | GMS version far behind; other GMS features broken | current GMS |
| H7 | Drive API not enabled on project — SECREL-02 | ~0 for **this** symptom | n/a (would be 403 after a token) | — | authorize() fails before any HTTPS, so cannot be the 8 |

## 4. Device script — Google Drive status 8 (coordinator, once the phone is authorized)

Rules: read-only on the phone. No install, uninstall, `pm clear`, `am force-stop`, account changes, or sideloading. Save every output under `evidence/drive-status8/`. Redact the Google account e-mail in anything committed.

```bash
set -u
OUT="evidence/drive-status8"; mkdir -p "$OUT"
PKG=com.wonyoungchoi.doseweek

# 0. Device + build facts
adb devices -l                                                    | tee "$OUT/00-devices.txt"
adb shell getprop ro.build.version.sdk                            | tee "$OUT/01-sdk.txt"      # 37 = Android 17 → hybrid v3.2 signer applies; ≤36 → Android ≤16 classical (deployment) cert applies
adb shell getprop ro.build.version.release                        | tee -a "$OUT/01-sdk.txt"
adb shell dumpsys package $PKG | grep -E 'versionCode|versionName|installerPackageName|apkSigningVersion|signatures|firstInstallTime|lastUpdateTime' \
                                                                  | tee "$OUT/02-app-package.txt"   # expect versionCode=9, installer com.android.vending
adb shell dumpsys package com.google.android.gms | grep -m1 versionName | tee "$OUT/03-gms-version.txt"
adb shell dumpsys package com.android.vending    | grep -m1 versionName | tee -a "$OUT/03-gms-version.txt"
adb shell dumpsys account | grep -cE 'type=com.google'            | tee "$OUT/04-google-account-count.txt"   # count only; do not commit names

# 1. Installed signer certificate (decisive for H1/H2)
APK=$(adb shell pm path $PKG | sed -n 's/^package://p' | grep -m1 base.apk | tr -d '\r')
adb pull "$APK" "$OUT/base.apk"
BT=$(ls -d "${ANDROID_HOME:-$HOME/Library/Android/sdk}"/build-tools/* | sort -V | tail -1)   # need build-tools ≥ 36 for v3.2 blocks
"$BT/apksigner" verify --print-certs -v "$OUT/base.apk"           | tee "$OUT/05-apksigner.txt"
keytool -printcert -jarfile "$OUT/base.apk" 2>/dev/null | grep -E 'SHA1|Signature algorithm' | tee "$OUT/05-keytool.txt"
# Compare every "Signer #N certificate SHA-1" against the four registered clients
# (Play classical 9/8, Play post-quantum 9/10, upload key A4:4A:E8…, debug). Any signer SHA-1 absent → H1 CONFIRMED.
# If apksigner says "v3.2" / lists 2 signers with ML-DSA → hybrid set in use (H2 in scope).

# 2. Logcat capture around ONE connect attempt
adb logcat -c
adb logcat -v time > "$OUT/10-logcat-attempt1.txt" 2>&1 &
LOGPID=$!
# Foreground-activity sampler: tells whether any Google UI (H3) was shown
( for i in $(seq 1 60); do date +%T; adb shell dumpsys activity activities | grep -E 'topResumedActivity|mResumedActivity|ResumedActivity' ; sleep 1; done ) > "$OUT/11-resumed-activity.txt" 2>&1 &
SAMPPID=$!
echo ">>> On the phone now: open DoseWeek → 설정(Settings) → Google Drive 백업 sheet → tap the connect button. Wait for the message. Note whether ANY Google screen (account chooser / consent) appeared. Press Enter here when the message is on screen."; read -r
sleep 3; kill $LOGPID $SAMPPID 2>/dev/null

# 3. Immediate retry (H4) — same screen, tap connect again, same capture
adb logcat -c
adb logcat -v time > "$OUT/12-logcat-attempt2.txt" 2>&1 & LOGPID=$!
echo ">>> Tap connect AGAIN without leaving the sheet. Enter when the result shows."; read -r
sleep 3; kill $LOGPID 2>/dev/null

# 4. Extract the relevant lines
for f in "$OUT"/1[02]-logcat-*.txt; do
  grep -iE 'GoogleAuth|GLSUser|GLSActivity|AuthZen|Authorization|AuthorizationService|AppCert|GetToken|TokenCache|INVALID_AUDIENCE|UNREGISTERED_ON_API_CONSOLE|DEVELOPER_ERROR|INTERNAL_ERROR|statusCode=|Unknown calling package|NeedPermission|SignatureVerif|apksig|doseweek' "$f" > "${f%.txt}-filtered.txt"
done
grep -E 'com.google.android.gms' "$OUT/11-resumed-activity.txt" | sort -u > "$OUT/13-gms-ui-seen.txt"
```

Screens to tap (Play code 9): app icon → bottom/side nav 설정 (Settings) → "Google Drive 백업" row → sheet → connect button (연결). The failure text is "다시 연결해야 합니다 / Google 응답 코드 8" on code 9; main renders the 8 as SERVER_ERROR copy with the same code line.

Outcome matrix:

| Observation | Meaning | Next |
|---|---|---|
| Signer SHA-1 (step 1) not among the 4 registered clients | **H1 confirmed** regardless of the code | Owner registers the missing cert(s) via Download certificates; retest after ~15 min; then fix `docs/PLAY_STORE.md:172-175` |
| Signer SHA-1 registered; logcat has `UNREGISTERED_ON_API_CONSOLE` / `INVALID_AUDIENCE` / `Unknown calling package` / `DEVELOPER_ERROR` | Client exists but wrong package/cert pairing or propagation not done | Owner re-checks package name + SHA-1 on that client; wait; retest |
| `13-gms-ui-seen.txt` empty and owner saw no Google screen; same 8 on retry | Silent-stage 8 from GMS core (H1/H2/H5/H6) | Read GMS stack trace in filtered log around `statusCode=8`; if it names cert/signature → H2; else H5/H6 check (account type, GMS version) |
| GMS activity resumed / owner saw chooser or consent, then 8 | Consent-stage 8 (H3): success status without result parcel | Capture `AuthorizationActivity` result lines; report to Google if reproducible; app fix = stage tag (DRIVE-AUTH-02) |
| Attempt 2 succeeds (Granted, sheet shows connected / code list) | H4 transient | Ship stage tag + "retry" copy; watch for recurrence |
| `01-sdk.txt` = 37 and apksigner shows 2 signers incl. ML-DSA | Hybrid signer set in play (H2 candidate); ≤16 deployment cert not what this phone verifies | Cert compare must be against the hybrid classical + PQC clients specifically |
| GMS versionName old (not 2026) | H6 | Owner updates Play services; retest |

Optional differential (out of this lane, needs owner consent, **installs an APK**): sideload the upload-key-signed APK (bundletool from the owner-signed AAB; upload cert registered 9/10) and repeat step 2. Connects → signer was the only variable (H1/H2). Not part of the script above.

## 5. Health Connect freshness (HEALTH-20260913-06) — ranked hypotheses

Facts: owner reports recent HC records missing in DoseWeek. Owner runs Play code 9 (`04fe817`). Handoff `docs:CURRENT_HANDOFF.md:47,419-421` records the report without saying whether "Import now" was tapped; it names status restoration / permission-history windows as suspects.

| Rank | Hypothesis | Prior | Predicts | Confirm | Refute |
|---|---|---|---|---|---|
| F1 | Code 9 never auto-imports; owner did not tap Import now after the record was written — HC-01 | high | Sheet "Last checked" older than the record; tapping Import now inserts it | Import now → inserted ≥ 1, record appears | Import now → inserted 0 and record still absent |
| F2 | 30-day read restriction: records dated >30 days before the permission was first granted are unreadable without the history permission ([read-data, "restrictions"](https://developer.android.com/health-and-fitness/guides/health-connect/develop/read-data)) — handoff suspect | medium for old rows, low for "recent" | Only rows older than grant−30d missing; recent ones import | Missing rows all older than 30 days before the grant date | missing rows are newer than the grant |
| F3 | Row imported then deleted by natural-key re-keying + provider deletion of a duplicate — DI-02 | low-medium | HC app shows the record once (dup already deleted) or twice; DoseWeek Body list lacks it; "Reimport all" brings it back | Reimport all restores the row; HC app shows/showed duplicate entries from the source | Reimport all also misses it |
| F4 | Import ran in background after Home → SecurityException misreported as permission revoked, run aborted early — HC-03 | low (self-heals) | Sheet per-type label "권한 없음"/"permission revoked" while HC app shows permission granted | that label + granted in HC app | labels normal |
| F5 | RemoteException aborted a run (FAILED, zero step rows) — HC-04 | low | Sheet shows FAILED with empty step report; next tap works | that exact sheet state | never seen |
| F6 | Source app writes to a different HC data type / unit (e.g. body-fat vs weight, or BMI) or HC permission for that type not granted | medium | HC app "Data and access" shows the record under a type DoseWeek has no permission for | permission list in HC app for DoseWeek lacks that type | type granted |
| F7 | Record written to HC is future-dated / skewed — HC-02 | refuted | — | — | platform rejects future times |

## 6. Device script — Health Connect freshness

Same rules: no install/uninstall, no `pm clear`, no `am force-stop` (would also cancel reminder alarms — use recents swipe instead). The Play build is not debuggable, so `run-as` DB reads are impossible; evidence comes from screens + logcat.

```bash
set -u
OUT="evidence/hc-freshness"; mkdir -p "$OUT"
PKG=com.wonyoungchoi.doseweek

# 0. Facts
adb shell getprop ro.build.version.sdk                           | tee "$OUT/01-sdk.txt"   # ≥34 = platform Health Connect (module); ≤33 = HC APK provider
adb shell dumpsys package $PKG | grep -E 'versionCode|versionName'                | tee "$OUT/02-app.txt"   # 9 → no auto-import (HC-01)
adb shell dumpsys package com.google.android.apps.healthdata | grep -m1 versionName | tee "$OUT/03-hc-provider.txt"
adb shell dumpsys package $PKG | grep -iE 'android.permission.health' \
                                                                 | tee "$OUT/04-hc-permissions.txt"   # granted=true per READ_* type; note READ_HEALTH_DATA_HISTORY / _IN_BACKGROUND absence
adb shell date                                                   | tee "$OUT/05-phone-clock.txt"
date                                                             | tee -a "$OUT/05-phone-clock.txt"

# 1. Manual observation BEFORE any import (write into $OUT/06-before.md)
#  a. Health Connect app (Settings → Health Connect, or the HC app) → Data and access → Weight (and other granted types)
#     → note the newest 3 records: time, value, source app. Also check for visible duplicates.
#  b. HC app → App permissions → DoseWeek → which types are allowed; whether "Access data in the background" / history rows exist.
#  c. DoseWeek → Body tab → headline value + date.
#  d. DoseWeek → Settings → Health Connect sheet → "Last checked" time, status (CONNECTED?), per-type phase labels
#     (look for "권한 없음"/"permission revoked" → F4; "FAILED" with zero rows → F5), history complete/pending.

# 2. Logcat during one "Import now"
adb logcat -c
adb logcat -v time > "$OUT/10-logcat-import-now.txt" 2>&1 & LOGPID=$!
echo ">>> DoseWeek → Settings → Health Connect sheet → tap 'Import now'. Wait for the step report. Enter when done."; read -r
sleep 3; kill $LOGPID 2>/dev/null
grep -iE 'HealthConnect|healthdata|HealthConnectServiceImpl|SecurityException|must be in foreground|RemoteException|changesToken|doseweek' \
  "$OUT/10-logcat-import-now.txt" > "$OUT/10-logcat-import-now-filtered.txt"
# Record the step report: per-type inserted / updated / deleted / skipped counts, phase labels, new "Last checked" (→ $OUT/11-after-import-now.md)

# 3. Foreground-trigger check (only meaningful on code 10+; on code 9 expect NO import)
#  Have a weight written in the source app (or HC app manual entry) → swipe DoseWeek away from recents (do NOT force-stop) → reopen
#  → Body tab. Code 9: headline unchanged until Import now (F1 confirmed). Code 10: headline updates within seconds.

# 4. Only if F3 suspected: Health Connect sheet → "Reimport all" (full read) → does the missing row come back? Capture step report.
```

Outcome matrix:

| Observation | Meaning | Next |
|---|---|---|
| Before: HC app newest record time > sheet "Last checked"; Import now → inserted ≥ 1, row appears | **F1 confirmed** (HC-01): code 9 has no foreground import | Ship code 10 (already on main); tell owner to tap Import now meanwhile |
| Import now → inserted 0; missing rows are all older than (first grant date − 30 days) | F2: read restriction | Request `READ_HEALTH_DATA_HISTORY` in a later build if product wants it; document |
| Import now → inserted 0; row is newer than grant; type is granted; Reimport all restores it | F3 (DI-02) or a previous tombstone | Fix DI-02 (restore-only adoption); check HC app for duplicate entries from the source |
| Sheet per-type label "권한 없음" while HC app shows the type granted | F4 (HC-03) | Fix job cancellation on onStop; label heals on next foreground |
| Sheet FAILED, zero step rows, logcat RemoteException / ERROR_REMOTE | F5 (HC-04) | Fix exception mapping; retry works |
| HC app shows the record under a type DoseWeek lacks permission for, or from a source DoseWeek filters | F6 | Grant/extend permissions; product decision |
| `04-hc-permissions.txt` shows READ_* granted=false for the type | permission actually revoked | Owner re-grants in HC app |

## 7. Action summary

Owner (console, no repo change): (a) Play Console → Download certificates → three SHA-1s → all three Android OAuth clients in `doseweek-507313` (DRIVE-AUTH-01); (b) confirm Google Drive API enabled (SECREL-02); (c) answer: did any Google screen appear before "응답 코드 8"?

Coordinator (adb lane): run §4 then §6 scripts; attach outputs to the evidence folder; feed the outcome rows back into the ledger.

Code (main, in priority order): LIFECYCLE-01 lock gate → DRIVE-AUTH-03 clearToken → DI-01 tombstone clamp → LIFECYCLE-02 SecureOn → RW-02 fired marker (cross-platform) → RW-03 setAndAllowWhileIdle → DI-02 restore-only adoption → DRIVE-AUTH-02 stage tag → HC-03/HC-04 exception hygiene. HC-01 is already fixed on main: ship code 10.
