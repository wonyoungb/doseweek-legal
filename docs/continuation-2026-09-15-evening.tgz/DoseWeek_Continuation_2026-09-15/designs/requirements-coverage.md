# DoseWeek requirements coverage — 2026-09-15

Read-only critic. Revision 2 (review fixes; see Review log). Worktree snapshot re-read 2026-09-15 12:43 KST:

- iOS `codex/v11-bugfix` **7e8681b** (12:40, calendar-bound fix, clean). CI evidence still **4c3e594**. 7e8681b changed `DoseDay/Features/History/HistoryView.swift` (+21/-5, production), `DoseDay/Features/Components/ConfirmedDateTimePicker.swift` (+5, doc only per lane handoff), `DoseDayUITests/HistoryExportFeedbackUITests.swift` (+57). Before the commit (first report 12:35) these were the 3 uncommitted files. 26 iOS DONE rows cite them → note `HEAD DRIFT`.
- Android main 79bb210 (clean). android-import `feat/history-import` 197d9f3 (clean).
- **Uncommitted lane work (not evidence):** ios-import on 4c3e594 — `DoseDaySchemaV6` + lightweight V5→V6 stage, HistoryImport entities/persistence, `DoseDay/Domain/HistoryImport/` (5 files), backup crypto/validator/file-import, pbxproj; no test changes. android-import-ui on 197d9f3 — HistoryImportFlow/Gateway, resolver/draft codec/UI models. android-import-data on 197d9f3 — StandardHistoryTable, ImportProvenanceMetadata/Views, TableImportRows, history_exchange strings, export sheet/History screens. android-nutrition-data on 79bb210 — untracked `nutrition-data/`.
- Machine rows: `requirements-coverage.json` (655 objects; one per ID×platform).

## Status rules

- **DONE_VERIFIED** — code at current head + mapped tests executed PASS on current head or app-identical candidate (iOS CI 4c3e594 iPhone/iPad legs + unit step; Android 79bb210 JVM 698 + API24/36 581 each) + prior audit shows no open scenario gap. Not release acceptance: iOS full CI not green, AX5 leg interrupted, iOS main unmerged.
- **IMPLEMENTED_UNVERIFIED** — code present; required scenario variant / final gate / human or legal review not executed. Process-only rows without mapped tests (DL01–DL04) are always here, never DONE.
- `Scope:` in a DONE note = the proven boundary; `Not claimed:` items are outside the requirement's expected clause, not open gaps (else the row would be IMPL_UNVER). `HEAD DRIFT:` = DONE evidence predates a later commit touching a cited file.
- **IN_PROGRESS_LANE** — an implementation lane running now owns the next step (ios-calendar-fix, android-import-finish, ios-history-import, nutrition-data-release).
- **MISSING** — no app code, or only outside-repo prep / design. `lane` = `design-*(design-only)` means a design lane exists but **no implementation lane** is launched.
- **BLOCKED_DEVICE** — needs physical device, real account/provider or real Apple model.
- Excluded as native evidence: python_reference, package_selftest (Swift prep 12 tests, nutrition calculators), hashes.

## Totals — registry IDs (profiles bugfix/new_features/full + feedback/compatibility/nutrition subsets)

| platform | DONE | IMPL_UNVER | LANE | BLOCKED | MISSING | total |
|---|---|---|---|---|---|---|
| ios | 53 | 52 | 57 | 3 | 121 | 286 |
| android | 70 | 51 | 53 | 3 | 119 | 296 |

### bugfix profile only
| platform | DONE | IMPL_UNVER | LANE | BLOCKED | MISSING | total |
|---|---|---|---|---|---|---|
| ios | 53 | 39 | 4 | 0 | 3 | 99 |
| android | 70 | 35 | 0 | 2 | 3 | 110 |

### new_features profile
| platform | DONE | IMPL_UNVER | LANE | BLOCKED | MISSING | total |
|---|---|---|---|---|---|---|
| ios | 4 | 30 | 55 | 3 | 120 | 212 |
| android | 6 | 33 | 53 | 2 | 118 | 212 |

### full profile
| platform | DONE | IMPL_UNVER | LANE | BLOCKED | MISSING | total |
|---|---|---|---|---|---|---|
| ios | 53 | 52 | 57 | 3 | 121 | 286 |
| android | 70 | 51 | 53 | 3 | 119 | 296 |

## Temporal pickers DT/UX

| platform | DONE | IMPL_UNVER | LANE | BLOCKED | MISSING | total |
|---|---|---|---|---|---|---|
| ios | 9 | 7 | 2 | 0 | 0 | 18 |
| android | 10 | 10 | 0 | 0 | 0 | 20 |

| id | plat | status | lane | code / test (first) | note |
|---|---|---|---|---|---|
| DT01 | ios | DONE | — | ios:DoseDay/DesignSystem/Components/ConfirmedDateTimePicker.swift; DoseDayTests/ExactEditTimeResolverTests.sw… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed; only shared-suite fail = export bound (owned ios-calendar-… |
| DT02 | ios | DONE | — | ios:DoseDay/DesignSystem/Components/ConfirmedDateTimePicker.swift; DoseDayTests/ExactEditTimeResolverTests.sw… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed; only shared-suite fail = export bound (owned ios-calendar-… |
| DT03 | ios | IMPL_UNVER | — | ios:DoseDay/DesignSystem/Components/ConfirmedDateTimePicker.swift; DoseDayTests/ExactEditTimeResolverTests.sw… | prior=NOT_RUN_FULL_SCENARIO. The new native clock trace preserves an Asia/Seoul date and instant across midnight/noon and 12/24-hour preference chang… |
| DT04 | ios | DONE | — | ios:DoseDay/DesignSystem/Components/ConfirmedDateTimePicker.swift; DoseDayTests/ExactEditTimeResolverTests.sw… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed; only shared-suite fail = export bound (owned ios-calendar-… |
| DT05 | ios | DONE | — | ios:DoseDay/DesignSystem/Components/ConfirmedDateTimePicker.swift; DoseDayTests/ExactEditTimeResolverTests.sw… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed; only shared-suite fail = export bound (owned ios-calendar-… |
| DT06 | ios | DONE | — | ios:DoseDay/DesignSystem/Components/ConfirmedDateTimePicker.swift; DoseDayTests/ExactEditTimeResolverTests.sw… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed; only shared-suite fail = export bound (owned ios-calendar-… |
| DT07 | ios | LANE | ios-calendar-fix | ios:DoseDay/DesignSystem/Components/ConfirmedDateTimePicker.swift; DoseDayTests/ExactEditTimeResolverTests.sw… | export period calendar bound stale; HistoryExportFeedbackUITests.testNativeExportCalendarEnforcesBothBoundsAndAcceptsOneDay fail iPhone+iPad 4c3e594.… |
| DT08 | ios | IMPL_UNVER | — | ios:DoseDay/DesignSystem/Components/ConfirmedDateTimePicker.swift; DoseDayTests/ExactEditTimeResolverTests.sw… | prior=NOT_RUN_LIFECYCLE. AX5 and some rotation/iPad evidence exists; popup-open app-lock/background/focus restoration and complete RTL matrix are not… |
| UX01 | ios | DONE | — | ios:DoseDay/DesignSystem/Components/ConfirmedDateTimePicker.swift; DoseDayTests/ExactEditTimeResolverTests.sw… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed; only shared-suite fail = export bound (owned ios-calendar-… |
| UX02 | ios | DONE | — | ios:DoseDay/DesignSystem/Components/ConfirmedDateTimePicker.swift; DoseDayTests/ExactEditTimeResolverTests.sw… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed; only shared-suite fail = export bound (owned ios-calendar-… |
| UX03 | ios | DONE | — | ios:DoseDay/DesignSystem/Components/ConfirmedDateTimePicker.swift; DoseDayTests/ExactEditTimeResolverTests.sw… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed; only shared-suite fail = export bound (owned ios-calendar-… |
| UX04 | ios | IMPL_UNVER | — | ios:DoseDay/DesignSystem/Components/ConfirmedDateTimePicker.swift; DoseDayTests/ExactEditTimeResolverTests.sw… | prior=PARTIAL_EVIDENCE. Actual midnight 00:00 and noon 12:00 storage, AM/PM distinction, native wheel and summary agreement passed in en-JP with Asia… |
| UX05 | ios | IMPL_UNVER | — | ios:DoseDay/DesignSystem/Components/ConfirmedDateTimePicker.swift; DoseDayTests/ExactEditTimeResolverTests.sw… | prior=PARTIAL_EVIDENCE. Actual global 12h/24h preference changes, ordinary relaunch and unchanged record UUID/instant passed. Dose-only edit preserve… |
| UX06 | ios | DONE | — | ios:DoseDay/DesignSystem/Components/ConfirmedDateTimePicker.swift; DoseDayTests/ExactEditTimeResolverTests.sw… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed; only shared-suite fail = export bound (owned ios-calendar-… |
| UX07 | ios | IMPL_UNVER | — | ios:DoseDay/DesignSystem/Components/ConfirmedDateTimePicker.swift; DoseDayTests/ExactEditTimeResolverTests.sw… | prior=PARTIAL_EVIDENCE. Cancel and Done-without-record-save are covered. The new actual-preference trace confirms native clock cancellation and recor… |
| UX08 | ios | IMPL_UNVER | — | ios:DoseDay/DesignSystem/Components/ConfirmedDateTimePicker.swift; DoseDayTests/ExactEditTimeResolverTests.sw… | prior=PARTIAL_EVIDENCE. Date parser/localized decimal tests and selected UI paths exist. Full cursor-middle deletion/paste/IME composition across nat… |
| UX09 | ios | LANE | ios-calendar-fix | ios:DoseDay/DesignSystem/Components/ConfirmedDateTimePicker.swift; DoseDayTests/ExactEditTimeResolverTests.sw… | export period calendar bound stale; HistoryExportFeedbackUITests.testNativeExportCalendarEnforcesBothBoundsAndAcceptsOneDay fail iPhone+iPad 4c3e594.… |
| UX10 | ios | IMPL_UNVER | — | ios:DoseDay/DesignSystem/Components/ConfirmedDateTimePicker.swift; DoseDayTests/ExactEditTimeResolverTests.sw… | prior=NOT_RUN_LIFECYCLE. AX5 and some rotation/iPad evidence exists; popup-open app-lock/background/focus restoration and complete RTL matrix are not… |
| DT01 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/designsystem/components/TemporalInputField.kt#TemporalInp… | 5/5 mapped tests present+pass in 79bb210-era results. |
| DT02 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/designsystem/components/TemporalInputField.kt#TemporalInp… | 5/5 mapped tests present+pass in 79bb210-era results. |
| DT03 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/designsystem/components/TemporalInputField.kt#TemporalInp… | 33/33 mapped tests present+pass in 79bb210-era results. |
| DT04 | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/designsystem/components/TemporalInputField.kt#TemporalInp… | remaining-map: EXISTING_IMPLEMENTATION_WITH_SPECIFIC_TEST_GAP; specific scenario variant untested. |
| DT05 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/designsystem/components/TemporalInputField.kt#TemporalInp… | 33/33 mapped tests present+pass in 79bb210-era results. |
| DT06 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/designsystem/components/TemporalInputField.kt#TemporalInp… | 33/33 mapped tests present+pass in 79bb210-era results. |
| DT07 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/designsystem/components/TemporalInputField.kt#TemporalInp… | 38/38 mapped tests present+pass in 79bb210-era results. |
| DT08 | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/designsystem/components/TemporalInputField.kt#TemporalInp… | remaining-map: EXISTING_IMPLEMENTATION_WITH_SPECIFIC_TEST_GAP; specific scenario variant untested. |
| DT09 | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/designsystem/components/TemporalInputField.kt#TemporalInp… | remaining-map: EXISTING_IMPLEMENTATION_WITH_SPECIFIC_TEST_GAP; specific scenario variant untested. |
| DT10 | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/designsystem/components/TemporalInputField.kt#TemporalInp… | remaining-map: EXISTING_IMPLEMENTATION_WITH_SPECIFIC_TEST_GAP; specific scenario variant untested. |
| UX01 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/designsystem/components/TemporalInputField.kt#TemporalInp… | 5/5 mapped tests present+pass in 79bb210-era results. |
| UX02 | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/designsystem/components/TemporalInputField.kt#TemporalInp… | remaining-map: EXISTING_IMPLEMENTATION_WITH_SPECIFIC_TEST_GAP; specific scenario variant untested. |
| UX03 | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/designsystem/components/TemporalInputField.kt#TemporalInp… | remaining-map: EXISTING_IMPLEMENTATION_WITH_SPECIFIC_TEST_GAP; specific scenario variant untested. |
| UX04 | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/designsystem/components/TemporalInputField.kt#TemporalInp… | remaining-map: EXISTING_IMPLEMENTATION_WITH_SPECIFIC_TEST_GAP; specific scenario variant untested. |
| UX05 | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/designsystem/components/TemporalInputField.kt#TemporalInp… | remaining-map: EXISTING_IMPLEMENTATION_WITH_SPECIFIC_TEST_GAP; specific scenario variant untested. |
| UX06 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/designsystem/components/TemporalInputField.kt#TemporalInp… | 33/33 mapped tests present+pass in 79bb210-era results. |
| UX07 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/designsystem/components/TemporalInputField.kt#TemporalInp… | 5/5 mapped tests present+pass in 79bb210-era results. |
| UX08 | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/designsystem/components/TemporalInputField.kt#TemporalInp… | remaining-map: EXISTING_IMPLEMENTATION_WITH_SPECIFIC_TEST_GAP; specific scenario variant untested. |
| UX09 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/designsystem/components/TemporalInputField.kt#TemporalInp… | 38/38 mapped tests present+pass in 79bb210-era results. |
| UX10 | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/designsystem/components/TemporalInputField.kt#TemporalInp… | remaining-map: EXISTING_IMPLEMENTATION_WITH_SPECIFIC_TEST_GAP; specific scenario variant untested. |

## Bugfix locale journeys BLOC

| platform | DONE | IMPL_UNVER | LANE | BLOCKED | MISSING | total |
|---|---|---|---|---|---|---|
| ios | 17 | 0 | 0 | 0 | 0 | 17 |
| android | 17 | 0 | 0 | 0 | 0 | 17 |

| id | plat | status | lane | code / test (first) | note |
|---|---|---|---|---|---|
| BLOC-ko | ios | DONE | — | ios:DoseDay/Resources/Localizable.xcstrings; DoseDayUITests/BugfixLocaleJourneyUITests.swift [CI4c3e594 9pass… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Final18 at 4ec0b47 passed DoseDayUITests/BugfixLocaleJourn… |
| BLOC-en | ios | DONE | — | ios:DoseDay/Resources/Localizable.xcstrings; DoseDayUITests/BugfixLocaleJourneyUITests.swift [CI4c3e594 9pass… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Final18 at 4ec0b47 passed DoseDayUITests/BugfixLocaleJourn… |
| BLOC-ja | ios | DONE | — | ios:DoseDay/Resources/Localizable.xcstrings; DoseDayUITests/BugfixLocaleJourneyUITests.swift [CI4c3e594 9pass… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Final18 at 4ec0b47 passed DoseDayUITests/BugfixLocaleJourn… |
| BLOC-de | ios | DONE | — | ios:DoseDay/Resources/Localizable.xcstrings; DoseDayUITests/BugfixLocaleJourneyUITests.swift [CI4c3e594 9pass… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Final18 at 4ec0b47 failed this locale. A separate focused … |
| BLOC-fr | ios | DONE | — | ios:DoseDay/Resources/Localizable.xcstrings; DoseDayUITests/BugfixLocaleJourneyUITests.swift [CI4c3e594 9pass… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Final18 at 4ec0b47 passed DoseDayUITests/BugfixLocaleJourn… |
| BLOC-es | ios | DONE | — | ios:DoseDay/Resources/Localizable.xcstrings; DoseDayUITests/BugfixLocaleJourneyUITests.swift [CI4c3e594 9pass… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Final18 at 4ec0b47 passed DoseDayUITests/BugfixLocaleJourn… |
| BLOC-it | ios | DONE | — | ios:DoseDay/Resources/Localizable.xcstrings; DoseDayUITests/BugfixLocaleJourneyUITests.swift [CI4c3e594 9pass… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Final18 at 4ec0b47 passed DoseDayUITests/BugfixLocaleJourn… |
| BLOC-nl | ios | DONE | — | ios:DoseDay/Resources/Localizable.xcstrings; DoseDayUITests/BugfixLocaleJourneyUITests.swift [CI4c3e594 9pass… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Final18 at 4ec0b47 passed DoseDayUITests/BugfixLocaleJourn… |
| BLOC-pt-PT | ios | DONE | — | ios:DoseDay/Resources/Localizable.xcstrings; DoseDayUITests/BugfixLocaleJourneyUITests.swift [CI4c3e594 9pass… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Final18 at 4ec0b47 passed DoseDayUITests/BugfixLocaleJourn… |
| BLOC-pl | ios | DONE | — | ios:DoseDay/Resources/Localizable.xcstrings; DoseDayUITests/BugfixLocaleJourneyUITests.swift [CI4c3e594 9pass… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Final18 at 4ec0b47 failed this locale. A separate focused … |
| BLOC-sv | ios | DONE | — | ios:DoseDay/Resources/Localizable.xcstrings; DoseDayUITests/BugfixLocaleJourneyUITests.swift [CI4c3e594 9pass… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Final18 at 4ec0b47 passed DoseDayUITests/BugfixLocaleJourn… |
| BLOC-hi | ios | DONE | — | ios:DoseDay/Resources/Localizable.xcstrings; DoseDayUITests/BugfixLocaleJourneyUITests.swift [CI4c3e594 9pass… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Final18 at 4ec0b47 passed DoseDayUITests/BugfixLocaleJourn… |
| BLOC-pt-BR | ios | DONE | — | ios:DoseDay/Resources/Localizable.xcstrings; DoseDayUITests/BugfixLocaleJourneyUITests.swift [CI4c3e594 9pass… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Final18 at 4ec0b47 passed DoseDayUITests/BugfixLocaleJourn… |
| BLOC-ar | ios | DONE | — | ios:DoseDay/Resources/Localizable.xcstrings; DoseDayUITests/BugfixLocaleJourneyUITests.swift [CI4c3e594 9pass… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Final18 at 4ec0b47 passed DoseDayUITests/BugfixLocaleJourn… |
| BLOC-zh-Hans | ios | DONE | — | ios:DoseDay/Resources/Localizable.xcstrings; DoseDayUITests/BugfixLocaleJourneyUITests.swift [CI4c3e594 9pass… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Final18 at 4ec0b47 passed DoseDayUITests/BugfixLocaleJourn… |
| BLOC-zh-Hant | ios | DONE | — | ios:DoseDay/Resources/Localizable.xcstrings; DoseDayUITests/BugfixLocaleJourneyUITests.swift [CI4c3e594 9pass… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Final18 at 4ec0b47 passed DoseDayUITests/BugfixLocaleJourn… |
| BLOC-tr | ios | DONE | — | ios:DoseDay/Resources/Localizable.xcstrings; DoseDayUITests/BugfixLocaleJourneyUITests.swift [CI4c3e594 9pass… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Final18 at 4ec0b47 passed DoseDayUITests/BugfixLocaleJourn… |
| BLOC-ko | and | DONE | — | android:app/src/androidTest/java/com/wonyoungchoi/doseweek/features/navigation/BugfixLocaleJourneyTest.kt#cla… | 1/1 mapped tests present+pass in 79bb210-era results. |
| BLOC-en | and | DONE | — | android:app/src/androidTest/java/com/wonyoungchoi/doseweek/features/navigation/BugfixLocaleJourneyTest.kt#cla… | 2/2 mapped tests present+pass in 79bb210-era results. |
| BLOC-ja | and | DONE | — | android:app/src/androidTest/java/com/wonyoungchoi/doseweek/features/navigation/BugfixLocaleJourneyTest.kt#cla… | 1/1 mapped tests present+pass in 79bb210-era results. |
| BLOC-de | and | DONE | — | android:app/src/androidTest/java/com/wonyoungchoi/doseweek/features/navigation/BugfixLocaleJourneyTest.kt#cla… | 1/1 mapped tests present+pass in 79bb210-era results. |
| BLOC-fr | and | DONE | — | android:app/src/androidTest/java/com/wonyoungchoi/doseweek/features/navigation/BugfixLocaleJourneyTest.kt#cla… | 1/1 mapped tests present+pass in 79bb210-era results. |
| BLOC-es | and | DONE | — | android:app/src/androidTest/java/com/wonyoungchoi/doseweek/features/navigation/BugfixLocaleJourneyTest.kt#cla… | 1/1 mapped tests present+pass in 79bb210-era results. |
| BLOC-it | and | DONE | — | android:app/src/androidTest/java/com/wonyoungchoi/doseweek/features/navigation/BugfixLocaleJourneyTest.kt#cla… | 1/1 mapped tests present+pass in 79bb210-era results. |
| BLOC-nl | and | DONE | — | android:app/src/androidTest/java/com/wonyoungchoi/doseweek/features/navigation/BugfixLocaleJourneyTest.kt#cla… | 1/1 mapped tests present+pass in 79bb210-era results. |
| BLOC-pt-PT | and | DONE | — | android:app/src/androidTest/java/com/wonyoungchoi/doseweek/features/navigation/BugfixLocaleJourneyTest.kt#cla… | 1/1 mapped tests present+pass in 79bb210-era results. |
| BLOC-pl | and | DONE | — | android:app/src/androidTest/java/com/wonyoungchoi/doseweek/features/navigation/BugfixLocaleJourneyTest.kt#cla… | 1/1 mapped tests present+pass in 79bb210-era results. |
| BLOC-sv | and | DONE | — | android:app/src/androidTest/java/com/wonyoungchoi/doseweek/features/navigation/BugfixLocaleJourneyTest.kt#cla… | 1/1 mapped tests present+pass in 79bb210-era results. |
| BLOC-hi | and | DONE | — | android:app/src/androidTest/java/com/wonyoungchoi/doseweek/features/navigation/BugfixLocaleJourneyTest.kt#cla… | 1/1 mapped tests present+pass in 79bb210-era results. |
| BLOC-pt-BR | and | DONE | — | android:app/src/androidTest/java/com/wonyoungchoi/doseweek/features/navigation/BugfixLocaleJourneyTest.kt#cla… | 1/1 mapped tests present+pass in 79bb210-era results. |
| BLOC-ar | and | DONE | — | android:app/src/androidTest/java/com/wonyoungchoi/doseweek/features/navigation/BugfixLocaleJourneyTest.kt#cla… | 2/2 mapped tests present+pass in 79bb210-era results. |
| BLOC-zh-Hans | and | DONE | — | android:app/src/androidTest/java/com/wonyoungchoi/doseweek/features/navigation/BugfixLocaleJourneyTest.kt#cla… | 1/1 mapped tests present+pass in 79bb210-era results. |
| BLOC-zh-Hant | and | DONE | — | android:app/src/androidTest/java/com/wonyoungchoi/doseweek/features/navigation/BugfixLocaleJourneyTest.kt#cla… | 1/1 mapped tests present+pass in 79bb210-era results. |
| BLOC-tr | and | DONE | — | android:app/src/androidTest/java/com/wonyoungchoi/doseweek/features/navigation/BugfixLocaleJourneyTest.kt#cla… | 1/1 mapped tests present+pass in 79bb210-era results. |

## Health recency HC/HK

| platform | DONE | IMPL_UNVER | LANE | BLOCKED | MISSING | total |
|---|---|---|---|---|---|---|
| ios | 3 | 2 | 0 | 0 | 0 | 5 |
| android | 10 | 1 | 0 | 2 | 0 | 13 |

| id | plat | status | lane | code / test (first) | note |
|---|---|---|---|---|---|
| HK01 | ios | DONE | — | ios:DoseDay/Data/Services/HealthKitService.swift; DoseDayTests/AppleHealthImportTests.swift [64 tests; unit s… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. The always-visible fixed Apple Health import-limit notice … |
| HK02 | ios | IMPL_UNVER | — | ios:DoseDay/Data/Services/HealthKitService.swift; DoseDayTests/AppleHealthImportTests.swift [64 tests; unit s… | prior=PARTIAL_EVIDENCE. UUID replay, tombstones, failed actor save and failed Keychain checkpoint have fake/real local persistence tests. HK04 now ad… |
| HK03 | ios | IMPL_UNVER | — | ios:DoseDay/Data/Services/HealthKitService.swift; DoseDayTests/AppleHealthImportTests.swift [64 tests; unit s… | prior=PARTIAL_EVIDENCE. Passive failure 1 RED/3 GREEN accepted; empty/limited/cancel/type errors have existing unit definitions. A successful permiss… |
| HK04 | ios | DONE | — | ios:DoseDay/Data/Services/HealthKitService.swift; DoseDayTests/AppleHealthImportTests.swift [64 tests; unit s… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Actual HealthKit provider-to-DB-to-latest-screen and ordin… |
| HEALTH_READ | ios | DONE | — | ios:DoseDay/Data/Services/HealthKitService.swift; DoseDayTests/AppleHealthImportTests.swift [64 tests; unit s… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Actual HealthKit provider-to-DB-to-latest-screen and ordin… |
| HC01 | and | BLOCKED | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/health/HealthConnectImporter.kt#HealthConnectImporter | owner physical Google/Health Connect omission report; no device/ADB; synthetic API36 provider PASS separate (HC12). |
| HC02 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/health/HealthConnectImporter.kt#HealthConnectImporte… | 57/57 mapped tests present+pass in 79bb210-era results. |
| HC03 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/health/HealthConnectImporter.kt#HealthConnectImporte… | 57/57 mapped tests present+pass in 79bb210-era results. |
| HC04 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/health/HealthConnectImporter.kt#HealthConnectImporte… | 57/57 mapped tests present+pass in 79bb210-era results. |
| HC05 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/health/HealthConnectImporter.kt#HealthConnectImporte… | 57/57 mapped tests present+pass in 79bb210-era results. |
| HC06 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/health/HealthConnectSyncPlanner.kt#fun plan(; Health… | 53/56 mapped tests present+pass in 79bb210-era results. 3 mapped test names not in current results. |
| HC07 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/health/HealthConnectImporter.kt#HealthConnectImporte… | 57/57 mapped tests present+pass in 79bb210-era results. |
| HC08 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/health/HealthConnectImporter.kt#HealthConnectImporte… | 57/57 mapped tests present+pass in 79bb210-era results. |
| HC09 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/DoseWeekRepository.kt#DoseWeekRepository; ImportedMe… | 20/20 mapped tests present+pass in 79bb210-era results. Stored-native limit proof ImportedMeasurementsViewModelTest (1000 newer height rows, period/m… |
| HC10 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/health/HealthConnectImporter.kt#HealthConnectImporte… | 58/58 mapped tests present+pass in 79bb210-era results. |
| HC11 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/health/HealthConnectImporter.kt#HealthConnectImporte… | 58/58 mapped tests present+pass in 79bb210-era results. |
| HC12 | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/health/HealthConnectImporter.kt#HealthConnectImporte… | staged mutation initial/add/update/delete + real-provider handshake PASS API24+36 in 79bb210-era matrix. Provider→ordinary DB→screen trace PASS_SCOPE… |
| HEALTH_READ | and | BLOCKED | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/health/HealthConnectImporter.kt#HealthConnectImporte… | owner physical Google/Health Connect omission report; no device/ADB; synthetic API36 provider PASS separate (HC12). |

## Injection-site perspective SM

| platform | DONE | IMPL_UNVER | LANE | BLOCKED | MISSING | total |
|---|---|---|---|---|---|---|
| ios | 7 | 3 | 0 | 0 | 0 | 10 |
| android | 9 | 1 | 0 | 0 | 0 | 10 |

| id | plat | status | lane | code / test (first) | note |
|---|---|---|---|---|---|
| SM01 | ios | DONE | — | ios:DoseDay/DesignSystem/BodyMapDisplayPreferences.swift; DoseDayTests/AuditBodyMapTests.swift [6 tests; unit… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Six geometry/default/provenance tests and both normal/AX5 … |
| SM02 | ios | DONE | — | ios:DoseDay/DesignSystem/BodyMapDisplayPreferences.swift; DoseDayTests/AuditBodyMapTests.swift [6 tests; unit… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Six geometry/default/provenance tests and both normal/AX5 … |
| SM03 | ios | DONE | — | ios:DoseDay/DesignSystem/BodyMapDisplayPreferences.swift; DoseDayTests/AuditBodyMapTests.swift [6 tests; unit… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Six geometry/default/provenance tests and both normal/AX5 … |
| SM04 | ios | IMPL_UNVER | — | ios:DoseDay/DesignSystem/BodyMapDisplayPreferences.swift; DoseDayTests/AuditBodyMapTests.swift [6 tests; unit… | prior=PARTIAL_EVIDENCE. Mode/list/rotation and anatomical identity are covered. Dedicated final saved-row→History/CSV/PDF/backup round trip while swi… |
| SM05 | ios | IMPL_UNVER | — | ios:DoseDay/DesignSystem/BodyMapDisplayPreferences.swift; DoseDayTests/AuditBodyMapTests.swift [6 tests; unit… | prior=PARTIAL_EVIDENCE. Mode/list/rotation and anatomical identity are covered. Dedicated final saved-row→History/CSV/PDF/backup round trip while swi… |
| SM06 | ios | DONE | — | ios:DoseDay/DesignSystem/BodyMapDisplayPreferences.swift; DoseDayTests/AuditBodyMapTests.swift [6 tests; unit… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Six geometry/default/provenance tests and both normal/AX5 … |
| SM07 | ios | DONE | — | ios:DoseDay/DesignSystem/BodyMapDisplayPreferences.swift; DoseDayTests/AuditBodyMapTests.swift [6 tests; unit… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Six geometry/default/provenance tests and both normal/AX5 … |
| SM08 | ios | DONE | — | ios:DoseDay/DesignSystem/BodyMapDisplayPreferences.swift; DoseDayTests/AuditBodyMapTests.swift [6 tests; unit… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Six geometry/default/provenance tests and both normal/AX5 … |
| SM09 | ios | DONE | — | ios:DoseDay/DesignSystem/BodyMapDisplayPreferences.swift; DoseDayTests/AuditBodyMapTests.swift [6 tests; unit… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Six geometry/default/provenance tests and both normal/AX5 … |
| SM10 | ios | IMPL_UNVER | — | ios:DoseDay/DesignSystem/BodyMapDisplayPreferences.swift; DoseDayTests/AuditBodyMapTests.swift [6 tests; unit… | prior=PARTIAL_EVIDENCE. Mode/list/rotation and anatomical identity are covered. Dedicated final saved-row→History/CSV/PDF/backup round trip while swi… |
| SM01 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/record/BodyMapView.kt#BodyMapView; BodyMapTouchT… | 34/34 mapped tests present+pass in 79bb210-era results. |
| SM02 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/record/BodyMapView.kt#BodyMapView; BodyMapTouchT… | 34/34 mapped tests present+pass in 79bb210-era results. |
| SM03 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/record/BodyMapView.kt#BodyMapView; BodyMapTouchT… | 34/34 mapped tests present+pass in 79bb210-era results. |
| SM04 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/record/BodyMapView.kt#BodyMapView; BodyMapTouchT… | 34/34 mapped tests present+pass in 79bb210-era results. |
| SM05 | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/record/BodyMapView.kt#BodyMapView; AuditExportVi… | remaining-map: EXISTING_IMPLEMENTATION_WITH_SPECIFIC_TEST_GAP; specific scenario variant untested. |
| SM06 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/record/BodyMapView.kt#BodyMapView; BodyMapTouchT… | 34/34 mapped tests present+pass in 79bb210-era results. |
| SM07 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/record/BodyMapView.kt#BodyMapView; BodyMapTouchT… | 34/34 mapped tests present+pass in 79bb210-era results. |
| SM08 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/record/BodyMapView.kt#BodyMapView; BodyMapTouchT… | 34/34 mapped tests present+pass in 79bb210-era results. |
| SM09 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/record/BodyMapView.kt#BodyMapView; BodyMapTouchT… | 34/34 mapped tests present+pass in 79bb210-era results. |
| SM10 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/record/BodyMapView.kt#BodyMapView; BodyMapTouchT… | 34/34 mapped tests present+pass in 79bb210-era results. |

## Same-record edit ED

| platform | DONE | IMPL_UNVER | LANE | BLOCKED | MISSING | total |
|---|---|---|---|---|---|---|
| ios | 7 | 5 | 0 | 0 | 0 | 12 |
| android | 6 | 6 | 0 | 0 | 0 | 12 |

| id | plat | status | lane | code / test (first) | note |
|---|---|---|---|---|---|
| ED01 | ios | DONE | — | ios:DoseDay/Features/History/HistoryView.swift; DoseDayTests/AuditHistoryCorrectionTests.swift [22 tests; uni… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Same-ID actor/visible edit/correction notice/backup and sc… |
| ED02 | ios | IMPL_UNVER | — | ios:DoseDay/Features/History/HistoryView.swift; DoseDayTests/AuditHistoryCorrectionTests.swift [22 tests; uni… | prior=PARTIAL_EVIDENCE. Selected-ID and neighbor preservation unit tests exist; an accepted UI case explicitly choosing the second of multiple same-d… |
| ED03 | ios | DONE | — | ios:DoseDay/Features/History/HistoryView.swift; DoseDayTests/AuditHistoryCorrectionTests.swift [22 tests; uni… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Same-ID actor/visible edit/correction notice/backup and sc… |
| ED04 | ios | DONE | — | ios:DoseDay/Features/History/HistoryView.swift; DoseDayTests/AuditHistoryCorrectionTests.swift [22 tests; uni… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Same-ID actor/visible edit/correction notice/backup and sc… |
| ED05 | ios | IMPL_UNVER | — | ios:DoseDay/Features/History/HistoryView.swift; DoseDayTests/AuditHistoryCorrectionTests.swift [22 tests; uni… | prior=PARTIAL_EVIDENCE. Administration/symptom stale, ABA, double-submit and post-restore tokens have tests; concurrent native sheets for every edita… |
| ED06 | ios | DONE | — | ios:DoseDay/Features/History/HistoryView.swift; DoseDayTests/AuditHistoryCorrectionTests.swift [22 tests; uni… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Same-ID actor/visible edit/correction notice/backup and sc… |
| ED07 | ios | DONE | — | ios:DoseDay/Features/History/HistoryView.swift; DoseDayTests/AuditHistoryCorrectionTests.swift [22 tests; uni… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Same-ID actor/visible edit/correction notice/backup and sc… |
| ED08 | ios | DONE | — | ios:DoseDay/Features/History/HistoryView.swift; DoseDayTests/AuditHistoryCorrectionTests.swift [22 tests; uni… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Same-ID actor/visible edit/correction notice/backup and sc… |
| ED09 | ios | DONE | — | ios:DoseDay/Features/History/HistoryView.swift; DoseDayTests/AuditHistoryCorrectionTests.swift [22 tests; uni… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Same-ID actor/visible edit/correction notice/backup and sc… |
| ED10 | ios | IMPL_UNVER | — | ios:DoseDay/Features/History/HistoryView.swift; DoseDayTests/AuditHistoryCorrectionTests.swift [22 tests; uni… | prior=NOT_RUN_FULL_SCENARIO. Existing date-filter and imported-hide paths are present. No accepted complete hide-all/empty-date/reset-to-all journey … |
| ED11 | ios | IMPL_UNVER | — | ios:DoseDay/Features/History/HistoryView.swift; DoseDayTests/AuditHistoryCorrectionTests.swift [22 tests; uni… | owner meaning PENDING (RECORD-DRAFT-PROCESS-EXIT). in-window retry/atomic tests exist. failedEditPreservesDraftForRetry, inFlightEditCannotDuplicate,… |
| ED12 | ios | IMPL_UNVER | — | ios:DoseDay/Features/History/HistoryView.swift; DoseDayTests/AuditHistoryCorrectionTests.swift [22 tests; uni… | prior=PARTIAL_EVIDENCE. Same-ID revisions, encrypted symptom and detached-fact round trips, dense revision projection and period export code/tests ar… |
| ED01 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/history/HistoryScreen.kt#HistoryScreen; EditAdmi… | 19/19 mapped tests present+pass in 79bb210-era results. |
| ED02 | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/history/HistoryScreen.kt#HistoryScreen; Administ… | remaining-map: EXISTING_IMPLEMENTATION_WITH_SPECIFIC_TEST_GAP; specific scenario variant untested. |
| ED03 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/DoseWeekRepository.kt#DoseWeekRepository; DoseWeekRe… | 28/28 mapped tests present+pass in 79bb210-era results. |
| ED04 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/history/HistoryScreen.kt#HistoryScreen; AuditAdm… | 10/10 mapped tests present+pass in 79bb210-era results. |
| ED05 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/PersistenceModels.kt#data class AdministrationEditSn… | 21/21 mapped tests present+pass in 79bb210-era results. |
| ED06 | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/DoseWeekRepository.kt#DoseWeekRepository; DoseWeekRe… | prior=PARTIAL/; mapped pass 32/32. |
| ED07 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/DoseWeekRepository.kt#DoseWeekRepository; AuditCaden… | 29/29 mapped tests present+pass in 79bb210-era results. |
| ED08 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/DoseWeekRepository.kt#DoseWeekRepository; AuditCaden… | 29/29 mapped tests present+pass in 79bb210-era results. |
| ED09 | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/app/DoseWeekViewModel.kt#DoseWeekViewModel; BodyRecordCor… | remaining-map: EXISTING_IMPLEMENTATION_WITH_SPECIFIC_TEST_GAP; specific scenario variant untested. 1 mapped test names not in current results. |
| ED10 | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/history/HistoryScreen.kt#HistoryScreen; AuditAdm… | remaining-map: EXISTING_IMPLEMENTATION_WITH_SPECIFIC_TEST_GAP; specific scenario variant untested. |
| ED11 | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/app/DoseWeekViewModel.kt#DoseWeekViewModel; Administratio… | owner meaning PENDING (RECORD-DRAFT-PROCESS-EXIT); atomicity tests pass. |
| ED12 | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/DoseWeekRepository.kt#DoseWeekRepository; AuditExpor… | remaining-map: EXISTING_IMPLEMENTATION_WITH_SPECIFIC_TEST_GAP; specific scenario variant untested. |

## Past administration PR

| platform | DONE | IMPL_UNVER | LANE | BLOCKED | MISSING | total |
|---|---|---|---|---|---|---|
| ios | 7 | 5 | 0 | 0 | 0 | 12 |
| android | 12 | 0 | 0 | 0 | 0 | 12 |

| id | plat | status | lane | code / test (first) | note |
|---|---|---|---|---|---|
| PR01 | ios | DONE | — | ios:DoseDay/Features/RecordFlow/RecordFlowViewModel.swift; DoseDayTests/RecordOnlyAdministrationTests.swift [… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. RecordOnlyAdministrationTests and normal/AX5 RecordOnlyUIT… |
| PR02 | ios | DONE | — | ios:DoseDay/Features/RecordFlow/RecordFlowViewModel.swift; DoseDayTests/RecordOnlyAdministrationTests.swift [… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. RecordOnlyAdministrationTests and normal/AX5 RecordOnlyUIT… |
| PR03 | ios | DONE | — | ios:DoseDay/Features/RecordFlow/RecordFlowViewModel.swift; DoseDayTests/RecordOnlyAdministrationTests.swift [… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. RecordOnlyAdministrationTests and normal/AX5 RecordOnlyUIT… |
| PR04 | ios | IMPL_UNVER | — | ios:DoseDay/Features/RecordFlow/RecordFlowViewModel.swift; DoseDayTests/RecordOnlyAdministrationTests.swift [… | prior=PARTIAL_EVIDENCE. Production uses actual administeredAt ordering and plan-scoped schedule rules. Source and unit tests cover historical identit… |
| PR05 | ios | IMPL_UNVER | — | ios:DoseDay/Features/RecordFlow/RecordFlowViewModel.swift; DoseDayTests/RecordOnlyAdministrationTests.swift [… | prior=PARTIAL_EVIDENCE. Production uses actual administeredAt ordering and plan-scoped schedule rules. Source and unit tests cover historical identit… |
| PR06 | ios | IMPL_UNVER | — | ios:DoseDay/Features/RecordFlow/RecordFlowViewModel.swift; DoseDayTests/RecordOnlyAdministrationTests.swift [… | prior=PARTIAL_EVIDENCE. Production uses actual administeredAt ordering and plan-scoped schedule rules. Source and unit tests cover historical identit… |
| PR07 | ios | IMPL_UNVER | — | ios:DoseDay/Features/RecordFlow/RecordFlowViewModel.swift; DoseDayTests/RecordOnlyAdministrationTests.swift [… | prior=PARTIAL_EVIDENCE. Production uses actual administeredAt ordering and plan-scoped schedule rules. Source and unit tests cover historical identit… |
| PR08 | ios | DONE | — | ios:DoseDay/Features/RecordFlow/RecordFlowViewModel.swift; DoseDayTests/RecordOnlyAdministrationTests.swift [… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. RecordOnlyAdministrationTests and normal/AX5 RecordOnlyUIT… |
| PR09 | ios | DONE | — | ios:DoseDay/Features/RecordFlow/RecordFlowViewModel.swift; DoseDayTests/RecordOnlyAdministrationTests.swift [… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. RecordOnlyAdministrationTests and normal/AX5 RecordOnlyUIT… |
| PR10 | ios | DONE | — | ios:DoseDay/Features/RecordFlow/RecordFlowViewModel.swift; DoseDayTests/RecordOnlyAdministrationTests.swift [… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. RecordOnlyAdministrationTests and normal/AX5 RecordOnlyUIT… |
| PR11 | ios | DONE | — | ios:DoseDay/Features/RecordFlow/RecordFlowViewModel.swift; DoseDayTests/RecordOnlyAdministrationTests.swift [… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. RecordOnlyAdministrationTests and normal/AX5 RecordOnlyUIT… |
| PR12 | ios | IMPL_UNVER | — | ios:DoseDay/Features/RecordFlow/RecordFlowViewModel.swift; DoseDayTests/RecordOnlyAdministrationTests.swift [… | prior=PARTIAL_EVIDENCE. SwiftData V5 migration and backup7 readers1–6, detached records/revisions, planless round trip and older snapshot tests passe… |
| PR01 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/app/DoseWeekViewModel.kt#DoseWeekViewModel; HistoricalAdm… | 27/27 mapped tests present+pass in 79bb210-era results. |
| PR02 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/app/DoseWeekViewModel.kt#DoseWeekViewModel; HistoricalAdm… | 27/27 mapped tests present+pass in 79bb210-era results. |
| PR03 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/app/DoseWeekViewModel.kt#DoseWeekViewModel; HistoricalAdm… | 27/27 mapped tests present+pass in 79bb210-era results. |
| PR04 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/app/DoseWeekViewModel.kt#DoseWeekViewModel; HistoricalAdm… | 27/27 mapped tests present+pass in 79bb210-era results. |
| PR05 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/DoseWeekRepository.kt#DoseWeekRepository; Historical… | 19/19 mapped tests present+pass in 79bb210-era results. |
| PR06 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/DoseWeekRepository.kt#DoseWeekRepository; Historical… | 19/19 mapped tests present+pass in 79bb210-era results. |
| PR07 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/DoseWeekRepository.kt#DoseWeekRepository; Historical… | 19/19 mapped tests present+pass in 79bb210-era results. |
| PR08 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/app/DoseWeekViewModel.kt#DoseWeekViewModel; HistoricalAdm… | 27/27 mapped tests present+pass in 79bb210-era results. |
| PR09 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/app/DoseWeekViewModel.kt#DoseWeekViewModel; HistoricalAdm… | 27/27 mapped tests present+pass in 79bb210-era results. |
| PR10 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/DoseWeekRepository.kt#DoseWeekRepository; FutureSkip… | 20/20 mapped tests present+pass in 79bb210-era results. Scope: attach only to explicitly requested SCHEDULED/DUE/NEEDS_REVIEW slot with no record (Oc… |
| PR11 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/DoseWeekRepository.kt#DoseWeekRepository; Historical… | 10/10 mapped tests present+pass in 79bb210-era results. |
| PR12 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/DoseWeekDatabase.kt#DoseWeekDatabase; DoseWeekViewMo… | 25/25 mapped tests present+pass in 79bb210-era results. Scope: 101 admin + 101 skipped + 101 body rows past legacy 100-row boundary, V10/V11 migratio… |

## Discoverability VIS

| platform | DONE | IMPL_UNVER | LANE | BLOCKED | MISSING | total |
|---|---|---|---|---|---|---|
| ios | 3 | 5 | 0 | 0 | 0 | 8 |
| android | 4 | 4 | 0 | 0 | 0 | 8 |

| id | plat | status | lane | code / test (first) | note |
|---|---|---|---|---|---|
| VIS01 | ios | DONE | — | ios:DoseDay/Features/Settings/RecordHelpView.swift; DoseDayUITests/RecordHelpUITests.swift [CI4c3e594 4pass/0… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Visible Edit/past add and actual bundled help are exercise… |
| VIS02 | ios | DONE | — | ios:DoseDay/Features/Settings/RecordHelpView.swift; DoseDayUITests/RecordHelpUITests.swift [CI4c3e594 4pass/0… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Visible Edit/past add and actual bundled help are exercise… |
| VIS03 | ios | IMPL_UNVER | — | ios:DoseDay/Features/Settings/RecordHelpView.swift; DoseDayUITests/RecordHelpUITests.swift [CI4c3e594 4pass/0… | prior=NOT_RUN_FULL_SCENARIO. Separate known empty/limited/error states and visible past-add exist; full empty-vs-filter-hidden-vs-permission journey … |
| VIS04 | ios | DONE | — | ios:DoseDay/Features/Settings/RecordHelpView.swift; DoseDayUITests/RecordHelpUITests.swift [CI4c3e594 4pass/0… | focused native PASS + mapped suites pass in CI 4c3e594 iPhone/iPad; AX5 leg not completed. Visible Edit/past add and actual bundled help are exercise… |
| VIS05 | ios | IMPL_UNVER | — | ios:DoseDay/Features/Settings/RecordHelpView.swift; DoseDayUITests/RecordHelpUITests.swift [CI4c3e594 4pass/0… | prior=NOT_RUN_REQUIRED_MATRIX. Existing help KO/AR and body map EN/AR normal/AX5 evidence remains. The 15 passed final18 locale journeys and separate… |
| VIS06 | ios | IMPL_UNVER | — | ios:DoseDay/Features/Settings/RecordHelpView.swift; DoseDayUITests/RecordHelpUITests.swift [CI4c3e594 4pass/0… | legal stage1 FAQ live f6bd054; final app↔legal alignment not run; no lane owns legal. No active JSON/file import action is claimed in current iOS gui… |
| VIS07 | ios | IMPL_UNVER | — | ios:DoseDay/Features/Settings/RecordHelpView.swift; DoseDayUITests/RecordHelpUITests.swift [CI4c3e594 4pass/0… | automated visible-control journeys only; human first-use task not recorded. |
| VIS08 | ios | IMPL_UNVER | — | ios:DoseDay/Features/Settings/RecordHelpView.swift; DoseDayUITests/RecordHelpUITests.swift [CI4c3e594 4pass/0… | legal stage1 FAQ live f6bd054; final app↔legal alignment not run; no lane owns legal. In-app seventeen-locale help and corrected canonical candidate … |
| VIS01 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/history/HistoryScreen.kt#HistoryScreen; RecordHe… | 37/37 mapped tests present+pass in 79bb210-era results. |
| VIS02 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/history/HistoryScreen.kt#HistoryScreen; RecordHe… | 37/37 mapped tests present+pass in 79bb210-era results. |
| VIS03 | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/history/HistoryScreen.kt#HistoryScreen; AuditAdm… | remaining-map: EXISTING_IMPLEMENTATION_WITH_SPECIFIC_TEST_GAP; specific scenario variant untested. |
| VIS04 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/help/RecordHelpSheet.kt#RecordHelpSheet; RecordH… | 11/11 mapped tests present+pass in 79bb210-era results. |
| VIS05 | and | DONE | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/help/RecordHelpSheet.kt#RecordHelpSheet; RecordH… | 63/63 mapped tests present+pass in 79bb210-era results. Scope: automated native evidence only (17 BLOC locales, 5 locales 200% layout, KO/AR help, Ta… |
| VIS06 | and | IMPL_UNVER | — |  | legal stage1 live f6bd054; final alignment not run; unowned. |
| VIS07 | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/help/RecordHelpSheet.kt#RecordHelpSheet; FreshIn… | automated task evidence only; human first-use not recorded. |
| VIS08 | and | IMPL_UNVER | — |  | legal stage1 live f6bd054; final alignment not run; unowned. |

## Legal/docs LG

| platform | DONE | IMPL_UNVER | LANE | BLOCKED | MISSING | total |
|---|---|---|---|---|---|---|
| ios | 0 | 7 | 0 | 0 | 0 | 7 |
| android | 0 | 7 | 0 | 0 | 0 | 7 |

| id | plat | status | lane | code / test (first) | note |
|---|---|---|---|---|---|
| LEGAL_COPY | ios | IMPL_UNVER | — | ios:DoseDay/Resources/Localizable.xcstrings | legal stage1 FAQ live f6bd054; final app↔legal alignment not run; no lane owns legal. In-app seventeen-locale help and corrected canonical candidate … |
| LG01 | ios | IMPL_UNVER | — | ios:DoseDay/Resources/Localizable.xcstrings | legal stage1 FAQ live f6bd054; final app↔legal alignment not run; no lane owns legal. In-app seventeen-locale help and corrected canonical candidate … |
| LG02 | ios | IMPL_UNVER | — | ios:DoseDay/Resources/Localizable.xcstrings | legal stage1 FAQ live f6bd054; final app↔legal alignment not run; no lane owns legal. In-app seventeen-locale help and corrected canonical candidate … |
| LG03 | ios | IMPL_UNVER | — | ios:DoseDay/Resources/Localizable.xcstrings | legal stage1 FAQ live f6bd054; final app↔legal alignment not run; no lane owns legal. In-app seventeen-locale help and corrected canonical candidate … |
| LG04 | ios | IMPL_UNVER | — | ios:DoseDay/Resources/Localizable.xcstrings | legal stage1 FAQ live f6bd054; final app↔legal alignment not run; no lane owns legal. In-app seventeen-locale help and corrected canonical candidate … |
| LG05 | ios | IMPL_UNVER | — | ios:DoseDay/Resources/Localizable.xcstrings | legal stage1 FAQ live f6bd054; final app↔legal alignment not run; no lane owns legal. In-app seventeen-locale help and corrected canonical candidate … |
| LG06 | ios | IMPL_UNVER | — | ios:DoseDay/Resources/Localizable.xcstrings | legal stage1 FAQ live f6bd054; final app↔legal alignment not run; no lane owns legal. In-app seventeen-locale help and corrected canonical candidate … |
| LEGAL_COPY | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/help/RecordHelpSheet.kt#RecordHelpSheet | legal stage1 live f6bd054; final alignment not run; unowned. |
| LG01 | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/help/RecordHelpSheet.kt#RecordHelpSheet; RecordH… | legal stage1 live f6bd054; final alignment not run; unowned. |
| LG02 | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/help/RecordHelpSheet.kt#RecordHelpSheet | legal stage1 live f6bd054; final alignment not run; unowned. |
| LG03 | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/help/RecordHelpSheet.kt#RecordHelpSheet | legal stage1 live f6bd054; final alignment not run; unowned. |
| LG04 | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/help/RecordHelpSheet.kt#RecordHelpSheet | legal stage1 live f6bd054; final alignment not run; unowned. |
| LG05 | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/help/RecordHelpSheet.kt#RecordHelpSheet | legal stage1 live f6bd054; final alignment not run; unowned. |
| LG06 | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/help/RecordHelpSheet.kt#RecordHelpSheet | legal stage1 live f6bd054; final alignment not run; unowned. |

## Delivery gates DL/build/regression/assets

| platform | DONE | IMPL_UNVER | LANE | BLOCKED | MISSING | total |
|---|---|---|---|---|---|---|
| ios | 0 | 5 | 2 | 0 | 3 | 10 |
| android | 2 | 6 | 0 | 0 | 3 | 11 |

| id | plat | status | lane | code / test (first) | note |
|---|---|---|---|---|---|
| APP_BUILD | ios | LANE | ios-calendar-fix | ios:scripts/run_ci.sh | full CI 4c3e594 not green: 1 fail each iPhone/iPad, AX5 interrupted; Release built only at 4f0feec. Fix now at 7e8681b; rerun full CI + Release on 7e… |
| APP_REGRESSION | ios | LANE | ios-calendar-fix | ios:scripts/run_ci.sh | full CI 4c3e594 not green: 1 fail each iPhone/iPad, AX5 interrupted; Release built only at 4f0feec. Fix now at 7e8681b; rerun full CI + Release on 7e… |
| BACKUP_FLOW | ios | IMPL_UNVER | — | ios:DoseDay/Features/RecordFlow/RecordFlowViewModel.swift; DoseDayTests/RecordOnlyAdministrationTests.swift [… | prior=PARTIAL_EVIDENCE. SwiftData V5 migration and backup7 readers1–6, detached records/revisions, planless round trip and older snapshot tests passe… |
| BUGFIX_PARITY | ios | MISSING | — | ios:scripts/run_ci.sh | no cross-platform manual parity review recorded; unowned. |
| DL01 | ios | IMPL_UNVER | — | ios:scripts/run_ci.sh | work branch codex/v11-bugfix pushed 4c3e594; draft PR7; main 990002d not integrated. |
| DL02 | ios | IMPL_UNVER | — | ios:scripts/run_ci.sh | process-only row, no mapped test (never DONE). STATE.decisions 24 recorded; only ED11 meaning pending; audit DECISION_RECORDS_PARTIAL. |
| DL03 | ios | IMPL_UNVER | — | ios:scripts/run_ci.sh | process-only row, no mapped test (never DONE). STATE.decisions 24 recorded; only ED11 meaning pending; audit DECISION_RECORDS_PARTIAL. |
| DL04 | ios | IMPL_UNVER | — | ios:scripts/run_ci.sh | work branch codex/v11-bugfix pushed 4c3e594; draft PR7; main 990002d not integrated. |
| DL05 | ios | MISSING | — | ios:scripts/run_ci.sh | no BUGFIX_BASELINE.json found; iOS main integration + 3-repo SHA/build/site reconciliation unowned. |
| DL06 | ios | MISSING | — | ios:scripts/run_ci.sh | no BUGFIX_BASELINE.json found; iOS main integration + 3-repo SHA/build/site reconciliation unowned. |
| APP_BUILD | and | DONE | — | BugfixLocaleJourneyTest#nativeDateTimeErrorPastSaveAndVisibleSameIdEdit[BLOC-ko] | main 79bb210 run_ci exit0 Release AAB; JVM698 + API24/36 581 each (app-identical candidate). Must rerun after import/nutrition merge (full profile). |
| APP_REGRESSION | and | DONE | — | BodyRecordCorrectionViewModelTest#aCorrectionKeepsAColumnTheSheetDoesNotEdit | main 79bb210 run_ci exit0 Release AAB; JVM698 + API24/36 581 each (app-identical candidate). Must rerun after import/nutrition merge (full profile). … |
| BACKUP_FLOW | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/DoseWeekRepository.kt#DoseWeekRepository; BackupFlow… | local backup tests 23 pass; real Drive account path unverified (status8 cause unknown). |
| PLAY_ASSETS | and | IMPL_UNVER | — | android:app/src/main/java/com/wonyoungchoi/doseweek/features/record/BodyMapView.kt#BodyMapView | evidence/capture-equivalence.json 85/85 raw identical (reuses prior visual review, not a new one); evidence/frame-pixel-equivalence.json identicalPix… |
| BUGFIX_PARITY | and | MISSING | — |  | no cross-platform parity review; unowned. |
| DL01 | and | IMPL_UNVER | — |  | process-only row, no mapped test (never DONE). PR3+PR4 merged normally, main 79bb210 == origin/main, no force-push; audit NOT_RUN; root BUGFIX_BASELI… |
| DL02 | and | IMPL_UNVER | — |  | process-only row, no mapped test (never DONE). STATE.decisions recorded, ED11 only pending; audit NOT_RUN (root-owned). |
| DL03 | and | IMPL_UNVER | — |  | process-only row, no mapped test (never DONE). STATE.decisions recorded, ED11 only pending; audit NOT_RUN (root-owned). |
| DL04 | and | IMPL_UNVER | — |  | process-only row, no mapped test (never DONE). PR3+PR4 merged normally, main 79bb210 == origin/main, no force-push; audit NOT_RUN; root BUGFIX_BASELI… |
| DL05 | and | MISSING | — |  | 3-repo baseline/SHA reconciliation unowned; feat/history-import unmerged. |
| DL06 | and | MISSING | — |  | 3-repo baseline/SHA reconciliation unowned; feat/history-import unmerged. |

## History import IM/IL

| platform | DONE | IMPL_UNVER | LANE | BLOCKED | MISSING | total |
|---|---|---|---|---|---|---|
| ios | 0 | 0 | 45 | 0 | 3 | 48 |
| android | 0 | 0 | 45 | 0 | 3 | 48 |

| id | plat | status | lane | code / test (first) | note |
|---|---|---|---|---|---|
| IM01 | ios | LANE | ios-history-import |  | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM02 | ios | LANE | ios-history-import |  | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM03 | ios | LANE | ios-history-import | prep(outside repo):history-import-prep/Sources/HistoryImportPreparation/TabularHistoryParser.swift; TabularHi… | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM04 | ios | LANE | ios-history-import |  | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM05 | ios | LANE | ios-history-import |  | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM06 | ios | LANE | ios-history-import |  | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM07 | ios | LANE | ios-history-import |  | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM08 | ios | LANE | ios-history-import |  | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM09 | ios | LANE | ios-history-import |  | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM10 | ios | LANE | ios-history-import |  | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM11 | ios | LANE | ios-history-import |  | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM12 | ios | LANE | ios-history-import |  | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM13 | ios | LANE | ios-history-import |  | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM14 | ios | LANE | ios-history-import |  | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM15 | ios | LANE | ios-history-import |  | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM16 | ios | LANE | ios-history-import |  | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM17 | ios | MISSING | — |  | not in ios-history-import scope (UI/actor txn/staging/migration/backup/export/locales). |
| IM18 | ios | MISSING | — |  | not in ios-history-import scope (UI/actor txn/staging/migration/backup/export/locales). |
| IM19 | ios | LANE | ios-history-import |  | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM20 | ios | LANE | ios-history-import |  | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM21 | ios | LANE | ios-history-import | prep(outside repo):history-import-prep/Sources/HistoryImportPreparation/TabularHistoryParser.swift; limitsRej… | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM22 | ios | LANE | ios-history-import |  | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM23 | ios | LANE | ios-history-import |  | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM24 | ios | LANE | ios-history-import |  | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM25 | ios | LANE | ios-history-import | prep(outside repo):history-import-prep/Sources/HistoryImportPreparation/HistoryExtractionParser.swift; extern… | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM26 | ios | LANE | ios-history-import |  | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM27 | ios | LANE | ios-history-import |  | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM28 | ios | LANE | ios-history-import |  | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM29 | ios | LANE | ios-history-import |  | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM30 | ios | MISSING | — |  | format scope owner question; see md. |
| IL-ko | ios | LANE | ios-history-import | prep(outside repo):history-import-prep/localizations.json | no iOS catalog entries yet. |
| IL-en | ios | LANE | ios-history-import | prep(outside repo):history-import-prep/localizations.json | no iOS catalog entries yet. |
| IL-ja | ios | LANE | ios-history-import | prep(outside repo):history-import-prep/localizations.json | no iOS catalog entries yet. |
| IL-de | ios | LANE | ios-history-import | prep(outside repo):history-import-prep/localizations.json | no iOS catalog entries yet. |
| IL-fr | ios | LANE | ios-history-import | prep(outside repo):history-import-prep/localizations.json | no iOS catalog entries yet. |
| IL-es | ios | LANE | ios-history-import | prep(outside repo):history-import-prep/localizations.json | no iOS catalog entries yet. |
| IL-it | ios | LANE | ios-history-import | prep(outside repo):history-import-prep/localizations.json | no iOS catalog entries yet. |
| IL-nl | ios | LANE | ios-history-import | prep(outside repo):history-import-prep/localizations.json | no iOS catalog entries yet. |
| IL-pt-PT | ios | LANE | ios-history-import | prep(outside repo):history-import-prep/localizations.json | no iOS catalog entries yet. |
| IL-pl | ios | LANE | ios-history-import | prep(outside repo):history-import-prep/localizations.json | no iOS catalog entries yet. |
| IL-sv | ios | LANE | ios-history-import | prep(outside repo):history-import-prep/localizations.json | no iOS catalog entries yet. |
| IL-hi | ios | LANE | ios-history-import | prep(outside repo):history-import-prep/localizations.json | no iOS catalog entries yet. |
| IL-pt-BR | ios | LANE | ios-history-import | prep(outside repo):history-import-prep/localizations.json | no iOS catalog entries yet. |
| IL-ar | ios | LANE | ios-history-import | prep(outside repo):history-import-prep/localizations.json | no iOS catalog entries yet. |
| IL-zh-Hans | ios | LANE | ios-history-import | prep(outside repo):history-import-prep/localizations.json | no iOS catalog entries yet. |
| IL-zh-Hant | ios | LANE | ios-history-import | prep(outside repo):history-import-prep/localizations.json | no iOS catalog entries yet. |
| IL-tr | ios | LANE | ios-history-import | prep(outside repo):history-import-prep/localizations.json | no iOS catalog entries yet. |
| IMPORT_PARITY | ios | LANE | ios-history-import |  | ios-import has UNCOMMITTED lane work (checked 12:43): DoseDaySchemaV6 + lightweight V5→V6 stage, HistoryImportEntities/Persistence, Domain/HistoryImp… |
| IM01 | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/java/com/wonyoungchoi/doseweek/features/historyimport/HistoryImportSheet.… | branch unmerged. manual multi-row + native pickers; pasted JSON only natively. |
| IM02 | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/java/com/wonyoungchoi/doseweek/app/MainActivity.kt#openHistoryImportDocum… | branch unmerged. SAF OpenDocument wired; no native picker test yet. |
| IM03 | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/java/com/wonyoungchoi/doseweek/data/historyimport/TabularHistoryParser.kt… | branch unmerged. BOM/CRLF case not named in tests. |
| IM04 | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/java/com/wonyoungchoi/doseweek/data/historyimport/HistoryImportStore.kt; … | branch unmerged. rename/same-bytes reselect journey not run. |
| IM05 | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/java/com/wonyoungchoi/doseweek/features/historyimport/HistoryImportSheet.… | branch unmerged. mapping labels still machine header IDs (handoff item 4). |
| IM06 | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/java/com/wonyoungchoi/doseweek/features/historyimport/ImportRowResolver.k… | branch unmerged. |
| IM07 | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/java/com/wonyoungchoi/doseweek/features/historyimport/ImportRowResolver.k… | branch unmerged. owner decision TRANSFER-12 honored. |
| IM08 | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/java/com/wonyoungchoi/doseweek/features/historyimport/ImportRowResolver.k… | branch unmerged. |
| IM09 | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/java/com/wonyoungchoi/doseweek/features/historyimport/ImportRowResolver.kt | branch unmerged. no manual-vs-file equivalence test. |
| IM10 | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/java/com/wonyoungchoi/doseweek/data/historyimport/HistoryImportStore.kt; … | branch unmerged. row-reason UI journey not run. |
| IM11 | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/java/com/wonyoungchoi/doseweek/data/historyimport/HistoryImportStore.kt; … | branch unmerged. |
| IM12 | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/java/com/wonyoungchoi/doseweek/data/historyimport/HistoryImportStore.kt; … | branch unmerged. |
| IM13 | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/java/com/wonyoungchoi/doseweek/features/historyimport/HistoryImportContro… | branch unmerged. potential-duplicate acknowledgement in code; no named test. |
| IM14 | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/java/com/wonyoungchoi/doseweek/data/historyimport/HistoryImportStore.kt; … | branch unmerged. disk-full variant untested. |
| IM15 | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/java/com/wonyoungchoi/doseweek/data/historyimport/HistoryImportStore.kt; … | branch unmerged. process-kill journey not run. |
| IM16 | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/java/com/wonyoungchoi/doseweek/data/historyimport/HistoryImportStore.kt; … | branch unmerged. lock/wipe/restore late-callback journey not run. |
| IM17 | and | MISSING | — | android-import:app/src/main/java/com/wonyoungchoi/doseweek/data/historyimport/HistoryImportStore.kt#require(i… | inventory opt-in net effect absent (default no deduction only); not in android-import-finish scope. |
| IM18 | and | MISSING | — |  | future-schedule impact preview absent; not in lane scope. |
| IM19 | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/java/com/wonyoungchoi/doseweek/data/historyimport/HistoryImportFileReader… | branch unmerged. cancellable reader; provider offline/refusal untested. |
| IM20 | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/java/com/wonyoungchoi/doseweek/app/MainActivity.kt | branch unmerged. AndroidManifest diff 79bb210..197d9f3 empty (no new permission); not a counted test. |
| IM21 | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/java/com/wonyoungchoi/doseweek/data/historyimport/HistoryImportContract.k… | branch unmerged. draft snapshot/Add Row budget open (handoff item 5). |
| IM22 | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/java/com/wonyoungchoi/doseweek/data/historyimport/TabularHistoryParser.kt… | branch unmerged. re-export formula guard pending export build. |
| IM23 | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/java/com/wonyoungchoi/doseweek/features/historyimport/HistoryImportSheet.… | branch unmerged. separate sheet from encrypted restore. |
| IM24 | and | LANE | android-import-finish |  | branch unmerged. standard CSV export not committed (uncommitted StandardHistoryTable.kt in android-import-data); roundtrip untested; iOS side absent … |
| IM25 | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/java/com/wonyoungchoi/doseweek/data/historyimport/HistoryExtractionParser… | branch unmerged. |
| IM26 | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/java/com/wonyoungchoi/doseweek/data/historyimport/HistoryImportStore.kt; … | branch unmerged. provenance on history detail pending (handoff item 6); uncommitted ImportProvenanceViews.kt in android-import-data. |
| IM27 | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/java/com/wonyoungchoi/doseweek/data/DoseWeekRepository.kt#commitHistoryIm… | branch unmerged. no explicit Drive dirty-revision assertion/test for import commit found. |
| IM28 | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/java/com/wonyoungchoi/doseweek/features/historyimport/HistoryImportDraftC… | branch unmerged. drafts/retry authority excluded from backup per handoff; cleanup/protection untested. |
| IM29 | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/res/values*/history_import.xml(17×37) | branch unmerged. 17 locale journeys not run. |
| IM30 | and | MISSING | — |  | XLSX/PDF/other formats: no owner decision recorded; CSV/TSV/JSON decided. Question needed (see md). |
| IL-ko | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/res/values*/history_import.xml(17 files×37 keys) | strings+placeholder checks only; locale journey not run. |
| IL-en | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/res/values*/history_import.xml(17 files×37 keys) | strings+placeholder checks only; locale journey not run. |
| IL-ja | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/res/values*/history_import.xml(17 files×37 keys) | strings+placeholder checks only; locale journey not run. |
| IL-de | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/res/values*/history_import.xml(17 files×37 keys) | strings+placeholder checks only; locale journey not run. |
| IL-fr | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/res/values*/history_import.xml(17 files×37 keys) | strings+placeholder checks only; locale journey not run. |
| IL-es | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/res/values*/history_import.xml(17 files×37 keys) | strings+placeholder checks only; locale journey not run. |
| IL-it | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/res/values*/history_import.xml(17 files×37 keys) | strings+placeholder checks only; locale journey not run. |
| IL-nl | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/res/values*/history_import.xml(17 files×37 keys) | strings+placeholder checks only; locale journey not run. |
| IL-pt-PT | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/res/values*/history_import.xml(17 files×37 keys) | strings+placeholder checks only; locale journey not run. |
| IL-pl | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/res/values*/history_import.xml(17 files×37 keys) | strings+placeholder checks only; locale journey not run. |
| IL-sv | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/res/values*/history_import.xml(17 files×37 keys) | strings+placeholder checks only; locale journey not run. |
| IL-hi | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/res/values*/history_import.xml(17 files×37 keys) | strings+placeholder checks only; locale journey not run. |
| IL-pt-BR | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/res/values*/history_import.xml(17 files×37 keys) | strings+placeholder checks only; locale journey not run. |
| IL-ar | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/res/values*/history_import.xml(17 files×37 keys) | strings+placeholder checks only; locale journey not run. |
| IL-zh-Hans | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/res/values*/history_import.xml(17 files×37 keys) | strings+placeholder checks only; locale journey not run. |
| IL-zh-Hant | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/res/values*/history_import.xml(17 files×37 keys) | strings+placeholder checks only; locale journey not run. |
| IL-tr | and | LANE | android-import-finish | android-import@197d9f3:app/src/main/res/values*/history_import.xml(17 files×37 keys) | strings+placeholder checks only; locale journey not run. |
| IMPORT_PARITY | and | LANE | android-import-finish |  | branch unmerged. |

## Nutrition C/S/F/G/I/E/L/data

| platform | DONE | IMPL_UNVER | LANE | BLOCKED | MISSING | total |
|---|---|---|---|---|---|---|
| ios | 0 | 0 | 8 | 0 | 106 | 114 |
| android | 0 | 0 | 8 | 0 | 106 | 114 |

| id | plat | status | lane | code / test (first) | note |
|---|---|---|---|---|---|
| C01 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C02 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C03 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C04 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C05 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C06 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C07 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C08 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C09 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C10 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C11 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C12 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C13 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C14 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C15 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C16 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C17 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C18 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C19 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C20 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C21 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C22 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C23 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C24 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C25 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C26 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C27 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C28 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C29 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C30 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C31 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C32 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C33 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C34 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C35 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C36 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C37 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C38 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C39 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C40 | ios | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/swift-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| S01 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| S02 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| S03 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| S04 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| S05 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| S06 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| S07 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| S08 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| F01 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| F02 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| F03 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| F04 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| F05 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| F06 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| F07 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| F08 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| F09 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| F10 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| F11 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| F12 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G01 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G02 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G03 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G04 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G05 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G06 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G07 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G08 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G09 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G10 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G11 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G12 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G13 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G14 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G15 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G16 | ios | LANE | nutrition-data-release |  | data side only (android-nutrition-data: untracked nutrition-data/ dir at 12:43, no commits); app consumption absent both platforms; python_reference … |
| G17 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G18 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| I01 | ios | LANE | nutrition-data-release |  | data side only (android-nutrition-data: untracked nutrition-data/ dir at 12:43, no commits); app consumption absent both platforms; python_reference … |
| I02 | ios | LANE | nutrition-data-release |  | data side only (android-nutrition-data: untracked nutrition-data/ dir at 12:43, no commits); app consumption absent both platforms; python_reference … |
| I03 | ios | LANE | nutrition-data-release |  | data side only (android-nutrition-data: untracked nutrition-data/ dir at 12:43, no commits); app consumption absent both platforms; python_reference … |
| I04 | ios | LANE | nutrition-data-release |  | data side only (android-nutrition-data: untracked nutrition-data/ dir at 12:43, no commits); app consumption absent both platforms; python_reference … |
| I05 | ios | LANE | nutrition-data-release | prep:nutrition-prep/usda/normalize_source.py | data side only (android-nutrition-data: untracked nutrition-data/ dir at 12:43, no commits); app consumption absent both platforms; python_reference … |
| E01 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| E02 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| E03 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| E04 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| E05 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| E06 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| E07 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| E08 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| E09 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| E10 | ios | LANE | nutrition-data-release |  | data side only (android-nutrition-data: untracked nutrition-data/ dir at 12:43, no commits); app consumption absent both platforms; python_reference … |
| E11 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| E12 | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-ko | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-en | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-ja | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-de | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-fr | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-es | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-it | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-nl | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-pt-PT | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-pl | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-sv | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-hi | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-pt-BR | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-ar | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-zh-Hans | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-zh-Hant | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-tr | ios | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| DATA_RELEASE | ios | LANE | nutrition-data-release | prep:nutrition-prep/usda/normalize_source.py | data side only (android-nutrition-data: untracked nutrition-data/ dir at 12:43, no commits); app consumption absent both platforms; python_reference … |
| CROSS_PLATFORM | ios | MISSING | — |  | needs same dataReleaseId + both app runs; no nutrition app on either platform; unowned. |
| C01 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C02 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C03 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C04 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C05 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C06 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C07 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C08 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C09 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C10 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C11 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C12 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C13 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C14 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C15 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C16 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C17 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C18 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C19 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C20 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C21 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C22 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C23 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C24 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C25 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C26 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C27 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C28 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C29 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C30 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C31 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C32 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C33 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C34 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C35 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C36 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C37 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C38 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C39 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| C40 | and | MISSING | design-nutrition-app(design-only) | prep(outside repo):nutrition-prep/kotlin-calculator | calc candidate outside app; package_selftest/python_reference excluded from native evidence; no app integration or impl lane. |
| S01 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| S02 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| S03 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| S04 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| S05 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| S06 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| S07 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| S08 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| F01 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| F02 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| F03 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| F04 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| F05 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| F06 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| F07 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| F08 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| F09 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| F10 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| F11 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| F12 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G01 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G02 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G03 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G04 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G05 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G06 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G07 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G08 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G09 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G10 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G11 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G12 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G13 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G14 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G15 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G16 | and | LANE | nutrition-data-release |  | data side only (android-nutrition-data: untracked nutrition-data/ dir at 12:43, no commits); app consumption absent both platforms; python_reference … |
| G17 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| G18 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| I01 | and | LANE | nutrition-data-release |  | data side only (android-nutrition-data: untracked nutrition-data/ dir at 12:43, no commits); app consumption absent both platforms; python_reference … |
| I02 | and | LANE | nutrition-data-release |  | data side only (android-nutrition-data: untracked nutrition-data/ dir at 12:43, no commits); app consumption absent both platforms; python_reference … |
| I03 | and | LANE | nutrition-data-release |  | data side only (android-nutrition-data: untracked nutrition-data/ dir at 12:43, no commits); app consumption absent both platforms; python_reference … |
| I04 | and | LANE | nutrition-data-release |  | data side only (android-nutrition-data: untracked nutrition-data/ dir at 12:43, no commits); app consumption absent both platforms; python_reference … |
| I05 | and | LANE | nutrition-data-release | prep:nutrition-prep/usda/normalize_source.py | data side only (android-nutrition-data: untracked nutrition-data/ dir at 12:43, no commits); app consumption absent both platforms; python_reference … |
| E01 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| E02 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| E03 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| E04 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| E05 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| E06 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| E07 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| E08 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| E09 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| E10 | and | LANE | nutrition-data-release |  | data side only (android-nutrition-data: untracked nutrition-data/ dir at 12:43, no commits); app consumption absent both platforms; python_reference … |
| E11 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| E12 | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-ko | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-en | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-ja | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-de | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-fr | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-es | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-it | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-nl | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-pt-PT | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-pl | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-sv | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-hi | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-pt-BR | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-ar | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-zh-Hans | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-zh-Hant | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| L-tr | and | MISSING | design-nutrition-app(design-only) |  | no meal/food code in app; impl lane not launched. |
| DATA_RELEASE | and | LANE | nutrition-data-release | prep:nutrition-prep/usda/normalize_source.py | data side only (android-nutrition-data: untracked nutrition-data/ dir at 12:43, no commits); app consumption absent both platforms; python_reference … |
| CROSS_PLATFORM | and | MISSING | — |  | needs same dataReleaseId + both app runs; no nutrition app on either platform; unowned. |

## SDK/AI/adaptive D

| platform | DONE | IMPL_UNVER | LANE | BLOCKED | MISSING | total |
|---|---|---|---|---|---|---|
| ios | 0 | 13 | 0 | 3 | 9 | 25 |
| android | 0 | 16 | 0 | 1 | 7 | 24 |

| id | plat | status | lane | code / test (first) | note |
|---|---|---|---|---|---|
| D01 | ios | IMPL_UNVER | design-sdk-adaptive(design-only) |  | generic behavior exists (draft/revision/lock/large text) but no resize/fold/posture scenario run. |
| D02 | ios | MISSING | design-sdk-adaptive(design-only) |  | no two-pane/posture/scene/split code (iOS only ViewThatFits; Android no WindowSizeClass/FoldingFeature). |
| D03 | ios | IMPL_UNVER | design-sdk-adaptive(design-only) |  | generic behavior exists (draft/revision/lock/large text) but no resize/fold/posture scenario run. |
| D04 | ios | IMPL_UNVER | design-sdk-adaptive(design-only) |  | generic behavior exists (draft/revision/lock/large text) but no resize/fold/posture scenario run. |
| D05 | ios | MISSING | design-nutrition-app(design-only) |  | needs meal feature. |
| D06 | ios | IMPL_UNVER | design-sdk-adaptive(design-only) |  | generic behavior exists (draft/revision/lock/large text) but no resize/fold/posture scenario run. |
| D07 | ios | IMPL_UNVER | design-sdk-adaptive(design-only) |  | generic behavior exists (draft/revision/lock/large text) but no resize/fold/posture scenario run. |
| D08 | ios | IMPL_UNVER | design-sdk-adaptive(design-only) |  | generic behavior exists (draft/revision/lock/large text) but no resize/fold/posture scenario run. |
| D09 | ios | MISSING | design-sdk-adaptive(design-only) |  | no two-pane/posture/scene/split code (iOS only ViewThatFits; Android no WindowSizeClass/FoldingFeature). |
| D10 | ios | MISSING | design-sdk-adaptive(design-only) |  | no two-pane/posture/scene/split code (iOS only ViewThatFits; Android no WindowSizeClass/FoldingFeature). |
| D11 | ios | IMPL_UNVER | design-sdk-adaptive(design-only) |  | generic behavior exists (draft/revision/lock/large text) but no resize/fold/posture scenario run. |
| D12 | ios | IMPL_UNVER | design-sdk-adaptive(design-only) |  | generic behavior exists (draft/revision/lock/large text) but no resize/fold/posture scenario run. |
| D13 | ios | IMPL_UNVER | design-sdk-adaptive(design-only) |  | generic behavior exists (draft/revision/lock/large text) but no resize/fold/posture scenario run. |
| D14 | ios | MISSING | design-sdk-adaptive(design-only) |  | no two-pane/posture/scene/split code (iOS only ViewThatFits; Android no WindowSizeClass/FoldingFeature). |
| D15 | ios | IMPL_UNVER | design-sdk-adaptive(design-only) |  | generic behavior exists (draft/revision/lock/large text) but no resize/fold/posture scenario run. |
| D16 | ios | IMPL_UNVER | design-sdk-adaptive(design-only) |  | generic behavior exists (draft/revision/lock/large text) but no resize/fold/posture scenario run. |
| D17 | ios | MISSING | design-sdk-adaptive(design-only) |  | no two-pane/posture/scene/split code (iOS only ViewThatFits; Android no WindowSizeClass/FoldingFeature). |
| D18 | ios | IMPL_UNVER | design-sdk-adaptive(design-only) |  | generic behavior exists (draft/revision/lock/large text) but no resize/fold/posture scenario run. |
| D19 | ios | IMPL_UNVER | design-sdk-adaptive(design-only) | ios:DoseDay.xcodeproj(IPHONEOS_DEPLOYMENT_TARGET 26.0) | Xcode 26.6 / iPhoneOS SDK 26.5 only; iOS 27 SDK not installed; Release not rebuilt at 4c3e594. |
| D20 | ios | MISSING | design-sdk-adaptive(design-only) |  | no two-pane/posture/scene/split code (iOS only ViewThatFits; Android no WindowSizeClass/FoldingFeature). |
| D21 | ios | BLOCKED | design-sdk-adaptive(design-only) |  | physical iPhone Duo / Galaxy Z Fold only. |
| D22 | ios | MISSING | design-sdk-adaptive(design-only) |  | no two-pane/posture/scene/split code (iOS only ViewThatFits; Android no WindowSizeClass/FoldingFeature). |
| D23 | ios | BLOCKED | design-sdk-adaptive(design-only) | ios:DoseDay/Data/Services/AIModelGateway.swift | real_model evidence needs Apple Intelligence device; fakes only. |
| D24 | ios | MISSING | design-sdk-adaptive(design-only) |  | no two-pane/posture/scene/split code (iOS only ViewThatFits; Android no WindowSizeClass/FoldingFeature). |
| AI_INPUT | ios | BLOCKED | design-sdk-adaptive(design-only) | ios:DoseDay/Data/Services/AIModelGateway.swift; DoseDayTests/NaturalLanguageEntryViewModelTests(fake) | real_model only; simulator/fake runs do not count. |
| D01 | and | IMPL_UNVER | design-sdk-adaptive(design-only) |  | generic behavior exists (draft/revision/lock/large text) but no resize/fold/posture scenario run. |
| D02 | and | MISSING | design-sdk-adaptive(design-only) |  | no two-pane/posture/scene/split code (iOS only ViewThatFits; Android no WindowSizeClass/FoldingFeature). |
| D03 | and | IMPL_UNVER | design-sdk-adaptive(design-only) |  | generic behavior exists (draft/revision/lock/large text) but no resize/fold/posture scenario run. |
| D04 | and | IMPL_UNVER | design-sdk-adaptive(design-only) |  | generic behavior exists (draft/revision/lock/large text) but no resize/fold/posture scenario run. |
| D05 | and | MISSING | design-nutrition-app(design-only) |  | needs meal feature. |
| D06 | and | IMPL_UNVER | design-sdk-adaptive(design-only) |  | generic behavior exists (draft/revision/lock/large text) but no resize/fold/posture scenario run. |
| D07 | and | IMPL_UNVER | design-sdk-adaptive(design-only) |  | generic behavior exists (draft/revision/lock/large text) but no resize/fold/posture scenario run. |
| D08 | and | IMPL_UNVER | design-sdk-adaptive(design-only) |  | generic behavior exists (draft/revision/lock/large text) but no resize/fold/posture scenario run. |
| D09 | and | MISSING | design-sdk-adaptive(design-only) |  | no two-pane/posture/scene/split code (iOS only ViewThatFits; Android no WindowSizeClass/FoldingFeature). |
| D10 | and | MISSING | design-sdk-adaptive(design-only) |  | no two-pane/posture/scene/split code (iOS only ViewThatFits; Android no WindowSizeClass/FoldingFeature). |
| D11 | and | IMPL_UNVER | design-sdk-adaptive(design-only) |  | generic behavior exists (draft/revision/lock/large text) but no resize/fold/posture scenario run. |
| D12 | and | IMPL_UNVER | design-sdk-adaptive(design-only) |  | generic behavior exists (draft/revision/lock/large text) but no resize/fold/posture scenario run. |
| D13 | and | IMPL_UNVER | design-sdk-adaptive(design-only) |  | generic behavior exists (draft/revision/lock/large text) but no resize/fold/posture scenario run. |
| D14 | and | MISSING | design-sdk-adaptive(design-only) |  | no two-pane/posture/scene/split code (iOS only ViewThatFits; Android no WindowSizeClass/FoldingFeature). |
| D15 | and | IMPL_UNVER | design-sdk-adaptive(design-only) |  | generic behavior exists (draft/revision/lock/large text) but no resize/fold/posture scenario run. |
| D16 | and | IMPL_UNVER | design-sdk-adaptive(design-only) |  | generic behavior exists (draft/revision/lock/large text) but no resize/fold/posture scenario run. |
| D17 | and | MISSING | design-sdk-adaptive(design-only) |  | no two-pane/posture/scene/split code (iOS only ViewThatFits; Android no WindowSizeClass/FoldingFeature). |
| D18 | and | IMPL_UNVER | design-sdk-adaptive(design-only) |  | generic behavior exists (draft/revision/lock/large text) but no resize/fold/posture scenario run. |
| D25 | and | IMPL_UNVER | design-sdk-adaptive(design-only) | android:app/build.gradle.kts(compileSdk release(37), targetSdk 36) | compile37 builds; targetSdk37 candidate + behavior changes not done. |
| D26 | and | MISSING | design-sdk-adaptive(design-only) |  | no two-pane/posture/scene/split code (iOS only ViewThatFits; Android no WindowSizeClass/FoldingFeature). |
| D27 | and | BLOCKED | design-sdk-adaptive(design-only) |  | physical iPhone Duo / Galaxy Z Fold only. |
| D28 | and | IMPL_UNVER | design-sdk-adaptive(design-only) |  | generic behavior exists (draft/revision/lock/large text) but no resize/fold/posture scenario run. |
| D29 | and | IMPL_UNVER | design-sdk-adaptive(design-only) | android:app/src/main/java/com/wonyoungchoi/doseweek/app/MainActivity.kt#FLAG_SECURE | FLAG_SECURE present; target37 capture/Glance bitmap check not run. |
| D30 | and | IMPL_UNVER | design-sdk-adaptive(design-only) |  | generic behavior exists (draft/revision/lock/large text) but no resize/fold/posture scenario run. |

## User requirements U01–U21 (rollup)

| platform | DONE | IMPL_UNVER | LANE | BLOCKED | MISSING | total |
|---|---|---|---|---|---|---|
| ios | 0 | 7 | 3 | 1 | 8 | 19 |
| android | 1 | 10 | 1 | 0 | 7 | 19 |

| id | plat | status | lane | code / test (first) | note |
|---|---|---|---|---|---|
| U01 | ios | MISSING | design-sdk-adaptive(design-only) |  | iOS 27 및 최신 SDK; rollup worst-of 2 rows: IMPLEMENTED_UNVERIFIED=1, MISSING=1 |
| U01 | and | IMPL_UNVER | design-sdk-adaptive(design-only) |  | iOS 27 및 최신 SDK; rollup worst-of 1 rows: IMPLEMENTED_UNVERIFIED=1 |
| U02 | ios | BLOCKED | design-sdk-adaptive(design-only) |  | Apple AI 지원; rollup worst-of 2 rows: BLOCKED_DEVICE=2 |
| U03 | ios | MISSING | design-nutrition-app(design-only),design-sdk-adaptive(design-only) |  | iPhone Duo; rollup worst-of 24 rows: IMPLEMENTED_UNVERIFIED=13, MISSING=9, BLOCKED_DEVICE=2 |
| U04 | and | MISSING | design-nutrition-app(design-only),design-sdk-adaptive(design-only) |  | Samsung Galaxy Z Fold; rollup worst-of 24 rows: IMPLEMENTED_UNVERIFIED=16, MISSING=7, BLOCKED_DEVICE=1 |
| U05 | and | IMPL_UNVER | — |  | Google Play 사진 개선·올리기; rollup worst-of 1 rows: IMPLEMENTED_UNVERIFIED=1 |
| U06 | ios | MISSING | design-nutrition-app(design-only),nutrition-data-release |  | 식단 기능; rollup worst-of 72 rows: MISSING=71, IN_PROGRESS_LANE=1 |
| U06 | and | MISSING | design-nutrition-app(design-only),nutrition-data-release |  | 식단 기능; rollup worst-of 72 rows: MISSING=71, IN_PROGRESS_LANE=1 |
| U07 | ios | LANE | nutrition-data-release |  | 칼로리 근거 및 해외 음식; rollup worst-of 7 rows: IN_PROGRESS_LANE=7 |
| U07 | and | LANE | nutrition-data-release |  | 칼로리 근거 및 해외 음식; rollup worst-of 7 rows: IN_PROGRESS_LANE=7 |
| U08 | ios | MISSING | design-nutrition-app(design-only),nutrition-data-release |  | 다른 언어들도 지원; rollup worst-of 35 rows: MISSING=34, IN_PROGRESS_LANE=1 |
| U08 | and | MISSING | design-nutrition-app(design-only),nutrition-data-release |  | 다른 언어들도 지원; rollup worst-of 35 rows: MISSING=34, IN_PROGRESS_LANE=1 |
| U09 | ios | MISSING | — |  | iOS/Android 기능·계산 일치; rollup worst-of 1 rows: MISSING=1 |
| U09 | and | MISSING | — |  | iOS/Android 기능·계산 일치; rollup worst-of 1 rows: MISSING=1 |
| U10 | ios | LANE | ios-calendar-fix |  | 기존 앱 기능 유지; rollup worst-of 4 rows: IN_PROGRESS_LANE=2, DONE_VERIFIED=1, IMPLEMENTED_UNVERIFIED=1 |
| U10 | and | IMPL_UNVER | — |  | 기존 앱 기능 유지; rollup worst-of 4 rows: DONE_VERIFIED=2, BLOCKED_DEVICE=1, IMPLEMENTED_UNVERIFIED=1 |
| U11 | ios | MISSING | design-nutrition-app(design-only),design-sdk-adaptive(design-only),nutrition-data-release |  | 버그·사용성까지 검증; rollup worst-of 107 rows: MISSING=86, IN_PROGRESS_LANE=6, IMPLEMENTED_UNVERIFIED=13, BLOCKED_DEVICE=2 |
| U11 | and | MISSING | design-nutrition-app(design-only),design-sdk-adaptive(design-only),nutrition-data-release |  | 버그·사용성까지 검증; rollup worst-of 107 rows: MISSING=84, IN_PROGRESS_LANE=6, IMPLEMENTED_UNVERIFIED=16, BLOCKED_DEVICE=1 |
| U12 | ios | IMPL_UNVER | — |  | 세 저장소 문서·지침 정리; rollup worst-of 7 rows: IMPLEMENTED_UNVERIFIED=7 |
| U12 | and | IMPL_UNVER | — |  | 세 저장소 문서·지침 정리; rollup worst-of 7 rows: IMPLEMENTED_UNVERIFIED=7 |
| U13 | ios | LANE | ios-calendar-fix |  | 날짜·시간 시스템 선택기와 숫자 입력 편의; rollup worst-of 35 rows: DONE_VERIFIED=26, IMPLEMENTED_UNVERIFIED=7, IN_PROGRESS_LANE=2 |
| U13 | and | IMPL_UNVER | — |  | 날짜·시간 시스템 선택기와 숫자 입력 편의; rollup worst-of 37 rows: DONE_VERIFIED=27, IMPLEMENTED_UNVERIFIED=10 |
| U14 | ios | IMPL_UNVER | — |  | 최근 건강 기록 누락 조사·수정과 iOS 예방 검증; rollup worst-of 4 rows: DONE_VERIFIED=2, IMPLEMENTED_UNVERIFIED=2 |
| U14 | and | IMPL_UNVER | — |  | 최근 건강 기록 누락 조사·수정과 iOS 예방 검증; rollup worst-of 12 rows: BLOCKED_DEVICE=1, DONE_VERIFIED=10, IMPLEMENTED_UNVERIFIED=1 |
| U15 | ios | IMPL_UNVER | — |  | 주사 부위 좌우 시점 명확화; rollup worst-of 10 rows: DONE_VERIFIED=7, IMPLEMENTED_UNVERIFIED=3 |
| U15 | and | IMPL_UNVER | — |  | 주사 부위 좌우 시점 명확화; rollup worst-of 10 rows: DONE_VERIFIED=9, IMPLEMENTED_UNVERIFIED=1 |
| U16 | ios | IMPL_UNVER | — |  | 내역 수정 발견성과 같은 기록 정정; rollup worst-of 12 rows: DONE_VERIFIED=7, IMPLEMENTED_UNVERIFIED=5 |
| U16 | and | IMPL_UNVER | — |  | 내역 수정 발견성과 같은 기록 정정; rollup worst-of 12 rows: DONE_VERIFIED=6, IMPLEMENTED_UNVERIFIED=6 |
| U17 | ios | IMPL_UNVER | — |  | 임의 과거 날짜의 투약기록 추가; rollup worst-of 12 rows: DONE_VERIFIED=7, IMPLEMENTED_UNVERIFIED=5 |
| U17 | and | DONE | — |  | 임의 과거 날짜의 투약기록 추가; rollup worst-of 12 rows: DONE_VERIFIED=12 |
| U18 | ios | MISSING | ios-history-import |  | 과거 기록 직접/일괄 입력과 파일 가져오기; rollup worst-of 48 rows: IN_PROGRESS_LANE=45, MISSING=3 |
| U18 | and | MISSING | android-import-finish |  | 과거 기록 직접/일괄 입력과 파일 가져오기; rollup worst-of 48 rows: IN_PROGRESS_LANE=45, MISSING=3 |
| U19 | ios | IMPL_UNVER | — |  | 이미 구현된 기능의 발견성·인앱 설명서·FAQ; rollup worst-of 8 rows: DONE_VERIFIED=3, IMPLEMENTED_UNVERIFIED=5 |
| U19 | and | IMPL_UNVER | — |  | 이미 구현된 기능의 발견성·인앱 설명서·FAQ; rollup worst-of 8 rows: DONE_VERIFIED=4, IMPLEMENTED_UNVERIFIED=4 |
| U20 | ios | IMPL_UNVER | — |  | 모르는 의미는 사용자에게 명확하게 질문; rollup worst-of 2 rows: IMPLEMENTED_UNVERIFIED=2 |
| U20 | and | IMPL_UNVER | — |  | 모르는 의미는 사용자에게 명확하게 질문; rollup worst-of 2 rows: IMPLEMENTED_UNVERIFIED=2 |
| U21 | ios | MISSING | — |  | 수정·커밋·푸시·main·빌드 최종 권한 승인; rollup worst-of 4 rows: IMPLEMENTED_UNVERIFIED=2, MISSING=2 |
| U21 | and | MISSING | — |  | 수정·커밋·푸시·main·빌드 최종 권한 승인; rollup worst-of 4 rows: IMPLEMENTED_UNVERIFIED=2, MISSING=2 |

## Owner decisions (STATE.decisions)

| platform | DONE | IMPL_UNVER | LANE | BLOCKED | MISSING | total |
|---|---|---|---|---|---|---|
| both | 8 | 3 | 4 | 1 | 9 | 25 |

| id | plat | status | lane | code / test (first) | note |
|---|---|---|---|---|---|
| CHART-20260913-01 | bot | MISSING | design-body-charts(design-only) |  | no official-ref/personal-target selector, pinch period, landscape chart code (grep lossRate/referenceBand/pinch empty both). |
| HOST-20260913-02 | bot | DONE | — |  | process decision; parallel runs used. |
| CHART-20260913-03 | bot | MISSING | design-body-charts(design-only) | ios:DoseDay/Features/Body/BodyViewModel.swift(.bmi metric) | BMI computed; no green reference band. |
| CHART-20260913-04 | bot | MISSING | design-body-charts(design-only) |  | no weekly kg / % loss-rate display. |
| TRANSFER-20260913-05 | bot | LANE | android-import-finish+ios-history-import | prep:transfer-research/SCREENSHOT_TO_RECORDS_PROMPT_KO.md | JSON extraction parse Android branch; symptom/unclassified rows not savable; iOS none. |
| HEALTH-20260913-06 | bot | BLOCKED | — | android:app/src/main/java/com/wonyoungchoi/doseweek/data/health/HealthConnectImporter.kt | owner phone repro details unknown; synthetic fixes on main unreleased. |
| TRANSFER-20260913-07 | bot | LANE | android-import-finish+ios-history-import | android-import: Onboarding/Settings import entry (HISTORY_IMPORT_HANDOFF) | Android entries on branch; iOS absent; guide link points to unpublished legal /import/. |
| TRANSFER-20260913-08 | bot | MISSING | — | legal@candidate/import-guide cc6fa49:import/ | multilingual guide candidate preparation_only, unpublished; no lane publishes legal. |
| UX-20260913-09 | bot | IMPL_UNVER | — |  | principle; import UI 3-step review exists Android; final visual review pending. |
| TRANSFER-20260913-10 | bot | LANE | android-import-finish+ios-history-import | android-import:app/src/main/java/com/wonyoungchoi/doseweek/features/historyimport/HistoryImportSheet.kt | JSON file import Android partial (pasted JSON natively tested, SAF not); iOS lane; guide post-copy steps unpublished. |
| VERIFY-20260913-11 | bot | DONE | — |  | process; emulator/simulator manual inspection used. |
| TRANSFER-20260913-12 | bot | LANE | android-import-finish+ios-history-import | android-import:app/src/main/java/com/wonyoungchoi/doseweek/features/historyimport/ImportRowResolver.kt | Android ImportRowResolverTest#missingTimeCannotBeInventedByAConfirmationFlag + HistoryImportStoreTest#unconfirmedRowsCannotBeSaved pass; iOS pending. |
| DESIGN-20260913-13 | bot | IMPL_UNVER | — |  | final integrated visual/regression pass not done (iOS CI red, features unmerged). |
| SCHEDULE-20260913-14 | bot | DONE | — | ios:Packages/DoseDayCore/Sources/DoseDayCore/ScheduleCadence.swift | iOS CoordinatorReminderSyncTests 'Eight- and nine-day plans…' args[8,9]; Android custom-interval-8-9-evidence 6/6 API36 (head 967602a). physical noti… |
| MAINTAINABILITY-20260913-15 | bot | IMPL_UNVER | — | ios:docs/CURRENT_HANDOFF.md | docs per slice exist; final architecture/doc cleanup after all features pending. |
| SCHEDULE-20260913-16 | bot | MISSING | design-explicit-dates(design-only) |  | no explicit multi-date schedule mode either platform. |
| CALENDAR-20260913-17 | bot | MISSING | design-calendar-sync(design-only) |  | no EventKit / CalendarContract code. |
| CALENDAR-20260913-18 | bot | MISSING | design-calendar-sync(design-only) |  | iCloud/Samsung/Google destinations absent. |
| CALENDAR-20260913-19 | bot | MISSING | design-calendar-sync(design-only) |  | iCloud auto sync authorized, not implemented. |
| MEDICATION-KR-20260913-20 | bot | DONE | — | ios:Packages/DoseDayCore/Sources/DoseDayCore/PolicyRepository.swift(market KR) | iOS ShippedPolicyTests.testMounjaroKRUsesItsOwnMFDSLabelAndSingleUsePen; kr-ios-evidence.json; Android kr-policy-evidence JVM15/API36 8. NOT_RELEASED. |
| MEDICATION-KR-20260913-21 | bot | DONE | — | same as -20 | 72h/96h/5.5d values; focused PASS both; unreleased. |
| RECORD_ONLY_WITHOUT_TREATMENT_PLAN_20260913 | bot | DONE | — | ios:DoseDay/Features/RecordFlow/RecordFlowViewModel.swift | iOS RecordOnlyAdministrationTests + RecordOnly UI std/AX5; Android historical-facts evidence; in 79bb210 matrix. iOS main not merged. |
| OWNER-AUTONOMY-20260913-27 | bot | DONE | — |  | process. |
| CONTINUE_INDEPENDENT_WORK_WHILE_ANSWER_PENDING_20260913 | bot | DONE | — |  | process; ED11 pending held. |
| HEALTH-20260915-01 | bot | MISSING | — |  | calculated body fat mass (weight × same-measurement body fat %, 'calculated' label 17 locales, read-time only, never written/backed up as imported): … |

## HANDOFF §6 remaining work

| platform | DONE | IMPL_UNVER | LANE | BLOCKED | MISSING | total |
|---|---|---|---|---|---|---|
| both | 1 | 0 | 3 | 0 | 6 | 10 |

| id | plat | status | lane | code / test (first) | note |
|---|---|---|---|---|---|
| H6-01 | bot | LANE | ios-history-import |  | iOS import full integration + parity — ios-import base 4c3e594 with uncommitted V6 schema/backup/HistoryImport domain work (12:43); no V5→V6 migratio… |
| H6-01b | bot | LANE | android-import-finish |  | Android import finish (SAF/CSV mapping, v11→v12 migration+rollback, back nav, limits, provenance, export, 17 locales, matrix) — android-import-ui (fl… |
| H6-02a | bot | LANE | nutrition-data-release |  | Global nutrition official data pack — USDA 346/49 candidate; CoFID/MEXT prep; android-nutrition-data untracked nutrition-data/, no commits. |
| H6-02b | bot | MISSING | design-nutrition-app(design-only) |  | Nutrition app: direct entry, save/edit/delete, same calc, search, favorites/copy, backup/export, 17 locales (both) — no app code either platform; no … |
| H6-03 | bot | MISSING | design-body-charts(design-only) |  | Loss-rate/body charts: ref vs target, kg/% toggle, green bands, pinch period, landscape — no impl lane. |
| H6-04a | bot | DONE | — |  | Repeat interval 1–90 keep/verify — iOS BackupCadenceTests 1…90 + 8/9 reminder test; Android ScheduleEngine require 1..90. |
| H6-04b | bot | MISSING | design-explicit-dates(design-only) |  | Explicit multi-date schedule — no impl lane. |
| H6-05 | bot | MISSING | design-calendar-sync(design-only) |  | Opt-in calendar sync iCloud/Google/Samsung create/update/delete — no impl lane. |
| H6-06 | bot | MISSING | design-sdk-adaptive(design-only) |  | Latest SDK / Apple AI / adaptive / Fold / Duo — SDK 26.5 only; Duo/Fold/real AI BLOCKED_DEVICE portions. |
| H6-07 | bot | MISSING | — |  | 3-repo docs/legal/store candidates, final integrated regression, main + build SHA reconciliation — no lane; iOS main unmerged, legal import guide unp… |

## Handoff claims checked against code

| claim | check | result |
|---|---|---|
| iOS widget uses Today current occurrence, 377 nested tests | `DoseDayTests/WidgetSnapshotSyncTests.swift` "An expired reminder window does not erase the widget's unresolved schedule"; commit 32ce645 | code+test present; unit step PASS 4c3e594 |
| iOS launch/foreground passive Health import | 32ce645 touches `DoseDay/Features/Navigation/MainTabView.swift` (+4) | present; physical freshness unverified |
| Android foreground HC import already present | `DoseWeekViewModel.kt:522 fun onForegrounded()` | present |
| Android status8 fix, main 79bb210 CI exit0, 581×2 | evidence/android-main-ci.exit=0, android-matrix.log 581/581 API24+36, JVM XML 698 pass | confirmed |
| iOS CI 4c3e594 123p/1f/4s iPhone, 125p/1f/2s iPad, AX5 running | evidence/ios-ci summaries; ax5.log ends `BUILD INTERRUPTED`, no exit-code.txt in run-oyRImc0x | confirmed; AX5 **did not finish** (not "running") |
| Android import 723 JVM, storage 8, journey 1 | android-import JVM XML 723 pass; import-storage 8/8; import-latest 1/1 (pasted JSON) | confirmed; SAF not tested |
| DB 12 / backup 9 on import branch | `DoseWeekDatabase.kt DATABASE_VERSION = 12`; android-import, -ui, -data androidTest have only `DatabaseMigrationV3Test`…`V11Test` | v11→v12 migration test missing in all 3 import worktrees (re-checked 12:43, uncommitted work included) |
| iOS import schema | ios-import uncommitted `DoseDaySchemaV6`, `.lightweight(V5→V6)`, `CurrentDoseDaySchema = V6`; no DoseDayTests change | V5→V6 migration + backup-reader test absent so far (lane scope) |
| 17 locales × 37 keys import strings | 17 `values*/history_import.xml` | files present; journeys not run |
| Swift import prep 12 tests, not integrated | `history-import-prep/` 2 sources, 2 test files; ios 7e8681b has no `HistoryImport` symbol; ios-import has **uncommitted** `Domain/HistoryImport/` + SchemaV6 (12:43) | prep not integrated in any commit; lane work in progress, untested |
| USDA 346/49 candidate | `nutrition-prep/usda/normalize_source.py` + `test_normalize_source.py` | present outside repos; android-nutrition-data: untracked `nutrition-data/`, no commits |
| Interval 1–90 both, 8/9 verified | iOS `CoordinatorReminderSyncTests` args [8,9], `BackupCadenceTests` 1…90; Android `ScheduleEngine.kt require(intervalDays in MIN..MAX)` | confirmed |
| KR Mounjaro both | iOS `PolicyRepository.swift market "KR"` + `ShippedPolicyTests.testMounjaroKRUsesItsOwnMFDSLabelAndSingleUsePen`; Android `PolicyCatalog.kt` MFDS | confirmed |
| Calendar sync / explicit dates / loss-rate charts / nutrition app absent | grep EventKit, CalendarContract, explicitDate, lossRate/referenceBand, kcal/FoodCatalog → none | confirmed absent |
| Adaptive | iOS only `ViewThatFits`; no NavigationSplitView/sizeClass; Android no WindowSizeClass/FoldingFeature; compileSdk 37, targetSdk 36; Xcode 26.6 / SDK 26.5 | absent beyond basics |
| BUGFIX_BASELINE | no file found under v11 tmp or continuation folder | absent |
| iOS calendar-bound fix | ios 7e8681b; `docs/CURRENT_HANDOFF.md` records red iPhone (:295, :236) then `HistoryExportFeedbackUITests` 8/8 iPhone, iPad, AX5 | class-level only; full CI + Release on 7e8681b not run → DT07/UX09/APP_* stay LANE |
| HC12 provider→screen (Android) | `hc-native-fixture/manual-ui-evidence/result.json` PASS_HC12_REAL_PROVIDER_ORDINARY_DB_AND_UI, candidate 0cddc34 / app e10d959, API36 weight; `HealthConnectStagedMutationTest` + `HealthConnectProviderHandshakeTest` pass API24+36 in 79bb210-era matrix | trace real but not rerun at 79bb210 |
| Android Play assets | `evidence/capture-equivalence.json` 85/85 raw identical; `evidence/frame-pixel-equivalence.json` identicalPixels 0 | frames not re-verified → PLAY_ASSETS IMPL_UNVER |

## Open owner questions (genuinely undecided; not previously answered)

**Q1 — ED11 edit draft after process exit** (STATE.unansweredQuestions RECORD-DRAFT-PROCESS-EXIT, PENDING).
Facts: both apps keep an in-window draft and retry after failed save; original record atomic (iOS `failedEditPreservesDraftForRetry`, Android atomicity tests 13/13). Nothing persists an unfinished injection edit across process kill. Android import already persists a protected draft (`HistoryImportDraftCodec`) excluded from backup; nutrition spec E02 also requires a protected checkpoint.
- A: persist protected edit draft until Save or explicit Discard (excluded from backup, cleared on wipe/restore).
- B: discard on termination; only in-session retry.
- Recommend **A** — matches import/nutrition draft model, E02, "기능 누락 금지".

**Q2 — IM30 file formats beyond CSV/TSV/JSON.**
Facts: owner decided JSON (TRANSFER-10) and spec CSV/TSV; no decision on XLSX/PDF. Parsers are dependency-free with a 10 MiB limit.
- A: CSV/TSV/JSON only; guide says "export/save as CSV"; XLSX/PDF gets a specific unsupported-format message.
- B: add XLSX reader (new dependency, larger attack surface) and still no PDF.
- Recommend **A**.

**Q3 — JSON symptom / unclassified rows.**
Facts: Android `HistoryExtractionParser` keeps symptom/unclassified rows; save resolver supports administration + body only; both apps already have editable local symptom records.
- A: extend import save to symptoms (same-ID symptom model exists) and keep unclassified as must-deselect.
- B: keep administration/body only; show explicit "symptoms not importable yet" in review and guide.
- Recommend **A** (owner "투약·체중 등" + no feature loss), B acceptable as a stated interim.

## Top gaps no running lane owns (ordered by release impact)

1. **iOS bugfix release path** — calendar fix now committed 7e8681b (class 8/8 three legs only). Next: full CI including the AX5 leg on 7e8681b (4c3e594 AX5 `BUILD INTERRUPTED`), which also reruns the mapped suites behind the 26 `HEAD DRIFT` DONE rows (DT01 DT02 DT04 DT05 DT06 UX01 UX02 UX03 UX06 ED01 ED03 ED04 ED06 ED07 ED08 ED09 PR01 PR02 PR03 PR08 PR09 PR10 PR11 VIS01 VIS02 VIS04). Then a Release build at the final head, merge `codex/v11-bugfix` (draft PR7) → main 990002d, write the 3-repo `BUGFIX_BASELINE` (DL01/DL04/DL05/DL06 iOS, APP_BUILD/APP_REGRESSION iOS). The coordinator launches the CI; nobody owns the merge or the baseline.
2. **Legal/FAQ final alignment + publication** — LG01–LG06, LEGAL_COPY, VIS06, VIS08 both platforms; import guide on `legal@candidate/import-guide` unpublished (TRANSFER-08); the in-app guide link on the Android import branch points to it. It blocks both releases, since the FAQ has to match shipped screens.
3. **Bugfix scenario-variant test gaps (IMPLEMENTED_UNVERIFIED)** — iOS DT03 DT08 UX04 UX05 UX07 UX08 UX10 ED02 ED05 ED10 ED12 PR04–PR07 PR12 SM04 SM05 SM10 HK02 HK03 VIS03 VIS05 BACKUP_FLOW (provider-file restore UI); Android DT04 DT08 DT09 DT10 UX02–UX05 UX08 UX10 ED02 ED06 ED09 ED10 ED12 SM05 VIS03. Code exists, but the named variant was never executed.
3b. **Rerun at current head (not variant gaps)** — Android HC12: provider→ordinary DB→screen weight trace passed on API36 at candidate 0cddc34; mutation and handshake pass in the 79bb210-era matrix; rerun the manual trace on 79bb210 or on the merge head. Android PLAY_ASSETS: re-verify frames against current raw captures. Process-only DL01–DL04 (both platforms): close at root baseline.
4. **BUGFIX_PARITY** — no cross-platform manual comparison recorded (MISSING both).
5. **ED11 meaning** — Q1 unanswered, so the bugfix row can't close.
6. **New-feature implementation lanes not launched** (design-only): nutrition app both platforms (C01–C40, S, F, G, E, L-17, D05; 212 of the 240 registry MISSING rows), body charts (CHART-01/03/04), explicit schedule dates (SCHEDULE-16), calendar sync iCloud/Google/Samsung (CALENDAR-17/18/19), adaptive D rows (U03/U04). After the nutrition data lane lands, no lane integrates the pack into either app (CROSS_PLATFORM, U09).
7. **Import items outside both import lanes** — IM17 inventory opt-in net effect, IM18 schedule-impact preview (both platforms), IM30 (Q2), IM24 cross-platform CSV roundtrip and IMPORT_PARITY comparison, symptom rows (Q3), IM27 Drive dirty-revision assertion for import commit.
8. **SDK targets** — iOS 27 SDK not installed (D19, U01); Android targetSdk 37 candidate + FLAG_SECURE/Glance recheck (D25, D29). Only design lane.
9. **Store assets** — Android PLAY_ASSETS: frames not re-verified at current candidate (bugfix), plus full profile new screens, listing map and upload; iOS store captures for features; no lane.
9b. **Calculated body fat mass (HEALTH-20260915-01, confirmed 2026-09-15)** — no code on either platform, and no design or implementation lane owns it.
10. **VIS07 human first-use task** — both platforms; automation only.
11. **Owner/device-only** (BLOCKED_DEVICE, not assignable): Google HC omission (HC01, HEALTH_READ Android, HEALTH-06), real Drive auth (BACKUP_FLOW Android), Apple AI real model (AI_INPUT, D23), Duo/Fold physical (D21, D27).

## Review log (revision 2, 2026-09-15 12:43 KST)

| # | reviewer issue | verdict | action / reason |
|---|---|---|---|
| 1 | HC12 Android note wrong (claims probe only) | **ACCEPTED** | The 79bb210-era results do include `HealthConnectStagedMutationTest#optInNativeFixtureStagesPreserveIncrementalIdentityAndBookmarks` passing on API36 and API24; gen.py had filtered to the handshake test only. Audit VERIFIED_SCOPED plus `manual-ui-evidence/result.json` (candidate 0cddc34, API36 weight) closes provider→DB→screen. The row stays IMPL_UNVER, and its only gap is that the screen trace was not rerun at 79bb210. Removed from the variant-gap list and moved to 3b. The Android matcher now also resolves parameterized names (`[add]`) to the base result; no status changed. |
| 2a | Android PR10 DONE despite audit PARTIAL | **REJECTED (note scoped)** | The audit (updated 2026-09-13 13:16 UTC) is superseded by `stage1-android-remaining-evidence-map.json` (created 13:41 UTC, same source f4ef476). Its `corrected_prior_overstatements`: "PR10 already has a real explicit Today/History skip-undo journey plus collision-safe repository tests"; `specific_test_gaps` []. Code: `OccurrenceAttachmentPolicy.actionableOrNull` attaches only an explicitly requested SCHEDULED/DUE/NEEDS_REVIEW slot with no linked record; COMPLETED/SKIPPED/CANCELLED → unlinked fact. The expected clause "explicit relation only, no overwrite or silent status change" is enforced. All 10 map refs pass (8 API24+36, 2 JVM, including `olderLinkedBackfill…ExactlyOnce`). The `native_variants_not_yet_linked` list is the older audit inventory, which also lists rows the map kept as SPECIFIC_TEST_GAP. The note now names a UI journey linking to a NEEDS_REVIEW slot as not claimed. |
| 2b | Android PR12 DONE despite "very large backfill performance not measured" | **REJECTED (note scoped)** | The expected clause (keep period, page, time zone and full history through upgrade and backup/restore) has no performance term. Map correction: "no arbitrary new stress threshold is required". 10/10 map refs pass API24+36 (101 admin + 101 skipped + 101 body rows past the 100-row boundary, V10/V11 migration with rollback, backups 1–7, multi-page PDF). The note states performance is not claimed. |
| 2c | Android HC09 DONE with JVM-only refs | **REJECTED (display fixed)** | The reviewer's condition is met: the stored-native limit proof `ImportedMeasurementsViewModelTest#aThousandNewerHeightSamplesDoNotHideTheLatestWeight` and 7 siblings pass on API24 and API36 in the 79bb210-era matrix, and the map corrects the audit's "merged-data unit tests" remark. testRefs now list map native refs first. |
| 2d | Android VIS05 DONE despite TalkBack/human unclaimed | **ACCEPTED as scoping** | Kept DONE, scoped to automated native evidence (63/63 incl. TalkBackSemanticsTest, 17-locale BLOC, 200% layout, RTL body map). The expected clause asks for accessible actions, focus, errors and no English-only fallback; a live TalkBack session is noted as not claimed, and human first-use belongs to VIS07 (IMPL_UNVER). |
| 3 | Hard-coded DONE without mapped tests (DL01–DL04, PLAY_ASSETS) | **ACCEPTED** | DL02/DL03 on iOS and Android, and DL01/DL04 on Android → IMPL_UNVER as process-only rows (a new status rule). Android PLAY_ASSETS → IMPL_UNVER (`frame-pixel-equivalence.json` identicalPixels 0; audit framed assets PENDING). Rollups U05 Android and U20 on both platforms follow. Android APP_BUILD/APP_REGRESSION **kept DONE**: they have mapped tests, and the audit's open items (fresh full CI, full API24/36 matrix) are closed by `evidence/android-main/android-main-ci` exit0 at 79bb210 and the 581/581 × 2 matrix. Signing and upload are release-only. |
| 4 | iOS dirty-worktree snapshot understated | **ACCEPTED** | At 12:35 the three files (HistoryView.swift, ConfirmedDateTimePicker.swift, HistoryExportFeedbackUITests.swift) were uncommitted. They are now commit 7e8681b (12:40). The snapshot lists all three with diffstat. 26 iOS DONE rows carry a `HEAD DRIFT` note, and gap item 1 requires the rerun on 7e8681b before merge/baseline. DT07/UX09/APP_* notes cite the fix commit and class-level 8/8. |
| 5 | "Zero diffs" claim false for import/nutrition worktrees | **ACCEPTED** | mtimes predate the report (ios-import HistoryImportEntities 12:32:50, DoseDaySchema 12:34:29; android-import-data StandardHistoryTable 12:35:59, md 12:36:15). Snapshot is now timestamped 12:43 and lists uncommitted work in ios-import, android-import-ui, android-import-data and android-nutrition-data. Migration re-check: still no DatabaseMigrationV12Test in any Android import worktree; ios-import adds V5→V6 lightweight stage with no test. H6-01/H6-01b/H6-02a, IM24, IM26 and iOS import notes updated. |
| + | New since revision 1 | added | STATE decision HEALTH-20260915-01 (calculated body fat mass) → MISSING, unowned. |
