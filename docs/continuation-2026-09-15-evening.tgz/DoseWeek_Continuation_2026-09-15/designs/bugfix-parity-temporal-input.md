# Bugfix parity — temporal input (DT01–DT10, UX01–UX10)

Read-only review, 2026-09-15 (rev 2 after verifier pass; see Review log). Trees: iOS `/private/tmp/doseweek-v11-20260913/ios` branch `codex/v11-bugfix` HEAD `93ae0e2`; Android `/private/tmp/doseweek-v11-20260913/android` `main` `79bb210`.
Requirements: `01_BUGFIX_BOTH_PLATFORMS.md` §3 (lines 39–64; §3.1 jump text :43, exact-time/overlap :61), `specs/PRIOR_FEEDBACK.md` U13 (lines 20–32) + DT table (75–84), `review_feedback_cases_v2.json` UX01–UX10, `acceptance_registry.json` U13. Starting index: `designs/requirements-coverage.json` (checked against the code, not copied).

Path prefixes: **A:** = `android/app/src/main/java/com/wonyoungchoi/doseweek/`, **AT:** = `android/app/src/androidTest/java/com/wonyoungchoi/doseweek/`, **AU:** = `android/app/src/test/java/com/wonyoungchoi/doseweek/`, **I:** = `ios/DoseDay/`, **IT:** = `ios/DoseDayTests/`, **IU:** = `ios/DoseDayUITests/`.

## Verdict table

| ID | Topic | Class | One-line reason |
|---|---|---|---|
| DT01 | native picker default, typing secondary | PARITY_OK | A: DatePickerDialog/TimePickerDialog; I: native DatePicker sheet; typing is opt-in on both |
| DT02 | cancel keeps draft; confirm ≠ save | PARITY_OK | only the positive button / Done writes the draft; no record commit |
| DT03 | local calendar date, month-index and zone safety | PARITY_OK | A: `zeroBasedMonth + 1` → LocalDate, no M3 millis; I: picker runs in the record zone. iOS KST/US month/year boundary run incomplete |
| DT04 | 12/24h, midnight/noon, app locale | PARITY_OK | both follow the system 12/24h setting; drafts stay canonical. Evidence on both = runtime traces, no committed 12h assertion |
| DT05 | open and confirm unchanged → exact instant, seconds, offset | PARITY_OK | A: unchanged callback skipped + `BodyEntrySeed`; I: resolver returns `original` |
| DT06 | zone pinned, DST gap/overlap, stale validation | **DIVERGENCE (Android Body)** | gap → error on both. Overlap: iOS requires a tap at every callsite incl. Body; Android dose/edit/side-effect require a choice, but Android Body silently takes the earlier offset for a fresh or retyped time |
| DT07 | every callsite; date-only; end exclusive | PLATFORM_DIFFERENCE_ALLOWED | export-period date editor exists only on iOS; Android export uses preset rolling windows. Body range end is +1 day exclusive on both |
| DT08 | rotation/fold/large text/RTL/lock with picker open | UNVERIFIABLE | code behaves the same (keep on rotation, drop the temporary value on background); focus, fold, lock and RTL-with-picker-open not run on either platform |
| DT09 | Android YMD8/HHmm mask, local digits | PLATFORM_DIFFERENCE_ALLOWED | requirement is Android-only; Android meets it in code. iOS typed paths parse the same shapes without a mask |
| DT10 | Android invalid/partial/IME | PLATFORM_DIFFERENCE_ALLOWED | Android-only; strict parser, no repair. Active IME composing not run |
| UX01 | past selected date → date row opens calendar seeded there | PARITY_OK | both seed the selected date. Time seed differs (A blank, I `min(date, now)` + exact-time toggle); neither invents a time |
| UX02 | fast jump to an earlier year | **DIVERGENCE (Android, parity only)** | UX02 text met on both via the native date picker's month/year selection. Parity gap: Android History calendar has arrows only; iOS title opens a date wheel |
| UX03 | AM/PM in a 12h system | PARITY_OK | A: `is24HourFormat` fed to the dialog + `"hm"` skeleton; I: wheel follows locale/system. Typed time is 24h-only on both, with a hint |
| UX04 | 12AM/12PM/9:30PM/11:59PM stored meaning | PARITY_OK | same conversion. A runtime covers all four; I runtime covers midnight/noon only |
| UX05 | switching 12h/24h changes display only | PARITY_OK | drafts and storage are format-independent on both; runtime traces show records and revisions unchanged |
| UX06 | date-only / time-only / unchanged confirm | PARITY_OK | same component-preservation contract |
| UX07 | temporary value vs draft; cancel/outside/back | PARITY_OK | the dialog/sheet holds the temporary value; only confirm writes the draft; save stays explicit |
| UX08 | mask only on dates; cursor/IME; decimals not rewritten | PLATFORM_DIFFERENCE_ALLOWED | Android visual-only mask; iOS has no mask. Both decimal parsers reject a wrong-locale separator. IME composing unverified on both |
| UX09 | shared picker on every existing callsite | PLATFORM_DIFFERENCE_ALLOWED | shared picker component on both. Unmatched rows: iOS-only export range (allowed), iOS calendar jump (= UX02), Android Body overlap choice (= DT06); not counted twice |
| UX10 | picker a11y/focus/no duplicate dialog under stress | UNVERIFIABLE | same code-level design; required open-picker lock/fold/RTL/focus runs missing on both |

Count: PARITY_OK 10 · PLATFORM_DIFFERENCE_ALLOWED 5 · DIVERGENCE 2 (DT06 Android Body — data meaning; UX02 Android History — navigation parity) · UNVERIFIABLE 2 (DT08, UX10).

## Shared implementation map

| Concern | Android | iOS |
|---|---|---|
| Shared component | `A:designsystem/components/TemporalInputField.kt:80-162` (button + optional manual field) | `I:DesignSystem/Components/ConfirmedDateTimePicker.swift:5-94` (date/time buttons → confirm sheet) |
| Native control | `DatePickerDialog` `:180-187`, `TimePickerDialog(..., DateFormat.is24HourFormat(context))` `:188-198` | `DatePicker(.graphical)` `:217-223`, `.wheel` at AX sizes `:211-216`, time `.wheel` with `.gmt` neutral day `:207-210` |
| Temporary vs draft | dialog owns the temporary value; `onDateSet`/`onTimeSet` call `update()` only if the value changed `:184`, `:193-195`; cancel/dismiss → `close()` `:200-201` | `dateDraft`/`clockDraft` @State `:125-126`; Cancel `:173-177`; Done → `onConfirm` `:180-188`; stale-session guard `:51` |
| Exact resolver | `A:common/time/ExactLocalTimeResolver.kt:35-70`; record/edit/side effect `A:app/DoseWeekViewModel.kt:7356-7420` (explicit choice); Body `:5680-5711` via `instantPreferring` (silent earlier, `ExactLocalTimeResolver.kt:61-69`) | `I:Domain/Services/ExactEditTimeResolver.swift:37-79` |
| Precision keep | `A:app/BodyEntrySeed.kt:36-66` (`holdsSeed`, `editedTime`) | `ExactEditTimeResolver.swift:52-64` |
| Typed parser | `A:common/formatting/LocalizedInputParser.kt:15-56` (strict ISO/BASIC_ISO, HH:mm, Unicode digits) | `I:Features/Body/BodyCustomDateRange.swift:29-50`; side-effect time `I:Features/SideEffects/SideEffectLogSheet.swift:260-271` |
| Decimal parser | `LocalizedInputParser.kt:58-93` | `I:Domain/Services/LocalizedDecimalInput.swift:7-35` |
| Lifecycle | keeps dialog state across config change `:214-217`/`:202`; dismisses on `ON_STOP` `:205-210`; one dialog per `viewModel(key="temporal.$fieldTag")` `:98` | sheet closes on background `:57-59`, on selection change `:55`, on zone change `:56` |

### Callsite inventory (UX09 / DT07)

| Purpose | Android | iOS | Match |
|---|---|---|---|
| New dose date/time | `A:features/record/RecordAdministrationDialog.kt:595,608` | `I:Features/RecordFlow/RecordFlowView.swift:457` | ✓ |
| Past dose (backfill) | same dialog, `isHistoricalEntry`; seed `A:app/DoseWeekViewModel.kt:4036-4037` | `RecordFlowView.swift:482` + exact-time toggle | ✓ (seed differs, see UX01) |
| Edit dose | `A:features/history/HistorySheets.kt:78,90` | `I:Features/History/Components/EditAdministrationSheet.swift:129` | ✓ |
| Body entry/correction | `A:features/body/BodyScreen.kt:573,596` | `I:Features/Body/Components/ManualWeightEntrySheet.swift:123` | ✗ overlap choice missing on Android → DT06 (picker reuse itself ✓) |
| Body custom range | `BodyScreen.kt:312,322` | `I:Features/Body/Components/BodyCustomRangeEditor.swift:73` (+ typed fields `:22-40`) | ✓ |
| Side effect | `A:features/sideeffects/SideEffectSheets.kt:163,173` | `I:Features/SideEffects/SideEffectLogSheet.swift:204` (+ typed `:229-258`) | ✓ |
| Onboarding time / last dose | `A:features/onboarding/OnboardingScreen.kt:564,619` | `I:Features/Onboarding/OnboardingView.swift:377,410` | ✓ |
| Plan start / plan time | `A:features/settings/SettingsDialogs.kt:179,199` | `I:Features/Settings/Components/EditTreatmentPlanSheet.swift:251,263` | ✓ |
| History calendar date jump | **none**, arrows only `A:features/history/HistoryScreen.kt:245-281` | `I:Features/History/Components/CalendarMonthView.swift:161-177, 332-373` | ✗ → UX02 |
| Export period | presets `A:features/history/DocumentExportSheet.kt:41-53`, `A:domain/HistoryExportRange.kt:18-35` | `I:Features/History/HistoryView.swift:380-392` → `HistoryViewModel.swift:581-597` | allowed difference (DT07) |

Localization: Android temporal strings are in all 17 locale catalogs (`record_time_format_hint`, `record_time_ambiguous`: 17 files each). iOS `temporal.*`, `export.range.*`, `temporal.manual.hint`: 17 localizations each in `I:Resources/Localizable.xcstrings`.

Evidence freshness: Android runtime evidence is from `3ba51b7`, an ancestor of `79bb210`. `git log 3ba51b7..79bb210` shows no change to `TemporalInputField.kt`, `HistoryScreen.kt` or `LocalizedInputParser.kt`, so that evidence still applies. iOS mapped CI is from `4c3e594`. `7e8681b` changed `HistoryView.swift` (+21/−5) and a doc comment in the picker; `93ae0e2` is test/doc only. Rerun the export UI tests on HEAD before calling DT07/UX09 current.

## Details

### DT01 — PARITY_OK
- **Path.** A: tapping the row's `OutlinedButton` opens the system dialog (`TemporalInputField.kt:116-135`). The pencil `IconButton` reveals the manual field (`:136-156`). I: bordered button → confirm sheet with native DatePicker (`ConfirmedDateTimePicker.swift:62-74`). Typing appears only at two callsites, behind "Type instead" (`SideEffectLogSheet.swift:229-258`, `BodyCustomRangeEditor.swift:22-40`).
- **Validation.** Allowed difference: iOS disables Done and shows the reason inline for future/out-of-bound values (`:262-281`). Android `DatePickerDialog` sets no min/max, so the value is accepted and a field error blocks the save (`RecordAdministrationDialog.kt:624+`, `HistorySheets.kt:104-121`). Both block the save and give a localized reason.
- **A11y note (low).** The Android manual toggle's `contentDescription` is the generic `common_edit` (`:141`). Date and time toggles both read "Edit", so TalkBack does not say which field. The iOS disclosure reads "Type instead". This does not break DT01; Android could fix it by appending the field label.
- **Tests.** A: `AT:designsystem/components/TemporalInputFieldTest.kt:67-86` (`onboardingLastInjectionOpensTheNativeCalendar`), `BugfixLocaleJourneyTest.kt:126`. I: `IU:RecordFlowUITests.swift:146`, `IU:ScheduleRecoveryAuditUITests.swift:40`, `IU:SettingsScheduleEditingUITests.swift:78`.

### DT02 / UX07 — PARITY_OK
- **Data.** A: the draft is a String in UI state. Only the dialog callback calls `onValueChange` (`TemporalInputField.kt:182-197`). Cancel and dismiss listeners only `close()` (`:200-201`). ViewModel actions only copy the input (`DoseWeekViewModel.kt:716-721, 836-841`). I: the sheet edits local `@State`. `onConfirm` sets `selection` only; there is no save call (`ConfirmedDateTimePicker.swift:43-54`). A swipe-dismiss drops the session.
- **Save** stays behind the explicit Save button on both.
- **Tests.** A: `TemporalInputFieldTest.kt:87-148` (`nativeCalendarChangesOnlyTheDraftAfterConfirmation…`, `nativeClockCancellationAndUnchangedConfirmation…`). I: `IU:RecordFlowUITests.swift:146`, `IU:AuditHistoryCorrectionUITests.swift:340,427`, `IU:HistoryExportFeedbackUITests.swift:75`.

### DT03 — PARITY_OK
- A: the platform callback's `zeroBasedMonth + 1` becomes a `LocalDate` (`TemporalInputField.kt:182-183`). The seed passes `monthValue - 1` (`:186`). No Material3 `selectedDateMillis`, so no UTC day shift. The date is combined with `enteredTimeZoneId` only in the resolver (`DoseWeekViewModel.kt:7362-7376`).
- I: the date sheet runs with `.environment(\.timeZone, timeZone)` in the record zone (`:215,221`). Date-only callers pin a Gregorian calendar in that zone (`:226-230, 258`).
- **Tests.** A: `TemporalInputFieldTest.kt:88` (one-based months); STATE Android native follow-up `24-us-december-confirmed.xml`. I: coverage note says the KST/US month/year-boundary scenario is not complete. That is an iOS evidence gap, not a code difference.

### DT04 / UX03 / UX04 / UX05 — PARITY_OK
- **12/24h source.** A: `DateFormat.is24HourFormat(context)` for the dialog (`:197`). The button text uses `getBestDateTimePattern(locale, "Hm"|"hm")` (`:107-112`), so AM/PM text is localized. I: wheel `DatePicker(.hourAndMinute)` (`:208`) follows the system/locale hour cycle. The summary uses `Date.FormatStyle(locale:timeZone:).hour().minute()` (`:78-80`). Neither overrides `\.locale` (grep: only reads at `:24,129`).
- **Stored meaning.** A: the callback's 0–23 hour is written as canonical `HH:mm` with `Locale.ROOT` (`:194`). I: wheel hour/minute is read in GMT from a neutral day (`:153-155, 237-244`). 12 AM → 00, 12 PM → 12 on both. Neither parses AM/PM text.
- **Typed time.** 24h only on both, with an explicit hint. A: `record_time_format_hint` "HH:MM (24시간제)" (`res/values/strings.xml:76`). I: `temporal.manual.hint` "Time: 24-hour format (21:30)". Allowed by 01 §3.3: 12h entry goes through the system picker's AM/PM field.
- **UX05.** Drafts are format-independent (A String `HH:mm`; I `Date`), so switching format changes nothing stored.
- **Evidence.** Both platforms rely on runtime traces, not committed assertions. A: `native-followup-3ba51b7/api-24-clock/result.json` (midnight/noon/23:59 + 21:30, switch to 24h drops AM/PM, 4 records and revisions unchanged). `TemporalInputFieldTest` has no 12h-specific case. I: `dt04-native-clock/runtime-global-preference/result.json` (en-JP midnight/noon, same UUID and instant across preference change and relaunch). **Gap:** the iOS UX04 trace does not show 9:30 PM or 11:59 PM.

### DT05 / UX06 — PARITY_OK
- **Unchanged confirm.** A: the date callback skips `update` when the parsed date is equal (`:184`); the time callback skips it when hour and minute are equal (`:192-195`). If the fields still match the seed, `holdsSeed` keeps the stored offset (`BodyEntrySeed.kt:36-45`; `DoseWeekViewModel.kt:7371-7374`). I: the resolver returns `original` when date and minute are unchanged (`ExactEditTimeResolver.swift:54-56`).
- **Date only changed.** Original seconds and fraction are kept. A: `editedTime` returns the original `LocalTime` (`BodyEntrySeed.kt:62-66`). I: `:61-64`.
- **Time changed.** Seconds become 0 on both (A: parsed `LocalTime`; I: `:61`).
- **Edit wiring.** A passes `originalInstant` for dose edit (`DoseWeekViewModel.kt:4774-4780`), side effects (`:4448-4451`) and body (`:5691-5697`). I: `EditAdministrationSheet.swift:129-132` binds the stored `administeredAt` plus the stored zone.
- **Tests.** I: `IT:ExactEditTimeResolverTests.swift` (18: `:6,22,31,46,125,134,143`). A: `AU:common/formatting/BodyEntrySeedRoundTripTest.kt:18,36`; `BodyRecordCorrectionViewModelTest#aSecondsBearingCorrectionInTheFallBackHourKeepsItsOccurrence`; `LatestAdministrationCorrectionTest` (per coverage map).

### DT06 — DIVERGENCE (Android Body)
- **Requirement.** `PRIOR_FEEDBACK.md:80` "gap 조용한 보정 금지, overlap 명시 선택, 오래된 validation 무효화"; `01_BUGFIX…md:61` "DST gap을 조용히 보정하지 않고 overlap은 offset을 명시한다".
- **Gap (parity OK).** A returns `Nonexistent` → `NONEXISTENT` (`ExactLocalTimeResolver.kt:43`; record `DoseWeekViewModel.kt:7381-7384`; Body `:5700-5702`, shown at `BodyScreen.kt:607`). I: `.nonexistent` → Done disabled with `temporal.nonexistent` (`ConfirmedDateTimePicker.swift:187, 262-266, 302-305`).
- **Overlap, record/edit/side effect (parity OK).** A lists offset options and returns `AMBIGUOUS_SELECTION_REQUIRED` unless the selected or untouched-seed offset matches (`DoseWeekViewModel.kt:7385-7408`); UI at `RecordAdministrationDialog.kt:632`, `HistorySheets.kt:110, 124-145`, `SideEffectSheets.kt:186`. I lists choices; `selectedChoice` is nil until a tap, so Done stays disabled (`ConfirmedDateTimePicker.swift:247-252, 187, 306-320`).
- **Overlap, Body (DIVERGENCE).**
  - A: `resolveBodyEntryTime` (`DoseWeekViewModel.kt:5680-5711`) calls `ExactLocalTimeResolver.resolve(...).instantPreferring(preferredOffset ?: preservedOffset)` (`:5700-5701`). With no matching offset, `instantPreferring` returns `choices.first()`, "the earlier reading, as a fresh entry does" (`ExactLocalTimeResolver.kt:61-69`). `instantPreferring` has no other caller (grep). `saveBodyRecord` passes only the stored offset, and only while the seed is untouched (`:5824-5827`). `BodyEntryTimeResolution` has no options field (`:5668-5672`); `BodyUiState` has no offset fields (`DoseWeekUiModels.kt:795-804`); the Body time field handles only `INVALID_TIME`/`NONEXISTENT` (`BodyScreen.kt:604-609`).
  - I: Body uses the shared `ConfirmedDateTimePicker` (`ManualWeightEntrySheet.swift:123-127`), so an overlap wall time needs a tap before Done. An untouched confirm returns `original` as `.exact` (`ExactEditTimeResolver.swift:54-56`).
  - **Scenario.** America/New_York, 2026-11-01 01:30. New Android Body entry, or a correction whose date/time was retyped → saved at the first pass (05:30Z) with no prompt. iOS → blocks until the user picks 05:30Z or 06:30Z. Same input, different stored instant possible: a data-meaning divergence.
  - Untouched Android correction is fine: it keeps the stored occurrence (`AU:app/BodyEntrySeedTest.kt:55,97`; `AT:app/BodyRecordCorrectionViewModelTest.kt:380`). `BodyEntrySeedTest.kt:114-115` pins the silent fresh-entry fallback as expected helper behaviour. No fresh or retyped Body overlap test exists.
- **Stale validation (parity OK).** A: `ChangeRecordDate/Time`, `ChangeEditDate/Time` reset `selectedTimeOffsetSeconds` (`DoseWeekViewModel.kt:716-721, 836-841`). Body has no selection to reset (`:971-972`). I: a draft change resets `selectedOffset` (`ConfirmedDateTimePicker.swift:192-193`); the sheet closes on zone change (`:56`).
- **Pinned zone (parity OK).** A: `enteredTimeZoneId` in the draft (`:4038`); Body uses `entryZone(body)` (`:5816`). I: `TimeZone(identifier: event.enteredTimeZoneIdentifier)` (`EditAdministrationSheet.swift:131`); Body `entryTimeZone` (`ManualWeightEntrySheet.swift:125`).
- **Minimal fix (Android only).**
  1. `resolveBodyEntryTime` (`:5680-5711`): mirror `resolveRecordTime` `:7385-7408`. On `Ambiguous`, build `RecordTimeOffsetOptionUi` options and set `timeError = AMBIGUOUS_SELECTION_REQUIRED` unless the selected offset or the untouched-seed offset matches. Add `options` to `BodyEntryTimeResolution` (`:5668-5672`). Drop the silent `choices.first()` fallback, or keep `instantPreferring` only for the seed path.
  2. `BodyUiState` (`DoseWeekUiModels.kt:795-804`): add `selectedTimeOffsetSeconds: Int?` and `timeOffsetOptions`. Add a `SelectBodyTimeOffset` action. Reset the selection in `ChangeBodyEntryDate/Time` (`DoseWeekViewModel.kt:971-972`). `evaluatedBodyEntry` (`:5628-5646`) copies the options. `saveBodyRecord` (`:5824-5827`) passes selected ?: stored.
  3. `BodyScreen.kt:604-609`: add an `AMBIGUOUS_SELECTION_REQUIRED` branch using the existing `record_time_ambiguous` (already in 17 catalogs), plus radio rows like `HistorySheets.kt:124-145`.
  4. Tests: a new entry at 01:30 on 2026-11-01 New_York is unsavable until a choice, and each choice stores its instant; a retyped correction (date changed, or 01:31 → 01:30) also needs a choice; the existing untouched-seed test (`BodyRecordCorrectionViewModelTest.kt:380`) stays green; update `BodyEntrySeedTest.kt:114-115` if the fallback is removed.

### DT07 — PLATFORM_DIFFERENCE_ALLOWED
- **Shared callsites** match one-for-one (inventory above). Date-only fields build no time on either side. A onboarding/settings dates are LocalDate strings. I uses `includesTime: false` → `startOfDay` (`:258`).
- **Body range end** is next-day exclusive on both: A `BodyTrendRange.kt:23` (`end.plusDays(1).atStartOfDay(zone)`), I `BodyCustomDateRange.swift:22-24`.
- **Export period differs.** iOS: user-chosen inclusive calendar days, end +1 day exclusive (`HistoryViewModel.swift:588-596`), with both-bound pickers (`HistoryView.swift:380-392`). Android: fixed presets, a rolling window of 30-day "months" measured from now (`HistoryExportRange.kt:18-44`), with no date callsite. This is pre-existing product asymmetry. `PRIOR_FEEDBACK.md:26` says not to build absent screens in the bugfix, so it is allowed here. The data meaning still differs (rolling instants vs calendar days), so log it as new-feature parity backlog, not a bugfix blocker.
- **iOS status.** The export-bound fix (`7e8681b`, `93ae0e2`) is committed. Full CI was not rerun; the lane reports class 8/8. Tests: `IU:HistoryExportFeedbackUITests.swift:75,105,205`.
- **Android tests.** `BodyTrendRangeUiTest#customPeriodCoversTheTypedDatesInclusively…`.

### DT08 / UX10 — UNVERIFIABLE
- **Code-level parity.**
  - Rotation keeps the picker. A saves and restores dialog state (`TemporalInputField.kt:202, 214-217`). I keeps the sheet state.
  - Background or lock drops the temporary value and keeps the draft. A: `ON_STOP` → `close()` + `dismiss()` (`:205-210`). I: `scenePhase == .background` → `editor = nil` (`:57-59`).
  - One dialog per field. A: a keyed ViewModel `isOpen` flag and one `DisposableEffect` (`:98, 176-225`). I: one `sheet(item:)`.
  - AX layout. I: wheel fallback plus toolbar icons (`:31-33, 196-204, 211-216`). A: the system dialog handles font scale.
- **Shared interpretation.** Both platforms drop the temporary value on app lock. DT08's wording "임시 선택… 보존" could be read the other way; that question applies to both platforms, so it is not a parity issue.
- **Missing on both.** Accessibility-focus return after confirm or cancel; fold/posture; RTL with the picker open; app-lock/PIN with the picker open; active IME composing (STATE Android follow-up "open-picker large-text/RTL/accessibility, PIN/app-lock and fold remain separate"; iOS coverage "popup-open app-lock/background/focus restoration and complete RTL matrix not covered").
- **Partial evidence.** A: `native-followup-3ba51b7/api-24-lifecycle/timezone-rotation-background-result.json`. I: `IU:OrientationUITests.swift:24`; STATE "picker rotation/background cancellation PASS"; AX5 focused runs.
- **Latent Android nit.** The `TemporalPickerState` key is `temporal.$fieldTag` in the Activity-scoped ViewModel store (`:98`), so `isManual` can stay expanded when the same sheet reopens. Low impact; not a DT08 failure.

### DT09 / DT10 — PLATFORM_DIFFERENCE_ALLOWED (Android-only requirement)
- **Android.**
  - The mask is visual only: exactly 8 or 4 decimal code points, raw text, selection and composition untouched (`TemporalInputField.kt:234-266`).
  - Parser is strict `BASIC_ISO_DATE`/`ISO_LOCAL_DATE` and `H:mm` (`LocalizedInputParser.kt:15-37, 113-119`). `20260230` and `2460` are rejected. No 6-digit dates or 3-digit times.
  - Unicode digits and fullwidth colon are normalized (`:44-56`).
  - The dose field uses `parseDecimal`, never the mask (`:58-93`).
  - Unit tests: `AU:common/formatting/LocalizedInputParserTest.kt:12-126`. UI tests: `TemporalInputFieldTest.kt:149` (`explicitTypingKeepsInvalidAndPartialDrafts…`). Runtime: `api-24-lifecycle/middle-delete-paste-result.json`. **Gap:** active IME composing not executed.
- **iOS** (for comparison only). Typed dates accept ISO or 8 digits in any Unicode decimal digits (`BodyCustomDateRange.swift:29-50`). Typed time is `H:mm`/`HH:mm` (`SideEffectLogSheet.swift:264-267`). No mask. Same accept/reject meaning.

### UX01 — PARITY_OK
- **Date seed** = selected History date on both. A: `dateInput = selectedDate` when `historical` (`DoseWeekViewModel.kt:4036`); the picker opens on the parsed draft (`TemporalInputField.kt:181`). I: `RecordFlowViewModel(historicalDate: selectedDate)` (`HistoryViewModel.swift:33-39`) → `administeredAt = min(historicalDate, .now)` (`RecordFlowViewModel.swift:297-299`); the sheet opens on `selection` (`ConfirmedDateTimePicker.swift:64`).
- **Time seed differs (allowed).** A leaves time blank (`:4037`), so the clock opens at now (`TemporalInputField.kt:189`). I seeds from the date and requires the `exactTimeConfirmed` toggle (`RecordFlowView.swift:479-498`). Neither saves an invented time, which satisfies owner decision `TRANSFER-20260913-12`.
- **Tests.** A: `TemporalInputFieldTest.kt:67`, `BugfixLocaleJourneyTest.kt:126` (17 BLOC). I: `IU:RecordFlowUITests.swift` (CI 4c3e594, 6/0).

### UX02 — DIVERGENCE (Android; History navigation parity, not a requirement failure)
- **Requirement.** UX02 scenario "현재 달에서 이전 연도로 빠른 이동"; expected "월/연도 이동 또는 native 선택 제공; 많은 이전달 탭만으로 접근하도록 강요하지 않음" (`review_feedback_cases_v2.json` UX02). `01_BUGFIX…md:43` places "월·연도 빠른 이동" in the paragraph "날짜 행을 누르면 달력…", i.e. the date-row picker.
- **Requirement status: met on both.** A: date rows open the native `DatePickerDialog` (`TemporalInputField.kt:180-187`), whose year list reaches earlier years without month taps. Runtime: "DatePicker year-header list selection 2026→2025" (`native-followup-3ba51b7/api-24/result.json`). I: the native picker in `ConfirmedDateTimePicker.swift:217-223`, plus the History jump below.
- **Parity gap: History calendar browse.** I: the History calendar title is a button (`history.calendar.chooseDate`, `CalendarMonthView.swift:161-177`) that opens a wheel date sheet with Cancel/Done (`:332-362`); `confirmDateJump` sets the month offset and selected day (`:364-373`). Tests: `IU:DoseDayUITests.swift:83` `testCalendarTitleJumpsAcrossYearsAndKeepsMonthButtonsWorking`, `:112` `testCalendarDateJumpCancelKeepsMonthAndSelectedDay`. A: `CalendarCard` shows `state.monthLabel` as plain `Text` (`HistoryScreen.kt:257-261`); the only navigation is the `ChangeHistoryMonth(-1/+1)` arrows (`:262-281`). The actions are `SelectHistoryDate` and `ChangeHistoryMonth` only (`DoseWeekUiModels.kt:1404-1405`; handled at `DoseWeekViewModel.kt:805-806`); no jump action exists.
- **Impact.** Reaching a day N months back in Android History, before ED edit entry or PR "add on this date", takes N arrow taps. On iOS it is one sheet. Stored data meaning is the same.
- **Priority.** Optional for the UX02 text, needed for parity. Bugfix-stage priority is an owner call (see questions).
- **Minimal fix (Android only), if parity is wanted.**
  1. `HistoryScreen.kt:257-261`: make the month label a clickable button with a calendar icon and a localized a11y label.
  2. Open a native `DatePickerDialog` seeded with the selected day if it is in the displayed month, otherwise the displayed month. Reuse the `NativeTemporalDialog` lifecycle pattern (`TemporalInputField.kt:164-226`) or extract it.
  3. On confirm, dispatch `ChangeHistoryMonth(monthsBetween)` then `SelectHistoryDate(epochDay)` (`DoseWeekViewModel.kt:805-806`), or add one `JumpHistoryToDate` action. Cancel changes nothing.
  4. Add 1 string × 17 locales and an androidTest mirroring the two iOS UI tests.

### UX08 — PLATFORM_DIFFERENCE_ALLOWED
- **Mask.** Android only, on typed date/time (see DT09). iOS has no typed mask anywhere, so it has no cursor or IME risk from a mask.
- **Decimals.** Both accept only the locale's decimal separator and reject grouping, so "1,5" in an en locale is rejected on both, not read as 15. A: `LocalizedInputParser.kt:78-87` (Arabic `٫` extra). I: `LocalizedDecimalInput.swift:12-31`.
- **Tests.** A: `LocalizedInputParserTest.kt:101,126`. I: `IT:LocalizedDecimalInputTests.swift:7` (rejects `"1,000"`, `"70,2,5"`, …), `:23` (17 locales).
- **Gap on both.** Mid-field deletion, paste and IME composing across native locales. A has a partial runtime trace (`middle-delete-paste-result.json`, PNGs 47/49); I has none.

### UX09 — PLATFORM_DIFFERENCE_ALLOWED
Both platforms reuse one picker component at every matching callsite (inventory). Imported health samples have no temporal editor on either. Unmatched rows are the export period (allowed, DT07), the History jump (tracked under UX02) and the Android Body overlap choice (tracked under DT06); neither divergence is counted twice. The iOS lane `ios-calendar-fix` status is IN_PROGRESS pending a HEAD CI rerun.

## Action list
1. **Android DT06 Body overlap (major, data meaning):** require an explicit offset choice for fresh or retyped Body times in a repeated hour. Fix location in the DT06 details.
2. **Android UX02 History jump (parity; owner call on bugfix priority):** add a month/year jump to the History calendar. Fix location in the UX02 details.
3. **iOS DT07/UX09 freshness:** rerun `IU:HistoryExportFeedbackUITests` and the mapped suites on `93ae0e2`.
4. **Evidence gaps, both platforms (not divergences):** iOS UX04 9:30 PM/11:59 PM trace; iOS DT03 KST/US month/year boundary; DT08/UX10 focus/fold/lock/RTL with picker open; UX08/DT10 IME composing; Android Body fresh-entry overlap test (lands with fix 1).
5. **Optional Android a11y:** field-specific `contentDescription` for the manual-entry toggle (`TemporalInputField.kt:141`).
6. **Backlog (not bugfix):** export-period model parity (Android rolling presets vs iOS calendar range). Needs an owner decision if parity is wanted.

## Review log
Verifier pass on rev 1. Each item was checked against `android@79bb210` and `ios@93ae0e2`.

| Verifier id | Result | What changed / why |
|---|---|---|
| DT06-body-overlap-silent (major) | **Accepted** | Confirmed at `DoseWeekViewModel.kt:5700-5701, 5824-5827`, `ExactLocalTimeResolver.kt:61-69`, `BodyScreen.kt:604-609` (no ambiguous branch), `DoseWeekUiModels.kt:795-804` (no offset state); iOS Body gated at `ConfirmedDateTimePicker.swift:187, 247-252`. DT06 reclassified PARITY_OK → DIVERGENCE (Android Body); inventory Body row ✓ → ✗; fix and tests added; count 11/1 → 10/2. Rev 1 cited only the record resolver path. |
| UX02-requirement-scope (minor) | **Accepted** | UX02 expected text allows "native 선택", and `01…md:43` sits in the date-row picker paragraph; Android `DatePickerDialog` (`TemporalInputField.kt:180-187`) meets it. Kept DIVERGENCE, relabelled as History navigation parity (not a requirement failure), with the fix optional-for-requirement and needed-for-parity. |
| (self) UX02 citation | Corrected | Rev 1 cited `01_BUGFIX…md:24` and §3 "lines 20–44"; the text is at `:43` and §3 spans 39–64. The verifier repeated `:24`; both corrected. HistoryScreen label/arrow lines tightened to `:257-261` / `:262-281`. |
| Rejected items | none | Both verifier findings reproduced in code; nothing rejected. |
