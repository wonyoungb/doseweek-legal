# DoseWeek — latest SDK, Apple AI, iPhone Duo and Galaxy Z Fold adaptive scope (design)

- Design ID: `sdk-adaptive`, revision 2 (review fixes; see §10 Review log). Author: research subagent. Date: 2026-09-15 (KST host clock).
- Inputs: `DoseWeek_Final_v11_2026-09-13/specs/SDK_AI_FOLDABLE.md` (A1-A4, iOS C1-C3, Android C1-C3, D01-D30), `contracts/adaptive_device_contract_v1.json` (unchanged, SHA from spec `2f2cbb83…3fdb2`), `STATE.json` decisions (DESIGN-20260913-13, UX-20260913-09, MAINTAINABILITY-20260913-15, VERIFY-20260913-11, OWNER-AUTONOMY-20260913-27, CONTINUE_INDEPENDENT_WORK…; pending question RECORD-DRAFT-PROCESS-EXIT).
- Repos read (read-only, nothing edited, built, or booted):
  - iOS `/private/tmp/doseweek-v11-20260913/ios`, branch `codex/v11-bugfix`, HEAD `7e8681b` (re-read 2026-09-15; revision 1 read `4c3e594`). This is **not** `origin/main` `990002d`. Implementers must rebase these file paths onto the integration branch they are assigned.
    - Dirty-work note: at `4c3e594` the worktree had uncommitted edits in `DoseDay/Features/History/HistoryView.swift`, `DoseDay/DesignSystem/Components/ConfirmedDateTimePicker.swift` and `DoseDayUITests/HistoryExportFeedbackUITests.swift`. They are now committed as `7e8681b` ("Keep export range bounds on the latest confirmed dates"; +21/−5 in HistoryView), and the worktree is clean. **Precondition for lane ios-adaptive-ui:** `7e8681b` (or its merged equivalent) must be in the branch before any adaptive History edit starts. If `git status` shows new dirty edits in any file this design assigns, stop and preserve them per AGENTS rules.
  - Android `/private/tmp/doseweek-v11-20260913/android`, `main` = `origin/main` `79bb210`.
- Companion artifacts (this folder):
  - `adaptive_layout_fixture_v2.json`: the shared behaviour fixture. SHA-256 `c4741a317036e6fe323d75b879ed7e09d61b1e04532f6ec52d4a80be2013104c`. It has 27 layout cases (unchanged from v1) and 7 transition cases (reducer redesigned). v1 (`f3577790…986a2`) is withdrawn and its files are removed; no repository ever held a copy.
  - `adaptive_layout_fixture_v2.reference.py`: the reference algorithm that generated the expected values. It is normative together with §6. `python3 adaptive_layout_fixture_v2.reference.py out.json` reproduces the fixture byte for byte.

Status words follow the spec: `NOT_RUN`, `BLOCKED`, `DUO_ADAPTATION_PREPARED`, etc. Nothing in this document is a PASS.

---

## 0. Bottom line (terse)

- iOS today:
  - Xcode 26.6 (17F113) with the iOS 26.5 SDK. Swift compiler 6.3.3, language mode 6.0, deployment target 26.0.
  - Sim runtimes: 26.5 (23F77) and a 27.0 **beta** runtime (24A5408d). Final 27.0 is 24A437.
  - No Xcode 27 is installed, so there is no iOS 27 SDK and no Duo SDK. Local SDK grep finds zero hits for `reservedRegions`, `ArrangementView`, `onHingeChange`, `defaultTabBarPlacement`, `UIViewReservedRegion`, `UIHingeInteraction` and `UIArrangementViewController`.
- Apple public state:
  - Xcode 27 (27A266a) and iOS 27.0 (24A437) are listed as released on 2026-09-14.
  - Xcode 27.1 beta is "coming later this month".
  - iPhone Duo was announced 2026-09-09. Pre-order 2026-10-16, availability 2026-10-23, ships with iOS 27.1.
  - Duo-specific APIs are published in tech talks as iOS 27.1 SDK APIs.
  - Submission floor today is Xcode 26 / iOS 26 SDK. The iOS 27 SDK becomes the floor in April 2027.
- iOS plan:
  - Keep 26.6 as the shipping toolchain.
  - Install Xcode 27 side by side and compile-check it via `DEVELOPER_DIR`.
  - Implement the generic adaptive layout with today's SDK. Duo stays `DUO_ADAPTATION_PREPARED` until the 27.1 SDK and a Duo simulator (Device Hub) exist; D20/D21 stay BLOCKED.
- Android today:
  - AGP 9.3.2, Gradle 9.5.0, Kotlin 2.3.21, Compose BOM 2026.08.00.
  - compileSdk `release(37)`, targetSdk 36, minSdk 24.
  - Installed platforms: android-24 and android-37.0. Emulator 37.1.11. Foldable device definitions exist but there is no foldable AVD.
- Android public state:
  - Android 17 (API 37) is stable. AGP 9.4.0 is stable (needs Gradle 9.6.0). Kotlin 2.4.20 is stable.
  - material3-adaptive 1.3.0 is stable; window 1.5.1 is stable.
  - Play requires target 36+ since 2026-08-31 and has published no API 37 deadline.
- Android plan:
  - No toolchain bump.
  - Add `androidx.compose.material3.adaptive:adaptive:1.3.0` and `androidx.window:window:1.5.1`, plus `androidx.window:window-testing:1.5.1` for androidTest.
  - Run targetSdk 37 as a separate candidate.
  - Create a foldable AVD. D27 physical Fold is BLOCKED.
- Both platforms:
  - One pure `AdaptiveLayoutPolicy` plus a pane reducer, loaded from the byte-identical fixture.
  - Layout never mutates the draft, a save, consent, a backup or permissions.
  - No DB, backup, or contract change.

---

## 1. Official-source ledger (all accessed 2026-09-15)

| Ref | URL | What it says (as fetched) |
|---|---|---|
| A-XREQ | https://developer.apple.com/xcode/system-requirements/ | Top row "Xcode 27", labelled **Beta** at fetch time. Host macOS Tahoe 26.6+. SDKs iOS 27. Swift 6.4. Deployment iOS 15–27. Next row: Xcode 26.6 Release, iOS 26.5 SDK, Swift 6.3, host macOS 26.2–26.x. |
| A-REL | https://developer.apple.com/news/releases/ | 2026-09-14: "Xcode 27 (27A266a)", "iOS 27.0 (24A437)", "iPadOS 27.0 (24A437)". 2026-09-11: "iOS 27.0 RC (24A437)". No Duo and no Xcode 27.1 entry. **Discrepancy with A-XREQ (Beta label) recorded. Treat A-REL as the release signal and re-check A-XREQ before archiving.** |
| A-UPREQ | https://developer.apple.com/news/upcoming-requirements/ | "Since April 28, 2026 … Apps uploaded to App Store Connect must be built with Xcode 26 or later using an SDK for iOS 26 …" |
| A-SUBMIT | https://developer.apple.com/app-store/submitting/ | "Starting April 2027 … iOS and iPadOS apps must be built with the iOS & iPadOS 27 SDK or later". |
| A-NEWS27 | https://developer.apple.com/news/?id=k1mtkt1k | 2026-09-09, "App Store submissions now open for the latest OS releases". Xcode 27 RC. No Duo mention. |
| A-DUO | https://developer.apple.com/iphone-duo/ | "Xcode 27.1 beta … Coming later this month". "Preparing your app for iPhone Duo" doc also coming later. HIG link present. |
| A-DUO-NEWS | https://www.apple.com/newsroom/2026/09/apple-unveils-iphone-duo/ | Announced 2026-09-09. Pre-order Fri Oct 16, available Fri Oct 23. "available with iOS 27.1". 7.6" inner / 5.4" outer. Split View and two windows of the same app. |
| A-TT-PREP | https://developer.apple.com/videos/play/tech-talks/111461/ | iOS 27 SDK build extends left of the status bar on the inner display. iOS 27.1 SDK build reaches the screen edge with vertical standard bars. "The inner display doesn't honor supported interface orientations, so use size classes." Use `window?.windowScene?.screen` and `traitCollection.displayScale`. `ReservedRegion`/`UIViewReservedRegion` and `.defaultTabBarPlacement(.sidebar)` are 27.1. Duo simulator via Device Hub in Xcode 27.1. Verbatim (re-fetched for review): "the iOS 27.1 SDK reaches the screen edge and lays standard navigation and toolbar buttons out vertically"; "ReservedRegion in SwiftUI and UIViewReservedRegion in UIKit let custom UI claim as much screen space as possible without colliding with system UI — useful for custom bars and edge-to-edge designs"; "NavigationSplitView, UISplitViewController, TabView, and UITabBarController are fully adaptive across every pose — columns collapse when closed and tile or overlay when open." |
| A-TT-LAYOUT | https://developer.apple.com/videos/play/tech-talks/111463/ | `proxy.reservedRegions(kind: .division)`, `.includeInactive`. Division vs occlusion. `ArrangementView`, `.arrangementViewStyle(.split/.overlay)`, `UIArrangementViewController`. Availability iOS 27.1. System containers (NavigationStack/SplitView/TabView/List/ScrollView) adapt automatically. |
| A-TT-SCENES | https://developer.apple.com/videos/play/tech-talks/111464/ | "iPhone Duo is the first iPhone to support multiple instances of your app's UI, and apps that support this on iPad will too." (The talk does **not** name any Info.plist key; the `UIApplicationSupportsMultipleScenes=false` fact comes from the repo `DoseDay/Resources/Info.plist`, not from this source.) "new windows can't be created on the outer display". `UIWindowSceneActivationAction` hides itself when unavailable and requests may fail. `.onHingeChange`/`UIHingeInteraction`. `.sceneAccessory`/`CameraCaptureAccessory`. Layout should use arrangement/region/size classes, not hinge angle. |
| A-TT-DESIGN | https://developer.apple.com/videos/play/tech-talks/111466/ | Linked from A-DUO. Not re-fetched in this pass. |
| A-HIG-DUO | https://developer.apple.com/design/human-interface-guidelines/designing-for-iphone-duo | **Fetch returned title only (JS page); body NOT read.** |
| A-XRN27 | https://developer.apple.com/documentation/xcode-release-notes/xcode-27-release-notes | **Fetch returned title only; body NOT read.** |
| A-FM | https://developer.apple.com/documentation/foundationmodels | **Fetch returned title only; body NOT read.** |
| A-FM-26 | https://developer.apple.com/videos/play/wwdc2026/241/ | New on-device model "rebuilt from the ground up". Private Cloud Compute model (32k context). Dynamic Profiles. `LanguageModel` protocol for third-party and server models. Evaluations framework. |
| A-GUIDE | https://developer.apple.com/app-store/review/guidelines/ | 2.3.1(a) no misleading marketing; 2.3.3 screenshots show app in use; 2.3.7 no trademarked-term stuffing and no unverifiable claims in subtitle; 2.3.10 no names/imagery of other mobile platforms; 1.4.1 medical apps get greater scrutiny. |
| A-TM | https://www.apple.com/legal/intellectual-property/guidelinesfor3rdparties.html | Allowed: "compatible with"/"for" referential use. Exact spelling. Adjective + generic noun. No implied endorsement. |
| G-TARGET | https://developer.android.com/google/play/requirements/target-sdk | From 2026-08-31, new apps and updates must target API 36+. Extension to 2026-11-01. Page updated 2026-09-01. No API 37 deadline. |
| G-A17 | https://developer.android.com/about/versions/17 | Android 17 = API 37 released. QPR1 (37.1) beta. |
| G-A17-BLOG | https://android-developers.googleblog.com/2026/06/Android-17.html | "Today we're releasing Android 17 …". Removes the orientation/resizability opt-out on sw>600dp for API 37 targets. |
| G-A17-SETUP | https://developer.android.com/about/versions/17/setup-sdk | `compileSdk = 37`, `targetSdk = 37`. Min AGP stated 8.9.0-rc01 (stale doc; project is already on 9.3.2). |
| G-A17-BEH | https://developer.android.com/about/versions/17/behavior-changes-17 | Target-37 items: RemoteViews bitmap+icon memory limit `1.5*w*h*4` (crash on exceed); lock-free `MessageQueue`; static final reflection blocked; `ACCESS_LOCAL_NETWORK`; ECH default; CT default; BAL hardening on `IntentSender`; native DCL read-only; `setContentCaptureEnabled(false)` no-op, so use `FLAG_SECURE`; background audio; RFCOMM read. |
| G-FF | https://developer.android.com/about/versions/17/changes/ff-restrictions-ignored | On sw≥600dp, API 37 targets ignore `screenOrientation`, `resizeableActivity`, `min/maxAspectRatio`, `setRequestedOrientation`. Exceptions: games, user opt-in, sw<600. Test with compat flag `UNIVERSAL_RESIZABLE_BY_DEFAULT`. |
| G-AGP | https://developer.android.com/build/releases/gradle-plugin | AGP 9.4.0 (Sep 2026). Gradle min 9.6.0, JDK 17, max API 37. |
| G-KT | https://kotlinlang.org/docs/releases.html | Kotlin 2.4.20 (2026-09-07) latest stable; 2.3.20 (2026-03-16). |
| G-BOM | https://developer.android.com/develop/ui/compose/bom/bom-mapping | Latest BOM 2026.08.00: material3 1.4.0, compose ui 1.12.0. |
| G-WIN | https://developer.android.com/jetpack/androidx/releases/window | window stable 1.5.1 (2025-11-19); alpha 1.6.0-alpha05. |
| G-M3A | https://developer.android.com/jetpack/androidx/releases/compose-material3-adaptive | adaptive/adaptive-layout/adaptive-navigation 1.3.0 stable (2026-08-12); 1.4.0-alpha02. |
| G-WSC | https://developer.android.com/develop/ui/compose/layouts/adaptive/use-window-size-classes | Breakpoints: width 600/840/1200/1600, height 480/900. Size classes are "NOT device-based". `currentWindowAdaptiveInfo(supportLargeAndXLargeWidth = true)`. |
| G-FOLD | https://developer.android.com/develop/ui/compose/layouts/adaptive/foldables/learn-about-foldables | FoldingFeature state/orientation/isSeparating/occlusionType/bounds. Tabletop/book. "7.6 Fold-in" resizable emulator. |
| G-FOLDAWARE | https://developer.android.com/develop/ui/compose/layouts/adaptive/foldables/make-your-app-fold-aware | `collectFoldingFeaturesAsState()`, `currentWindowAdaptiveInfoV2().windowPosture.isTabletop`, tabletop/book predicates. |
| G-MAVEN | https://dl.google.com/android/maven2/androidx/compose/material3/adaptive/adaptive-android/1.3.0/adaptive-android-1.3.0.pom and https://dl.google.com/android/maven2/androidx/window/window/1.5.1/window-1.5.1.pom | adaptive 1.3.0 depends on `androidx.window:window:1.5.0` (compile). window 1.5.1 depends on window-core 1.5.1 and core 1.8.0. |
| G-META | https://support.google.com/googleplay/android-developer/answer/9898842 | No misleading or irrelevant metadata, no brand logos without permission, no ranking claims, screenshots reflect the actual app. |
| S-TEST | https://developer.samsung.com/galaxy-z/testing.html | Emulator foldable profiles, Remote Test Lab (real device), physical device. |
| S-FLEX | https://developer.samsung.com/galaxy-z/flex-mode.html | Uses Jetpack WindowManager (cites 1.0.0; outdated). No Samsung SDK required. |
| S-CONT / S-MULTI | https://developer.samsung.com/galaxy-z/app-continuity.html and https://developer.samsung.com/galaxy-z/multi-window.html | Spec-cited. **Not re-fetched in this pass.** |

Verified locally against binaries, not docs:
- iOS 26.5 SDK swiftinterfaces:
  - `horizontalSizeClass`/`verticalSizeClass` and `onGeometryChange` are in SwiftUICore.
  - `NavigationSplitView.init(columnVisibility:preferredCompactColumn:sidebar:content:detail:)` and `NavigationSplitViewColumn` are available iOS 17+.
  - The Duo symbols are absent (0 hits).
- Android AARs downloaded to scratch and read with `javap`:
  - material3-adaptive 1.3.0: `currentWindowAdaptiveInfo(boolean)`, `currentWindowAdaptiveInfoV2()`, `currentWindowDpSize()`, `collectFoldingFeaturesAsState()`, `calculatePosture(List<FoldingFeature>)`.
  - `Posture.isTabletop` and `getHingeList()`. `HingeInfo(bounds,isFlat,isVertical,isSeparating,isOccluding)`. `separatingVerticalHingeBounds`.
  - window-core 1.5.1: `WindowSizeClass.isWidthAtLeastBreakpoint/isHeightAtLeastBreakpoint`, `WIDTH_DP_MEDIUM_LOWER_BOUND` etc.
  - window 1.5.1: `WindowInfoTracker.getOrCreate`, `windowLayoutInfo(Activity|Context)`, `FoldingFeature.isSeparating/getOcclusionType/getOrientation/getState`.
  - window-testing 1.5.1: `WindowLayoutInfoPublisherRule.overrideWindowLayoutInfo`, `DisplayFeatureTesting.createFoldingFeature(Rect|Activity,…)`, `WindowLayoutInfoTesting.createWindowLayoutInfo`.
  - All of these AARs declare `minSdkVersion 23`, which is ≤ app minSdk 24.

---

## 2. iOS — A1/C1 toolchain table

| Item | Installed (this Mac) | Latest public stable | Beta / upcoming | Submission requirement |
|---|---|---|---|---|
| Host OS | macOS 26.6.2 (25G83) | — | — | Xcode 27 needs macOS Tahoe 26.6+ (A-XREQ); satisfied |
| Xcode | 26.6 (17F113) at `/Applications/Xcode.app` (xcode-select) | Xcode 27 (27A266a), 2026-09-14 (A-REL). A-XREQ still labels it Beta; re-check | Xcode 27.1 beta "coming later this month" (A-DUO) | Xcode 26+ now (A-UPREQ); Xcode 27/iOS 27 SDK from April 2027 (A-SUBMIT) |
| iOS SDK | iOS 26.5 (`iphoneos26.5`) | iOS 27.0 | iOS 27.1 (Duo APIs) | as above |
| Swift compiler | 6.3.3 (swiftlang-6.3.3.1.3) | Swift 6.4 (with Xcode 27) | — | — |
| Swift language mode | `SWIFT_VERSION = 6.0`, strict concurrency complete (generate_project.py:579) | unchanged | — | — |
| Deployment target | iOS 26.0 (`IPHONEOS_DEPLOYMENT_TARGET`) | keep | — | none imposed |
| Simulator runtimes | iOS 26.5 (23F77); iOS 27.0 (24A5408d, a beta build older than the final 24A437) | iOS 27.0 (24A437) | iOS 27.1 + Duo device type (Device Hub, Xcode 27.1) | — |
| Duo sim device type | none (`simctl list devicetypes` has no Duo) | not public | Xcode 27.1 beta | — |
| Foundation Models | `import FoundationModels` only in `DoseDay/Data/Services/AIModelGateway.swift`; `SystemLanguageModel.default`; one-shot sessions; gate = `supportsLocale` ∩ `AIShippingLanguages.grounded` (ko/en/ja); guards `check_foundation_models_isolated`, `check_ai_stays_on_device` (`scripts/check_invariants.py:990`) | iOS 27 rebuilt on-device model; PCC/`LanguageModel` protocol exist (A-FM-26) | — | — |
| Scenes / orientation | `UIApplicationSupportsMultipleScenes=false`; iPhone portrait-only; iPad all 4 | Duo inner ignores orientations (A-TT-PREP) | — | — |

The three proof kinds A1 requires are kept separate:

| Proof kind | Current evidence | This design's command/owner |
|---|---|---|
| Old-SDK app on new OS | `docs/ios27-readiness/README.md`: 26.5-SDK app on the 27.0 **beta** runtime. iPhone legs passed; iPad AIEntry 2/5 failed with the sim `InputUI` crash (open). Historical; must re-run on the 24A437 runtime. | `CI_IOS_MAJOR=27 ./scripts/run_ci.sh` (Terminal, not a harness background task) after installing the 27.0 final runtime |
| New-SDK compile | none (no Xcode 27) | `DEVELOPER_DIR=/Applications/Xcode-27.app/Contents/Developer xcodebuild build -scheme DoseDay -configuration Release -destination 'generic/platform=iOS Simulator'`, plus RecordOnlyFallback and widgets |
| Real Apple AI model | none recorded in this pass | physical Apple Intelligence device, ko/en/ja synthetic set (A2); results must be kept separate from `AIFakes.swift` |

### 2.1 iOS minimal safe upgrade plan

- **U0 — no change to the shipping lane.**
  - 1.0.x keeps building with Xcode 26.6 / iOS 26.5 SDK, which is valid until April 2027.
  - Do not `xcode-select -s` globally.
  - Do not raise the deployment target or change `SWIFT_VERSION`.
- **U1 — side-by-side Xcode 27 (owner download; Apple ID).**
  - Install to `/Applications/Xcode-27.app` and the iOS 27.0 (24A437) sim runtime from Apple only.
  - Every command sets `DEVELOPER_DIR` for that command.
  - The runners must resolve the UDID (the AGENTS rule about same-named 26.5/27.0 simulators).
- **U2 — compile pass (D19).**
  - Release + RecordOnlyFallback + DoseDayWidgets.appex + DoseDayTests build.
  - Known break list from `docs/ios27-readiness`: the Swift 6.3/6.4 `@State` macro with default + `init` assignment. Source fixes are prepared in MainTabView (`selectedTab`, `isRecordFlowPresented`), ManualWeightEntrySheet (`value`) and SideEffectLogSheet (`selectedSymptoms`, `note`). Re-verify them.
  - Build step 9 re-runs invariants (xcstrings write-back).
  - Decline Xcode's "update to recommended settings" prompt. `project.pbxproj` is generated and must never be hand-edited or Xcode-upgraded.
- **U3 — A2 AI re-test.**
  - The rebuilt on-device model can change recall, so re-run `ParsedEntryComposerTests` / `NaturalLanguageEntryViewModelTests` cases against the real model on device.
  - Keep `SystemLanguageModel.default` only. PCC, `LanguageModel` providers and Dynamic Profiles are banned by `check_ai_stays_on_device`, so extend that denylist with any new off-device symbol found in the 27 SDK.
  - The gate stays ko/en/ja even if the model supports more.
- **U4 — A3 HealthKit.** Gate `HKHealthStore.earliestAuthorizedSampleDate(for:)` with `if #available(iOS 27, *)` inside the existing HealthKit adapter. Compile it only under Xcode 27; it is additive. This belongs to the A3 lane, not to adaptive layout.
- **U5 — Duo (C1.4/C1.5).**
  - Until Xcode 27.1 beta ships: generic adaptive layout only (§4), status `DUO_ADAPTATION_PREPARED`.
  - When 27.1 beta ships:
    - Probe `reservedRegions(kind:.division/.occlusion)`, `.defaultTabBarPlacement`, `ArrangementView` and `onHingeChange` in `docs/iphone-duo/probe/` (a doc plus a throwaway Swift file, **not** in any generate_project target).
    - Run the Duo sim via Device Hub.
    - Submission builds must not contain 27.1-only symbols until Xcode 27.1 is released and A-UPREQ/A-NEWS allow it.
- **U6 — submission (D24).**
  - Pick the channel per candidate: 26.6 Release, 27 Release, or 27.1 Release.
  - Record `xcodebuild -version`, archive SDK, entitlements and `MinimumOSVersion`.
  - No automatic upload.

iOS migration risks:
- Swift 6.4 new strict-concurrency diagnostics. Do not blanket-suppress them.
- SwiftData store under the iOS 27 runtime: verify that `PrivateStoreRelocation` and file protection still run before `ModelContainer` init.
- Liquid Glass rendering changes (unverified).
- The iOS 27 HealthKit history screen now appears without code changes.
- `@Generable` warnings.
- Duo inner display ignores the iPhone portrait lock: a portrait-only iPhone layout will be shown in a wide inner window even with no code change. This is the main reason the adaptive work is needed on iPhone.

---

## 3. Android — C1 toolchain table

| Item | Current (repo `main` 79bb210 / host) | Latest stable (official) | Beta | Play requirement |
|---|---|---|---|---|
| AGP | 9.3.2 (`gradle/libs.versions.toml`) | 9.4.0 (needs Gradle 9.6.0, JDK 17, max API 37) (G-AGP) | — | none |
| Gradle wrapper | 9.5.0 | 9.6.0 required only by AGP 9.4 | — | none |
| Kotlin + Compose compiler plugin | 2.3.21 | 2.4.20 (2026-09-07) (G-KT) | — | none |
| Compose BOM | 2026.08.00 (material3 1.4.0, ui 1.12.0) | 2026.08.00 (G-BOM) | — | none |
| material3-adaptive | not used | 1.3.0 (G-M3A) | 1.4.0-alpha02 | none |
| androidx.window | not direct (1.5.0 present in the Gradle cache only) | 1.5.1 (G-WIN) | 1.6.0-alpha05 | none |
| compileSdk | `release(37)` | 37 (Android 17 stable) | 37.1 QPR1 beta | none |
| targetSdk | 36 | 37 | — | ≥36 since 2026-08-31 (G-TARGET); no 37 date published |
| minSdk | 24 | keep (policy `preserve_current_shipped_floor…`) | — | — |
| JDK | source/target 17; Studio JBR 25.0.2; Studio 2026.1 | — | — | — |
| SDK platforms installed | android-24 (rev 3), android-37.0 (rev 2, ext 22); build-tools 36.0.0; platform-tools 37.0.1; emulator 37.1.11 | — | — | — |
| System images / AVDs | images: 24 default, 36 google_apis, 37.1 google_apis_playstore_ps16k. AVDs: DoseWeek_API_24 (pixel), DoseWeek_API_36 (pixel_8), DoseWeek_Store_API_36, Pixel_10_Pro (37.1) | — | — | — |
| Foldable device defs available (`avdmanager list device -c`) | `7.6in Foldable`, `8in Foldable`, `6.7in Foldable`, `pixel_fold`, `pixel_9_pro_fold`, `pixel_10_pro_fold`, `resizable`, `medium_tablet`, `desktop_*` — **no foldable AVD created yet** | — | — | — |

Relevant current code facts:
- Manifest has no `screenOrientation`, `resizeableActivity` or `maxAspectRatio`, and guard `large_screen_violations` (`scripts/check_invariants.py:2502`) forbids adding them.
- `MainActivity` is `singleTask` with no `configChanges`, so recreation is the default path.
- `FLAG_SECURE` toggles on the Activity window (`MainActivity.kt:198-207`), pinned by invariants 2646-2848.
- No `setContentCaptureEnabled` anywhere.
- Widget: Glance text-only, no Image/Bitmap in `features/widget/`.
- Drafts: `SavedStateDraftStore` (`app/DoseWeekDrafts.kt`).
- One-shot system requests: `OneShotRequestEffect` with `rememberSaveable` consumed IDs.
- Navigation: `DoseWeekApp.kt` `when(state.selectedTab)` with the floating tab bar.
- Readable width 700.dp (`designsystem/theme/Dimensions.kt:9`).

### 3.1 Android minimal safe upgrade plan

- **A-U0 — no toolchain bump.**
  - AGP 9.3.2 already compiles `release(37)`; handoff `docs/CURRENT_HANDOFF.md:1324` records compileSdk 37 with targetSdk 36.
  - Do not move to AGP 9.4/Gradle 9.6/Kotlin 2.4.20 inside this work. That is an optional, separate toolchain PR with full `run_ci.sh` and the instrumentation matrix.
- **A-U1 — dependencies (C2), one commit.**
  - `libs.versions.toml`:
    - `material3Adaptive = "1.3.0"`, `window = "1.5.1"`.
    - Libraries `androidx-compose-material3-adaptive` (group `androidx.compose.material3.adaptive`, name `adaptive`), `androidx-window` (`androidx.window:window`), `androidx-window-testing` (`androidx.window:window-testing`).
  - `app/build.gradle.kts`:
    - `implementation(libs.androidx.compose.material3.adaptive)`
    - `implementation(libs.androidx.window)` — direct pin so that main and androidTest resolve to the same 1.5.1 instead of the transitive 1.5.0.
    - `androidTestImplementation(libs.androidx.window.testing)`
  - Do not add `adaptive-layout` / `adaptive-navigation`. The policy-driven Row reuses VM-owned state (hard rule 13); a scaffold navigator would keep state outside the VM.
  - Review for `docs/ARCHITECTURE.md`:
    - AndroidX (hard rule "Prefer AndroidX").
    - minSdk 23 AARs, so no override.
    - Merged manifest must keep `ALLOWED_MANIFEST_PERMISSIONS` exact.
    - `NETWORK_DEPENDENCY_PATTERNS` must stay green.
    - No network or storage.
    - Record `./gradlew :app:dependencies` diff evidence.
- **A-U2 — targetSdk 37 candidate (D25), a separate commit/candidate after A-U1 is green.**
  - Change `targetSdk = 37` only, with no compileSdk change and a new literal `versionCode` if built for upload (hard rule 18).
  - Checklist against G-A17-BEH:
    - Large-screen ignore (already resizable; verify the sw≥600 foldable AVD).
    - `FLAG_SECURE` on Compose Dialog windows. `DialogProperties.securePolicy` defaults to Inherit **at dialog creation**. A lock toggle while a dialog is open is a D29 test. `DialogWindowEffects.kt` is not present on `main` and was referenced only in the handoff history.
    - RemoteViews bitmap limit (text-only widget, so low risk; still run `DoseWeekWidgetRenderTest` on the 37 AVD).
    - Lock-free `MessageQueue`: risk to Espresso/Compose test idling; run the full instrumentation set on API 37.
    - Static-final reflection.
    - BAL `IntentSender` for notification PendingIntents (user tap is allowed; verify).
    - CT/ECH default on the Drive TLS path (verify a real Drive round trip).
    - `ACCESS_LOCAL_NETWORK` (not used).
    - Health Connect/OAuth result paths.
  - Keep the API 24 and 36 matrix; add API 37.
  - Play has no 37 deadline, so ship target 37 only after D25 evidence.
- **A-U3 — foldable AVD (owned).**
  - Create `DoseWeek_Fold_API_37` from device `pixel_9_pro_fold` or `7.6in Foldable`.
  - Image options: the installed `android-37.1;google_apis_playstore_ps16k` (a QPR1 beta image, so record it as beta), or install `system-images;android-37;google_apis;arm64-v8a` for the stable 37 image (preferred for evidence).
  - Plus `DoseWeek_Resizable_API_37` from device `resizable`.
  - New owned runner `scripts/run_adaptive_matrix.sh`: sources `scripts/lib/host_resource_guard.sh`, has a fixed serial/port distinct from 24/36, owned cleanup only (rule 19).

Android migration risks:
- The transitive window 1.5.0 → 1.5.1 upgrade.
- Configuration cache with new dependencies.
- API 37 `MessageQueue` affecting tests.
- Compose Dialog secure-flag inheritance.
- 16 KB page-size image (native libs: none).
- Emulator posture APIs are emulator-provided, so they are `runtime_posture` evidence, not physical.

---

## 4. Adaptive layout plan (C2 both platforms)

### 4.1 Shared rules (normative)

1. Inputs come from the **current app window**, never from the screen or device model:
   - iOS: SwiftUI container size via `onGeometryChange(for:)` on the root, safe-area insets, `@Environment(\.horizontalSizeClass)`, `\.layoutDirection`, `\.dynamicTypeSize.isAccessibilitySize`.
   - Android: `currentWindowDpSize()`, `currentWindowAdaptiveInfo().windowSizeClass`, `WindowInsets.safeDrawing` (dp), `LocalLayoutDirection`, font scale ≥ 1.5 as `largeText`, and `collectFoldingFeaturesAsState()` with bounds converted px→dp through `LocalDensity`.
   - Ban `UIScreen.main`, `userInterfaceIdiom` for layout, `isTablet`, model allowlists and first-orientation snapshots.
2. `systemWidthCompact`:
   - iOS: `horizontalSizeClass == .compact`.
   - Android: `!windowSizeClass.isWidthAtLeastBreakpoint(WindowSizeClass.WIDTH_DP_MEDIUM_LOWER_BOUND)`.
3. Features (hinge/fold):
   - Android: `FoldingFeature` list.
   - iOS: **empty list** until the 27.1 SDK is verified. Then map `reservedRegions(kind: .division)` active regions to `{orientation by aspect, isSeparating: true, occlusion: "none"}` and `.occlusion` regions to avoid rects only. Mapping to be confirmed against real SDK declarations.
4. Modes: `single`, `listDetail` (History, Body), `twoColumn` (Today), and always `single` for Settings, Record/edit sheets and Onboarding. Settings keeps its existing readable width (700).
5. IME never changes mode or `compactHeight`. Existing `imePadding`/safe-area handling keeps actions reachable (D11).
6. Layout events never call save, permission, consent, export, restore, HealthKit/Health Connect or Drive. They never change draft identity, request IDs or generation (`windowStateMustNotMutate` in the contract).
7. No fake hinge: a non-separating flat crease (Galaxy Z Fold flat) is ignored for layout. A **vertical** separating or fully occluding hinge is split at, or produces `single` when a side is too narrow; panes never straddle a vertical hinge.
8. Horizontal hinge (tabletop, Q2-A): columns are **not** split and scrolling content (`List`/`LazyColumn`/`ScrollView`) may pass across it; that is acceptable because the user scrolls it off the fold. `avoidRects` from a horizontal feature bind **only fixed chrome**: the floating tab bar, sticky/pinned action rows (save/cancel, record/skip), bottom bars and IME accessory rows. Such an element whose frame intersects an avoid rect (bounds inflated by 8 units above and below for zero-height hinges) is moved to the nearest side that keeps it fully on screen, preferring below. Save/cancel behind the fold is a failure (spec Android C2). Covered by L06 plus device tests in §5 D09.
9. Navigation chrome stays the approved floating tab bar (DESIGN-20260913-13), **conditional on D20**: see Q1. If the 27.1-SDK Duo probe shows the floating bar overlapping the vertical system bars or side space, Q1 falls back to B for that environment (spec iOS C2 bullet 3).
10. Narrow list/detail stays **inline** (Q5-A): `single` on History/Body renders the existing one-screen layout; selecting a day or metric never pushes a detail screen and the pane layer never intercepts back.

### 4.2 Algorithm (identical to `adaptive_layout_fixture_v2.reference.py`)

```
constants: minList=320 (largeText 400), minDetail=360, twoPane=680 (largeText 800), listFraction=0.4, listMax=420,
           twoColumn=840, minColumn=360, compactHeightBelow=480
x0=insets.left; x1=width-insets.right; uw=x1-x0; uh=height-insets.top-insets.bottom
features' = input features minus those entirely outside [0,width]x[0,height]
            (zero-width vertical at x<=0 or x>=width, zero-height horizontal at y<=0 or y>=height also dropped); bounds clipped
avoidRects = bounds of features' with isSeparating || occlusion=="full"
vsep = features' vertical && (isSeparating || occlusion=="full") && left>x0 && right<x1  (first one)
compactHeight = uh < 480 ; ignoredFeatureCount = |features| - |features'|
if systemWidthCompact or screen in {settings, record, onboarding}: single
history/body: if vsep: leftW=h.left-x0, rightW=x1-h.right; listSide = LTR?left:right
                 if listSideW>=minList && otherW>=minDetail: listDetail(split=hinge) else single
              elif uw>=twoPane: listW=clamp(floor(uw*0.4), minList, 420); detailW=uw-listW (>=360) -> listDetail(proportional)
              else single
today:        if vsep: both sides>=360 && uw>=840 -> twoColumn(hinge) else single
              elif uw>=840: a=floor(uw/2) -> twoColumn(proportional) else single
startPane = list/primary column (left in LTR, right in RTL); endPane = detail/secondary
```

Pane reducer, v2 (`AdaptivePaneState {mode, selectionKey, focusedItemId, generation, draftToken, pendingSaveRequestId}`):

- `selectionKey` is per screen and mirrors the **existing** VM selection. It is never a record id.
  - History: ISO day `yyyy-MM-dd` ⇄ iOS `HistoryViewModel.selectedDate` (non-optional `Date`, `HistoryViewModel.swift:12`) / Android `historySelectedDate` (`DoseWeekViewModel.kt:439`). Always non-null.
  - Body: metric key, an opaque per-platform string. iOS `SelectedMetric.rawValue` (`weight|bmi|bodyFat|leanMass|waist`, `BodyViewModel.swift:38`). Android `BodyMetricUi` (`WEIGHT, WAIST, HEIGHT, BODY_FAT, LEAN_BODY_MASS`, `DoseWeekUiModels.kt:713`) maps as `WEIGHT→weight`, `WAIST→waist`, `BODY_FAT→bodyFat`, `LEAN_BODY_MASS→leanMass`, `HEIGHT→height`. The metric sets differ (iOS `bmi`, Android `height`), so the fixture uses only `weight`/`waist`, which exist on both. The reducer never validates the key. Always non-null.
  - Today: `null`.
- `focusedItemId` is optional and mirrors the existing routed/highlighted record focus: iOS `focusedMissedOccurrenceID` (`HistoryViewModel.swift:55`); Android `historyFocusedOccurrenceId`/`historyFocusedSideEffectId`/`historyFocusedAdministrationId` (`DoseWeekViewModel.kt:442` area). Body/Today: always `null`.

| Event | Effect |
|---|---|
| `layout(mode)` | set mode only |
| `select(key)` | selectionKey=key. Nothing else (no column, no push). |
| `focus(id)` | focusedItemId=id |
| `back` | **never consumed** by the pane layer (Q5-A); no state change. System/tab back behaves exactly as today. |
| `recordDeleted(id)` | if id==focusedItemId → focusedItemId=null. `selectionKey` is **not** changed (a day or metric is not a record, so it cannot be resurrected). |
| `generationBumped(selectionKeyAfterReset)` | delete-all / restore: generation+1; focusedItemId, draftToken, pending → null; selectionKey = the value the platform's **existing** reset produces, passed in. Android today resets to `LocalDate.now(clock…)` (`DoseWeekViewModel.kt:6627-6632`, which also nulls the three focused ids); iOS passes its current `selectedDate` unless its existing reset changes it. Fixture pins `2026-09-15`; product uses Clock. |

`draftToken`/`pendingSaveRequestId` are pass-through probes. The real draft and save engines stay the existing ones (iOS `RecordFlowViewModel`, Android `DoseWeekDrafts` / `OneShotRequestEffect`).

Rendering rule (normative on both platforms):
- `single` renders the **existing** one-screen layout, unchanged:
  - iOS History: `NavigationStack { List { calendarSection; daySection; insightSection } }` (`HistoryView.swift:57-66`). iOS Body: the existing `NavigationStack`.
  - Android History: `CalendarCard`, then the selected-day label and items inline (`HistoryScreen.kt:140-175`). Android Body: existing column.
- `listDetail` renders two panes from the same VM state.
  - iOS: **container swap by policy mode.** `single` → the existing `NavigationStack`; `listDetail` → `NavigationSplitView(columnVisibility: .constant(.all), sidebar:detail:)` with `.navigationSplitViewStyle(.balanced)` and sidebar `.navigationSplitViewColumnWidth(startPane.width)` (all in the iOS 26.5 SDK SwiftUI swiftinterface `arm64e-apple-ios.swiftinterface`: `init(columnVisibility:sidebar:detail:)` at line 19937, `NavigationSplitViewVisibility.all` at 19962, `navigationSplitViewColumnWidth(_:)` at 299, `.balanced` at 1667). `preferredCompactColumn` is **not** used: `listDetail` is only produced when `systemWidthCompact == false`, so the split view is never collapsed, and regular-width windows below the threshold (fixture L08 600, L10 679, L11 740 large text) get the `NavigationStack` instead of a split view that would always show both columns.
  - Android: a `Row` of two panes sized from the result (dp).
- State survives the swap because selection lives in the VM, never in `@State`/`remember` keyed by width. Scroll context (D03): each container restores position by anchoring to the selected day's section (iOS `ScrollViewReader.scrollTo(selectedDayID, anchor: .top)` on appear, `SwiftUI.swiftinterface:18272`; Android `LazyListState` hoisted in the VM-scoped holder, or `animateScrollToItem` on the selected-day index). Sheets (`.sheet` record edit, export, visit prep) stay attached **outside** the swapped container so a swap never dismisses or duplicates them.

State machine (per list-detail screen, v2):

```mermaid
stateDiagram-v2
    [*] --> Single
    Single --> Single: select(key) / focus(id) / back (not consumed) / recordDeleted / generationBumped
    Single --> ListDetail: layout(listDetail)
    ListDetail --> Single: layout(single) [selectionKey, focusedItemId kept]
    ListDetail --> ListDetail: select(key) / focus(id) / back (not consumed) / recordDeleted / generationBumped
```

### 4.3 Screen mapping

| Screen | single (compact/narrow) | wide |
|---|---|---|
| Today | existing single column | `twoColumn`: start = next-dose/schedule card and the **only** record/skip actions + backup/missed notices; end = remaining-amount estimate, side-effect summary, inventory. No duplicated save/record buttons. No empty card: if the end column has no card, fall back to single. |
| History | existing one-screen calendar + inline day section + insight (no push, no pane back; Q5-A) | `listDetail`: start = calendar + insight section; end = selected day items + edit/audit entry. `selectionKey` = ISO day (always present; existing default today). `focusedItemId` = existing routed record focus (optional). The record edit sheet stays a sheet. |
| Body | existing one-screen layout (metric chips inline; Q5-A) | `listDetail`: start = metric selector + period + entry CTA; end = chart + samples. `selectionKey` = metric raw key (iOS `SelectedMetric`, Android `BodyMetricUi`). |
| Settings / backup / restore | existing readable column | unchanged (readable 700); restore preflight identical |
| Record/edit/side-effect/onboarding sheets | existing | sheet width capped by existing readable measure; keep safe-area/IME handling; no split |

### 4.4 iOS file ownership

| File | Change | Owner lane |
|---|---|---|
| `DoseDay/DesignSystem/Adaptive/AdaptiveLayoutPolicy.swift` (new) | `import Foundation` only: `AdaptiveLayoutInput`, `AdaptiveLayoutResult`, `AdaptiveLayoutPolicy.resolve(_:)`, `AdaptivePaneState`, `AdaptivePaneEvent`, `reduce`. Codable to match the fixture keys. | ios-adaptive-core |
| `DoseDay/DesignSystem/Adaptive/AdaptiveLayoutReader.swift` (new) | SwiftUI `ViewModifier`/`EnvironmentKey`: root `onGeometryChange` + size class + safe area + layoutDirection + `dynamicTypeSize.isAccessibilitySize` → `\.adaptiveLayout` environment value. `features = []`. | ios-adaptive-core |
| `DoseDay/Features/Navigation/MainTabView.swift` | apply reader once at the TabView root; floating bar unchanged (capped at `ReadableMeasure.maximumWidth` in single; spans the start pane only when wide is **not** done — keep existing overlay cap) | ios-adaptive-ui |
| `DoseDay/Features/History/HistoryView.swift`, `HistoryViewModel.swift` | **Precondition:** `7e8681b` present, no foreign dirty edits (header note). Container swap per §4.2 rendering rule: `single` → existing `NavigationStack { List {…} }` untouched; `listDetail` → `NavigationSplitView(columnVisibility: .constant(.all))`, sidebar = calendar+insight, detail = day section. Extract `calendarSection`/`daySection`/`insightSection` so both containers reuse them (no copy). Move the `.sheet`/`.alert` modifiers to the outer view above the swap. `selectedDate` and `focusedMissedOccurrenceID` unchanged in type/meaning. Accessibility identifiers `history.container.single` / `history.container.split` for tests. | ios-adaptive-ui |
| `DoseDay/Features/Body/BodyView.swift`, `BodyViewModel.swift` | same container-swap pattern, `selectedMetric` unchanged; identifiers `body.container.single` / `body.container.split` | ios-adaptive-ui |
| `DoseDay/Features/Today/TodayView.swift` | `twoColumn` HStack of existing cards when policy says so; single action group | ios-adaptive-ui |
| `DoseDay/Features/AppShell/AppLockController.swift` | no change while multi-scene=false. Add a unit/UI test that the shield window covers the foreground scene after a size change (D12). If Q3 enables scenes: shield per `UIWindowScene`. | ios-security |
| `DoseDay/Resources/Info.plist` | no change (Q3, Q4) | — |
| `DoseDayTests/AdaptiveLayoutPolicyFixtureTests.swift` (new) | loads the fixture; asserts every layoutCase with `"ios"` in platforms + all transitionCases | ios-adaptive-core |
| `DoseDayTests/AdaptiveContainerSelectionTests.swift` (new) | pure mapping test: `AdaptiveLayoutResult.mode` → container kind (`.stack`/`.split`) for fixture L08 (600, regular), L09 (680), L10 (679), L11 (740 large text), L12 (820 large text) with `systemWidthCompact=false`; asserts 600/679/740 → `.stack`. The container kind is a small `enum` next to the policy so the test needs no view hosting (static_spec). | ios-adaptive-core |
| `DoseDayTests/Fixtures/AdaptiveLayout/adaptive_layout_fixture_v2.json` (new, byte copy) | add `tests_root / "Fixtures" / "AdaptiveLayout"` to `resource_folders` in `scripts/generate_project.py:49`, then run `python3 scripts/generate_project.py` | ios-adaptive-core |
| `DoseDayUITests/AdaptiveLayoutUITests.swift` (new) | iPad portrait/landscape (existing `OrientationUITests` pattern) + iPhone: selection survives rotation, record draft survives rotation, lock shield on background; `run_app_ui_tests.sh --device ipad` / `--ax5`. **Regular-width ~600 pt window:** XCUITest cannot resize an iPad window, so add launch argument `-uitest-adaptive-width 600` (same `-uitest-*` pattern as `HistoryViewModel.swift:718` / `BodyMapDisplayPreferences.swift:56`, read only when UI-testing) that makes the reader clamp its measured width to 600 while keeping the real `horizontalSizeClass` (`.regular` on iPad full screen). Test `testRegularWidth600UsesSingleStack`: iPad full screen + arg → `history.container.single` exists, `history.container.split` absent, selecting a day keeps the day section inline (no back button), then relaunch without the arg → `history.container.split`, same selected day (simulator_runtime). A real Stage Manager resize to ~600 pt stays a manual owned-sim check (D10). The guard must forbid reading this argument outside the reader. | ios-adaptive-ui |
| `scripts/check_invariants.py` | new guard `check_adaptive_layout_sources`: `AdaptiveLayoutPolicy.swift` imports Foundation only; forbid `UIScreen.main` in `DoseDay/`; allowlist the existing `userInterfaceIdiom` keyboardType use (`RecordFlowView.swift:558`), forbid new ones; forbid Duo-only symbols (`reservedRegions`, `ArrangementView`, `onHingeChange`, `defaultTabBarPlacement`) in target sources until a verified 27.1 lane flips the guard; red+green fixtures | ios-guards |
| `docs/ARCHITECTURE.md`, `docs/iphone-duo/README.md` (new) | module entry + Duo research status | ios-docs |

### 4.5 Android file ownership

| File (`app/src/main/java/com/wonyoungchoi/doseweek/…` unless rooted) | Change | Owner lane |
|---|---|---|
| `gradle/libs.versions.toml`, `app/build.gradle.kts` | A-U1 deps | android-deps |
| `designsystem/adaptive/AdaptiveLayoutPolicy.kt` (new) | pure Kotlin (no Compose/Android import): data classes + `resolve` + `reduce` | android-adaptive-core |
| `designsystem/adaptive/AdaptiveWindowInputs.kt` (new) | `@Composable fun rememberAdaptiveLayoutInput(screen)`: `currentWindowDpSize()`, `currentWindowAdaptiveInfo().windowSizeClass`, `collectFoldingFeaturesAsState()`, `WindowInsets.safeDrawing`, density, layoutDirection, fontScale | android-adaptive-core |
| `features/navigation/DoseWeekUiModels.kt` | `AdaptivePaneUiState(mode)` for HISTORY/BODY/TODAY in `DoseWeekUiState`; `DoseWeekUiAction.PaneLayoutChanged(screen, mode)` only. Selection keeps the existing actions (calendar day tap, `SelectBodyMetric`); no new select/back action. | android-adaptive-ui |
| `app/DoseWeekViewModel.kt` | existing `historySelectedDate`/focused ids/metric remain the source of truth; the reducer is applied as a pure mirror so the fixture pins their layout-independence; `generationBumped` maps onto the existing delete-all reset (`:6627-6632`) and restore success | android-adaptive-ui |
| `app/DoseWeekDrafts.kt` | **no change needed** for Q5-A: `historySelectedDate`, focused ids and metric already survive via existing state; mode is recomputed from the window. Only if an existing field is found not to survive `ActivityScenario.recreate()` (D03 test) add a **nullable** field (Java deserialization leaves missing fields null) and keep `serialVersionUID` | android-adaptive-ui |
| `features/navigation/DoseWeekApp.kt` | pass inputs. **No `BackHandler`** (none exists in `app/src/main/java` today; Q5-A keeps it that way). | android-adaptive-ui |
| `features/history/HistoryScreen.kt`, `features/body/BodyScreen.kt`, `features/today/TodayScreen.kt` | `single`: existing column untouched. `listDetail`/`twoColumn`: Row of panes sized from the result (dp), `Modifier.semantics { paneTitle = … }`. Avoid rects per §4.1 rule 8: fixed action rows, tab bar and bottom bars never intersect `avoidRects`; scrolling content may. Hoist the pane `LazyListState`/`ScrollState` above the `single`/`listDetail` branch so a swap keeps scroll. | android-adaptive-ui |
| `app/src/test/java/com/wonyoungchoi/doseweek/designsystem/adaptive/AdaptiveLayoutPolicyFixtureTest.kt` (new) + `app/src/test/resources/adaptive/adaptive_layout_fixture_v2.json` (byte copy) | parse with the existing hand-written codec in `data/drive/DriveJson.kt` if its API fits; else a test-only minimal parser (no new JSON dependency) | android-adaptive-core |
| `app/src/androidTest/java/com/wonyoungchoi/doseweek/features/navigation/AdaptiveLayoutDeviceTest.kt` (new) | `DeviceConfigurationOverride.ForcedSize` (already used by `LocalizationLayoutTest`) for 344/600/680/820/1024 dp; `WindowLayoutInfoPublisherRule` + `DisplayFeatureTesting.createFoldingFeature(Rect,…)` for mock book/tabletop (`mock_posture` proof); draft/selection survive `ActivityScenario.recreate()` | android-adaptive-ui |
| `scripts/run_adaptive_matrix.sh` (new) | owned Fold/resizable API 37 AVDs | android-ci |
| `scripts/check_invariants.py` | forbid `Build.MODEL`/`Build.MANUFACTURER`/`isTablet`/`screenWidthDp` for layout outside `designsystem/adaptive/`; the adaptive policy file must not import `android.`/`androidx.`; red+green fixtures | android-guards |
| `docs/ARCHITECTURE.md` | dependency review + adaptive module | android-docs |

### 4.6 Data model / migration / backup impact

- iOS: no SwiftData schema change (stays `DoseDaySchemaV5` = `CurrentDoseDaySchema`, `DoseDaySchema.swift:414`; migration plan V1→V5 untouched). No backup payload change. No `AppPreferences` key. Pane state is VM memory.
- Android: no Room/DB version change. No backup payload change (Backup8). No preference. `DoseWeekDrafts` gains nullable saved-instance-state fields only. That is not persistent storage, and it keeps the privacy boundary.
- The contracts `adaptive_device_contract_v1.json` and the nutrition JSONs are unchanged. The new fixture is a test resource, not a data contract.

### 4.7 Edge cases (each must have a test)

1. Resize across 680 while the record sheet is open: the sheet and its draft stay, and there is no second sheet (T02, D04).
2. Save committed then fold: the result screen is shown once and there is no retry save (existing request ID; D06).
3. Delete-all while wide with a focused record: focus, draft and pending cleared; day set to the platform's existing reset value; nothing resurrected (T04, D13).
4. Edit a record open in the detail pane that is then deleted from another entry point: the stale editor keeps its input and needs reopening (existing DB11/revision rules). Record focus clears; the selected **day stays** (T03). No new day-reset behaviour.
4a. Phone History/Body: tapping a day or metric keeps the existing inline screen, and back is not intercepted (T01, T05, T07; Q5-A).
4b. iPad regular window at ~600 pt: `NavigationStack`, not a split view (L08, `testRegularWidth600UsesSingleStack`).
4c. Container swap `single`⇄`listDetail` with an open record edit sheet or export sheet: the sheet stays and is not re-presented; the selected day stays in view (D03/D04).
5. A split-screen window of 370dp on an unfolded device: single (L07, D10).
6. An RTL Arabic wide window: list on the right (L13/L26, D14).
7. Accessibility text at 740: single (L11, D15).
8. Landscape short height 387: `compactHeight`, scrollable actions (L14, D08).
9. A separating vertical hinge off-centre: single, never straddling (L25).
9a. Tabletop (horizontal hinge): lists scroll across the fold, but save/cancel, record/skip rows and the floating tab bar sit fully off the avoid rect (L06; §4.1 rule 8).
10. Feature bounds outside the window: ignored (L17).
11. Lock engages while wide: the shield covers the full window. FLAG_SECURE on an open dialog is a separate check (D12/D29).
12. Backup file picker open during resize:
    - Android: consumed ID survives recreation (existing `OneShotRequestEffect`).
    - iOS: `fileExporter`/`fileImporter` binding lives on SettingsView state, which is not re-keyed by width (D07).
13. Health Connect or Drive consent in flight during a fold: result delivered once (D30).
14. Process death with a pane in detail (Android): restored from drafts. iOS process-death retention is governed by pending RECORD-DRAFT-PROCESS-EXIT and is not decided here.
15. Repeated resize: one reader and one geometry observer at the root, not per row; memory stays flat (D17).

### 4.8 Localization keys (17 locales: ko, en, ja, de, fr, es, it, nl, pt-PT, pl, sv, hi, pt-BR, ar, zh-Hans, zh-Hant, tr)

The work is structural; no visible new copy is required. The only new keys are pane accessibility titles, which TalkBack/VoiceOver announce on pane change.

| iOS key (`Localizable.xcstrings`) | Android key (`res/values*/strings.xml`) | en | ko |
|---|---|---|---|
| `history.a11y.paneCalendar` | `history_a11y_pane_calendar` | Calendar | 달력 |
| `history.a11y.paneDay` | `history_a11y_pane_day` | Selected day records | 선택한 날짜 기록 |
| `body.a11y.paneMetrics` | `body_a11y_pane_metrics` | Measurements | 신체 기록 항목 |
| `body.a11y.paneDetail` | `body_a11y_pane_detail` | Measurement details | 신체 기록 상세 |

Names follow the existing `<screen>.a11y.<camelCase>` (iOS: `history.a11y.hasRecord`, `today.a11y.dday`) and `<screen>_a11y_<snake>` (Android: `history_a11y_has_record`) patterns.

- **No back key is needed.** Q5-A adds no push, so there is no custom back control. The iOS `NavigationSplitView` is only shown uncollapsed, and any system back is system-localized. The iOS catalog has **no** `common.back` (824 keys; only `onboarding.back`), so none is reused or added. If the owner picks Q5-B, use the system `NavigationStack` back on iOS (no key); on Android a visible top-bar back icon reuses the existing `common_back` (`res/values/strings.xml:4`) as its contentDescription.
- The other 15 locales come through the existing localization workflow (`prepare_help_localizations.py`-style), with human review. Android base `values/` is Korean.
- The iOS invariants require every `REQUIRED_LOCALES` entry.

---

## 5. D01–D30 mapping

Proof kinds: `static_spec`, `geometry_preview`, `mock_posture`, `simulator_runtime`, `physical_device`, `remote_physical_device`, `real_model`. The fixture tests are `static_spec`/`geometry_preview`, never device PASS.

| ID | iOS executable test (proof kind) | Android executable test (proof kind) | Blocked / notes |
|---|---|---|---|
| D01 | `AdaptiveLayoutUITests.testNarrowFirstLaunchReachesAllSections` on iPhone 17e (smallest sim) standard+AX5; reuse `canReachAllSections` (simulator_runtime) | `AdaptiveLayoutDeviceTest.firstLaunchAt344dp` ForcedSize 344×882 (geometry_preview) + Fold AVD outer display (simulator_runtime) | Duo outer display BLOCKED (no Duo sim) |
| D02 | Fixture L09/L18/L23 + iPad Pro 13" landscape UI test: History/Body split visible, single record button (simulator_runtime) | Fixture + ForcedSize 1024×768 + Fold AVD unfolded (simulator_runtime) | Duo inner BLOCKED |
| D03 | Fixture T01/T03/T05/T07 + `AdaptiveContainerSelectionTests` + iPad rotation test preserving `selectedDate`, the selected-day section on screen and an open edit sheet across the stack⇄split swap; `testRegularWidth600UsesSingleStack` (simulator_runtime) | Fixture + ForcedSize change 600→820→600 asserting `historySelectedDate`, focused id, visible selected-day item and no `BackHandler` interception + `ActivityScenario.recreate` (geometry_preview) + AVD fold/unfold (simulator_runtime) | — |
| D04 | `RecordFlowUITests` extension: type dose, rotate iPad; assert same field values, zero new events (simulator_runtime) | `DraftPersistenceViewModelTest` + new fold during record dialog on Fold AVD; assert 1 draft, 0 commits (simulator_runtime) | process-death leg iOS depends on pending RECORD-DRAFT-PROCESS-EXIT |
| D05 | BLOCKED until the nutrition/meal feature lands in the tree (not on this branch); keep the row and add when meal editor exists | same | not NOT_APPLICABLE; BLOCKED on feature presence |
| D06 | unit: `AdministrationRecordingOutcomeTests` + UI rotate after save tap; count events == 1 (simulator_runtime) | `AdministrationEditConcurrencyViewModelTest` + recreate between request and result (geometry_preview) | — |
| D07 | UI: open export options then rotate iPad; restore sheet drafts kept (`AuditBackupPreviewUITests` pattern) (simulator_runtime) | `BackupFlowViewModelTest` + recreate while SAF launched (existing consumed-ID) on AVD (simulator_runtime) | real cloud file provider not tested |
| D08 | Fixture L14 + UI AX5 iPhone landscape is impossible (portrait-only) → iPad Slide Over not scriptable; use iPad landscape + keyboard (simulator_runtime) | ForcedSize 914×411 + `DialogKeyboardTest` pattern (geometry_preview) | Duo occlusion regions BLOCKED |
| D09 | Fixture only (iOS features=[]) (static_spec) | Fixture L03-L06,L16,L22,L25 (static_spec) + `WindowLayoutInfoPublisherRule` book/tabletop (mock_posture): `tabletopKeepsFixedActionsOffHinge` injects one horizontal separating `FoldingFeature` at the vertical middle; asserts that the record dialog save/cancel row, the Today record/skip row and the floating tab bar `boundsInRoot` do not intersect the avoid rect inflated by 8 dp above and below, while the History list may + Fold AVD posture controls (simulator_runtime) | iOS runtime posture BLOCKED (27.1 SDK); physical BLOCKED |
| D10 | iPad Split View resize is not scriptable in XCUITest → manual owned-sim inspection per VERIFY-20260913-11, recorded window bounds (simulator_runtime/manual) | Resizable AVD + `adb shell wm size` on owned serial / freeform; fixture L07 (simulator_runtime) | — |
| D11 | `AuditRecordInputUITests` + rotation with keyboard up (simulator_runtime) | `DialogKeyboardTest` on API 37 + Fold AVD (simulator_runtime) | external keyboard: sim hardware keyboard only |
| D12 | `AppLockPhaseMachineTests` + UI background→foreground after rotation; screenshot shield (simulator_runtime) | lock + recents on Fold AVD, FLAG_SECURE assert via `WindowManager.LayoutParams.flags` in test (simulator_runtime) | — |
| D13 | `HistoryViewModelTests` stale callback + record deleted while focused keeps `selectedDate` + fixture T03/T04 (static_spec+unit) | `HistoryCorrectionViewModelTest`, `AdministrationEditSnapshotRepositoryTest` + fixture (unit) | — |
| D14 | `LocalizationLayoutUITests` extended with iPad wide for the fold/resize deep path ko/en/ja + long Latin (de) + ar/hi/zh-Hant/tr (spec line 184), remaining locales pairwise with exclusion reasons in the ledger (simulator_runtime) | `LocalizationLayoutTest` parameterize 17 locales × {360, 840}dp (geometry_preview) | full 17 × posture product not required (spec) |
| D15 | VoiceOver audit via `XCUIApplication.performAccessibilityAudit` on iPad wide + AX5 (simulator_runtime) | `TalkBackSemanticsTest` + paneTitle semantics at 1024dp (geometry_preview) | real VoiceOver/TalkBack device listening: manual |
| D16 | `run_ci.sh` full (3 legs) unchanged + `CI_IOS_MAJOR=27` rehearsal (simulator_runtime) | `run_instrumentation_matrix.sh` API 24/36 + new API 37 leg (simulator_runtime) | — |
| D17 | Instruments Allocations over 50 rotations (manual owned sim), assert one reader (simulator_runtime) | macrobenchmark-free: `dumpsys meminfo` on owned serial before/after 50 folds (simulator_runtime) | — |
| D18 | Fixture features=[] path + AI unavailable path (`AIFakes`) (unit) | Fixture with no features + API 24 AVD (no WindowManager extensions) (simulator_runtime) | — |
| D19 | `DEVELOPER_DIR=…Xcode-27.app … xcodebuild build` Release/RecordOnlyFallback/widgets (native_build) | n/a (ios row) | **BLOCKED**: Xcode 27 not installed (owner download) |
| D20 | Duo probe compile + Device Hub run (duo_runtime) | n/a | **BLOCKED**: Xcode 27.1 beta / iOS 27.1 SDK not released (A-DUO, 2026-09-15) |
| D21 | physical Duo transitions | n/a | **BLOCKED**: hardware available 2026-10-23 at earliest; none owned |
| D22 | multi-scene false: test that `UIWindowSceneActivationAction` is never offered and the shield uses the foreground scene (unit/UI); if Q3→enable, per-scene lock tests | n/a | Duo multi-window runtime BLOCKED |
| D23 | real model during rotate/lock/edit: request generation cancel (`NaturalLanguageEntryViewModelTests` fakes = static; device = real_model) | n/a | **BLOCKED** real_model: no Apple Intelligence device recorded; Duo fold leg BLOCKED |
| D24 | archive ledger: `xcodebuild -showBuildSettings`, `codesign -d --entitlements`, `MinimumOSVersion`; no upload | n/a | depends on D19 |
| D25 | n/a | `./gradlew bundleRelease` target 37 + merged manifest diff + matrix 24/36/37 (native_build) | NOT_RUN; stable 37 system image not installed (37.1 beta image only) |
| D26 | n/a | `WindowLayoutInfoPublisherRule` (mock_posture) vs Fold AVD real `WindowInfoTracker` stream (simulator_runtime); none-provided on API 24/36 phone AVD | physical BLOCKED |
| D27 | n/a | physical Galaxy Z Fold | **BLOCKED**: no approved device; Remote Test Lab requires separate owner approval for APK/account (spec) |
| D28 | n/a | `ActivityScenario.recreate` + `adb shell am kill` on owned serial with drafts; lock resume after screen off on Fold AVD | cover-screen continuity settings physical BLOCKED |
| D29 | n/a | target 37 `DoseWeekWidgetRenderTest` + FLAG_SECURE on dialog opened before lock toggle (simulator_runtime) | — |
| D30 | n/a | Fold AVD with Health Connect fixture (`hc-native-fixture`) + Drive fake transport; fold mid-operation; assert single upload/ grant retained (simulator_runtime) | real Drive account round trip = owner manual |

Common rows D01–D18 run on both platforms. iOS Duo/foldable-specific evidence is BLOCKED, never NOT_APPLICABLE.

---

## 6. Shared behaviour fixture

- Path in this folder: `adaptive_layout_fixture_v2.json`.
- Copy byte-identically to:
  - iOS `DoseDayTests/Fixtures/AdaptiveLayout/adaptive_layout_fixture_v2.json`
  - Android `app/src/test/resources/adaptive/adaptive_layout_fixture_v2.json`
- Both tests assert SHA-256 `c4741a317036e6fe323d75b879ed7e09d61b1e04532f6ec52d4a80be2013104c` before evaluation. The format is `json.dumps(sort_keys=True, indent=2, ensure_ascii=False)` plus a trailing LF.

Schema:
- `constants`
- `policy`: `navigationChrome` (`floatingTabBar_pendingD20OverlapCheck`), `tabletop` (`avoidHingeOnly`), `tabletopAvoidRectsApplyTo` (`fixedActionRowsAndBarsOnly`), `narrowListDetail` (`inline`, Q5-A), `singleContainerIOS` (`NavigationStack`), `listDetailContainerIOS` (`NavigationSplitView`), `imeAffectsMode`, `imeAffectsCompactHeight`, `iosFeatureSource`. Tests assert these literal values so that a changed Q answer forces a fixture bump.
- `layoutCases[]`:
  - `{id, platforms, note, input{screen, window{width,height}, insets{left,top,right,bottom}, systemWidthCompact, largeText, layoutDirection, imeBottom, features[{bounds{left,top,right,bottom}, state, orientation, isSeparating, occlusion}]}, expected{mode, splitSource, startPane{x,width}|null, endPane|null, avoidRects[], compactHeight, ignoredFeatureCount}}`
  - A test runs a case only when its platform is in `platforms`. The iOS feature cases are Android-only until the 27.1 mapping is verified.
- `transitionCases[]`: `{id, platforms, screen, note, initial, steps[{event, expected{state, backConsumed?}}]}`.
  - `state` = `{mode, selectionKey, focusedItemId, generation, draftToken, pendingSaveRequestId}`.
  - Events: `{event:"layout",mode}`, `{event:"select",key}`, `{event:"focus",id}`, `{event:"back"}`, `{event:"recordDeleted",id}`, `{event:"generationBumped",selectionKeyAfterReset}`.
  - T01 History day survives widen/narrow, back not consumed. T02 layout never touches draft/pending. T03 focused record deleted → focus cleared, day kept. T04 generation bump → focus/draft/pending cleared, day = injected reset. T05 Body metric survives, back not consumed. T06 Today churn. T07 phone single with focus: back not consumed, nothing changes.

Summary of expected modes: L01 single, L03 listDetail proportional 320|392, L04 hinge 370|370, L05 single, L06 proportional + tabletop avoid rect, L09 boundary listDetail 320|360, L10 single, L12 large text 400|420, L13 RTL start x=492, L14 compactHeight true, L16 occluding hinge 400 | gap 20 | 400, L17 ignored feature, L18 today 512|512, L22 today hinge, L24/L25 single, L26 RTL hinge list on right.

Changing a threshold or a Q1/Q2/Q5 answer requires `version: 3`, a regenerated fixture and hash, and updates on both platforms in the same change set. (Q5-B would reintroduce a compact column and consumed back.)

---

## 7. Store and legal wording limits

- Do not claim "optimized for iPhone Duo", "Duo-ready", "certified for Galaxy Z Fold" or "works on all foldables" until the matching `DUO_NATIVE_VERIFIED_FOR_RECORDED_ENVIRONMENT` / `GALAXY_FOLD_DEVICE_VERIFIED_FOR_RECORDED_ENVIRONMENT` status exists. Even then, limit claims to the tested model/OS (A-GUIDE 2.3.1(a), G-META).
- Wording allowed after `ADAPTIVE_LAYOUT_VERIFIED_FOR_TESTED_WINDOWS`: generic "Adapts to larger screens, split-screen windows and foldable phones." Release notes may say "Improved layout for larger and resizable windows."
- App Store metadata:
  - No "Galaxy", "Samsung", "Android" or Play imagery (A-GUIDE 2.3.10).
  - "iPhone Duo" only as exact referential use ("for iPhone Duo"), never implying Apple endorsement (A-TM), and only after the device is released and verified.
  - No keyword stuffing with device names (2.3.7).
- Play metadata:
  - No Samsung/Galaxy logos (G-META).
  - The textual "Galaxy Z Fold" name is only allowed as a factual compatibility statement backed by D27 evidence; prefer "foldable phones".
- Screenshots: only real captures from the stated device class (2.3.3, G-META). Do not draw a Duo/Fold device frame before real captures exist. Per spec, do not guess device-specific screenshot sizes before checking the console.
- Apple AI:
  - Keep existing "on-device" claims only while `SystemLanguageModel.default` remains the sole model.
  - Do not advertise AI languages beyond ko/en/ja.
  - Do not say "Apple Intelligence optimized for iOS 27" from a compile alone.
  - Medical: no accuracy/diagnostic claims (1.4.1).
- Internal status words (§spec "출시·최적화 완료") must be used verbatim in handoffs.

---

## 8. Implementation order

1. Android A-U1 dependencies + dependency review + invariants (green).
2. Shared: copy the fixture; implement `AdaptiveLayoutPolicy` on both platforms and the fixture tests (green on JVM and `run_app_unit_tests.sh`).
3. iOS (after `7e8681b` is on the branch): reader + History/Body container swap (`NavigationStack` for `single`, uncollapsed `NavigationSplitView` for `listDetail`, sheets above the swap); Today twoColumn; `-uitest-adaptive-width` hook; guards; pane a11y keys in 17 locales.
4. Android inputs + `PaneLayoutChanged` action + History/Body/Today panes with hoisted scroll state (no BackHandler, no draft field unless D03 recreate proves one missing); tabletop fixed-action placement; guards; keys.
5. Device tests: Android ForcedSize/mock posture; iOS iPad/iPhone UI tests (single `xcodebuild` at a time, Terminal for full CI).
6. Android foldable/resizable AVD runner; D03/D04/D09/D26/D28-D30 runtime legs.
7. Android targetSdk 37 candidate (A-U2) + API 37 matrix leg (D25/D29).
8. iOS Xcode 27 side-by-side compile (D19) + `CI_IOS_MAJOR=27` rehearsal + A2 real model re-test (owner device).
9. When Xcode 27.1 beta ships: Duo probe (D20), fixture v2 for the iOS feature mapping if needed; D21 on hardware after 2026-10-23.
10. Docs: both `ARCHITECTURE.md`, handoffs, verification-manifest tool section (`checkedAtKST/sourceURL/installedVersion/publicVersion/channel/compileSdk/targetSdk/minimumOs/runtime/build/submissionAcceptanceEvidence`).

## 9. Open product questions (facts, two options, recommendation)

- **Q1 — navigation chrome in wide windows.**
  - Facts: approved design uses a floating tab bar (DESIGN-20260913-13). iOS 27.1 offers `.defaultTabBarPlacement(.sidebar)` (A-TT-PREP). Android has NavigationRail.
  - More facts: spec iOS C2 bullet 3 requires a custom floating tab/toolbar to follow the native adaptive structure **if** it overlaps the system's vertical bar layout or side space. A-TT-PREP: "the iOS 27.1 SDK reaches the screen edge and lays standard navigation and toolbar buttons out vertically", and custom bars should use `ReservedRegion` to avoid colliding with system UI.
  - A: keep the floating bar, capped (recommended **for current 26.x/27.0-SDK builds and iPad/Android now**; zero design change). **Conditional on D20:** when the 27.1-SDK Duo probe runs, capture the inner display in closed/open/split poses with the floating bar and record whether it overlaps system vertical bars or side space. Overlap found → B becomes mandatory for 27.1-SDK builds (sidebar placement / `ReservedRegion` placement), without re-asking.
  - B: sidebar/rail when wide (more native on Duo inner/iPad; iOS needs the 27.1 SDK; visual redesign).
- **Q2 — tabletop posture.**
  - Facts: horizontal separating hinge. The spec allows a read/input split but does not require it.
  - A: avoid-hinge only, no split (recommended; fixture v1).
  - B: summary top / controls bottom on Today/History (more work; new layout per screen).
- **Q3 — iOS multiple scenes on Duo.**
  - Facts: `UIApplicationSupportsMultipleScenes=false`. Duo allows two windows of the same app (A-DUO-NEWS). Split View with other apps works regardless.
  - A: keep disabled (recommended; one lock and persistence boundary).
  - B: enable (per-scene shield, concurrent edit revision tests, D22 heavier).
- **Q4 — iPhone orientation plist.**
  - Facts: iPhone is portrait-only. The Duo inner display ignores supported orientations.
  - A: keep portrait-only, with layouts driven by size class (recommended).
  - B: allow landscape on all iPhones (more test surface; `OrientationUITests` extended).
- **Q5 — narrow History/Body: inline one screen or list→detail push.**
  - Facts: today both platforms show History as one screen (iOS `HistoryView.swift:57-66` one `List` with calendar, day and insight sections; Android `HistoryScreen.kt:140-175` calendar card then inline day items) and Body with inline metric chips. Android has no `BackHandler` in `app/src/main/java`. DESIGN-20260913-13: "시각적으로 디자인 유지". UX-20260913-09: keep it simple. The spec's narrow History row (`SDK_AI_FOLDABLE.md:132`) says "목록→상세의 네이티브 back 흐름", and line 74 requires the detail/edit the user was viewing to continue when folding from wide to narrow.
  - A: keep inline on phone and narrow windows (recommended; zero phone UX change; the "detail" the user sees wide, the selected day section and the edit sheet, is still on screen after folding, which satisfies line 74; the design question is kept open for the owner). Fixture v2.
  - B: native list→detail push on narrow (matches the spec row literally; changes phone UX on both platforms; needs a compact column in the reducer, consumed back, Android `BackHandler`, iOS collapsed split or stack push; fixture v3).
- Pending, not re-asked: RECORD-DRAFT-PROCESS-EXIT governs iOS draft retention across process exit (affects the D04/D28 iOS leg only).

---

## 10. Review log (revision 2, 2026-09-15)

Each reviewer finding was re-checked against code/sources at iOS `7e8681b`, Android `79bb210`, the iOS 26.5 SDK swiftinterface and re-fetched tech talks.

| # | Finding | Verdict | Evidence re-checked | Fix |
|---|---|---|---|---|
| 1 | Reducer silently turns phone History/Body into push+back | **Confirmed** | `HistoryView.swift:57-66` one List; `HistoryScreen.kt:140-175` inline; no `BackHandler` in Android main; v1 T01/T05 `backConsumed=true`. Spec line 132 vs DESIGN-20260913-13 → genuinely undecided | Added Q5 (A inline, rec / B push). Reducer v2: `select` sets key only, `back` never consumed. §4.1 rule 10, §4.2, §4.3, §4.5 (BackHandler removed). Fixture v2. |
| 2 | History selection contract contradictory (day vs record id, nil vs non-optional `Date`) | **Confirmed** | `HistoryViewModel.swift:12` non-optional `selectedDate`; focus ids exist separately (iOS `:55`, Android `:442`); Android delete-all resets day to today and nulls focus (`DoseWeekViewModel.kt:6627-6632`) | Split state: non-null `selectionKey` (day/metric) + optional `focusedItemId`. `recordDeleted` clears focus only. `generationBumped` takes the platform's existing reset day. Edge cases 3/4 rewritten. Fixture v2 T03/T04/T07. |
| 3 | iOS `preferredCompactColumn` cannot produce `single` at regular width 600/679/740 | **Confirmed** | swiftinterface 19950/19952 only `columnVisibility`+`preferredCompactColumn` inits; L08/L10/L11 `systemWidthCompact=false` → single | Rule: container swap (`NavigationStack` ⇄ uncollapsed `NavigationSplitView(columnVisibility: .constant(.all))`), selection in VM, sheets above swap, scroll re-anchored. Added `AdaptiveContainerSelectionTests` + `testRegularWidth600UsesSingleStack` via `-uitest-adaptive-width`. |
| 4 | Schema is V5, not V3 | **Confirmed** | `DoseDaySchema.swift:414` | §4.6 fixed. |
| 5 | iOS `common.back` does not exist | **Confirmed** | 0 hits in `Localizable.xcstrings`; `onboarding.back` 1 hit; Android `common_back` at `strings.xml:4` | §4.8: no back key needed under Q5-A; no false reuse claim; Q5-B path stated. |
| 6 | D14 iOS deep path omits en | **Confirmed** | `SDK_AI_FOLDABLE.md:184` 한국어·영어·일본어 + long Latin/ar/hi/zh/tr | D14 iOS row now ko/en/ja + de + ar/hi/zh-Hant/tr. |
| 7 | "Nothing is ever straddled" contradicts L06 tabletop | **Confirmed** | L06 panes span the horizontal hinge; spec line 107 save/cancel behind fold = failure | Rule 7 limited to vertical hinges; new rule 8: horizontal avoid rects bind fixed action rows/bars only; policy key `tabletopAvoidRectsApplyTo`; D09 device test `tabletopKeepsFixedActionsOffHinge`; edge 9a. Layout expectations unchanged. |
| 8 | Q1-A ignores the spec's conditional overlap requirement | **Confirmed** | spec line 66; tech talk 111461 quote re-fetched 2026-09-15 | Q1-A is now conditional on D20 overlap evidence, with B mandatory for 27.1-SDK builds when overlap is found; policy value `floatingTabBar_pendingD20OverlapCheck`; §4.1 rule 9. |
| 9 | Tech talk 111464 does not name `UIApplicationSupportsMultipleScenes` | **Confirmed** | re-fetched https://developer.apple.com/videos/play/tech-talks/111464/ (2026-09-15): only "multiple instances of your app's UI … apps that support this on iPad will too" | Ledger row A-TT-SCENES quotes the talk and attributes the key to repo Info.plist. |
| 10 | HistoryView.swift has uncommitted foreign edits | **Partly confirmed / superseded** | True at `4c3e594`; the 3 dirty files are now committed in `7e8681b` (plus `docs/CURRENT_HANDOFF.md`), `git status` clean, `4c3e594` is an ancestor | Header records the history and a hard precondition (`7e8681b` in branch, stop on new dirty edits); §4.4 row and §8 step 3 repeat it. |
| 11 | a11y key names break naming pattern | **Confirmed** | iOS `history.a11y.hasRecord`, `today.a11y.dday`; Android `history_a11y_has_record` | Renamed to `history.a11y.paneCalendar`/`history_a11y_pane_calendar` etc. (§4.8). |

Rejected findings: none. Layout-case expectations (L01–L27) are byte-identical between v1 and v2. Only the policy block, version and transition cases changed.
