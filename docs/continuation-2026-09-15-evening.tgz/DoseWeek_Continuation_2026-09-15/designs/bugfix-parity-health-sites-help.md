# Bugfix parity — health / sites / help / legal / remaining rows

Scope: HC01–HC12, HK01–HK04, SM01–SM10, VIS01–VIS08, LG01–LG06, BACKUP_FLOW, HEALTH_READ, LEGAL_COPY, APP_BUILD, APP_REGRESSION, PLAY_ASSETS, BUGFIX_PARITY, DL01–DL06, BLOC-* (grouped).
Trees read (read-only): iOS `/private/tmp/doseweek-v11-20260913/ios` branch `codex/v11-bugfix` HEAD `93ae0e2`; Android `/private/tmp/doseweek-v11-20260913/android` main `79bb210`; legal `/private/tmp/doseweek-v11-20260913/legal` (HEAD `cc6fa49` on `candidate/import-guide`, origin/main `f6bd054`).
Paths below: `ios:` = `ios/`, `and:` = `android/app/src/main/java/com/wonyoungchoi/doseweek/`, `res:` = `android/app/src/main/res/`, `legal:` = legal repo. Test names come from source; pass counts come from `requirements-coverage.json` and were not rerun here.
Classes: PARITY_OK · PLATFORM_DIFFERENCE_ALLOWED · DIVERGENCE · UNVERIFIABLE.

## Summary table

| ID | Class | One-line reason |
|---|---|---|
| HC01 | UNVERIFIABLE | android-only. owner phone repro unknown (version, source app, HC visibility). no device/ADB. |
| HC02 | PLATFORM_DIFFERENCE_ALLOWED | android token/range model. iOS counterpart = HK01 latest-N. spec forbids cloning tokens on iOS. |
| HC03 | PLATFORM_DIFFERENCE_ALLOWED | finishing the old range consumes the pending token in the same run (and:data/health/HealthConnectImporter.kt:407-415). iOS anchor model differs by design. |
| HC04 | PLATFORM_DIFFERENCE_ALLOWED | token taken before the read, then consumed. android-only. |
| HC05 | PLATFORM_DIFFERENCE_ALLOWED | MAX_PAGES=500 pause (HealthConnectImporter.kt:358,447,550). partial feed keeps lastSyncedAt (:483-484). iOS cap 4 pages ≈ same bounded idea. |
| HC06 | PLATFORM_DIFFERENCE_ALLOWED | expired token / re-grant is android-only. hide/ID retention same meaning as HK02. |
| HC07 | PARITY_OK | per-type results + copy that doesn't demand history/background permission (res:values-en/strings.xml:549-551,569). iOS shows no denial claim (ios:DoseDay/Domain/Services/AppleHealthImporter.swift:236-239). |
| HC08 | PARITY_OK | explicit delete only; stable source ID; hide persists. iOS tombstones + UUID (HK02). |
| HC09 | PARITY_OK | latest shown despite backlog/limit on both (iOS latest-500 query separate from anchor, ios:DoseDay/Data/Services/HealthKitService.swift:83-89,364-370; android 1000-row test). |
| HC10 | PARITY_OK | commit-before-bookmark on both (AppleHealthImporter.swift:110-129; HealthConnectImporter.kt:478-490). |
| HC11 | DIVERGENCE (iOS) | android shows persistent last-check time + history complete/pending + read in progress. iOS has no last-check/success time and no partial state; checkpointPending renders as success. |
| HC12 | PARITY_OK (scoped) | both have a synthetic real-provider → DB → screen pass. android at older candidate, weight only; iOS on 26.5 sim. rerun at HEAD needed. |
| HK01 | PARITY_OK | = HC09. |
| HK02 | PARITY_OK | = HC08/HC10. |
| HK03 | DIVERGENCE (iOS) | latest measured date shown (ios:DoseDay/Features/Body/BodyView.swift:39-65). missing: last-check time + unfinished catch-up/past-range state (same as HC11). empty result is not treated as denial (OK). |
| HK04 | PARITY_OK (scoped) | = HC12. |
| HEALTH_READ | UNVERIFIABLE | iOS sim provider PASS; android blocked on owner's physical device. |
| SM01 | PARITY_OK | 8 IDs unchanged, same design rects. raw codes differ per platform (iOS `upperArmLeftPosterior`, android enum name), which is allowed. |
| SM02 | PARITY_OK | both have self/front modes, my-left/my-right labels, a selected full-name label and an always-visible guide. |
| SM03 | PARITY_OK | zones, touch rects and highlights all use the same mirror (iOS BodyMapView.swift:163-187; android BodyMapPerspective.kt:34-35, BodyMapView.kt:217,248,266). |
| SM04 | PARITY_OK | mode change never calls select or save on either side. iOS has less test coverage of locale/restore. |
| SM05 | PARITY_OK | exports map the stored code → name; no swap (ios ExportService.swift:262,880,999; and:app/DoseWeekViewModel.kt:3922,7291-7307). neither side has an end-to-end round-trip test. |
| SM06 | PARITY_OK | new store → self, existing/unknown → front, plus guidance (iOS BodyMapDisplayPreferences.swift:25-44; android DoseWeekPreferences.kt:60-64). notice text differs, which is allowed. |
| SM07 | PARITY_OK | geometry forced LTR, labels keep text direction (iOS BodyMapView.swift:195,202,207; android BodyMapView.kt:200,326-329). |
| SM08 | PLATFORM_DIFFERENCE_ALLOWED | iOS: list replaces the figure at AX sizes or via toggle. android: expandable list below the figure. same 8 IDs. |
| SM09 | PARITY_OK | laterality same. arm/thigh copy differs (iOS "Back of left upper arm", android "Left upper arm"); pre-existing (ios 6dc10fb, android 5eb76a8). mode name also differs in en ("Facing me" vs "Front view"); new bugfix copy on both, ko same. allowed. |
| SM10 | PARITY_OK | pref is display-only, survives reset and restore (iOS AppPreferences.swift:190-205,253-270 has no bodyMap removal; android DoseWeekPreferences.kt:66-69). only android has a test. |
| VIS01 | PARITY_OK | visible help + edit/past entry on both. evidence is automated only. |
| VIS02 | PARITY_OK | visible Edit is owned by the ED area; help/entry exercised by UI tests on both. |
| VIS03 | PLATFORM_DIFFERENCE_ALLOWED | android has a filter-hides-all state (HistoryScreen.kt:165,786). iOS History has no type filter, so the state can't occur. unconsented health copy OK on both. |
| VIS04 | PARITY_OK | same 5 offline topics, context-first, 17 locales, one online button. |
| VIS05 | UNVERIFIABLE | android: 17-locale journeys + 200% layout. iOS: AX5 CI leg incomplete; DE/PL final18 failed and were retried separately. no live TalkBack/VoiceOver session. |
| VIS06 | PARITY_OK | no active import/JSON action on either bugfix tree; only backup restore pickers. |
| VIS07 | UNVERIFIABLE | no human first-use test on either side. |
| VIS08 | UNVERIFIABLE | legal FAQ aligned at f6bd054; final app↔legal check not run; iOS app on an unmerged branch. |
| LG01 | PARITY_OK (source) | FAQ text on both pages matches in-app help copy for the platform's real path. |
| LG02 | UNVERIFIABLE | generators exist (legal:scripts/check_site.py, render_android.py); not rerun against HEAD catalogs. |
| LG03 | UNVERIFIABLE | web matrix not run. note: iOS support page/link has ko/en/ja only; android has 17. |
| LG04 | PARITY_OK | release map: privacy effective dates unchanged, UX-only. |
| LG05 | UNVERIFIABLE | per-platform versioned candidate guidance exists; iOS app not on main; store release not verified. |
| LG06 | UNVERIFIABLE | no BUGFIX_BASELINE.json. |
| LEGAL_COPY | UNVERIFIABLE | = LG01/LG02/VIS08. |
| BACKUP_FLOW | PARITY_OK (semantics) / UNVERIFIABLE (e2e) | both: display pref and device integration state kept out of backup; revisions + plan-optional facts in payload (iOS schema 7.0, android payload 8). android Drive account path unverified. |
| APP_BUILD | UNVERIFIABLE | android main CI green. iOS full CI not green at 4c3e594; HEAD 93ae0e2 not rerun. |
| APP_REGRESSION | UNVERIFIABLE | same as APP_BUILD. |
| PLAY_ASSETS | PLATFORM_DIFFERENCE_ALLOWED | android-only profile row; frames not re-verified. |
| BUGFIX_PARITY | IN_PROGRESS | this document is the manual review for this area; the other areas are separate. |
| DL01–DL04 | PLATFORM_DIFFERENCE_ALLOWED | process rows. android merged to main; iOS draft PR7, not merged. |
| DL05–DL06 | UNVERIFIABLE | no 3-repo baseline/SHA reconciliation; no BUGFIX_BASELINE.json. |
| BLOC-* (17) | PARITY_OK (scoped) | both have a 17-locale date/edit/past journey. iOS DE/PL final18 retried separately. owned by DT/UX/ED/PR area. |

## Details

### Health — Android HC vs iOS HK

**Path and entry point**
- Android: Settings → Health Connect sheet shows status, "Import now", last check, history, in-progress and recent records (and:features/integrations/HealthConnectSheet.kt:155-229). Body screen has only help (and:features/body/BodyScreen.kt:105) and the imported-measurements list (:164-167). Foreground import on return (and:app/DoseWeekViewModel.kt:522-527).
- iOS: Body → health card has an import button (ios:DoseDay/Features/Body/BodyView.swift:260-264), pull-to-refresh (:380-382) and a passive refresh in loadMetrics (ios:DoseDay/Features/Body/BodyViewModel.swift:365,406-410). Foreground return reloads Body (ios:DoseDay/Features/AppShell/RootView.swift:86-89 → ios:DoseDay/Features/Navigation/MainTabView.swift:289-296). Settings import is at ios:DoseDay/Features/Settings/SettingsView.swift:593.
- The spec lists "신체 화면·연동 설정" as either location, so the different placement is allowed. Each help topic names its own real path (res:values-en/strings.xml:775 vs iOS `settings.guide.health.body`).

**Data semantics**
- Android: a fixed range ending days ago does not count as "latest checked". The pending token is consumed with the remaining budget (HealthConnectImporter.kt:407-415). A partial feed does not advance lastSyncedAt (:480-484). Page data and token go through one store import (:486+).
- iOS: a latest-500 query feeds the UI, separate from the anchor backlog (HealthKitService.swift:83-89,364-370). The SwiftData save happens before the Keychain anchor commit; a failed commit leaves the old anchor for safe replay (AppleHealthImporter.swift:110-129).
- Both keep imported data read-only and hides permanent. Neither invents a denial.

**DIVERGENCE HC11/HK03 (iOS deviates from U14/HK03 "최근 확인/최신 측정/과거 범위 구분")**
- Android status, shown separately:
  - last check time (persisted `lastReadAt` → and:app/DoseWeekViewModel.kt:2554; HealthConnectSheet.kt:156-160)
  - latest measured date (DoseWeekViewModel.kt:6066; BodyScreen.kt:196)
  - history complete vs pending (HealthConnectSheet.kt:208-222)
  - read in progress (:223-229)
- iOS:
  - `AppleHealthImportState.statusText` is session-only and idle → nil (AppleHealthImporter.swift:240-266).
  - No persisted last-check/success timestamp anywhere in `DoseDay` (grep for lastRefresh/checkedAt/lastImportedAt: none).
  - `.importedCheckpointPending` reuses the success text (:245-246).
  - Shown instead: the limit notice (BodyView.swift:147-152), limited history (:160-172) and "latest only" (:175-181).
  - Latest measured date is shown: `latest.recordedAt` stamp + source (BodyView.swift:39-65, stamp at :64-65). So the "최신 측정" part is met.
  - Missing parts only: last-check time, and a signal that the catch-up is unfinished (4-page cap loop ends with no pending flag, HealthKitService.swift:955-975).
- Impact: an iOS user can't tell when DoseWeek last checked Apple Health, or whether an anchored catch-up (4-page cap, HealthKitService.swift:85) is still unfinished. The owner's missing-data report is Android-only, so severity is low-medium.
- Minimal fix: persist a device-local last successful refresh instant (AppPreferences, not backup) when `AppleHealthImporter.run` finishes. Render it plus a "catch-up unfinished" line in the `BodyView.healthCard` (BodyView.swift:242-300). 17-locale strings. Unit test on the state mapping plus a Body UI assertion.

**Tests**
- Android: HealthConnectHistoryBackfillTest, IntegrationStateFeedbackViewModelTest, ImportedMeasurementsViewModelTest, HealthConnectStagedMutationTest, HealthConnectProviderHandshakeTest.
- iOS: AppleHealthImportTests, ImportedMetricHideBackupTests, BodyCustomPeriodAuditTests.
- Neither side has a status-separation UI test.

**Real provider (HC12/HK04)**
- Android: synthetic pass on API36, weight only, at candidate 0cddc34.
- iOS: synthetic pass on the 26.5 sim.
- Neither covers the physical owner case (HC01/HEALTH_READ). Don't claim resolved.

### Site laterality (SM)

**IDs and geometry**
- Both use the same 300×288 design and identical zone rects (ios BodyMapView.swift:141-150; and BodyMapView.kt:143-152).
- Raw codes: iOS `InjectionSiteRegion` (ios:DoseDay/Domain/Models/InjectionSiteRegion.swift:5-12); Android stores the `InjectionSiteUi` enum name (and:features/navigation/DoseWeekUiModels.kt:475-484, decoded at DoseWeekViewModel.kt:7306-7307). Separate backups, so allowed.

**Mirror**
- iOS: `canvasViewport.maxX - rect.maxX` inside the symmetric viewport (BodyMapView.swift:169). Hit frames derive from the same frame (:178-187). Silhouette unchanged but symmetric (:128-136).
- Android: `canvasWidth - x - width` on silhouette, zone and touch rects (BodyMapPerspective.kt:34-35; BodyMapView.kt:217,236,248,266).
- No text flip on either side.

**Labels**
- iOS: `bodyMap.side.left/right` "My left/My right" swap by mode (BodyMapView.swift:198-213), guide "Left and right refer to your body…" always shown (BodyMapDisplayPreferences.swift:85-88), selected name (BodyMapView.swift:297-315).
- Android: `body_map_my_left/right` (BodyMapView.kt:321-338), per-mode help (BodyMapPerspective.kt:76-81), "Selected site (your body): %s" (BodyMapView.kt:82-87).
- Mode-name copy differs, and it is new bugfix copy on both sides: iOS "Facing me" (ios Localizable.xcstrings `bodyMap.mode.front`, added in 0f1ad1b, not on origin/main); Android "Front view" (res:values-en/strings.xml:750, added in cc96f26 via bugfix merge 2ccd963). ko 정면에서 보기 on both (xcstrings; res:values/strings.xml:741). Neither says "back view". Allowed; recorded as a bugfix copy difference, not a pre-existing one.
- Arm/thigh site-name copy difference is pre-existing: iOS "Back of left upper arm" (6dc10fb, on main), Android "Left upper arm" (5eb76a8 MVP).

**Default (SM06)**
- iOS: verified first store creation plus no prefs, no reset/restore intent → self. Otherwise front, a legacy notice and a persisted `legacyFront` sentinel (ios:DoseDay/App/DoseDayApp.swift:193-197,223-225; BodyMapDisplayPreferences.swift:31-43).
- Android: `openedFreshDatabase()` from onCreate only (and:data/DoseWeekRepository.kt:281-285) → SELF, else FRONT (DoseWeekPreferences.kt:60-64). The front help always offers the switch.
- Same meaning.

**Persistence (SM10/BACKUP)**
- iOS UserDefaults key survives `resetBehaviorFlags` (AppPreferences.swift:253-270 doesn't remove it); no SwiftData field (docs/BODY_MAP_DISPLAY.md:26-27).
- Android SharedPreferences survive `resetBehaviorFlags` (DoseWeekPreferences.kt:66-69); tested in BodyMapPerspectiveViewModelTest `backupRestoreAndDeleteAllKeepDisplayChoiceWithoutSwappingHistoricalSites`, `changingViewWhileSaveIsEnteredCannotChangeTheRequestedSite`.
- Test gap: iOS AuditBodyMapTests (6) and AuditBodyMapUITests (3) cover geometry, defaults, RTL and rotation, but not restore, reset, mode-during-save or locale change. Fix location: ios DoseDayTests/AuditBodyMapTests.swift. Not a behaviour divergence.

**Text alternative (SM08)**: platform layout differs (see table); both have 44/48 pt targets, radio/selected traits and the recent badge.

### Help and discoverability (VIS)

**Topics**
- Same 5 topics on both: dates, edit, past, health, sites (ios:DoseDay/Features/Settings/RecordHelpView.swift:4; and:features/help/RecordHelpSheet.kt:48-53).

**Entry points**
- iOS: Settings row (SettingsView.swift:680-684), History past (ios:DoseDay/Features/History/HistoryView.swift:96), Body health (BodyView.swift:329), Record flow dates or sites (RecordFlowView.swift:66).
- Android: Settings (SettingsScreen.kt:91), History (HistoryScreen.kt:115), Body (BodyScreen.kt:105), Record dialog past/sites/dates (RecordAdministrationDialog.kt:96-99).
- Android sends historical entries to PAST from the record dialog; iOS record flow only offers dates/sites. Minor; PAST is still reachable from History.

**Copy**: platform-specific facts are accurate. Android adds the typed YYYYMMDD/HHmm fallback and past-entry stock/schedule notes (res:values-en/strings.xml:769,773); iOS has no typed fallback.

**Online link**
- iOS resolves ko/en/ja only, else en (RecordHelpView.swift:96-99), matching `legal:support/index.html` sections ko/en/ja.
- Android maps all 17 (and:features/help/RecordHelpLinks.kt:6-17) to 17 sections in `legal:android/support/index.html`.
- Offline in-app help is 17 locales on both, so VIS04/VIS05 are met. Web locale gap is pre-existing iOS page scope (LG03 says keep existing locales). Owner decision needed if iOS web parity is wanted.

**Tests**
- iOS: RecordHelpUITests — ko Settings, ar History, Body, record draft kept.
- Android: RecordHelpUiTest [ko, ar] — Settings/History/Body, draft kept, offline expand, large text.

### Legal (LG)
- Source release map `/private/tmp/doseweek-v11-20260913/legal-release-map.json`: f6bd054 on main, published bytes = candidate for both platform pages, privacy dates unchanged (LG04 OK).
- Import guide stays on an unpublished branch (`cc6fa49` candidate/import-guide), so VIS06/LG05 are not advertised as live.
- iOS page text matches iOS catalog wording ("My body and Facing me"; "Apple Health…refresh"). Android page matches Android wording ("Front view"; "Import now").
- Final generator checks against HEAD catalogs were not rerun, so LG02/LG03/LG06 remain unverifiable.

### Remaining rows
- BACKUP_FLOW: iOS `BackupCryptoService.currentSchemaVersion = "7.0"` (BackupCryptoService.swift:471); Android `PAYLOAD_VERSION = 8`, `PLAN_OPTIONAL_FACTS` (and:data/BackupModels.kt:399-446), revisions validated (:660-674). Both exclude device integration state and the display pref. E2E restore of edited/past records sits with the ED/PR areas; Drive account path unverified.
- APP_BUILD/APP_REGRESSION: iOS HEAD 93ae0e2 has no full CI; last full CI 4c3e594 had 1 failure each on iPhone/iPad and the AX5 leg was interrupted. Android main 79bb210 CI + API24/36 matrix green (coverage map).
- DL05/DL06: missing BUGFIX_BASELINE.json; iOS not merged to main (STATE repositories.ios.merge NOT_RUN).

## Divergence fix list (this area)
1. iOS HC11/HK03 status separation: `ios:DoseDay/Features/Body/BodyView.swift` healthCard (~242-300) + `AppleHealthImporter.run` result + device-local timestamp in `AppPreferences`; strings ×17; tests in `DoseDayTests/AppleHealthImportTests.swift` + Body UI test.
2. (test-only) iOS SM04/SM05/SM10 restore, reset and locale-switch assertions in `DoseDayTests/AuditBodyMapTests.swift`.
3. (owner choice, not a requirement breach) iOS web FAQ covers only ko/en/ja: `legal:support/index.html`, `ios:RecordHelpView.swift:96-99`.

## Review log (2026-09-15 revision)
Verifier issues checked against code.
- SM09-COPY-ORIGIN (minor): CONFIRMED, fixed. `git log -S '"bodyMap.mode.front"'` in ios → only 0f1ad1b, `merge-base --is-ancestor 0f1ad1b origin/main` false. android `-S body_map_perspective_front` → cc96f26, which is in bugfix merge 2ccd963 and not in the code 9 merge 6abca14. Arm copy: ios 6dc10fb (on origin/main), android 5eb76a8 → still pre-existing. SM09 row and SM Labels section split.
- HK03-LATEST-DATE (minor): CONFIRMED, fixed. BodyView.swift:39-65 renders `latest.recordedAt` + source. The HK03 row and HC11/HK03 detail now say the latest date is met; the divergence is limited to no last-check time + no unfinished catch-up signal. Core DIVERGENCE class unchanged.
- Rejected: none.
