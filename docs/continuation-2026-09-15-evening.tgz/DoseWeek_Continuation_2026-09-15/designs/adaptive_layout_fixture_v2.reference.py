import json, hashlib, math, sys, copy
C = dict(minListPaneWidth=320, largeTextMinListPaneWidth=400, minDetailPaneWidth=360,
         twoPaneMinUsableWidth=680, largeTextTwoPaneMinUsableWidth=800, listPaneFraction=0.4,
         listPaneMaxWidth=420, largeTextListPaneMaxWidth=420, twoColumnMinUsableWidth=840, minColumnWidth=360,
         compactHeightBelow=480, readableMaxWidth=700)
LISTDETAIL={"history","body"}; TWOCOL={"today"}; SINGLE={"settings","record","onboarding"}

def policy(i):
    w,h=i["window"]["width"],i["window"]["height"]; ins=i["insets"]
    x0=ins["left"]; x1=w-ins["right"]; uw=x1-x0; uh=h-ins["top"]-ins["bottom"]
    rtl=i["layoutDirection"]=="rtl"
    feats=[]
    for f in i["features"]:
        b=f["bounds"]
        if b["right"]<0 or b["left"]>w or b["bottom"]<0 or b["top"]>h: continue
        if b["left"]==b["right"] and (b["left"]<=0 or b["left"]>=w) and f["orientation"]=="vertical": continue
        if b["top"]==b["bottom"] and (b["top"]<=0 or b["top"]>=h) and f["orientation"]=="horizontal": continue
        feats.append(dict(f, bounds=dict(left=max(0,b["left"]),top=max(0,b["top"]),right=min(w,b["right"]),bottom=min(h,b["bottom"]))))
    avoid=[f["bounds"] for f in feats if f["isSeparating"] or f["occlusion"]=="full"]
    vsep=[f for f in feats if f["orientation"]=="vertical" and (f["isSeparating"] or f["occlusion"]=="full") and f["bounds"]["left"]>x0 and f["bounds"]["right"]<x1]
    out=dict(mode="single", splitSource="none", startPane=None, endPane=None, avoidRects=avoid,
             compactHeight=uh<C["compactHeightBelow"], ignoredFeatureCount=len(i["features"])-len(feats))
    s=i["screen"]
    if i["systemWidthCompact"] or s in SINGLE:
        return out
    if s in LISTDETAIL:
        lt=i["largeText"]; mn=C["largeTextMinListPaneWidth"] if lt else C["minListPaneWidth"]; md=C["minDetailPaneWidth"]
        need=C["largeTextTwoPaneMinUsableWidth"] if lt else C["twoPaneMinUsableWidth"]
        if vsep:
            hb=vsep[0]["bounds"]; leftW=hb["left"]-x0; rightW=x1-hb["right"]
            listW,detW=(rightW,leftW) if rtl else (leftW,rightW)
            if listW>=mn and detW>=md:
                L={"x":x0,"width":leftW}; R={"x":hb["right"],"width":rightW}
                out.update(mode="listDetail", splitSource="hinge", startPane=(R if rtl else L), endPane=(L if rtl else R))
            return out
        if uw>=need:
            listW=min(max(math.floor(uw*C["listPaneFraction"]),mn),C["listPaneMaxWidth"]); detW=uw-listW
            if detW>=md:
                if rtl: sp={"x":x1-listW,"width":listW}; ep={"x":x0,"width":detW}
                else: sp={"x":x0,"width":listW}; ep={"x":x0+listW,"width":detW}
                out.update(mode="listDetail", splitSource="proportional", startPane=sp, endPane=ep)
        return out
    if s in TWOCOL:
        mc=C["minColumnWidth"]
        if vsep:
            hb=vsep[0]["bounds"]; leftW=hb["left"]-x0; rightW=x1-hb["right"]
            if leftW>=mc and rightW>=mc and uw>=C["twoColumnMinUsableWidth"]:
                L={"x":x0,"width":leftW}; R={"x":hb["right"],"width":rightW}
                out.update(mode="twoColumn", splitSource="hinge", startPane=(R if rtl else L), endPane=(L if rtl else R))
            return out
        if uw>=C["twoColumnMinUsableWidth"]:
            a=math.floor(uw/2); b=uw-a
            L={"x":x0,"width":a}; R={"x":x0+a,"width":b}
            out.update(mode="twoColumn", splitSource="proportional", startPane=(R if rtl else L), endPane=(L if rtl else R))
        return out
    raise SystemExit("unknown screen "+s)

def inp(screen,w,h,compact=False,ins=(0,0,0,0),features=(),large=False,rtl=False,ime=0):
    return dict(screen=screen, window=dict(width=w,height=h), insets=dict(left=ins[0],top=ins[1],right=ins[2],bottom=ins[3]),
                systemWidthCompact=compact, largeText=large, layoutDirection="rtl" if rtl else "ltr", imeBottom=ime, features=list(features))
def fold(l,t,r,b,state,orient,sep,occ="none"):
    return dict(bounds=dict(left=l,top=t,right=r,bottom=b), state=state, orientation=orient, isSeparating=sep, occlusion=occ)

cases=[
 ("L01","both","phone portrait compact",inp("history",411,914,True,(0,24,0,48))),
 ("L02","both","narrow tall window like an outer/cover display",inp("today",344,882,True,(0,24,0,40))),
 ("L03","android","wide window, flat non-separating crease ignored for layout",inp("history",712,820,False,(0,0,0,0),[fold(356,0,356,820,"flat","vertical",False)])),
 ("L04","android","book posture, separating zero-width vertical hinge, both sides fit",inp("history",740,820,False,(0,0,0,0),[fold(370,0,370,820,"halfOpened","vertical",True)])),
 ("L05","android","book posture, detail side too narrow at hinge -> single, never straddle",inp("history",712,820,False,(0,0,0,0),[fold(356,0,356,820,"halfOpened","vertical",True)])),
 ("L06","android","tabletop posture, horizontal separating hinge does not split columns; avoid rect only",inp("history",820,740,False,(0,0,0,0),[fold(0,370,820,370,"halfOpened","horizontal",True)])),
 ("L07","both","split-screen half window, no feature inside window",inp("history",370,820,True)),
 ("L08","both","medium width but below two-pane minimum",inp("history",600,900,False)),
 ("L09","both","exact two-pane boundary 680 inclusive",inp("history",680,900,False)),
 ("L10","both","one unit below two-pane boundary",inp("history",679,900,False)),
 ("L11","both","large text raises two-pane minimum",inp("history",740,900,False,large=True)),
 ("L12","both","large text wide enough",inp("history",820,900,False,large=True)),
 ("L13","both","RTL proportional list pane on start (right) side",inp("history",820,900,False,rtl=True)),
 ("L14","both","landscape with side insets and short height",inp("body",914,411,False,(48,0,48,24))),
 ("L15","both","IME does not change mode or compactHeight",inp("history",820,740,False,ime=300)),
 ("L16","android","fully occluding vertical hinge with width",inp("history",820,800,False,(0,0,0,0),[fold(400,0,420,800,"flat","vertical",True,"full")])),
 ("L17","both","feature bounds outside window are ignored",inp("history",820,800,False,(0,0,0,0),[fold(900,0,900,800,"halfOpened","vertical",True)])),
 ("L18","both","today two columns on wide window",inp("today",1024,768,False)),
 ("L19","both","today below two-column minimum",inp("today",820,1180,False)),
 ("L20","both","settings always single readable column",inp("settings",1024,768,False)),
 ("L21","both","record flow always single",inp("record",1024,768,False)),
 ("L22","android","today split at separating vertical hinge",inp("today",1024,768,False,(0,0,0,0),[fold(512,0,512,768,"halfOpened","vertical",True)])),
 ("L23","both","body list-detail proportional on wide window",inp("body",1024,768,False)),
 ("L24","android","system compact width wins over hinge",inp("history",560,800,True,(0,0,0,0),[fold(280,0,280,800,"halfOpened","vertical",True)])),
 ("L25","android","off-centre separating hinge leaves list side too narrow -> single",inp("history",1000,800,False,(0,0,0,0),[fold(300,0,300,800,"halfOpened","vertical",True)])),
 ("L26","android","RTL hinge split puts list pane on right side",inp("history",740,820,False,(0,0,0,0),[fold(370,0,370,820,"halfOpened","vertical",True)],rtl=True)),
 ("L27","both","onboarding always single",inp("onboarding",1024,768,False)),
]
layoutCases=[dict(id=i,platforms=["android","ios"] if p=="both" else [p],note=n,input=x,expected=policy(x)) for i,p,n,x in cases]

# ---- v2 pane reducer (review 2026-09-15): Q5-A inline narrow, per-screen selection key, optional focused record ----
S0=dict(mode="single",selectionKey=None,focusedItemId=None,generation=0,draftToken=None,pendingSaveRequestId=None)
def reduce(s,e):
    s=copy.deepcopy(s); consumed=None; k=e["event"]
    if k=="layout": s["mode"]=e["mode"]
    elif k=="select": s["selectionKey"]=e["key"]              # day (history) / metric (body); never null on those screens
    elif k=="focus": s["focusedItemId"]=e["id"]               # routed/highlighted record (existing focused ids)
    elif k=="back": consumed=False                            # Q5-A: pane never intercepts back; no state change
    elif k=="recordDeleted":
        if s["focusedItemId"]==e["id"]: s["focusedItemId"]=None   # selectionKey untouched
    elif k=="generationBumped":                                # delete-all / restore
        s.update(generation=s["generation"]+1,focusedItemId=None,draftToken=None,pendingSaveRequestId=None,
                 selectionKey=e["selectionKeyAfterReset"])     # platform's existing reset value, injected (Clock in product)
    else: raise SystemExit(k)
    return s,consumed
def tcase(id,screen,note,init,events):
    s=dict(S0,**init); steps=[]
    for e in events:
        s,c=reduce(s,e); exp=dict(state=s)
        if e["event"]=="back": exp["backConsumed"]=c
        steps.append(dict(event=e,expected=exp))
    return dict(id=id,platforms=["android","ios"],screen=screen,note=note,initial=dict(S0,**init),steps=steps)
L=lambda m:{"event":"layout","mode":m}
B={"event":"back"}
transitionCases=[
 tcase("T01","history","selected day survives widen/narrow; narrow stays inline so back is never consumed by the pane",{"selectionKey":"2026-09-15"},
   [{"event":"select","key":"2026-09-10"},L("listDetail"),L("single"),B]),
 tcase("T02","history","layout never touches draft token or pending save request",{"selectionKey":"2026-09-15","draftToken":"draft-A","pendingSaveRequestId":"req-1"},
   [L("listDetail"),L("single"),L("listDetail"),L("listDetail")]),
 tcase("T03","history","deleting another record keeps focus; deleting the focused record clears focus only, day kept",{"selectionKey":"2026-09-15"},
   [{"event":"select","key":"2026-09-10"},{"event":"focus","id":"rec-1"},L("listDetail"),{"event":"recordDeleted","id":"rec-2"},{"event":"recordDeleted","id":"rec-1"},L("single")]),
 tcase("T04","history","generation bump (delete all / restore) clears focus, draft and pending; day set to injected reset value; later layout keeps it",{"selectionKey":"2026-09-10","draftToken":"draft-B","pendingSaveRequestId":"req-9"},
   [{"event":"focus","id":"rec-1"},{"event":"generationBumped","selectionKeyAfterReset":"2026-09-15"},L("listDetail"),L("single")]),
 tcase("T05","body","metric selection survives widen/narrow; back not consumed in either mode",{"selectionKey":"weight"},
   [{"event":"select","key":"waist"},L("listDetail"),B,L("single"),B]),
 tcase("T06","today","twoColumn/single churn on today keeps everything",{"draftToken":"draft-T"},
   [L("twoColumn"),L("single"),L("twoColumn")]),
 tcase("T07","history","narrow single with a focused record: back not consumed, focus and day unchanged (no push introduced)",{"selectionKey":"2026-09-15"},
   [{"event":"focus","id":"rec-3"},B,L("listDetail"),L("single"),B]),
]
fx=dict(schema="doseweek.adaptive_layout_fixture",version=2,units="layout units: iOS points == Android dp; window-relative absolute coordinates, origin top-left",
  policy=dict(navigationChrome="floatingTabBar_pendingD20OverlapCheck",tabletop="avoidHingeOnly",
              tabletopAvoidRectsApplyTo="fixedActionRowsAndBarsOnly",narrowListDetail="inline",
              singleContainerIOS="NavigationStack",listDetailContainerIOS="NavigationSplitView",
              imeAffectsMode=False,imeAffectsCompactHeight=False,iosFeatureSource="none_until_verified_ios_27_1_sdk_reservedRegions"),
  constants=C,layoutCases=layoutCases,transitionCases=transitionCases)
text=json.dumps(fx,sort_keys=True,indent=2,ensure_ascii=False)+"\n"
open(sys.argv[1],"w",encoding="utf-8").write(text)
print(hashlib.sha256(text.encode()).hexdigest(), len(layoutCases), len(transitionCases))
for c in layoutCases: e=c["expected"]; print(c["id"],e["mode"],e["splitSource"],e["startPane"],e["endPane"],e["compactHeight"],len(e["avoidRects"]),e["ignoredFeatureCount"])
