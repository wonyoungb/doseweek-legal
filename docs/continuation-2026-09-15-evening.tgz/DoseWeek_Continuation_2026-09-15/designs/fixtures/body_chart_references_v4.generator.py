"""body_chart_references v4 generator (reference implementation). Never hand-edit output.

v3 (2026-09-15, core-engines parity closure) keeps every v2 case unchanged at the start of its
section (`--v2` reproduces body_chart_references_v2.json byte for byte; the v2 generator file stays
untouched) and adds cases for the behaviour both platform engines implemented without one:
- samples whose kg is not a finite positive number are dropped before the daily winner;
- a rounding result of zero is +0, so a tiny gain prints 0.00, never -0.00;
- a zoom scale that is not a finite positive number keeps the span (the pan still applies);
- the percent band is null for a BMI reference, a threshold, or a non-positive start weight;
- personal target text is ASCII-only, with the check order pinned;
- setting resolution order (an unknown official id is unavailable before any metric check);
- personalTargetMembership (CORE-20260915-01): a personal target is inclusive at both bounds, value
  and bounds are compared in the chart unit after conversion, rounded to the rule's decimals (as
  official bands, design 4.3); lower == upper draws a single line.

v4 (2026-09-15, coordinator decision CORE-20260915-07 on the v3 open questions) keeps every v2 and v3
case unchanged (`--v2` and `--v3` reproduce the earlier files byte for byte; the v2 and v3 generator
files stay untouched) and adds:
- zoom: a spanDays at or below zero clamps to the 7-day minimum, no throw (the reference always did;
  Android `require(spanDays > 0)` aligns);
- personalTargetMembership: a percentPerWeek target shown in kgPerWeek with an interval start weight
  that is not finite and positive is unavailable (expected null, no throw); a kgPerWeek target shown
  in percentPerWeek converts symmetrically (bound / intervalStartKg * 100, the percent-band formula)
  and is unavailable under the same start-weight condition.

Usage: python3 body_chart_references_v4.generator.py [--v2|--v3] <output.json>
"""
import json, math, re, sys, hashlib
from datetime import datetime, date, timedelta
from zoneinfo import ZoneInfo

LB = 0.45359237
EPS = 1e-9
def rnd(x, dp):
    f = 10 ** dp
    if x >= 0: r = math.floor(x * f + 0.5 + EPS) / f
    else: r = -math.floor(-x * f + 0.5 + EPS) / f
    return 0.0 if r == 0 else r  # v3: a zero result is +0 (no v2 value rounds to -0)
def fx(x, dp): return format(rnd(x, dp), f'.{dp}f')

def local_day(s, zone):
    return datetime.fromisoformat(s['instant'].replace('Z', '+00:00')).astimezone(ZoneInfo(zone)).date()

def counted(s):
    if s.get('hidden') or not s.get('eligible', True): return False
    kg = s['kg']
    return isinstance(kg, (int, float)) and math.isfinite(kg) and kg > 0  # v3: finite positive weights only

def daily(samples, zone):
    by = {}
    for s in samples:
        if not counted(s): continue
        d = local_day(s, zone)
        key = (s['instant'], 1 if s['source'] == 'manual' else 0, s['id'])
        cur = by.get(d)
        if cur is None or key > cur[0]: by[d] = (key, s)
    out = []
    for d in sorted(by):
        s = by[d][1]
        out.append({'localDate': d.isoformat(), 'sampleId': s['id'], 'kg': s['kg']})
    return out

def rates(samples, zone, minGap=7, maxGap=28):
    pts = daily(samples, zone)
    res = []
    for i, p in enumerate(pts):
        di = date.fromisoformat(p['localDate'])
        start = None
        for j in range(i - 1, -1, -1):
            gap = (di - date.fromisoformat(pts[j]['localDate'])).days
            if gap >= minGap: start = (pts[j], gap); break
        row = {'endDate': p['localDate'], 'endSampleId': p['sampleId']}
        if start is None:
            row['status'] = 'insufficientHistory'
        elif start[1] > maxGap:
            row.update(status='gapTooLong', startDate=start[0]['localDate'], gapDays=start[1])
        else:
            sp, gap = start
            loss = (sp['kg'] - p['kg']) * 7 / gap
            pct = loss / sp['kg'] * 100
            row.update(status='ok', startDate=sp['localDate'], startSampleId=sp['sampleId'], gapDays=gap,
                       startKg=fx(sp['kg'], 6), endKg=fx(p['kg'], 6),
                       lossKgPerWeek=fx(loss, 6), lossPercentPerWeek=fx(pct, 6),
                       displayKgPerWeek=fx(abs(loss), 2), displayPercentPerWeek=fx(abs(pct), 2),
                       direction='loss' if rnd(loss, 2) > 0 else ('gain' if rnd(loss, 2) < 0 else 'noChange'))
        res.append(row)
    return pts, res

catalog = [
 {"id": "rate.nhs.2023", "kind": "band", "metric": "weightLossRate", "nativeUnit": "kgPerWeek", "lower": "0.5", "upper": "1.0",
  "lowerInclusive": True, "upperInclusive": True, "displayDecimals": 2, "populationKey": "adultsGeneralUK",
  "sourceUrl": "https://www.nhs.uk/live-well/healthy-weight/managing-your-weight/tips-to-help-you-lose-weight/",
  "sourceSummary": "aim to lose 1 to 2lbs, or 0.5 to 1kg, a week", "sourceReviewed": "2023-03-17", "accessed": "2026-09-15"},
 {"id": "rate.cdc.2025", "kind": "band", "metric": "weightLossRate", "nativeUnit": "lbPerWeek", "lower": "1", "upper": "2",
  "lowerInclusive": True, "upperInclusive": True, "displayDecimals": 2, "populationKey": "adultsGeneralUS",
  "sourceUrl": "https://www.cdc.gov/healthy-weight-growth/losing-weight/index.html",
  "sourceSummary": "a gradual, steady pace - about 1 to 2 pounds a week", "sourceReviewed": "2025-01-17", "accessed": "2026-09-15"},
 {"id": "bmi.who.adult", "kind": "band", "metric": "bmi", "nativeUnit": "kgPerM2", "lower": "18.5", "upper": "25.0",
  "lowerInclusive": True, "upperInclusive": False, "displayDecimals": 1, "populationKey": "adults18International",
  "sourceUrl": "https://www.who.int/news-room/fact-sheets/detail/obesity-and-overweight",
  "sourceSummary": "adults: overweight BMI >= 25, obesity BMI >= 30; underweight BMI < 18.5 (GHO indicator)", "sourceReviewed": "2025-12-08", "accessed": "2026-09-15"},
 {"id": "bmi.cdc.adult", "kind": "band", "metric": "bmi", "nativeUnit": "kgPerM2", "lower": "18.5", "upper": "25.0",
  "lowerInclusive": True, "upperInclusive": False, "displayDecimals": 1, "populationKey": "adults20US",
  "sourceUrl": "https://www.cdc.gov/bmi/adult-calculator/bmi-categories.html",
  "sourceSummary": "adults 20 and older: healthy weight 18.5 to less than 25", "sourceReviewed": "2024-03-19", "accessed": "2026-09-15"},
 {"id": "bmi.nice.ng246.lowerThreshold", "kind": "threshold", "metric": "bmi", "nativeUnit": "kgPerM2", "lower": None, "upper": "23.0",
  "lowerInclusive": True, "upperInclusive": False, "displayDecimals": 1, "populationKey": "adultsUKLowerThresholdBackgrounds",
  "sourceUrl": "https://www.nice.org.uk/guidance/ng246/chapter/Identifying-and-assessing-overweight-obesity-and-central-adiposity",
  "sourceSummary": "rec 1.9.11: South Asian, Chinese, other Asian, Middle Eastern, Black African or African-Caribbean background: lower thresholds, overweight BMI 23 to 27.4, obesity 27.5 or above; no lower range stated", "sourceReviewed": "2026-01-08", "accessed": "2026-09-15"},
 {"id": "bmi.nice.ng246.general", "kind": "band", "metric": "bmi", "nativeUnit": "kgPerM2", "lower": "18.5", "upper": "25.0",
  "lowerInclusive": True, "upperInclusive": False, "displayDecimals": 1, "populationKey": "adultsUKGeneral",
  "sourceUrl": "https://www.nice.org.uk/guidance/ng246/chapter/Identifying-and-assessing-overweight-obesity-and-central-adiposity",
  "sourceSummary": "rec 1.9.10: healthy weight BMI 18.5 to 24.9", "sourceReviewed": "2026-01-08", "accessed": "2026-09-15"},
 {"id": "bmi.ksso.2022", "kind": "band", "metric": "bmi", "nativeUnit": "kgPerM2", "lower": "18.5", "upper": "23.0",
  "lowerInclusive": True, "upperInclusive": False, "displayDecimals": 1, "populationKey": "koreanAdults18",
  "sourceUrl": "https://doi.org/10.7570/jomes23031",
  "sourceSummary": "KSSO 2022 update: overweight BMI >= 23, obesity BMI >= 25 (Korean adults); Table 1 normal 18.5-22.9", "sourceReviewed": "2023-06-01", "accessed": "2026-09-15"},
 {"id": "bmi.jasso", "kind": "band", "metric": "bmi", "nativeUnit": "kgPerM2", "lower": "18.5", "upper": "25.0",
  "lowerInclusive": True, "upperInclusive": False, "displayDecimals": 1, "populationKey": "japanJasso",
  "sourceUrl": "https://www.jasso.or.jp/data/magazine/pdf/chart_A.pdf",
  "sourceSummary": "JASSO himando bunrui: normal weight 18.5 <= BMI < 25", "sourceReviewed": "undated", "accessed": "2026-09-15"},
]

def band_bounds_kg(entry):
    lo = None if entry['lower'] is None else float(entry['lower'])
    up = float(entry['upper'])
    if entry['nativeUnit'] == 'lbPerWeek': lo, up = lo * LB, up * LB
    return lo, up

def member(value, entry):
    dp = entry['displayDecimals']
    lo, up = band_bounds_kg(entry)
    v, u = rnd(value, dp), rnd(up, dp)
    if entry['kind'] == 'threshold':
        above = v > u or (v == u and not entry['upperInclusive'])
        return {'roundedValue': fx(value, dp), 'roundedLower': None, 'roundedUpper': fx(up, dp),
                'position': 'atOrAboveThreshold' if above else 'belowThreshold'}
    l = rnd(lo, dp)
    below = v < l or (v == l and not entry['lowerInclusive'])
    above = v > u or (v == u and not entry['upperInclusive'])
    return {'roundedValue': fx(value, dp), 'roundedLower': fx(lo, dp), 'roundedUpper': fx(up, dp),
            'position': 'below' if below else ('above' if above else 'inside')}

cat = {c['id']: c for c in catalog}

S = lambda i, inst, v, src='manual', **k: dict(id=i, instant=inst, kg=v, source=src, **k)
rate_cases = []
def add_rate(cid, zone, samples, note):
    pts, res = rates(samples, zone)
    rate_cases.append({'id': cid, 'zone': zone, 'note': note, 'input': {'minGapDays': 7, 'maxGapDays': 28, 'samples': samples},
                       'expected': {'dailyPoints': [{'localDate': p['localDate'], 'sampleId': p['sampleId'], 'kg': fx(p['kg'], 6)} for p in pts], 'rates': res}})
c1 = [S('w1', '2026-08-01T23:00:00Z', 92.0), S('w2', '2026-08-09T00:00:00Z', 91.2), S('w3', '2026-08-16T00:30:00Z', 90.5),
      S('w4', '2026-08-20T00:00:00Z', 90.3), S('w5', '2026-08-23T00:00:00Z', 89.9)]
c2 = [S('g1', '2026-07-01T00:00:00Z', 95.0), S('g2', '2026-08-15T00:00:00Z', 93.0), S('g3', '2026-08-22T00:00:00Z', 92.6)]
c3 = [S('d1', '2026-03-07T13:00:00Z', 90.718474, 'imported'), S('d2', '2026-03-07T23:00:00Z', 91.17206637, 'imported'),
      S('d3', '2026-03-14T12:00:00Z', 90.9), S('d4', '2026-03-21T12:00:00Z', 91.4)]
c4 = [S('t1', '2026-05-24T14:00:00Z', 80.0, 'imported'), S('t2', '2026-05-31T15:30:00Z', 79.6, 'imported'),
      S('t3', '2026-05-31T15:30:00Z', 79.5, 'manual'), S('t4', '2026-05-31T14:00:00Z', 79.9, 'imported', hidden=True),
      S('t5', '2026-05-31T15:40:00Z', 12.0, 'imported', eligible=False)]
c6 = [S('s1', '2026-09-01T00:00:00Z', 88.0), S('s2', '2026-09-08T00:00:00Z', 88.0)]
for cid, zone, samples, note in [
    ('rate.basicKoreaTrailingWindow', 'Asia/Seoul', c1, 'start = latest earlier daily point >= 7 days back; 08-20 skips 08-16 (4 days) and uses 08-09 (11 days)'),
    ('rate.gapLongerThan28DaysBreaksSeries', 'Asia/Seoul', c2, 'no interpolation across a 45-day gap; line segment breaks'),
    ('rate.dstSameDayLastWinsAndGain', 'America/New_York', c3, 'kg input (200 lb and 201 lb rows already converted at platform read); 2026-03-08 DST start; gap counted in local calendar days; gain reported as direction gain'),
    ('rate.zoneDayBoundaryTieHiddenIneligible', 'Asia/Seoul', c4, '15:30Z is next local day in Seoul; same-instant tie prefers manual; hidden and ineligible imports excluded'),
    ('rate.noChange', 'Asia/Seoul', c6, 'zero change is noChange, not loss'),
]:
    add_rate(cid, zone, samples, note)

band_cases = []
def add_band(cid, ref, val):
    band_cases.append({'id': cid, 'referenceId': ref, 'value': val, 'expected': member(val, cat[ref])})
for cid, ref, val in [
    ('band.nhs.lowerEdgeInclusive', 'rate.nhs.2023', 0.5), ('band.nhs.roundsUpIntoBand', 'rate.nhs.2023', 0.499),
    ('band.nhs.upperEdgeInclusive', 'rate.nhs.2023', 1.004), ('band.nhs.binaryTieRoundsAbove', 'rate.nhs.2023', 1.005),
    ('band.nhs.gainIsBelow', 'rate.nhs.2023', -0.3),
    ('band.cdc.poundBoundsRounded', 'rate.cdc.2025', 0.451), ('band.cdc.aboveUpper', 'rate.cdc.2025', 0.915),
    ('band.ksso.insideTop', 'bmi.ksso.2022', 22.9), ('band.ksso.roundsToExclusiveUpper', 'bmi.ksso.2022', 22.95),
    ('band.ksso.roundsUpToLower', 'bmi.ksso.2022', 18.45), ('band.ksso.below', 'bmi.ksso.2022', 18.4),
    ('band.who.upperExclusive', 'bmi.who.adult', 25.0), ('band.who.inside', 'bmi.who.adult', 24.94),
    ('band.niceThreshold.atOrAboveAt23', 'bmi.nice.ng246.lowerThreshold', 23.0), ('band.niceThreshold.roundsUpTo23', 'bmi.nice.ng246.lowerThreshold', 22.95),
    ('band.niceThreshold.below', 'bmi.nice.ng246.lowerThreshold', 22.94), ('band.jasso.inside', 'bmi.jasso', 24.9),
]:
    add_band(cid, ref, val)

def percent_band(entry, start):
    """DESIGN-20260915-10 percent mode; null (no band) for BMI, a threshold, or an unusable start weight."""
    if entry['metric'] != 'weightLossRate' or entry['kind'] != 'band': return None
    if not (isinstance(start, (int, float)) and math.isfinite(start) and start > 0): return None
    lo, up = band_bounds_kg(entry)
    return {'lowerPercentPerWeek': fx(lo / start * 100, 6), 'upperPercentPerWeek': fx(up / start * 100, 6),
            'displayLower': fx(lo / start * 100, 2), 'displayUpper': fx(up / start * 100, 2)}
pct_band = []
def add_pct(cid, ref, startKg):
    pct_band.append({'id': cid, 'referenceId': ref, 'intervalStartKg': startKg, 'expected': percent_band(cat[ref], startKg)})
for cid, ref, startKg in [('percentBand.nhsAt92kg', 'rate.nhs.2023', 92.0), ('percentBand.cdcAt68kg', 'rate.cdc.2025', 68.0388555)]:
    add_pct(cid, ref, startKg)

def bmi(wk, h):
    if wk is None or h is None: return None
    if not (20.0 <= wk <= 400.0) or not (30.0 <= h <= 280.0): return None
    m = h / 100
    return wk / (m * m)
bmi_cases = []
for cid, w, h in [('bmi.kgCm', 92.0, 170.0), ('bmi.recordReadFromPoundRow', 90.718474, 180.0), ('bmi.missingHeight', 92.0, None),
                  ('bmi.heightOutOfRange', 70.0, 25.0), ('bmi.weightOutOfRange', 19.9, 150.0), ('bmi.exactBoundaryValue', 72.25, 170.0)]:
    v = bmi(w, h)
    bmi_cases.append({'id': cid, 'input': {'weightKg': w, 'heightCm': h},
                      'expected': None if v is None else {'bmi': fx(v, 6), 'display': fx(v, 1)}})

units = [{'id': 'unit.lbToKg', 'value': 1, 'from': 'lb', 'to': 'kg', 'expected': fx(LB, 8)},
         {'id': 'unit.lb150ToKg', 'value': 150, 'from': 'lb', 'to': 'kg', 'expected': fx(150 * LB, 8)},
         {'id': 'unit.kgToLb', 'value': 90.0, 'from': 'kg', 'to': 'lb', 'expected': fx(90.0 / LB, 8)}]

TARGET_RULES = {('weightLossRate', 'kgPerWeek'): (0.01, 5.0, 2), ('weightLossRate', 'percentPerWeek'): (0.01, 5.0, 2), ('bmi', 'kgPerM2'): (10.0, 60.0, 1)}
def target_validate(metric, unit, lo, up):
    if (metric, unit) not in TARGET_RULES: return 'unsupportedUnit'
    mn, mx, dp = TARGET_RULES[(metric, unit)]
    if lo is None or up is None: return 'missingBound'
    for s in (lo, up):
        # v3: ASCII digits only. Python's \d (used by v2) also matches other scripts' digits; no v2 case had any.
        if not re.fullmatch(r'[0-9]{1,3}(\.[0-9]{1,%d})?' % dp, s): return 'invalidDecimal'
    a, b = float(lo), float(up)
    if a < mn or b > mx: return 'outOfRange'
    if a > b: return 'lowerAboveUpper'
    return 'valid'
targets = []
def add_target(cid, m, u, lo, up):
    targets.append({'id': cid, 'input': {'metric': m, 'unit': u, 'lower': lo, 'upper': up}, 'expected': target_validate(m, u, lo, up)})
for cid, m, u, lo, up in [('target.kgValid', 'weightLossRate', 'kgPerWeek', '0.3', '0.8'), ('target.singleValueAllowed', 'weightLossRate', 'kgPerWeek', '0.5', '0.5'),
                          ('target.lowerAboveUpper', 'weightLossRate', 'kgPerWeek', '0.9', '0.4'), ('target.tooManyDecimals', 'weightLossRate', 'kgPerWeek', '0.125', '0.5'),
                          ('target.percentOutOfRange', 'weightLossRate', 'percentPerWeek', '0.5', '5.5'), ('target.missingUpper', 'weightLossRate', 'percentPerWeek', '0.5', None),
                          ('target.bmiValid', 'bmi', 'kgPerM2', '21.0', '24.5'), ('target.bmiTwoDecimals', 'bmi', 'kgPerM2', '21.05', '24.5'),
                          ('target.bmiWrongUnit', 'bmi', 'kgPerWeek', '21.0', '24.5'), ('target.zeroBelowMinimum', 'weightLossRate', 'kgPerWeek', '0', '0.5')]:
    add_target(cid, m, u, lo, up)

REFERENCE_METRICS = ('weightLossRate', 'bmi')
REFERENCE_UNITS = ('kgPerWeek', 'lbPerWeek', 'percentPerWeek', 'kgPerM2')
def resolve_setting(row):
    """Design 4.4, in the order both engines implement it."""
    if row is None: return {'effective': 'none'}
    mode = row.get('mode')
    if mode == 'official':
        rid = row.get('officialReferenceId')
        if rid is None: return {'effective': 'invalid'}
        ref = cat.get(rid)
        if ref is None: return {'effective': 'unavailable'}  # before any metric check
        if row.get('metric') not in REFERENCE_METRICS or ref['metric'] != row.get('metric'): return {'effective': 'invalid'}
        return {'effective': 'official', 'referenceId': rid}  # personal fields are ignored
    if mode == 'personal':
        metric, unit = row.get('metric'), row.get('personalUnit')
        if metric not in REFERENCE_METRICS or unit not in REFERENCE_UNITS: return {'effective': 'invalid'}
        ok = target_validate(metric, unit, row.get('personalLower'), row.get('personalUpper')) == 'valid'
        return {'effective': 'personal'} if ok else {'effective': 'invalid'}  # officialReferenceId is ignored
    return {'effective': 'invalid'}
settings = []
def add_setting(cid, row, expected=None):
    computed = resolve_setting(row)
    if expected is not None:
        assert computed == expected, (cid, computed, expected)  # v2 expectations were hand-written; the reference must agree
    settings.append({'id': cid, 'row': row, 'expected': computed})
for cid, row, exp in [
    ('setting.offDefault', None, {'effective': 'none'}),
    ('setting.official', {'metric': 'bmi', 'mode': 'official', 'officialReferenceId': 'bmi.ksso.2022'}, {'effective': 'official', 'referenceId': 'bmi.ksso.2022'}),
    ('setting.officialWrongMetric', {'metric': 'bmi', 'mode': 'official', 'officialReferenceId': 'rate.nhs.2023'}, {'effective': 'invalid'}),
    ('setting.unknownReferenceFromNewerCatalog', {'metric': 'bmi', 'mode': 'official', 'officialReferenceId': 'bmi.example.future'}, {'effective': 'unavailable'}),
    ('setting.personal', {'metric': 'weightLossRate', 'mode': 'personal', 'personalUnit': 'percentPerWeek', 'personalLower': '0.4', 'personalUpper': '0.9'}, {'effective': 'personal'}),
    ('setting.personalInvalidRestoredRejected', {'metric': 'weightLossRate', 'mode': 'personal', 'personalUnit': 'kgPerWeek', 'personalLower': '2', 'personalUpper': '1'}, {'effective': 'invalid'}),
    ('setting.unsupportedMetric', {'metric': 'bodyFat', 'mode': 'official', 'officialReferenceId': 'bmi.who.adult'}, {'effective': 'invalid'}),
]:
    add_setting(cid, row, exp)

def minus_years(d, n):
    # java.time LocalDate.minusYears / Foundation Calendar byAdding .year: Feb 29 -> Feb 28
    try: return d.replace(year=d.year - n)
    except ValueError: return d.replace(year=d.year - n, day=28)
def plus_years(d, n):
    try: return d.replace(year=d.year + n)
    except ValueError: return d.replace(year=d.year + n, day=28)
def min_start(end):
    # earliest start both validators accept: start + 5 years >= end
    s = minus_years(end, 5)
    if plus_years(s, 5) < end: s = s + timedelta(days=1)
    return s

PRESETS = [('oneMonth', 30), ('threeMonths', 90), ('sixMonths', 180), ('oneYear', 365)]
def zoom(spanDays, endDate, today, scale=1.0, panDays=0):
    if not (isinstance(scale, (int, float)) and math.isfinite(scale) and scale > 0): scale = 1.0  # v3: no usable scale, no zoom
    end = date.fromisoformat(endDate); td = date.fromisoformat(today)
    end = min(end + timedelta(days=panDays), td)
    maxSpan = (end - min_start(end)).days
    raw = min(max(spanDays / scale, 7.0), float(maxSpan))
    span = None
    for name, p in PRESETS:
        if abs(raw - p) <= 0.15 * p: span = p; break
    if span is None: span = int(math.floor(raw + 0.5 + EPS))
    span = min(span, maxSpan)
    start = end - timedelta(days=span)
    preset = next((n for n, p in PRESETS if p == span), None) if end == td else None
    return {'period': preset or 'custom', 'spanDays': span, 'start': start.isoformat(), 'end': end.isoformat(), 'rateLookbackStart': (start - timedelta(days=28)).isoformat()}
zooms = []
def add_zoom(cid, span, end, scale, pan, today='2026-09-15'):
    zooms.append({'id': cid, 'input': {'today': today, 'spanDays': span, 'end': end, 'cumulativeScale': scale, 'panDays': pan}, 'expected': zoom(span, end, today, scale, pan)})
for c in [('zoom.outNoSnap', 30, '2026-09-15', 0.5, 0), ('zoom.outSnapsToThreeMonths', 30, '2026-09-15', 0.35, 0),
          ('zoom.inClampsToSevenDays', 90, '2026-09-15', 20.0, 0), ('zoom.outClampsToFiveYears', 365, '2026-09-15', 0.1, 0),
          ('zoom.snapWhenEndNotTodayStaysCustom', 30, '2026-08-31', 1.05, 0), ('zoom.unchanged', 90, '2026-09-15', 1.0, 0),
          ('zoom.panForwardClampsToToday', 30, '2026-09-10', 1.0, 10), ('zoom.panBackKeepsSpan', 180, '2026-09-15', 1.0, -20),
          ('zoom.outClampsLeapDay', 365, '2028-02-29', 0.1, 0, '2028-02-29'),
          ('zoom.panOntoLeapDayReclampsSpan', 1827, '2028-03-01', 1.0, -1, '2028-03-01')]:
    add_zoom(*c)

V2N = {'weeklyRate': len(rate_cases), 'bandMembership': len(band_cases), 'percentBandConversion': len(pct_band),
       'personalTargetValidation': len(targets), 'referenceSettingResolution': len(settings), 'zoom': len(zooms)}

# ---------------------------------------------------------------- v3 additions (2026-09-15)
add_rate('rate.nonPositiveWeightsDropped', 'Asia/Seoul',
         [S('z1', '2026-09-01T00:00:00Z', 88.0), S('z2', '2026-09-08T00:00:00Z', 0.0), S('z3', '2026-09-08T01:00:00Z', -5.0, 'imported'),
          S('z4', '2026-09-15T00:00:00Z', 87.3, 'imported'), S('z5', '2026-09-15T02:00:00Z', 0.0)],
         'kg 0 and negative samples are dropped before the daily winner: 09-08 has no point, and on 09-15 the later manual 0 kg sample does not outrank the imported 87.3 kg; the rate starts at 09-01 (14 days)')
add_rate('rate.tinyGainIsNoChange', 'Asia/Seoul',
         [S('n1', '2026-09-01T00:00:00Z', 88.0), S('n2', '2026-09-08T00:00:00Z', 88.004)],
         'a 0.004 kg/week gain rounds to 0.00 at display precision: direction noChange, magnitudes print 0.00')
add_rate('rate.sameInstantSameSourceOrdinalIdWins', 'Asia/Seoul',
         [S('a1', '2026-09-01T00:00:00Z', 88.5), S('b10', '2026-09-08T00:00:00Z', 88.0), S('b9', '2026-09-08T00:00:00Z', 87.0)],
         'same instant and same source: the greater id in ordinal string order wins ("b9" > "b10"), not numeric order')

add_band('band.nhs.tinyGainRoundsToPositiveZero', 'rate.nhs.2023', -0.004)
add_band('band.nhs.gainTieRoundsAwayFromZero', 'rate.nhs.2023', -0.005)
add_band('band.cdc.tinyGainRoundsToPositiveZero', 'rate.cdc.2025', -0.004)
add_band('band.ksso.tinyNegativeRoundsToPositiveZero', 'bmi.ksso.2022', -0.04)
add_band('band.niceThreshold.tinyNegativeRoundsToPositiveZero', 'bmi.nice.ng246.lowerThreshold', -0.04)

add_pct('percentBand.bmiReferenceHasNone', 'bmi.who.adult', 92.0)
add_pct('percentBand.thresholdHasNone', 'bmi.nice.ng246.lowerThreshold', 92.0)
add_pct('percentBand.zeroStartWeightHasNone', 'rate.nhs.2023', 0.0)
add_pct('percentBand.negativeStartWeightHasNone', 'rate.cdc.2025', -80.0)

add_target('target.nonAsciiDigitsRejected', 'weightLossRate', 'kgPerWeek', '٠.٥', '0.9')
add_target('target.trailingDotRejected', 'weightLossRate', 'kgPerWeek', '0.5', '1.')
add_target('target.leadingDotRejected', 'weightLossRate', 'percentPerWeek', '.5', '1.0')
add_target('target.signRejected', 'weightLossRate', 'kgPerWeek', '+0.5', '1.0')
add_target('target.fourIntegerDigitsRejectedBeforeRange', 'bmi', 'kgPerM2', '21.0', '1000')
add_target('target.missingCheckedBeforeGrammar', 'weightLossRate', 'kgPerWeek', None, 'abc')
add_target('target.unitCheckedBeforeMissing', 'bmi', 'percentPerWeek', None, None)
add_target('target.rangeCheckedBeforeOrder', 'weightLossRate', 'kgPerWeek', '6', '5.5')
add_target('target.lowerAboveMaximumReportsOrder', 'weightLossRate', 'kgPerWeek', '5.5', '5.0')
add_target('target.rateBoundsInclusive', 'weightLossRate', 'percentPerWeek', '0.01', '5.00')
add_target('target.bmiBoundsInclusive', 'bmi', 'kgPerM2', '10.0', '60.0')

add_setting('setting.unknownIdCheckedBeforeMetric', {'metric': 'bodyFat', 'mode': 'official', 'officialReferenceId': 'bmi.example.future'})
add_setting('setting.officialMissingId', {'metric': 'bmi', 'mode': 'official', 'officialReferenceId': None})
add_setting('setting.unknownMode', {'metric': 'bmi', 'mode': 'automatic', 'officialReferenceId': 'bmi.who.adult'})
add_setting('setting.personalUnknownUnit', {'metric': 'weightLossRate', 'mode': 'personal', 'personalUnit': 'stonePerWeek', 'personalLower': '0.4', 'personalUpper': '0.9'})
add_setting('setting.personalMissingUnit', {'metric': 'weightLossRate', 'mode': 'personal', 'personalUnit': None, 'personalLower': '0.4', 'personalUpper': '0.9'})
add_setting('setting.personalBmi', {'metric': 'bmi', 'mode': 'personal', 'personalUnit': 'kgPerM2', 'personalLower': '21.0', 'personalUpper': '24.5'})
add_setting('setting.personalBmiWrongUnit', {'metric': 'bmi', 'mode': 'personal', 'personalUnit': 'percentPerWeek', 'personalLower': '0.4', 'personalUpper': '0.9'})
add_setting('setting.personalUnsupportedMetric', {'metric': 'waist', 'mode': 'personal', 'personalUnit': 'kgPerWeek', 'personalLower': '0.4', 'personalUpper': '0.9'})
add_setting('setting.personalIgnoresOfficialId', {'metric': 'weightLossRate', 'mode': 'personal', 'officialReferenceId': 'bmi.example.future', 'personalUnit': 'percentPerWeek', 'personalLower': '0.4', 'personalUpper': '0.9'})
add_setting('setting.officialIgnoresPersonalFields', {'metric': 'bmi', 'mode': 'official', 'officialReferenceId': 'bmi.who.adult', 'personalUnit': 'kgPerWeek', 'personalLower': '2', 'personalUpper': '1'})

add_zoom('zoom.zeroScaleKeepsSpan', 90, '2026-09-15', 0.0, 0)
add_zoom('zoom.negativeScaleKeepsSpanPanApplies', 30, '2026-09-10', -2.0, 3)
add_zoom('zoom.halfDayRoundsUp', 81, '2026-09-15', 2.0, 0)
add_zoom('zoom.snapToleranceInclusive', 69, '2026-09-15', 2.0, 0)
add_zoom('zoom.justOutsideSnapToleranceRounds', 173, '2026-09-15', 5.0, 0)

def usable_start(start):
    return isinstance(start, (int, float)) and math.isfinite(start) and start > 0
def target_membership(metric, unit, lo, up, chart_unit, start, value):
    """CORE-20260915-01. Inclusive at both bounds; compared in the chart unit after conversion, rounded to the rule's decimals.
    CORE-20260915-07 (v4): a rate target shown in the other rate unit converts through the interval start weight in both
    directions (% -> kg: bound * start / 100; kg -> %: bound / start * 100); a start weight that is not finite and positive
    makes the target unavailable (None): nothing is drawn, nothing throws."""
    assert target_validate(metric, unit, lo, up) == 'valid'
    dp = TARGET_RULES[(metric, unit)][2]
    a, b = float(lo), float(up)
    if chart_unit == unit:
        assert start is None
        la, ub = a, b
    elif (unit, chart_unit) == ('percentPerWeek', 'kgPerWeek'):
        if not usable_start(start): return None
        la, ub = a * start / 100, b * start / 100  # design 3.2: personal % target shown in kg -> x startKg / 100
    elif (unit, chart_unit) == ('kgPerWeek', 'percentPerWeek'):
        if not usable_start(start): return None
        la, ub = a / start * 100, b / start * 100  # CORE-20260915-07: the inverse, the percent-band formula (design 3.2)
    else:
        raise ValueError('conversion not pinned by the design')
    v, l, u = rnd(value, dp), rnd(la, dp), rnd(ub, dp)
    position = 'below' if v < l else ('above' if v > u else 'inside')
    return {'roundedValue': fx(value, dp), 'roundedLower': fx(la, dp), 'roundedUpper': fx(ub, dp), 'position': position, 'singleLine': a == b}
membership_cases = []
def add_membership(cid, metric, unit, lo, up, chart_unit, start, value):
    membership_cases.append({'id': cid, 'input': {'metric': metric, 'unit': unit, 'lower': lo, 'upper': up, 'chartUnit': chart_unit,
                                                  'intervalStartKg': start, 'value': value},
                             'expected': target_membership(metric, unit, lo, up, chart_unit, start, value)})
R, KG, PCT, M2 = 'weightLossRate', 'kgPerWeek', 'percentPerWeek', 'kgPerM2'
add_membership('targetMembership.kg.upperInclusive', R, KG, '0.3', '0.8', KG, None, 0.8)
add_membership('targetMembership.kg.lowerInclusive', R, KG, '0.3', '0.8', KG, None, 0.3)
add_membership('targetMembership.kg.roundsIntoLower', R, KG, '0.3', '0.8', KG, None, 0.2951)
add_membership('targetMembership.kg.roundsBelowLower', R, KG, '0.3', '0.8', KG, None, 0.294)
add_membership('targetMembership.kg.binaryTieRoundsAbove', R, KG, '0.3', '0.8', KG, None, 0.805)
add_membership('targetMembership.kg.tinyGainBelowAtPositiveZero', R, KG, '0.3', '0.8', KG, None, -0.004)
add_membership('targetMembership.percent.roundsOntoUpper', R, PCT, '0.4', '0.9', PCT, None, 0.904)
add_membership('targetMembership.percent.roundsAboveUpper', R, PCT, '0.4', '0.9', PCT, None, 0.905)
add_membership('targetMembership.percentTargetInKg.roundedLowerInclusive', R, PCT, '0.45', '0.9', KG, 87.3, 0.389)
add_membership('targetMembership.percentTargetInKg.roundsOntoUpper', R, PCT, '0.5', '1.0', KG, 92.0, 0.924)
add_membership('targetMembership.percentTargetInKg.roundsAboveUpper', R, PCT, '0.5', '1.0', KG, 92.0, 0.925)
add_membership('targetMembership.singleLine.kgOnLine', R, KG, '0.5', '0.5', KG, None, 0.504)
add_membership('targetMembership.singleLine.kgAbove', R, KG, '0.5', '0.5', KG, None, 0.505)
add_membership('targetMembership.singleLine.kgBelow', R, KG, '0.5', '0.5', KG, None, 0.4949)
add_membership('targetMembership.singleLine.percentTargetInKg', R, PCT, '0.6', '0.6', KG, 80.0, 0.48)
add_membership('targetMembership.bmi.roundsIntoLower', 'bmi', M2, '21.0', '24.5', M2, None, 20.95)
add_membership('targetMembership.bmi.upperInclusive', 'bmi', M2, '21.0', '24.5', M2, None, 24.54)
add_membership('targetMembership.bmi.roundsAboveUpper', 'bmi', M2, '21.0', '24.5', M2, None, 24.55)

V3N = {'weeklyRate': len(rate_cases), 'bandMembership': len(band_cases), 'percentBandConversion': len(pct_band),
       'personalTargetValidation': len(targets), 'referenceSettingResolution': len(settings), 'zoom': len(zooms),
       'personalTargetMembership': len(membership_cases)}

# ---------------------------------------------------------------- v4 additions (2026-09-15, CORE-20260915-07)
# Zoom: spanDays at or below zero clamps to the 7-day minimum (raw = clamp(spanDays / scale, 7, maxSpan)); no throw.
add_zoom('zoom.zeroSpanClampsToSevenDays', 0, '2026-09-15', 1.0, 0)
add_zoom('zoom.negativeSpanClampsToSevenDays', -30, '2026-09-15', 0.5, 0)
add_zoom('zoom.zeroSpanEndNotTodayIsCustomSevenDays', 0, '2026-08-31', 1.0, 0)
add_zoom('zoom.negativeSpanPanStillApplies', -1, '2026-09-10', 1.0, -5)

# A percentPerWeek target shown in kgPerWeek needs a finite positive interval start weight; otherwise unavailable (null).
add_membership('targetMembership.percentTargetInKg.zeroStartUnavailable', R, PCT, '0.5', '1.0', KG, 0.0, 0.5)
add_membership('targetMembership.percentTargetInKg.negativeStartUnavailable', R, PCT, '0.5', '1.0', KG, -80.0, 0.5)
# A kgPerWeek target shown in percentPerWeek converts symmetrically: bound / intervalStartKg * 100 (the percent-band formula).
add_membership('targetMembership.kgTargetInPercent.inside', R, KG, '0.5', '1.0', PCT, 80.0, 0.9)
add_membership('targetMembership.kgTargetInPercent.roundedLowerInclusive', R, KG, '0.5', '1.0', PCT, 80.0, 0.625)
add_membership('targetMembership.kgTargetInPercent.roundsBelowLower', R, KG, '0.5', '1.0', PCT, 80.0, 0.6249)
add_membership('targetMembership.kgTargetInPercent.upperInclusive', R, KG, '0.5', '1.0', PCT, 80.0, 1.25)
add_membership('targetMembership.kgTargetInPercent.roundsAboveUpper', R, KG, '0.5', '1.0', PCT, 80.0, 1.2551)
add_membership('targetMembership.kgTargetInPercent.nhsLikeAt92kg', R, KG, '0.5', '1.0', PCT, 92.0, 0.54)
add_membership('targetMembership.kgTargetInPercent.singleLine', R, KG, '0.5', '0.5', PCT, 100.0, 0.504)
add_membership('targetMembership.kgTargetInPercent.zeroStartUnavailable', R, KG, '0.5', '1.0', PCT, 0.0, 0.7)
add_membership('targetMembership.kgTargetInPercent.negativeStartUnavailable', R, KG, '0.5', '1.0', PCT, -80.0, 0.7)
# Symmetry: the kg bounds of an NHS-like personal target at 92 kg convert to the same percent bounds as the official
# percent band of rate.nhs.2023 at 92 kg (percentBand.nhsAt92kg): both are bound / 92 * 100.
_sym = target_membership(R, KG, '0.5', '1.0', PCT, 92.0, 0.54)
_pct = percent_band(cat['rate.nhs.2023'], 92.0)
assert (_sym['roundedLower'], _sym['roundedUpper']) == (_pct['displayLower'], _pct['displayUpper']), (_sym, _pct)

CONVENTIONS_V2 = {
    'numbers': 'expected decimal strings; compare parsed Double within 5e-7 for 6-dp values; display strings must match exactly',
    'rounding': 'halfUpEpsilon: sign(x) * floor(abs(x) * 10^dp + 0.5 + 1e-9) / 10^dp',
    'poundToKilogram': '0.45359237',
    'sampleUnits': 'engine input is kilograms only; platforms convert at read (Android DoseWeekRepository mapManualBodyRecord/mapBodyRecord, iOS valueSI); the engine never converts sample units',
    'dayKey': 'local calendar date of instant in the case zone; every body sample has an instant (no date-only samples exist on either platform)',
    'dailyWinner': 'max of (instant ISO string, source manual=1 imported=0, id); hidden and ineligible samples excluded',
    'rateStart': 'latest earlier daily point with gapDays >= minGapDays; if gapDays > maxGapDays status gapTooLong; none status insufficientHistory',
    'lossKgPerWeek': '(startKg - endKg) * 7 / gapDays; positive means loss',
    'lossPercentPerWeek': 'lossKgPerWeek / startKg * 100 (denominator = interval starting weight, CHART-20260913-04)',
    'direction': 'sign of lossKgPerWeek rounded to 2 dp: >0 loss, <0 gain, 0 noChange',
    'bandMembership': 'kind band: round value and bounds to displayDecimals then compare using inclusivity -> inside|above|below; lb bounds converted to kg first. kind threshold: lower is null, no fill, round value and upper -> atOrAboveThreshold|belowThreshold',
    'zoom': 'end = min(end + panDays, today) first; minStart = end minusYears 5 (Feb 29 -> Feb 28), plus 1 day if minStart plusYears 5 < end; maxSpan = days(minStart, end); raw = clamp(spanDays / cumulativeScale, 7, maxSpan); snap to preset p when abs(raw-p) <= 0.15p else halfUpEpsilon integer; span = min(span, maxSpan); start = end - span; preset only when end == today; rateLookbackStart = start - 28 days',
    'settingResolution': 'no row -> none; mode official with id absent from catalog -> unavailable; id present but catalog metric differs from row metric, metric not in {weightLossRate,bmi}, or personal target not valid -> invalid; else official or personal',
    'metricsWithoutReferences': ['bodyFat', 'leanMass', 'waist', 'height']
}
CONVENTION_APPENDS_V3 = {
    'rounding': '; a result of zero is +0, so it prints 0.00, never -0.00',
    'dailyWinner': '; samples whose kg is not a finite positive number are excluded before the winner is chosen',
    'zoom': '; a cumulativeScale that is not a finite positive number counts as 1 (span unchanged; panDays still applies)',
    'settingResolution': '. Order: mode official with officialReferenceId null -> invalid; an id absent from the catalog -> unavailable before any metric check; official ignores personal fields; mode personal ignores officialReferenceId and needs a known unit; any other mode -> invalid',
}
CONVENTIONS_V3_NEW = {
    'percentBand': 'percentBandConversion expected is null (no band drawn) for a bmi reference, a threshold, or an intervalStartKg that is not a finite positive number (DESIGN-20260915-10)',
    'personalTargetGrammar': 'canonical text is ASCII only: [0-9]{1,3}(\\.[0-9]{1,dp})?; other scripts\' digits, signs, spaces and a leading or trailing dot are invalidDecimal. Check order: supported unit, both bounds present, grammar, range (only lower >= minimum and upper <= maximum), order',
    'personalTargetMembership': 'CORE-20260915-01: a personal target is inclusive at both bounds. value is in chartUnit. A percentPerWeek target shown in kgPerWeek converts each bound as bound * intervalStartKg / 100 (design 3.2); a target in the chart unit uses its bounds as stored (intervalStartKg null). Value and bounds are rounded with halfUpEpsilon to the target rule decimals (weightLossRate 2, bmi 1), the same rule as official bands (design 4.3); then below when value < lower, above when value > upper, else inside. singleLine is true when the stored lower equals upper: one line is drawn and a value on it is inside',
    'decisions': ['DESIGN-20260915-10', 'DESIGN-20260915-12', 'CORE-20260915-01'],
    'versioning': 'version 3 supersedes body_chart_references_v2.json (SHA-256 16982165b2c0ae350faea48cc6ec01792f94fa54b79d0d04caa7f0536a64b27f). Every v2 case is unchanged at the start of its section; later cases and section personalTargetMembership are new. Generator: body_chart_references_v3.generator.py',
}

CONVENTION_APPENDS_V4 = {
    'zoom': '; a spanDays at or below zero clamps to the 7-day minimum like any raw value below 7 (CORE-20260915-07: no throw on either platform)',
}
CONVENTIONS_V4_NEW = {
    'personalTargetMembership': 'CORE-20260915-01: a personal target is inclusive at both bounds. value is in chartUnit. A percentPerWeek target shown in kgPerWeek converts each bound as bound * intervalStartKg / 100 (design 3.2); a kgPerWeek target shown in percentPerWeek converts each bound as bound / intervalStartKg * 100, the same formula as the official percent band (CORE-20260915-07, symmetric); a target in the chart unit uses its bounds as stored (intervalStartKg null). Value and bounds are rounded with halfUpEpsilon to the target rule decimals (weightLossRate 2, bmi 1), the same rule as official bands (design 4.3); then below when value < lower, above when value > upper, else inside. singleLine is true when the stored lower equals upper: one line is drawn and a value on it is inside. expected is null when a conversion needs intervalStartKg and it is not a finite positive number (0 and negatives here; NaN and infinity have no JSON form): the target is unavailable for that interval, nothing is drawn and nothing throws (CORE-20260915-07)',
    'decisions': ['DESIGN-20260915-10', 'DESIGN-20260915-12', 'CORE-20260915-01', 'CORE-20260915-07'],
    'versioning': 'version 4 supersedes body_chart_references_v3.json (SHA-256 535ec345860032d3ecb996721ac02e330f1cbf0200374f5fe04aa46ee4fdaaee) and v2 (16982165b2c0ae350faea48cc6ec01792f94fa54b79d0d04caa7f0536a64b27f). Every v2 and v3 case is unchanged at the start of its section (changedFromV3 is empty); 4 zoom and 11 personalTargetMembership cases are new. Generator: body_chart_references_v4.generator.py (--v2 and --v3 reproduce the earlier files byte for byte)',
}
CHANGED_FROM_V3 = []  # CORE-20260915-07 changes no v3 expectation: the reference already clamped spanDays <= 0, and no v3 case converted with an unusable start weight

def document(version):
    counts = {2: V2N, 3: V3N, 4: None}[version]
    cut = lambda name, rows: rows if counts is None else rows[:counts[name]]
    conventions = dict(CONVENTIONS_V2)
    if version >= 3:
        for k, extra in CONVENTION_APPENDS_V3.items(): conventions[k] = conventions[k] + extra
        conventions.update(CONVENTIONS_V3_NEW)
    if version >= 4:
        for k, extra in CONVENTION_APPENDS_V4.items(): conventions[k] = conventions[k] + extra
        conventions.update(CONVENTIONS_V4_NEW)
    doc = {'fixture': 'body_chart_references', 'version': version, 'accessed': '2026-09-15'}
    if version >= 4: doc['changedFromV3'] = CHANGED_FROM_V3
    doc.update({
      'conventions': conventions,
      'referenceCatalog': catalog,
      'unitConversion': units,
      'bmiFromSameRecord': bmi_cases,
      'weeklyRate': cut('weeklyRate', rate_cases),
      'bandMembership': cut('bandMembership', band_cases),
      'percentBandConversion': cut('percentBandConversion', pct_band),
      'personalTargetValidation': cut('personalTargetValidation', targets),
      'referenceSettingResolution': cut('referenceSettingResolution', settings),
      'zoom': cut('zoom', zooms),
    })
    if version >= 3: doc['personalTargetMembership'] = cut('personalTargetMembership', membership_cases)
    return doc

if __name__ == '__main__':
    flags = {a for a in sys.argv[1:] if a in ('--v2', '--v3')}
    args = [a for a in sys.argv[1:] if a not in flags]
    if len(args) != 1 or len(flags) > 1: sys.exit('usage: body_chart_references_v4.generator.py [--v2|--v3] <output.json>')
    version = 2 if '--v2' in flags else 3 if '--v3' in flags else 4
    out = (json.dumps(document(version), indent=2, ensure_ascii=True, sort_keys=False) + '\n').encode('ascii')
    open(args[0], 'wb').write(out)
    print('sha256', hashlib.sha256(out).hexdigest(), len(out))
    if version == 4:
        for r in zooms[V3N['zoom']:]: print(r['id'], json.dumps(r['expected']))
        for r in membership_cases[V3N['personalTargetMembership']:]: print(r['id'], json.dumps(r['expected']))
