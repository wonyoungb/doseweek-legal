#!/usr/bin/env python3
"""schedule_explicit_dates fixture generator: the reference implementation of
designs/schedule-explicit-dates.md sections 3.2-3.4 and 10. Never hand-edit the output.

Durable copy of the design-wave generator (session scratchpad `schedule-explicit-dates/gen.py`, which
wrote schedule_explicit_dates_v1.json, SHA-256 f19391910a20df8ec46188ceac98980508c9eb563ad53ad3bf9dd6dc3456577d),
updated 2026-09-15 for v3 (core-engines parity closure):

- CORE-20260915-02: only completed and skipped rows occupy a chosen slot. scheduled, due, needsReview
  and cancelled rows never do; their slot is generated and gated, and the gate still covers every
  generated slot of the full canonical list. (The v1 generator let unresolved rows occupy; no v1
  case exercised that branch, so every v1 expectation is unchanged.)
- Gate hours that are not a finite positive number mean policyUnavailable, exactly like null
  (iOS `ExplicitDateSchedule.propose` guard `hours.isFinite, hours > 0`; Android `toDurationOrNull`).

Every v1 case is regenerated unchanged at the start of its section; v3 cases are appended, plus the
new section `gateHoursGuard`. `--v1` writes the v1 document instead and must reproduce the v1 file
byte for byte.

Usage: python3 schedule_explicit_dates_v3.generator.py [--v1] <output.json>
"""
import json, hashlib, math, sys
from datetime import date, datetime, timedelta, timezone, time
from zoneinfo import ZoneInfo
E0=date(1970,1,1)
MAXN=60; AHEAD=366; MINE=10956; MAXE=84006
POL={"mounjaro.kr.prefilled-pen.2026-09-13":72.0,"mounjaro.us.weekly.2026-04-22":72.0,"wegovy.us.weekly.2025-08":48.0,"generic.weekly.record-only":None}
def ep(s): return (date.fromisoformat(s)-E0).days
def ds(e): return (E0+timedelta(days=e)).isoformat()
def iso(dt): return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
def pi(s): return datetime.strptime(s,"%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
def slot(e,lt,zone):
    h,m=map(int,lt.split(":")); d=E0+timedelta(days=e)
    naive=datetime(d.year,d.month,d.day,h,m)
    dt=datetime(d.year,d.month,d.day,h,m,tzinfo=ZoneInfo(zone),fold=0)
    u=dt.astimezone(timezone.utc); back=u.astimezone(ZoneInfo(zone))
    off=back.utcoffset(); sign="+" if off>=timedelta(0) else "-"; off=abs(off)
    return u,{"resolvedLocalTime":back.strftime("%H:%M"),"utcOffset":f"{sign}{off.seconds//3600:02d}:{(off.seconds%3600)//60:02d}","dstAdjusted":back.replace(tzinfo=None)!=naive}
def occupies(o):
    """CORE-20260915-02: only a completed or skipped fact holds a chosen slot, and only where both
    platforms' slot authorities let it (resolved on or after its slot, or earlier on the slot's own
    local day). scheduled, due, needsReview and cancelled rows hold nothing."""
    st=o["status"]; sa=pi(o["scheduledAt"]); ra=pi(o["resolvedAt"]) if o.get("resolvedAt") else None
    if st not in("completed","skipped") or ra is None: return False
    if not sa>ra: return True
    z=ZoneInfo(o["scheduledTimeZone"]); return sa.astimezone(z).date()==ra.astimezone(z).date()
def usable_hours(H):
    """A day-change minimum gates only as a finite positive number; anything else is no rule."""
    return H is not None and math.isfinite(H) and H>0
def canon(local):
    days=sorted({ep(s) for s in local})
    return days
def wiso(e): return (E0+timedelta(days=e)).isoweekday()

canonicalization=[]
def ccase(i,local,desc):
    days=canon(local); err=None
    if not days: err="empty"
    elif len(days)>MAXN: err="tooMany"
    elif any(not(MINE<=d<=MAXE) for d in days): err="outOfRange"
    canonicalization.append({"id":i,"description":desc,"input":{"localDates":local},
      "expected":{"valid":err is None,"error":err,"canonicalEpochDays":days if err is None else None,
      "storage":",".join(map(str,days)) if err is None else None,"firstWeekdayIso":wiso(days[0]) if err is None else None}})
ccase("c01_unordered_duplicates",["2026-10-02","2026-09-19","2026-09-22","2026-09-19"],"Picker set arrives unordered with a repeat; canonical form is ascending unique epoch days.")
ccase("c02_single",["2026-10-01"],"One chosen date is a valid explicit schedule.")
ccase("c03_empty",[],"No date chosen.")
sixty=[ds(ep("2026-09-16")+i) for i in range(60)]
ccase("c04_sixty_daily",sixty,"Sixty dates is the per-segment ceiling (data bound, not clinical).")
ccase("c05_sixty_one",sixty+[ds(ep("2026-09-16")+60)],"Sixty-one dates exceeds the ceiling.")
ccase("c06_beyond_contract_range",["2200-01-02"],"Epoch day 84007 is outside the shared anchor/epoch-day contract range 10956...84006.")

stepper=[]
def scase(i,days,lt,zone,after,desc):
    nxt=None
    for e in days:
        u,_=slot(e,lt,zone)
        if u>pi(after): nxt=iso(u); break
    stepper.append({"id":i,"description":desc,"input":{"epochDays":days,"localTime":lt,"generationZoneId":zone,"after":after},"expected":{"next":nxt}})
K=[ep("2026-09-19"),ep("2026-09-22"),ep("2026-10-02")]
scase("s01_first",K,"09:00","Asia/Seoul","2026-09-15T00:00:00Z","First slot after a cursor before all dates.")
scase("s02_strictly_after",K,"09:00","Asia/Seoul","2026-09-19T00:00:00Z","A cursor exactly on a slot returns the following slot.")
scase("s03_second_before",K,"09:00","Asia/Seoul","2026-09-18T23:59:59Z","One second before a slot returns that slot.")
scase("s04_second_after",K,"09:00","Asia/Seoul","2026-09-19T00:00:01Z","One second after a slot skips to the next chosen date, never to an interpolated day.")
scase("s05_exhausted",K,"09:00","Asia/Seoul","2026-10-02T00:00:00Z","After the last chosen slot there is no next occurrence (null, not an error, not a repeat).")
scase("s06_floating_seoul",[ep("2026-10-01")],"09:00","Asia/Seoul","2026-09-15T00:00:00Z","Floating plan generated in Seoul.")
scase("s07_floating_los_angeles",[ep("2026-10-01")],"09:00","America/Los_Angeles","2026-09-15T00:00:00Z","Same local date and time generated after travel to Los Angeles.")
scase("s08_dst_gap_new_york",[ep("2027-03-14")],"02:30","America/New_York","2027-03-01T00:00:00Z","Nonexistent 02:30 resolves forward by the gap length (03:30 EDT).")
scase("s09_dst_overlap_new_york",[ep("2026-11-01")],"01:30","America/New_York","2026-10-20T00:00:00Z","Repeated 01:30 resolves to the earlier offset (EDT).")
scase("s10_dst_gap_berlin",[ep("2027-03-28")],"02:15","Europe/Berlin","2027-03-20T00:00:00Z","Nonexistent 02:15 resolves forward by the gap length (03:15 CEST).")

def propose_expected(now,localDates,H,device,tzp,lt,latest,declared,occupied):
    zone=tzp["zoneId"] if tzp["kind"]=="fixed" else device
    n=pi(now); days=canon(localDates); errors=[]
    today=n.astimezone(ZoneInfo(zone)).date(); tE=(today-E0).days
    if not days: errors.append({"code":"empty","localDate":None})
    elif len(days)>MAXN: errors.append({"code":"tooMany","localDate":None})
    else:
        for e in days:
            if not(MINE<=e<=MAXE): errors.append({"code":"outOfRange","localDate":ds(e)}); continue
            u,_=slot(e,lt,zone)
            if not u>n: errors.append({"code":"notFuture","localDate":ds(e)})
            elif e>tE+AHEAD: errors.append({"code":"beyondWindow","localDate":ds(e)})
    exp={"validationErrors":errors,"canonicalEpochDays":days,"slots":None,"nextScheduledAt":None,"gate":None}
    if not errors:
        occ={o["scheduledAt"] for o in occupied if occupies(o)}
        slots=[];gen=[]
        for e in days:
            u,meta=slot(e,lt,zone); s=iso(u)
            disp="occupiedByFact" if s in occ else "generate"
            slots.append({"localDate":ds(e),"epochDay":e,"scheduledAt":s,"scheduledTimeZoneId":zone,**meta,"disposition":disp})
            if disp=="generate": gen.append(u)
        exp["slots"]=slots
        exp["nextScheduledAt"]=iso(gen[0]) if gen else None
        if not usable_hours(H):
            exp["gate"]={"decision":"policyUnavailable","conflicts":[]}
        else:
            conf=[]
            floor=None;fk=None
            if latest: floor=pi(latest);fk="previousAdministration"
            if declared:
                de=ep(declared)
                if latest is None or (pi(latest).astimezone(ZoneInfo(zone)).date()-E0).days<de:
                    floor,_=slot(de,lt,zone);fk="declaredLastInjection"
            h=timedelta(hours=H)
            if floor and gen and gen[0]<floor+h:
                conf.append({"kind":fk,"earlierAt":iso(floor),"laterAt":iso(gen[0]),"eligibleAt":iso(floor+h)})
            for a,b in zip(gen,gen[1:]):
                if b<a+h: conf.append({"kind":"adjacentDates","earlierAt":iso(a),"laterAt":iso(b),"eligibleAt":iso(a+h)})
            exp["gate"]={"decision":"blocked" if conf else "allowed","conflicts":conf}
    return exp

proposals=[]
def pcase(i,desc,now,localDates,policy,device="Asia/Seoul",tzp=None,lt="09:00",latest=None,declared=None,occupied=None):
    tzp=tzp or {"kind":"floating","zoneId":None}
    occupied=occupied or []
    H=POL[policy]
    exp=propose_expected(now,localDates,H,device,tzp,lt,latest,declared,occupied)
    proposals.append({"id":i,"description":desc,"input":{"now":now,"deviceZoneId":device,"timeZonePolicy":tzp,"localTime":lt,"localDates":localDates,
        "policyId":policy,"policyDayChangeMinimumIntervalHours":H,"latestAdministrationAt":latest,"declaredLastInjectionLocalDate":declared,"existingOccurrences":occupied},"expected":exp})
KR="mounjaro.kr.prefilled-pen.2026-09-13"; US="mounjaro.us.weekly.2026-04-22"; WG="wegovy.us.weekly.2025-08"; GEN="generic.weekly.record-only"
pcase("p01_kst_exact_minimum_allowed","Unordered picks; 19->22 is exactly 72h, which the gate allows (>=).","2026-09-15T00:00:00Z",["2026-10-02","2026-09-19","2026-09-22"],KR)
pcase("p02_adjacent_too_close_72h","Two chosen dates 48h apart under a 72h pack block the future schedule.","2026-09-15T00:00:00Z",["2026-09-20","2026-09-22"],US)
pcase("p03_adjacent_48h_pack_allowed","Same dates under a 48h pack are allowed; numbers come only from the pack.","2026-09-15T00:00:00Z",["2026-09-20","2026-09-22"],WG)
pcase("p04_record_only_pack_no_rule","Generic record-only pack carries no interval; nothing is gated.","2026-09-15T00:00:00Z",["2026-09-20","2026-09-21"],GEN)
pcase("p05_previous_administration_floor","First chosen date is 48h after the latest recorded dose under a 72h pack.","2026-09-15T00:00:00Z",["2026-09-25","2026-09-16"],KR,latest="2026-09-14T00:00:00Z")
pcase("p06_declared_last_injection_floor","Onboarding-declared last injection (not persisted as a fact) floors the first chosen date at the plan's clock time.","2026-09-15T00:00:00Z",["2026-09-16"],KR,declared="2026-09-14")
pcase("p07_recorded_dose_supersedes_declared","A recorded dose on or after the declared day replaces the declared floor; exactly 72h is allowed.","2026-09-15T01:00:00Z",["2026-09-18"],KR,latest="2026-09-15T00:00:00Z",declared="2026-09-14")
pcase("p08_not_future","A stale draft containing past dates, and today's slot already passed, cannot be saved.","2026-09-15T03:00:00Z",["2026-09-14","2026-09-15","2026-09-18"],KR)
pcase("p09_empty","No chosen dates.","2026-09-15T00:00:00Z",[],KR)
pcase("p10_beyond_window","A date more than 366 local days ahead of today in the schedule zone is refused.","2026-09-15T00:00:00Z",[ds(ep("2026-09-15")+367)],GEN)
pcase("p11_window_edge_allowed","A date exactly 366 local days ahead is accepted.","2026-09-15T00:00:00Z",[ds(ep("2026-09-15")+366)],GEN)
pcase("p12_occupied_by_completed_fact","A chosen date whose slot is already completed (early same-day dose) is kept as fact and not regenerated or gated.","2026-09-21T23:45:00Z",["2026-09-22","2026-09-29"],KR,latest="2026-09-21T23:30:00Z",
      occupied=[{"scheduledAt":"2026-09-22T00:00:00Z","scheduledTimeZone":"Asia/Seoul","status":"completed","resolvedAt":"2026-09-21T23:30:00Z"}])
pcase("p13_fixed_zone_from_new_york","Fixed Seoul plan edited on a device in New York keeps Seoul wall time.","2026-09-15T00:00:00Z",["2026-10-01"],KR,device="America/New_York",tzp={"kind":"fixed","zoneId":"Asia/Seoul"})
pcase("p14_floating_los_angeles","Floating plan edited in Los Angeles resolves in the device zone.","2026-09-15T00:00:00Z",["2026-10-01"],GEN,device="America/Los_Angeles")
pcase("p15_dst_gap_new_york","Preview flags the gap adjustment instead of hiding it.","2027-03-01T00:00:00Z",["2027-03-14"],GEN,device="America/New_York",lt="02:30")
pcase("p16_dst_overlap_new_york","Overlap resolves to the earlier offset; no adjustment flag.","2026-10-20T00:00:00Z",["2026-11-01"],GEN,device="America/New_York",lt="01:30")
pcase("p17_skipped_fact_occupies","A slot skipped earlier on its own local day is a fact; it is kept and not regenerated.","2026-09-18T23:30:00Z",["2026-09-19","2026-09-26"],GEN,
      occupied=[{"scheduledAt":"2026-09-19T00:00:00Z","scheduledTimeZone":"Asia/Seoul","status":"skipped","resolvedAt":"2026-09-18T23:00:00Z"}])
far=[ds(ep("2026-09-16")+7*i) for i in range(30)]; far.append(ds(ep(far[-1])+2))
pcase("p18_conflict_beyond_materialized_rows","31 dates: 30 weekly, then one 48h after the 30th. The only conflict is pair 30->31, past Android's 12 materialized rows and iOS's 26-week window; preview and commit must both block.","2026-09-15T00:00:00Z",far,KR)

reanchor=[
 {"id":"r01_recorded_on_chosen_date","description":"Recording on a chosen date is already aligned.","input":{"epochDays":K,"recordedLocalDate":"2026-09-22","policyId":KR},"expected":{"contains":True,"outcome":"alreadyAligned","appendsSegment":False}},
 {"id":"r02_recorded_off_chosen_dates","description":"Recording between chosen dates never converts them to an interval or moves them.","input":{"epochDays":K,"recordedLocalDate":"2026-09-21","policyId":KR},"expected":{"contains":False,"outcome":"preservedExplicitDates","appendsSegment":False}},
 {"id":"r03_recorded_after_last_date","description":"Recording after the schedule is exhausted appends nothing.","input":{"epochDays":K,"recordedLocalDate":"2026-10-09","policyId":KR},"expected":{"contains":False,"outcome":"preservedExplicitDates","appendsSegment":False}},
 {"id":"r04_generic_pack_on_chosen_date","description":"Record-only generic pack (no dayChange hours): the explicit check runs before the policy check, so the outcome is still alreadyAligned, not policyUnavailable.","input":{"epochDays":K,"recordedLocalDate":"2026-09-22","policyId":GEN},"expected":{"contains":True,"outcome":"alreadyAligned","appendsSegment":False}},
 {"id":"r05_generic_pack_off_chosen_dates","description":"Record-only generic pack, dose off the chosen dates: preservedExplicitDates, not policyUnavailable.","input":{"epochDays":K,"recordedLocalDate":"2026-09-21","policyId":GEN},"expected":{"contains":False,"outcome":"preservedExplicitDates","appendsSegment":False}},
]

segs=[]
def bcase(i,desc,wk,iv,anc,days,storage,valid,field):
    segs.append({"id":i,"description":desc,"input":{"weekdayIso":wk,"intervalDays":iv,"anchorEpochDay":anc,"explicitEpochDays":days,"storage":storage},"expected":{"valid":valid,"invalidField":field}})
bcase("b01_valid","Canonical explicit segment.",6,7,None,K,"20715,20718,20728",True,None)
bcase("b02_legacy_repeating_absent","Absent explicit dates keeps the repeating weekday shape.",1,7,None,None,None,True,None)
bcase("b03_anchored_absent","Absent explicit dates keeps an anchored N-day cadence untouched.",6,9,ep("2026-09-19"),None,None,True,None)
bcase("b04_unsorted","Storage must be ascending.",2,7,None,[20718,20715],"20718,20715",False,"explicitEpochDays")
bcase("b05_duplicate","Storage must be unique.",6,7,None,[20715,20715],"20715,20715",False,"explicitEpochDays")
bcase("b06_empty","An explicit segment needs at least one date.",6,7,None,[],"",False,"explicitEpochDays")
bcase("b07_with_anchor","Explicit dates and an anchor cannot coexist.",6,7,20715,K,"20715,20718,20728",False,"anchorEpochDay")
bcase("b08_interval_not_seven","Interval is the fixed sentinel 7 for explicit segments.",6,10,None,K,"20715,20718,20728",False,"intervalDays")
bcase("b09_weekday_mismatch","Stored weekday is derived from the first date.",1,7,None,K,"20715,20718,20728",False,"weekday")
bcase("b10_out_of_range","Epoch days share the anchor contract range.",6,7,None,[84007],"84007",False,"explicitEpochDays")
bcase("b11_too_many","More than sixty dates is refused.",3,7,None,[ep("2026-09-16")+i for i in range(61)],",".join(str(ep("2026-09-16")+i) for i in range(61)),False,"explicitEpochDays")
bcase("b12_storage_whitespace","Storage grammar is digits and commas only.",6,7,None,None,"20715, 20718",False,"explicitEpochDays")
bcase("b13_storage_leading_zero","Storage has no leading zeros or signs.",6,7,None,None,"020715",False,"explicitEpochDays")

V1N={"canonicalization":len(canonicalization),"stepper":len(stepper),"proposals":len(proposals),"reanchor":len(reanchor),"backupSegment":len(segs)}

# ---------------------------------------------------------------- v3 additions (2026-09-15)
ccase("c07_below_contract_range",["1999-12-30"],"Epoch day 10955 is below the shared contract range 10956...84006.")
ccase("c08_contract_range_edges",["2200-01-01","1999-12-31"],"Both contract edges, epoch days 10956 and 84006, are inside the range.")
ccase("c09_too_many_before_out_of_range",sixty+["2200-01-02"],"Sixty-one dates, one of them outside the range: tooMany is reported, not outOfRange.")

# CORE-20260915-02 occupancy by status. One chosen slot (2026-09-22 09:00 Seoul) carries a row whose
# status varies; the latest dose is 15 minutes before that slot under a 72h pack, so a slot that is
# generated is blocked by the floor and a slot held by a fact moves the floor check to 2026-09-25.
OCC_NOW="2026-09-21T23:45:00Z"; OCC_DATES=["2026-09-22","2026-09-25","2026-09-29"]; OCC_LATEST="2026-09-21T23:30:00Z"
def occ_row(status,resolved,at="2026-09-22T00:00:00Z"):
    return {"scheduledAt":at,"scheduledTimeZone":"Asia/Seoul","status":status,"resolvedAt":resolved}
pcase("p19_completed_row_occupies_slot","CORE-20260915-02: a completed fact (dose 30 minutes early, same local day) holds its chosen slot; the floor is checked against the next generated slot, which is clear.",OCC_NOW,OCC_DATES,KR,latest=OCC_LATEST,occupied=[occ_row("completed","2026-09-21T23:30:00Z")])
pcase("p20_skipped_row_occupies_slot","CORE-20260915-02: a skipped fact holds its chosen slot exactly as a completed one does.",OCC_NOW,OCC_DATES,KR,latest=OCC_LATEST,occupied=[occ_row("skipped","2026-09-21T23:40:00Z")])
pcase("p21_scheduled_row_does_not_occupy","CORE-20260915-02: a scheduled row at the chosen instant holds nothing; the slot is generated and the floor blocks it.",OCC_NOW,OCC_DATES,KR,latest=OCC_LATEST,occupied=[occ_row("scheduled",None)])
pcase("p22_due_row_does_not_occupy","CORE-20260915-02: a due row at the chosen instant holds nothing; the slot is generated and the floor blocks it.",OCC_NOW,OCC_DATES,KR,latest=OCC_LATEST,occupied=[occ_row("due",None)])
pcase("p23_needs_review_row_does_not_occupy","CORE-20260915-02: a needsReview row at the chosen instant holds nothing; the slot is generated and the floor blocks it.",OCC_NOW,OCC_DATES,KR,latest=OCC_LATEST,occupied=[occ_row("needsReview",None)])
pcase("p24_cancelled_row_does_not_occupy","CORE-20260915-02: a cancelled row holds nothing even when it carries a resolvedAt; the slot is generated and the floor blocks it.",OCC_NOW,OCC_DATES,KR,latest=OCC_LATEST,occupied=[occ_row("cancelled","2026-09-21T23:30:00Z")])
pcase("p25_fact_at_other_instant_does_not_occupy","Occupancy matches the exact slot instant: a completed fact scheduled at 10:00 the same local day does not hold the 09:00 chosen slot.",OCC_NOW,OCC_DATES,KR,latest=OCC_LATEST,occupied=[occ_row("completed","2026-09-21T23:30:00Z",at="2026-09-22T01:00:00Z")])
pcase("p26_fact_moves_floor_check_to_next_generated_slot","The gate covers the full list minus facts: today's slot is skipped, so the floor is checked against the next generated slot (2026-09-20) and blocks it there; 20->23 is exactly 72h.","2026-09-18T23:30:00Z",["2026-09-19","2026-09-20","2026-09-23"],KR,latest="2026-09-17T12:00:00Z",
      occupied=[{"scheduledAt":"2026-09-19T00:00:00Z","scheduledTimeZone":"Asia/Seoul","status":"skipped","resolvedAt":"2026-09-18T23:00:00Z"}])

# Declared last-injection floor (fixture floorRule).
pcase("p27_declared_floor_exact_minimum_allowed","The declared day is placed at the plan's clock time; a chosen slot exactly 72h later is allowed.","2026-09-15T00:00:00Z",["2026-09-17"],KR,declared="2026-09-14")
pcase("p28_declared_superseded_by_dose_on_that_local_day","A recorded dose at 00:30 on the declared local day (still the previous UTC date) is that injection and replaces the declared floor.","2026-09-15T00:00:00Z",["2026-09-16"],KR,latest="2026-09-13T15:30:00Z",declared="2026-09-14")
pcase("p29_declared_kept_when_dose_is_local_day_before","A recorded dose at 23:59:59 on the local day before the declared day does not replace it; the declared floor blocks.","2026-09-15T00:00:00Z",["2026-09-16"],KR,latest="2026-09-13T14:59:59Z",declared="2026-09-14")
pcase("p30_declared_floor_in_fixed_zone_abroad","Fixed Seoul plan set up on a device in New York: the declared day is placed at 09:00 in Seoul, the schedule zone, not in the device zone.","2026-09-15T00:00:00Z",["2026-09-16"],KR,device="America/New_York",tzp={"kind":"fixed","zoneId":"Asia/Seoul"},declared="2026-09-14")
pcase("p31_declared_floor_in_dst_gap","The declared day's 02:30 does not exist in New York (spring forward); the floor moves later by the gap (03:30 EDT) like any slot.","2027-03-01T00:00:00Z",["2027-03-16"],US,device="America/New_York",lt="02:30",declared="2027-03-14")

# Validation order and window zone.
pcase("p32_validation_errors_in_ascending_date_order","Per-date errors follow ascending date order, each with its own code: below range, not future, beyond window, above range; the valid date raises none.","2026-09-15T00:00:00Z",["2200-01-02","2026-09-20","1999-12-30","2027-09-20","2026-09-14"],GEN)
pcase("p33_window_counts_local_days_in_schedule_zone","Now is 01:00 on 16 September in Seoul, still the 15th in UTC: 2027-09-17 is exactly 366 local days ahead in the schedule zone and is accepted.","2026-09-15T16:00:00Z",["2027-09-17"],GEN)

# Gate hours given directly (no pack): only a finite positive number gates.
gate_hours_guard=[]
def gcase(i,desc,hours,now,localDates,device="Asia/Seoul",tzp=None,lt="09:00",latest=None,declared=None,occupied=None):
    tzp=tzp or {"kind":"floating","zoneId":None}
    occupied=occupied or []
    exp=propose_expected(now,localDates,hours,device,tzp,lt,latest,declared,occupied)
    gate_hours_guard.append({"id":i,"description":desc,"input":{"now":now,"deviceZoneId":device,"timeZonePolicy":tzp,"localTime":lt,"localDates":localDates,
        "dayChangeMinimumIntervalHours":hours,"latestAdministrationAt":latest,"declaredLastInjectionLocalDate":declared,"existingOccurrences":occupied},"expected":exp})
gcase("g01_zero_hours_no_gate","Zero hours is not a usable day-change minimum: policyUnavailable with no conflicts, exactly as null (not allowed).",0,"2026-09-15T00:00:00Z",["2026-09-20","2026-09-21"],latest="2026-09-19T00:00:00Z")
gcase("g02_negative_hours_no_gate","Negative hours are not a usable day-change minimum (never made positive): policyUnavailable with no conflicts.",-72,"2026-09-15T00:00:00Z",["2026-09-20","2026-09-21"],latest="2026-09-19T00:00:00Z")
gcase("g03_fractional_hours_gate","A finite positive fractional value gates like any other: eligibleAt is the floor plus 36.5h.",36.5,"2026-09-15T00:00:00Z",["2026-09-20","2026-09-22"],latest="2026-09-18T12:00:00Z")

bcase("b14_storage_trailing_comma","Storage has no empty field.",6,7,None,None,"20715,",False,"explicitEpochDays")
bcase("b15_storage_sign","Storage has no sign.",6,7,None,None,"+20715",False,"explicitEpochDays")
bcase("b16_storage_six_digit_field","A six-digit field is outside the epoch-day contract range.",6,7,None,None,"100000",False,"explicitEpochDays")
bcase("b17_contract_range_edges","Both epoch-day contract edges are storable (1999-12-31 is a Friday).",5,7,None,[MINE,MAXE],f"{MINE},{MAXE}",True,None)

CONVENTIONS_V1={
  "instant":"RFC 3339 UTC with literal Z and no fractional seconds",
  "localDate":"ISO 8601 yyyy-MM-dd, proleptic Gregorian",
  "epochDay":"whole days since 1970-01-01 (same integer as ScheduleCadence.anchorEpochDay / LocalDate.toEpochDay)",
  "localTime":"HH:mm 24-hour wall clock; seconds are zero",
  "weekdayIso":"1=Monday ... 7=Sunday; iOS Gregorian weekday = weekdayIso % 7 + 1",
  "gapRule":"nonexistent wall time moves later by the gap length; overlap uses the earlier offset",
  "gateRule":"conflict when later < earlier + policy dayChangeMinimumIntervalHours; equality is allowed",
  "floorRule":"floor = latestAdministrationAt, unless declaredLastInjectionLocalDate is set and no recorded dose falls on or after that local day, in which case floor = that day at localTime in the schedule zone",
  "slotZone":"fixed policy uses timeZonePolicy.zoneId; floating uses deviceZoneId",
  "validationOrder":"empty, tooMany, then per ascending date: outOfRange, notFuture (slot <= now), beyondWindow (epochDay > today-in-schedule-zone + maxDaysAhead)",
  "gateScope":"the gate covers every generated slot of the segment's full canonical date list (plus the floor), never only the rows a platform materializes (Android 12 rows, iOS 26 weeks)",
  "gateHours":"propose takes dayChangeMinimumIntervalHours as a nullable number; null means policyUnavailable (no gate). Callers derive it exactly as ClinicalRulesEngine.evaluateDayChange does; tests take it from input.policyDayChangeMinimumIntervalHours and assert it equals the live pack",
  "reanchorOrder":"for an explicit-date current segment: isValid, then contains (alreadyAligned) else preservedExplicitDates; evaluated before any policy check, so the outcome does not depend on policyId. Android record path has no outcome type: alreadyAligned and preservedExplicitDates both assert no appended segment",
  "nullMeans":"validation failed (slots/gate) or no further slot (next)"
 }
CONVENTIONS_V3={
  "occupancyRule":"CORE-20260915-02: a chosen slot is occupiedByFact only when an existingOccurrences row has status completed or skipped, scheduledAt equal to the slot instant, and resolvedAt on or after scheduledAt or earlier on the same local day in scheduledTimeZone (every fact row in this file satisfies both platforms' slot authorities). scheduled, due, needsReview and cancelled rows never occupy, with or without resolvedAt: their slot is generated and gated like any other",
  "gateHoursGuard":"section gateHoursGuard passes dayChangeMinimumIntervalHours directly, with no pack: a value that is not a finite positive number (0 and negatives here; NaN and infinity have no JSON form) means policyUnavailable with no conflicts, exactly like null. A finite positive fractional value gates normally",
  "versioning":"fixtureVersion 3 supersedes schedule_explicit_dates_v1.json (SHA-256 f19391910a20df8ec46188ceac98980508c9eb563ad53ad3bf9dd6dc3456577d). Every v1 case is unchanged at the start of its section; later cases and section gateHoursGuard are new. Generator: schedule_explicit_dates_v3.generator.py"
 }
DECISIONS_V1=["SCHEDULE-20260913-14","SCHEDULE-20260913-16"]

def document(version):
    v1=version==1
    def cut(name,rows): return rows[:V1N[name]] if v1 else rows
    conventions=dict(CONVENTIONS_V1)
    if not v1: conventions.update(CONVENTIONS_V3)
    doc={
     "fixture":"schedule_explicit_dates","fixtureVersion":version,
     "decisions":DECISIONS_V1 if v1 else DECISIONS_V1+["DESIGN-20260915-02","CORE-20260915-02"],
     "createdOn":"2026-09-15",
     "conventions":conventions,
     "limits":{"maxDatesPerSegment":MAXN,"maxDaysAhead":AHEAD,"minEpochDay":MINE,"maxEpochDay":MAXE,"explicitSegmentIntervalDaysSentinel":7},
     "policyEcho":{k:{"dayChangeMinimumIntervalHours":v} for k,v in POL.items()},
     "canonicalization":cut("canonicalization",canonicalization),"stepper":cut("stepper",stepper),"proposals":cut("proposals",proposals),
     "reanchor":cut("reanchor",reanchor),"backupSegment":cut("backupSegment",segs),
    }
    if not v1: doc["gateHoursGuard"]=gate_hours_guard
    return doc

if __name__=="__main__":
    args=[a for a in sys.argv[1:] if a!="--v1"]
    if len(args)!=1: sys.exit("usage: schedule_explicit_dates_v3.generator.py [--v1] <output.json>")
    version=1 if "--v1" in sys.argv[1:] else 3
    data=(json.dumps(document(version),ensure_ascii=True,indent=2,sort_keys=False)+"\n").encode("ascii")
    open(args[0],"wb").write(data)
    print(hashlib.sha256(data).hexdigest(), len(data))
    if version==3:
        for name,rows in (("canonicalization",canonicalization),("proposals",proposals),("backupSegment",segs)):
            for r in rows[V1N[name]:]: print(r["id"], json.dumps(r["expected"],separators=(",",":")))
        for r in gate_hours_guard: print(r["id"], json.dumps(r["expected"]["gate"],separators=(",",":")))
