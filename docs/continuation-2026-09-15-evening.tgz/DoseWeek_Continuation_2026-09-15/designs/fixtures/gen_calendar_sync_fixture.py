#!/usr/bin/env python3
"""Reference planner + fixture generator for calendar_sync_reconcile_v3.json (and, with --v1, the
unchanged calendar_sync_reconcile_v1.json).

Normative executable spec of designs/calendar-sync.md section 6. Both platform planners (Swift
DoseDayCore CalendarSyncPlanner, Kotlin domain CalendarSyncPlanner) must reproduce `expected` for
every case. Output: sorted keys, 2-space indent, UTF-8, trailing newline.

v3 (2026-09-15): minimum-interval hours that are not a finite positive number mean no gate (the guard
both platforms implement), and 17 cases are appended after the 56 v1 cases, which are unchanged.
`--v1` must reproduce calendar_sync_reconcile_v1.json byte for byte
(SHA-256 ae918c71958b6ddd74145b94c76924abd12cae43608d77cebe043460612172fb).

Usage: python3 gen_calendar_sync_fixture.py [--v1] <output.json>
"""
import json, hashlib, math, sys
from datetime import datetime, timezone, timedelta

HORIZON_DAYS = 84
MAX_EVENTS = 24
LOOKBACK_HOURS = 24
EVENT_MINUTES = 30
KEY_PREFIX = "dw1-"
UNRESOLVED = {"scheduled", "due", "needsReview"}
TITLES = {"generic": "Personal reminder", "descriptive": "Injection day"}


def parse(s):
    """ISO-8601 UTC ('Z') -> epoch millis floored to whole seconds."""
    dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
    return int(dt.replace(microsecond=0).timestamp()) * 1000


def fmt(ms):
    return datetime.fromtimestamp(ms // 1000, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def slot_key(plan_id, ms):
    """Opaque, PHI-free ownership key and calendar marker: plan UUID + scheduled epoch seconds."""
    return f"{KEY_PREFIX}{plan_id.lower()}-{ms // 1000}"


def counts(links, orphan=0):
    return {
        "managedCount": sum(1 for l in links if l["state"] == "active"),
        "detachedCount": sum(1 for l in links if l["state"] == "detached"),
        "tombstonedCount": sum(1 for l in links if l["state"] == "tombstoned"),
        "orphanFutureCount": orphan,
    }


def gate(inp):
    cfg = inp["config"]
    if inp["mode"] == "reconcile" and not cfg["enabled"]:
        return "off"
    acc = cfg["access"]
    if acc == "notDetermined":
        return "permissionRequired"
    if acc != "full":
        return "permissionLost"
    if inp["mode"] == "teardownRemoveFuture":
        return None
    sel = cfg["selectedCalendarId"]
    if sel is None:
        return "calendarNotSelected"
    cal = next((c for c in cfg["calendars"] if c["id"] == sel), None)
    if cal is None or not cal["available"]:
        return "calendarUnavailable"
    if not cal["writable"]:
        return "calendarReadOnly"
    return None


def by_key(links):
    return sorted(links, key=lambda l: l["slotKey"])


def user_owned(links):
    """Detached and tombstoned links record a user decision; they survive teardown (review fix R1)."""
    return [l for l in by_key(links) if l["state"] != "active"]


def plan(inp):
    mode = inp["mode"]
    cfg = inp["config"]
    links = [dict(l) for l in inp["links"]]
    if mode == "teardownKeep":
        ops = [{"op": "forget", "slotKey": l["slotKey"], "reason": "keep"} for l in by_key(links) if l["state"] == "active"]
        kept = user_owned(links)
        return {"status": dict(state="off", **counts(kept)), "operations": ops, "linksAfter": kept}
    g = gate(inp)
    if g is not None:
        return {"status": dict(state=g, **counts(links)), "operations": [], "linksAfter": by_key(links)}

    now = parse(inp["now"])
    observed = [dict(e, start_ms=parse(e["start"]), end_ms=parse(e["end"])) for e in inp["observedEvents"]]
    by_id = {e["eventId"]: e for e in observed}
    sel = cfg["selectedCalendarId"]

    def calendar_writable(cal_id):
        """Descriptor present, available and writable. Adapters pass descriptors for the selected calendar
        and for every calendarId referenced by a link; an absent descriptor means unavailable (review fix R3)."""
        c = next((c for c in cfg["calendars"] if c["id"] == cal_id), None)
        return c is not None and c["available"] and c["writable"]

    def modified(link, ev):
        return (ev["start_ms"] != parse(link["writtenStart"]) or ev["end_ms"] != parse(link["writtenEnd"])
                or ev["title"] != link["writtenTitle"] or ev["calendarId"] != link["calendarId"])

    def markers_in(cal_id):
        idx = {}
        for e in observed:
            if e["calendarId"] == cal_id and e.get("markerKey"):
                idx.setdefault(e["markerKey"], []).append(e)
        for k in idx:
            idx[k].sort(key=lambda e: e["eventId"])
        return idx

    ops = []
    if mode == "teardownRemoveFuture":
        for l in by_key(links):
            key = l["slotKey"]
            if l["state"] != "active":
                continue  # retained in linksAfter (user decision), never touched
            if not calendar_writable(l["calendarId"]):
                ops.append({"op": "forget", "slotKey": key, "reason": "calendarNotWritable"})
                continue
            ev = by_id.get(l["eventId"]) if l["eventId"] else None
            if ev is None:
                cands = markers_in(l["calendarId"]).get(key, [])
                ev = cands[0] if cands else None
            if ev is None:
                ops.append({"op": "forget", "slotKey": key, "reason": "eventMissing"})
            elif modified(l, ev):
                ops.append({"op": "forget", "slotKey": key, "reason": "userModified"})
            elif ev["start_ms"] < now:
                ops.append({"op": "forget", "slotKey": key, "reason": "past"})
            else:
                ops.append({"op": "delete", "eventId": ev["eventId"], "slotKey": key, "reason": "teardown"})
        kept = user_owned(links)
        return {"status": dict(state="off", **counts(kept)), "operations": ops, "linksAfter": kept}

    sel_markers = markers_in(sel)
    if mode == "cleanupOrphans":
        linked_ids = {l["eventId"] for l in links if l["eventId"]}
        linked_keys = {l["slotKey"] for l in links if l["state"] in ("active", "detached")}
        for e in sorted(observed, key=lambda e: e["eventId"]):
            if (e["calendarId"] == sel and e.get("markerKey") and e["eventId"] not in linked_ids
                    and e["markerKey"] not in linked_keys and e["start_ms"] >= now):
                ops.append({"op": "delete", "eventId": e["eventId"], "slotKey": None, "reason": "orphan"})
        return {"status": dict(state="synced", **counts(links, 0)), "operations": ops, "linksAfter": by_key(links)}

    # ---- reconcile ----
    ws, we = now - LOOKBACK_HOURS * 3_600_000, now + HORIZON_DAYS * 86_400_000
    gate_min = inp.get("minimumIntervalGate")
    earliest = None
    hours = gate_min["minimumIntervalHours"] if gate_min else None
    # v3: only a finite positive number of hours gates (the rules engine refuses any other pack value,
    # and both platform planners ignore it). 0 and negatives are pinned; NaN and infinity have no JSON form.
    if gate_min and isinstance(hours, (int, float)) and math.isfinite(hours) and hours > 0:
        earliest = parse(gate_min["latestAdministrationAt"]) + int(hours * 3_600_000)
    occs, live = [], set()
    for o in inp["occurrences"]:
        t = parse(o["scheduledAt"])
        if o["status"] in UNRESOLVED and ws <= t < we:
            # A live slot is unresolved and inside the window, whether or not the cap or the
            # minimum-interval gate keeps it out of `desired`. Tombstones and event-less detached
            # links survive while their slot is live (review fix R2).
            live.add(slot_key(o["planId"], t))
            if earliest is None or t >= earliest:
                occs.append(dict(o, t=t, key=slot_key(o["planId"], t)))
    occs.sort(key=lambda o: (o["t"], o["id"]))
    desired_list, seen = [], set()
    for o in occs:  # one event per slot key; first (instant, id) wins
        if o["key"] not in seen:
            seen.add(o["key"])
            desired_list.append(o)
    desired_list = desired_list[:MAX_EVENTS]
    desired = {o["key"]: o for o in desired_list}
    title = TITLES[cfg["titleMode"]]
    policy = cfg["userEditPolicy"]
    # Every title the app itself may have written (both modes x 17 locales, adapter-supplied constant).
    app_titles = set(cfg["knownAppTitles"]) | {title}

    def desired_fields(o):
        return {"writtenStart": fmt(o["t"]), "writtenEnd": fmt(o["t"] + EVENT_MINUTES * 60_000),
                "writtenTitle": title, "writtenTimeZone": o["timeZone"]}

    def create(o):
        f = desired_fields(o)
        ops.append({"op": "create", "slotKey": o["key"], "calendarId": sel, "start": f["writtenStart"],
                    "end": f["writtenEnd"], "timeZone": f["writtenTimeZone"], "title": title})
        return dict(slotKey=o["key"], calendarId=sel, eventId=None, state="active", **f)

    def update(link, o):
        f = desired_fields(o)
        if all(link[k] == v for k, v in f.items()):
            return link
        ops.append({"op": "update", "eventId": link["eventId"], "slotKey": o["key"], "start": f["writtenStart"],
                    "end": f["writtenEnd"], "timeZone": f["writtenTimeZone"], "title": title})
        return dict(link, **f)

    after, used_events = [], set()
    for l in by_key(links):
        key = l["slotKey"]
        o = desired.get(key)
        if l["state"] == "tombstoned":
            if key not in live:
                ops.append({"op": "forget", "slotKey": key, "reason": "slotGone"})
                continue
            back = [e for e in sel_markers.get(key, []) if e["eventId"] not in used_events]
            if back:  # the user restored the deleted event (undo / trash): it is theirs, never recreate or delete
                rev = back[0]
                used_events.add(rev["eventId"])
                ops.append({"op": "detach", "slotKey": key, "eventId": rev["eventId"]})
                after.append(dict(l, calendarId=sel, eventId=rev["eventId"], state="detached",
                                  writtenStart=fmt(rev["start_ms"]), writtenEnd=fmt(rev["end_ms"]),
                                  writtenTitle=rev["title"], writtenTimeZone=rev["timeZone"]))
            else:
                after.append(l)
            continue
        if l["state"] == "detached":
            dev = by_id.get(l["eventId"]) if l["eventId"] else None
            # User-owned event keeps its link while it exists in the future or its slot is live:
            # never an orphan, never cleaned up, never recreated.
            if key not in live and (dev is None or dev["start_ms"] < now):
                ops.append({"op": "forget", "slotKey": key, "reason": "slotGone"})
            else:
                after.append(l)
                if dev is not None:
                    used_events.add(dev["eventId"])
            continue
        if l["calendarId"] != sel:
            ev = by_id.get(l["eventId"]) if l["eventId"] else None
            if not calendar_writable(l["calendarId"]):
                ops.append({"op": "forget", "slotKey": key, "reason": "calendarNotWritable"})
            elif ev is not None and not modified(l, ev) and ev["start_ms"] >= now:
                ops.append({"op": "delete", "eventId": ev["eventId"], "slotKey": key, "reason": "calendarChanged"})
            else:
                ops.append({"op": "forget", "slotKey": key, "reason": "calendarChanged"})
            continue
        ev = by_id.get(l["eventId"]) if l["eventId"] else None
        if ev is None:
            cands = sel_markers.get(key, [])
            if cands:
                ev = cands[0]
                ops.append({"op": "relink", "slotKey": key, "fromEventId": l["eventId"], "toEventId": ev["eventId"]})
                l = dict(l, eventId=ev["eventId"])
        if ev is None:
            if o is None:
                ops.append({"op": "forget", "slotKey": key, "reason": "eventMissing"})
            elif policy == "detach":
                ops.append({"op": "tombstone", "slotKey": key})
                after.append(dict(l, eventId=None, state="tombstoned"))
            else:
                after.append(create(o))
            continue
        used_events.add(ev["eventId"])
        moved = ev["calendarId"] != l["calendarId"]
        mod = modified(l, ev)
        if o is None:
            if mod and (policy == "detach" or moved):
                ops.append({"op": "forget", "slotKey": key, "reason": "userModified"})
            elif ev["start_ms"] >= now:
                ops.append({"op": "delete", "eventId": ev["eventId"], "slotKey": key, "reason": "notDesired"})
            else:
                ops.append({"op": "forget", "slotKey": key, "reason": "past"})
            continue
        if mod and (policy == "detach" or moved):
            ops.append({"op": "detach", "slotKey": key, "eventId": ev["eventId"]})
            after.append(dict(l, state="detached"))
            continue
        if mod:  # restore policy, same calendar
            l = dict(l, writtenStart=fmt(ev["start_ms"]), writtenEnd=fmt(ev["end_ms"]), writtenTitle=ev["title"])
        after.append(update(l, o))

    linked = {l["slotKey"] for l in after}
    for o in desired_list:
        if o["key"] in linked:
            continue
        cands = [e for e in sel_markers.get(o["key"], []) if e["eventId"] not in used_events]
        if cands:
            ev = cands[0]
            used_events.add(ev["eventId"])
            base = dict(slotKey=o["key"], calendarId=sel, eventId=ev["eventId"], state="active",
                        writtenStart=fmt(ev["start_ms"]), writtenEnd=fmt(ev["end_ms"]), writtenTitle=ev["title"],
                        writtenTimeZone=ev["timeZone"])
            # No baseline survives reinstall / teardown, so judge the event against what the app could have
            # written for this key: start == key instant, end == start + 30 min, an app title. Anything else
            # is a user edit -> adopt as detached and never write (review fix R1). Restore policy overrides.
            untouched = (ev["start_ms"] == o["t"] and ev["end_ms"] == o["t"] + EVENT_MINUTES * 60_000
                         and ev["title"] in app_titles)
            if untouched or policy == "restore":
                ops.append({"op": "adopt", "slotKey": o["key"], "eventId": ev["eventId"], "state": "active"})
                after.append(update(base, o))
            else:
                ops.append({"op": "adopt", "slotKey": o["key"], "eventId": ev["eventId"], "state": "detached"})
                after.append(dict(base, state="detached"))
        else:
            after.append(create(o))

    deleted = {op["eventId"] for op in ops if op["op"] == "delete"}
    # Pending creates (active, eventId None) and linked events own their key; a tombstone owns nothing,
    # so a marker event for a tombstoned key is never deleted as a duplicate.
    kept_keys = {l["slotKey"] for l in after
                 if l["state"] != "tombstoned" and (l["eventId"] in used_events or l["eventId"] is None)}
    orphan = 0
    for e in sorted(observed, key=lambda e: e["eventId"]):
        if e["calendarId"] != sel or not e.get("markerKey") or e["eventId"] in used_events or e["eventId"] in deleted:
            continue
        if e["markerKey"] in kept_keys:
            if e["start_ms"] >= now:
                ops.append({"op": "delete", "eventId": e["eventId"], "slotKey": None, "reason": "duplicateMarker"})
        elif e["start_ms"] >= now:
            orphan += 1
    return {"status": dict(state="synced", **counts(after, orphan)), "operations": ops, "linksAfter": by_key(after)}


# ---------------------------------------------------------------- inputs
SEL = "cal-personal"
CALS = [{"id": SEL, "available": True, "writable": True}]
NOW = "2026-10-01T09:00:00Z"
PLAN = "11111111-1111-4111-8111-111111111111"
OTHER_PLAN = "22222222-2222-4222-8222-222222222222"


def cfg(**kw):
    c = {"enabled": True, "access": "full", "selectedCalendarId": SEL, "calendars": CALS,
         "titleMode": "generic", "userEditPolicy": "detach",
         # Production adapters pass all 34 texts of designs/calendar-sync.md section 10.2; fixture default is en.
         "knownAppTitles": sorted(TITLES.values())}
    c.update(kw)
    return c


def uid(n):
    return f"00000000-0000-4000-8000-{n:012d}"


def k(at, plan_id=PLAN):
    return slot_key(plan_id, parse(at))


def occ(n, at, status="scheduled", tz="Asia/Seoul", mode="interval", plan_id=PLAN):
    return {"id": uid(n), "planId": plan_id, "scheduledAt": at, "timeZone": tz, "status": status, "sourceMode": mode}


def link(at, event_id, state="active", tz="Asia/Seoul", title="Personal reminder", cal=SEL, plan_id=PLAN):
    s = parse(at)
    return {"slotKey": slot_key(plan_id, s), "calendarId": cal, "eventId": event_id, "state": state,
            "writtenStart": fmt(s), "writtenEnd": fmt(s + EVENT_MINUTES * 60_000), "writtenTitle": title,
            "writtenTimeZone": tz}


def ev(event_id, at, marker, title="Personal reminder", cal=SEL, tz="Asia/Seoul"):
    s = parse(at)
    return {"eventId": event_id, "calendarId": cal, "start": fmt(s), "end": fmt(s + EVENT_MINUTES * 60_000),
            "title": title, "timeZone": tz, "markerKey": marker}


def case(cid, desc, mode="reconcile", config=None, occurrences=(), links=(), observed=(), now=NOW, gate_min=None):
    inp = {"mode": mode, "now": now, "config": config or cfg(), "occurrences": list(occurrences),
           "links": list(links), "observedEvents": list(observed)}
    if gate_min:
        inp["minimumIntervalGate"] = gate_min
    return {"id": cid, "description": desc, "input": inp}


nine_day = [
    occ(1, "2026-09-22T00:00:00Z", "completed"),
    occ(2, "2026-09-30T23:30:00Z", "due"),          # 9.5h ago, inside 24h look-back
    occ(3, "2026-10-09T23:30:00Z"),
    occ(4, "2026-10-18T23:30:00Z"),
    occ(5, "2026-12-23T23:30:00Z"),                 # before horizon end 2026-12-24T09:00Z
    occ(6, "2026-12-24T09:00:00Z"),                 # == horizon end, exclusive
]
explicit = [
    occ(11, "2026-10-02T01:00:00Z", mode="explicitDates"),
    occ(12, "2026-10-05T10:15:00Z", mode="explicitDates"),
    occ(13, "2026-10-05T01:00:00Z", mode="explicitDates"),
    occ(14, "2026-11-30T01:00:00Z", "skipped", mode="explicitDates"),
    occ(15, "2027-02-01T01:00:00Z", mode="explicitDates"),
]
daily = [occ(100 + i, (datetime(2026, 10, 1, 12, 0, tzinfo=timezone.utc) + timedelta(days=i)).strftime("%Y-%m-%dT%H:%M:%SZ"))
         for i in range(26)]

A, B, C = "2026-10-03T00:00:00Z", "2026-10-12T00:00:00Z", "2026-09-30T12:00:00Z"
B1, B2 = "2026-10-12T01:00:00Z", "2026-10-12T02:00:00Z"
T2, T3, T4 = "2026-09-30T23:30:00Z", "2026-10-09T23:30:00Z", "2026-10-18T23:30:00Z"

cases = [
    case("gate_disabled_off", "Sync switched off: no provider access, no operations.", config=cfg(enabled=False), occurrences=nine_day),
    case("gate_permission_not_determined", "Enabled but access never asked: permissionRequired, nothing written.",
         config=cfg(access="notDetermined"), occurrences=nine_day),
    case("gate_ios_write_only_is_insufficient", "iOS write-only grant cannot read/update/delete: treated as lost, links kept.",
         config=cfg(access="writeOnly"), occurrences=nine_day, links=[link(T3, "ev-3")]),
    case("gate_permission_revoked_keeps_links", "Access denied after use: links retained untouched for later resume.",
         config=cfg(access="denied"), occurrences=nine_day, links=[link(T3, "ev-3")]),
    case("gate_calendar_not_selected", "Enabled with access but no calendar chosen.", config=cfg(selectedCalendarId=None), occurrences=nine_day),
    case("gate_calendar_unavailable_account_removed", "Selected calendar gone (account removed/disabled): no fallback to a default calendar.",
         config=cfg(calendars=[{"id": SEL, "available": False, "writable": True}]), occurrences=nine_day, links=[link(T3, "ev-3")]),
    case("gate_calendar_read_only", "Selected calendar no longer accepts event writes.",
         config=cfg(calendars=[{"id": SEL, "available": True, "writable": False}]), occurrences=nine_day),
    case("interval_initial_create", "Nine-day interval plan, first enable: unresolved rows in [now-24h, now+84d) created; completed and horizon-end rows skipped.",
         occurrences=nine_day),
    case("interval_cap_24_events", "Daily cadence: at most 24 earliest desired slots get events.", occurrences=daily),
    case("explicit_dates_initial_create", "Explicit-date plan: irregular persisted slots sorted by instant; skipped and beyond-horizon slots excluded.",
         occurrences=explicit),
    case("idempotent_noop", "Second run with matching links and events: zero operations.",
         occurrences=nine_day[:4], links=[link(T2, "ev-2"), link(T3, "ev-3"), link(T4, "ev-4")],
         observed=[ev("ev-2", T2, k(T2)), ev("ev-3", T3, k(T3)), ev("ev-4", T4, k(T4))]),
    case("regenerated_rows_same_instant_noop", "Plan append regenerated unresolved rows with new UUIDs at the same instants: slot keys unchanged, zero operations.",
         occurrences=[occ(501, A), occ(502, B), occ(301, A, "cancelled"), occ(302, B, "cancelled")],
         links=[link(A, "ev-a"), link(B, "ev-b")], observed=[ev("ev-a", A, k(A)), ev("ev-b", B, k(B))]),
    case("duplicate_slot_rows_one_event", "Two unresolved rows share plan and instant (transient): one event per slot key.",
         occurrences=[occ(601, A), occ(600, A)]),
    case("subsecond_instant_normalized_noop", "Store instant with milliseconds compares at whole seconds: no false update.",
         occurrences=[occ(21, "2026-10-03T00:00:00.500Z")], links=[link(A, "ev-21")], observed=[ev("ev-21", A, k(A))]),
    case("plan_change_moves_future_slots", "Date/cadence change: cancelled future slot deleted, early-completed future slot deleted, new slot created.",
         occurrences=[occ(31, A, "cancelled"), occ(32, B, "completed"), occ(33, "2026-10-04T00:00:00Z")],
         links=[link(A, "ev-31"), link(B, "ev-32")], observed=[ev("ev-31", A, k(A)), ev("ev-32", B, k(B))]),
    case("resolved_past_event_kept", "Completed slot whose time already passed: link forgotten, past event left in calendar.",
         occurrences=[occ(41, C, "completed")], links=[link(C, "ev-41")], observed=[ev("ev-41", C, k(C))]),
    case("minimum_interval_gate_suppresses_slot", "Verified pack minimum interval after an early dose: slot inside window not desired (future event deleted).",
         occurrences=[occ(51, "2026-10-02T00:00:00Z"), occ(52, "2026-10-09T00:00:00Z")],
         links=[link("2026-10-02T00:00:00Z", "ev-51")], observed=[ev("ev-51", "2026-10-02T00:00:00Z", k("2026-10-02T00:00:00Z"))],
         gate_min={"latestAdministrationAt": "2026-09-30T00:00:00Z", "minimumIntervalHours": 72}),
    case("user_moved_event_detach", "User moved app event in calendar app (policy detach): link detached, never overwritten.",
         occurrences=[occ(61, A)], links=[link(A, "ev-61")], observed=[ev("ev-61", "2026-10-03T02:00:00Z", k(A))]),
    case("user_moved_event_restore_policy", "Alternative policy restore: app rewrites its own event to the schedule.",
         config=cfg(userEditPolicy="restore"), occurrences=[occ(61, A)], links=[link(A, "ev-61")],
         observed=[ev("ev-61", "2026-10-03T02:00:00Z", k(A))]),
    case("user_retitled_event_detach", "User renamed app event: detached.",
         occurrences=[occ(62, A)], links=[link(A, "ev-62")], observed=[ev("ev-62", A, k(A), title="Clinic")]),
    case("user_moved_event_to_other_calendar", "Best effort: user moved event to another calendar and the provider kept its id (not expected on iOS, see EKEvent.h eventIdentifier): detached even under restore policy.",
         config=cfg(userEditPolicy="restore"), occurrences=[occ(63, A)], links=[link(A, "ev-63")],
         observed=[ev("ev-63", A, k(A), cal="cal-work")]),
    case("user_deleted_event_tombstone", "User deleted app event (policy detach): tombstoned, not recreated; existing tombstone stays quiet.",
         occurrences=[occ(71, A), occ(72, B)], links=[link(A, "ev-71"), link(B, None, state="tombstoned")]),
    case("user_deleted_event_restore_policy", "Alternative policy restore: deleted app event recreated with the same key.",
         config=cfg(userEditPolicy="restore"), occurrences=[occ(71, A)], links=[link(A, "ev-71")]),
    case("detached_event_kept_after_slot_resolved", "Detached (user-owned) future event: link kept after slot resolves, event untouched, not an orphan.",
         occurrences=[occ(81, A, "completed")], links=[link(A, "ev-81", state="detached")],
         observed=[ev("ev-81", "2026-10-03T03:00:00Z", k(A))]),
    case("detached_link_forgotten_when_event_gone", "Detached link whose event the user later deleted and slot resolved: forgotten.",
         occurrences=[occ(82, A, "completed")], links=[link(A, "ev-82", state="detached")]),
    case("event_identifier_changed_relink_by_marker", "Provider sync changed event id: exact key marker in selected calendar relinks, no duplicate.",
         occurrences=[occ(91, A)], links=[link(A, "ev-91-old")], observed=[ev("ev-91-new", A, k(A))]),
    case("restore_or_reinstall_adopts_marker_event", "Mapping lost (reinstall/restore; regenerated row ids): marker event adopted; title differs so updated.",
         config=cfg(titleMode="descriptive"), occurrences=[occ(92, A)], observed=[ev("ev-92", A, k(A))]),
    case("duplicate_marker_events_trimmed", "Two future events carry one key (crash or two devices): keep linked, delete extra.",
         occurrences=[occ(93, A)], links=[link(A, "ev-93-a")], observed=[ev("ev-93-a", A, k(A)), ev("ev-93-b", A, k(A))]),
    case("orphan_marker_events_counted_not_deleted", "Marker events with no desired slot or link: counted for user-confirmed cleanup, never auto-deleted.",
         occurrences=[occ(94, A)], links=[link(A, "ev-94")],
         observed=[ev("ev-94", A, k(A)), ev("ev-orphan-future", B, k(B, OTHER_PLAN)), ev("ev-orphan-past", C, k(C, OTHER_PLAN))]),
    case("foreign_event_never_touched", "Same time and title but no DoseWeek marker: ignored; app creates its own.",
         occurrences=[occ(95, A)], observed=[ev("ev-foreign", A, None)]),
    case("title_mode_change_updates_active_only", "Generic to descriptive: active links updated, detached untouched.",
         config=cfg(titleMode="descriptive"), occurrences=[occ(96, A), occ(97, B)],
         links=[link(A, "ev-96"), link(B, "ev-97", state="detached")],
         observed=[ev("ev-96", A, k(A)), ev("ev-97", "2026-10-12T05:00:00Z", k(B))]),
    case("zone_relabel_same_instant_updates", "Same instant, new zone id (fixed-zone plan relabel): same key, event time zone updated.",
         occurrences=[occ(98, A, tz="Europe/Berlin")], links=[link(A, "ev-98")], observed=[ev("ev-98", A, k(A))]),
    case("floating_travel_moves_event", "Floating plan regenerated after device zone change (new instant): old future event deleted, new one created.",
         occurrences=[occ(99, "2026-10-03T07:00:00Z", tz="Europe/Berlin")], links=[link(A, "ev-99")], observed=[ev("ev-99", A, k(A))]),
    case("selected_calendar_changed", "User picked another calendar: old future events removed, past forgotten, new calendar populated.",
         config=cfg(selectedCalendarId="cal-new", calendars=[{"id": "cal-new", "available": True, "writable": True},
                                                            {"id": SEL, "available": True, "writable": True}]),
         occurrences=[occ(99, A), occ(89, C, "due")],
         links=[link(A, "ev-99"), link(C, "ev-89")], observed=[ev("ev-99", A, k(A)), ev("ev-89", C, k(C))]),
    case("teardown_remove_future", "Turn off and remove: unmodified future deleted; past, user-modified and missing forgotten; detached link retained, event untouched.",
         mode="teardownRemoveFuture", config=cfg(enabled=False),
         links=[link(A, "ev-1"), link(C, "ev-2"), link(B, "ev-3"), link(B1, "ev-4"), link(B2, "ev-5", state="detached")],
         observed=[ev("ev-1", A, k(A)), ev("ev-2", C, k(C)), ev("ev-3", "2026-10-12T04:00:00Z", k(B)), ev("ev-5", B2, k(B2))]),
    case("teardown_without_permission", "Remove requested but access lost: nothing deleted, links kept; UI offers keep-and-turn-off.",
         mode="teardownRemoveFuture", config=cfg(access="denied"), links=[link(A, "ev-1")]),
    case("teardown_keep_events", "Turn off and keep: active links dropped, tombstone retained, provider untouched (no access needed).",
         mode="teardownKeep", config=cfg(access="denied"), links=[link(A, "ev-1"), link(B, None, state="tombstoned")]),
    case("cleanup_orphans_user_confirmed", "User-confirmed cleanup: future unlinked marker events in selected calendar deleted; past, linked, detached, foreign, other-calendar untouched.",
         mode="cleanupOrphans", links=[link(A, "ev-94"), link(B, "ev-97", state="detached")],
         observed=[ev("ev-94", A, k(A)), ev("ev-97", "2026-10-12T05:00:00Z", k(B)),
                   ev("ev-o1", B, k(B, OTHER_PLAN)), ev("ev-o0", "2026-10-20T00:00:00Z", k("2026-10-20T00:00:00Z", OTHER_PLAN)),
                   ev("ev-op", C, k(C, OTHER_PLAN)), ev("ev-foreign", B, None),
                   ev("ev-other-cal", B, k(B1, OTHER_PLAN), cal="cal-work")]),
]


# ---------------------------------------------------------------- review fixes (2026-09-15 revision)
def after_of(c):
    """Links a case leaves behind, for chaining a later step. Pending creates get deterministic ids."""
    out = plan(c["input"])["linksAfter"]
    return [dict(l, eventId=l["eventId"] or ("new-" + l["slotKey"][-10:])) if l["state"] == "active" else l for l in out]


MOVED = ev("ev-61", "2026-10-03T02:00:00Z", k(A), title="Clinic")
keep_with_user_owned = case("_", "_", mode="teardownKeep",
                            links=[link(A, "ev-61", state="detached"), link(B, None, state="tombstoned"), link(B1, "ev-4")])
KO_TITLES = sorted(TITLES.values()) + ["개인 알림", "주사 예정일"]

# 26 daily slots at 12:00Z from 2026-10-01; slot index 23 (2026-10-24) is the 24th desired slot.
cap26 = [occ(700 + i, (datetime(2026, 10, 1, 12, tzinfo=timezone.utc) + timedelta(days=i)).strftime("%Y-%m-%dT%H:%M:%SZ"))
         for i in range(26)]
SLOT24 = "2026-10-24T12:00:00Z"
EARLY = occ(799, "2026-10-01T18:00:00Z")
cap_links = [link(o["scheduledAt"], f"ev-c{i}") for i, o in enumerate(cap26[:23])] + [link(SLOT24, None, state="tombstoned")]
cap_obs = [ev(f"ev-c{i}", o["scheduledAt"], k(o["scheduledAt"])) for i, o in enumerate(cap26[:23])]
pushed = case("tombstone_kept_when_slot_pushed_past_cap",
              "Cap churn: an earlier slot appears and pushes the user-deleted 24th slot out of the cap; tombstone kept (slot still live), no create.",
              occurrences=cap26 + [EARLY], links=cap_links, observed=cap_obs)
cases += [
    case("reenable_after_keep_user_edited",
         "Turn off with keep, then turn on again: the retained detached link keeps the user-moved event untouched (no adopt, no update).",
         occurrences=[occ(61, A)], links=plan(keep_with_user_owned["input"])["linksAfter"], observed=[MOVED]),
    case("reenable_after_keep_user_deleted",
         "Turn off with keep, then turn on again: the retained tombstone stops the user-deleted slot from being recreated.",
         occurrences=[occ(72, B)], links=plan(keep_with_user_owned["input"])["linksAfter"]),
    case("reinstall_adopts_user_edited_event_as_detached",
         "No links (reinstall, or delete-all state loss) and the marker event was moved and renamed by the user: adopted as detached, never written.",
         occurrences=[occ(61, A)], observed=[MOVED]),
    case("reinstall_adopts_retimed_only_event_as_detached",
         "No links; marker event keeps an app title but its end was changed by the user: adopted as detached.",
         occurrences=[occ(64, A)], observed=[dict(ev("ev-64", A, k(A)), end="2026-10-03T01:00:00Z")]),
    case("reinstall_adopts_other_locale_title_as_active",
         "No links; untouched marker event written earlier in another app language: adopted active, title updated to the current text.",
         config=cfg(knownAppTitles=KO_TITLES), occurrences=[occ(65, A)], observed=[ev("ev-65", A, k(A), title="개인 알림")]),
    case("reinstall_restore_policy_adopts_edited_event",
         "Alternative restore policy: an edited marker event without a link is adopted active and rewritten to the schedule.",
         config=cfg(userEditPolicy="restore"), occurrences=[occ(61, A)], observed=[MOVED]),
    pushed,
    case("tombstone_kept_when_slot_returns_to_cap",
         "Cap churn reversed: the earlier slot is completed and the user-deleted slot is back in the cap; still tombstoned, not recreated.",
         occurrences=cap26 + [dict(EARLY, status="completed")], links=after_of(pushed),
         observed=cap_obs + [ev("new-" + k(EARLY["scheduledAt"])[-10:], EARLY["scheduledAt"], k(EARLY["scheduledAt"]))]),
    case("tombstone_kept_while_minimum_interval_gated",
         "Verified-pack minimum interval hides the user-deleted slot for a while: tombstone kept (slot live), nothing created.",
         occurrences=[occ(52, "2026-10-02T00:00:00Z")], links=[link("2026-10-02T00:00:00Z", None, state="tombstoned")],
         gate_min={"latestAdministrationAt": "2026-09-30T00:00:00Z", "minimumIntervalHours": 72}),
    case("tombstone_forgotten_when_slot_resolved",
         "User-deleted slot is later recorded as completed: slot gone, tombstone forgotten.",
         occurrences=[occ(73, B, "completed")], links=[link(B, None, state="tombstoned")]),
    case("tombstone_forgotten_after_lookback",
         "User-deleted slot still unresolved but older than the 24h look-back: slot gone, tombstone forgotten.",
         occurrences=[occ(74, "2026-09-29T00:00:00Z", "needsReview")], links=[link("2026-09-29T00:00:00Z", None, state="tombstoned")]),
    case("tombstone_forgotten_after_plan_change",
         "New plan id (plan replaced): the old plan's slot keys are not live, tombstone forgotten; the new plan slot is created.",
         occurrences=[occ(75, B, plan_id=OTHER_PLAN)], links=[link(B, None, state="tombstoned")]),
    case("tombstoned_event_restored_by_user_detaches",
         "User undoes the deletion (marker event reappears): link becomes detached on that event; never deleted as a duplicate, never recreated.",
         occurrences=[occ(76, B)], links=[link(B, None, state="tombstoned")], observed=[ev("ev-76-back", B, k(B))]),
    case("detached_event_deleted_kept_through_cap_churn",
         "Detached link whose event the user then deleted stays while the slot is live but outside the cap: nothing recreated.",
         occurrences=cap26 + [EARLY], links=cap_links[:23] + [link(SLOT24, "ev-gone", state="detached")], observed=cap_obs),
    case("selected_calendar_changed_old_read_only",
         "Re-pick after the old calendar became read-only: old links forgotten (cannot delete there), new calendar populated; batch cannot stall.",
         config=cfg(selectedCalendarId="cal-new", calendars=[{"id": "cal-new", "available": True, "writable": True},
                                                            {"id": SEL, "available": True, "writable": False}]),
         occurrences=[occ(99, A)], links=[link(A, "ev-99")], observed=[ev("ev-99", A, k(A))]),
    case("selected_calendar_changed_old_unavailable",
         "Re-pick after the old calendar disappeared (no descriptor): old links forgotten, new calendar populated.",
         config=cfg(selectedCalendarId="cal-new", calendars=[{"id": "cal-new", "available": True, "writable": True}]),
         occurrences=[occ(99, A)], links=[link(A, "ev-99")]),
    case("teardown_remove_future_read_only_calendar",
         "Turn off and remove while the link's calendar is read-only: forgotten with calendarNotWritable (UI reports it as not removed).",
         mode="teardownRemoveFuture", config=cfg(enabled=False, calendars=[{"id": SEL, "available": True, "writable": False}]),
         links=[link(A, "ev-1")], observed=[ev("ev-1", A, k(A))]),
    case("user_moved_event_to_other_calendar_id_changed",
         "Expected iOS outcome of a calendar move: event id changes and the marker is outside the selected calendar -> tombstone (no recreate).",
         occurrences=[occ(66, A)], links=[link(A, "ev-66")], observed=[ev("ev-66-moved", A, k(A), cal="cal-work")]),
]

V1_CASES = len(cases)

# ---------------------------------------------------------------- v3 additions (2026-09-15, core-engines parity closure)
# Behaviour both platform planners implemented without a fixture case: unusable gate hours, whole-second
# gate arithmetic, window and "now" boundaries, plan-id case, empty eventId / markerKey, and the two
# reconcile branches no v1 case reached (active link with no event for a resolved slot; user-edited
# event for a resolved slot).
UPPER_PLAN = "AAAAAAAA-AAAA-4AAA-8AAA-AAAAAAAAAAAA"
cases += [
    case("minimum_interval_gate_zero_hours_is_no_gate",
         "Gate hours 0 are not a usable minimum: planned exactly as with no gate, so the due slot before the latest dose still gets its event.",
         occurrences=[occ(201, T2, "due"), occ(202, T3)],
         gate_min={"latestAdministrationAt": "2026-10-01T08:00:00Z", "minimumIntervalHours": 0}),
    case("minimum_interval_gate_negative_hours_is_no_gate",
         "Negative gate hours are not a usable minimum (neither subtracted nor made positive): planned exactly as with no gate.",
         occurrences=[occ(203, T2, "due"), occ(204, T3)],
         gate_min={"latestAdministrationAt": NOW, "minimumIntervalHours": -1}),
    case("minimum_interval_gate_boundary_inclusive_at_whole_seconds",
         "The latest dose instant is floored to whole seconds before the hours are added; a slot exactly at the eligible instant gets an event, one second earlier does not.",
         occurrences=[occ(211, "2026-10-02T23:59:59Z"), occ(212, "2026-10-03T00:00:00Z")],
         gate_min={"latestAdministrationAt": "2026-09-30T00:00:00.900Z", "minimumIntervalHours": 72}),
    case("minimum_interval_gate_fractional_hours_truncate_to_milliseconds",
         "Gate milliseconds are hours x 3,600,000 truncated toward zero (72.0000002 h adds 259,200,000 ms, not 259,200,001): the slot exactly 72 h after the dose gets an event.",
         occurrences=[occ(213, "2026-10-03T00:00:00Z")],
         gate_min={"latestAdministrationAt": "2026-09-30T00:00:00Z", "minimumIntervalHours": 72.0000002}),
    case("lookback_window_start_is_inclusive",
         "The look-back starts exactly 24 h before now: a due slot at now - 24 h gets an event, one second older does not.",
         occurrences=[occ(221, "2026-09-30T09:00:00Z", "due"), occ(222, "2026-09-30T08:59:59Z", "due")]),
    case("event_starting_at_now_is_future",
         "An event starting exactly now is future: the resolved slot's event is deleted (not forgotten as past), and an unowned marker event starting now counts as an orphan.",
         occurrences=[occ(231, NOW, "completed")], links=[link(NOW, "ev-now")],
         observed=[ev("ev-now", NOW, k(NOW)), ev("ev-orphan-now", NOW, k(NOW, OTHER_PLAN))]),
    case("slot_key_lowercases_plan_id",
         "An upper-case plan id gives the same lower-case slot key as the stored link and the marker: zero operations.",
         occurrences=[occ(241, A, plan_id=UPPER_PLAN)], links=[link(A, "ev-241", plan_id=UPPER_PLAN)],
         observed=[ev("ev-241", A, k(A, UPPER_PLAN))]),
    case("observed_subsecond_event_times_floor_noop",
         "Provider event times with milliseconds compare at whole seconds with the written baseline: not a user edit, zero operations.",
         occurrences=[occ(251, A)], links=[link(A, "ev-251")],
         observed=[dict(ev("ev-251", A, k(A)), start="2026-10-03T00:00:00.750Z", end="2026-10-03T00:30:00.250Z")]),
    case("active_link_event_missing_slot_resolved_forgotten",
         "Active link whose event is gone and whose slot was resolved: forgotten with eventMissing; no tombstone, nothing created.",
         occurrences=[occ(261, A, "completed")], links=[link(A, "ev-261")]),
    case("user_edited_event_moved_to_past_slot_resolved_forgotten",
         "User moved the app event to an earlier time that has passed, then the slot was cancelled: the edit is checked before the past check, so the link is forgotten as userModified and the event is left alone.",
         occurrences=[occ(262, A, "cancelled")], links=[link(A, "ev-262")],
         observed=[ev("ev-262", "2026-09-30T20:00:00Z", k(A))]),
    case("restore_policy_moved_calendar_slot_resolved_forgotten",
         "Restore policy; the event moved to another calendar with its id kept, then the slot was completed: a calendar move is the user's even under restore, so forgotten as userModified, never deleted.",
         config=cfg(userEditPolicy="restore"), occurrences=[occ(263, B, "completed")], links=[link(B, "ev-263")],
         observed=[ev("ev-263", B, k(B), cal="cal-work")]),
    case("restore_policy_edited_event_slot_resolved_deleted",
         "Restore policy, same calendar: an edited future event whose slot was resolved is the app's to remove, so it is deleted as notDesired.",
         config=cfg(userEditPolicy="restore"), occurrences=[occ(264, B1, "completed")], links=[link(B1, "ev-264")],
         observed=[ev("ev-264", "2026-10-12T03:00:00Z", k(B1))]),
    case("empty_event_id_is_absent_in_reconcile",
         "Links stored with an empty eventId match no observed event, not even a foreign one whose id is empty: A relinks by its marker, B has no event and is tombstoned, and detached C, whose slot is gone, is forgotten.",
         occurrences=[occ(271, A), occ(272, B)],
         links=[link(A, ""), link(B, ""), link(C, "", state="detached")],
         observed=[ev("ev-271", A, k(A)), ev("", A, None, title="Dentist")]),
    case("empty_marker_key_is_not_a_marker",
         "Events whose marker key is empty are foreign: never adopted and never counted as orphans; the app creates its own event.",
         occurrences=[occ(273, A)],
         observed=[ev("ev-blank-a", A, ""), ev("ev-blank-b", B, "")]),
    case("cleanup_orphans_ignores_empty_marker_key",
         "User-confirmed cleanup: an event with an empty marker key is foreign and kept; the event whose key an active link holds is kept; the unowned marker event is deleted.",
         mode="cleanupOrphans", links=[link(A, "")],
         observed=[ev("ev-a", A, k(A)), ev("ev-blank", B, ""), ev("ev-o", B1, k(B1, OTHER_PLAN))]),
    case("teardown_remove_future_empty_event_id_is_absent",
         "Turn off and remove with links stored with an empty eventId: A is found by its marker and deleted; B matches neither the foreign event whose id is empty nor any marker, so it is forgotten as eventMissing.",
         mode="teardownRemoveFuture", config=cfg(enabled=False),
         links=[link(A, ""), link(B, "")],
         observed=[ev("ev-a", A, k(A)), ev("", B, None, title="Dentist")]),
    case("teardown_remove_future_without_selected_calendar",
         "Turn off and remove needs no selected calendar: gating stops before the selection check and each link's own calendar descriptor decides.",
         mode="teardownRemoveFuture", config=cfg(enabled=False, selectedCalendarId=None),
         links=[link(A, "ev-1")], observed=[ev("ev-1", A, k(A))]),
]

for c in cases:
    c["expected"] = plan(c["input"])

legacy = "--v1" in sys.argv[1:]
args = [a for a in sys.argv[1:] if a != "--v1"]
if len(args) != 1:
    sys.exit("usage: gen_calendar_sync_fixture.py [--v1] <output.json>")
out_cases = cases[:V1_CASES] if legacy else cases
doc = {
    "schema": "doseweek.calendarSync.reconcile",
    "version": 1 if legacy else 3,
    "generatedFrom": "designs/calendar-sync.md section 6 (reference planner gen_calendar_sync_fixture.py)",
    "constants": {"horizonDays": HORIZON_DAYS, "maxEvents": MAX_EVENTS, "lookbackHours": LOOKBACK_HOURS,
                  "eventDurationMinutes": EVENT_MINUTES, "slotKeyFormat": "dw1-<planId lowercase>-<scheduled epoch seconds>",
                  "instantComparison": "floor to whole seconds UTC", "unresolvedStatuses": sorted(UNRESOLVED)},
    "titleTexts": TITLES,
    "cases": out_cases,
}
if not legacy:
    doc["conventions"] = {
        "minimumIntervalGate": "only a finite positive minimumIntervalHours gates; any other value (0 and negatives here, NaN and infinity have no JSON form) plans exactly as if minimumIntervalGate were absent. earliest = latestAdministrationAt floored to whole seconds + trunc(hours x 3,600,000) ms; a slot at earliest is desired",
        "emptyIdentifiers": "an empty eventId (link or observed event) or markerKey is treated as absent: it matches no event, owns no event id, and is never a marker for adopt, relink, duplicate, orphan or cleanup decisions. relink reports the link's stored fromEventId unchanged",
        "boundaries": "window [now - 24 h, now + 84 d): start inclusive, end exclusive; an event whose start equals now is future",
        "versioning": "version 3 supersedes calendar_sync_reconcile_v1.json (SHA-256 ae918c71958b6ddd74145b94c76924abd12cae43608d77cebe043460612172fb); cases 1-56 are the v1 cases unchanged, cases 57-73 are new",
    }
out = json.dumps(doc, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
open(args[0], "w", encoding="utf-8").write(out)
print(len(out_cases), "cases", hashlib.sha256(out.encode()).hexdigest())
