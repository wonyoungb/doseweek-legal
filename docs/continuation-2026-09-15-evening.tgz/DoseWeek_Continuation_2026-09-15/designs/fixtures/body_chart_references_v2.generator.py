"""body_chart_references v2 generator (reference implementation). v1 superseded 2026-09-15 by review; never hand-edit output."""
import json, math
from datetime import datetime, date, timedelta
from zoneinfo import ZoneInfo

LB = 0.45359237
EPS = 1e-9
def rnd(x, dp):
    f = 10 ** dp
    if x >= 0: return math.floor(x * f + 0.5 + EPS) / f
    return -math.floor(-x * f + 0.5 + EPS) / f
def fx(x, dp): return format(rnd(x, dp), f'.{dp}f')

def local_day(s, zone):
    return datetime.fromisoformat(s['instant'].replace('Z', '+00:00')).astimezone(ZoneInfo(zone)).date()

def daily(samples, zone):
    by = {}
    for s in samples:
        if s.get('hidden') or not s.get('eligible', True): continue
        d = local_day(s, zone)
        key = (s['instant'], 1 if s['source'] == 'manual' else 0, s['id'])
        cur = by.get(d)
        if cur is None or key > cur[0]: by[d] = (key, s)
    out = []
    for d in sorted(by):
        s = by[d][1]
        out.append({'localDate': d.isoformat(), 'sampleId': s['id'], 'kg': s['kg']})
    return out

def rates(samples, zone, minGap=7, maxGap=28):
    pts = daily(samples, zone)
    res = []
    for i, p in enumerate(pts):
        di = date.fromisoformat(p['localDate'])
        start = None
        for j in range(i - 1, -1, -1):
            gap = (di - date.fromisoformat(pts[j]['localDate'])).days
            if gap >= minGap: start = (pts[j], gap); break
        row = {'endDate': p['localDate'], 'endSampleId': p['sampleId']}
        if start is None:
            row['status'] = 'insufficientHistory'
        elif start[1] > maxGap:
            row.update(status='gapTooLong', startDate=start[0]['localDate'], gapDays=start[1])
        else:
            sp, gap = start
            loss = (sp['kg'] - p['kg']) * 7 / gap
            pct = loss / sp['kg'] * 100
            row.update(status='ok', startDate=sp['localDate'], startSampleId=sp['sampleId'], gapDays=gap,
                       startKg=fx(sp['kg'], 6), endKg=fx(p['kg'], 6),
                       lossKgPerWeek=fx(loss, 6), lossPercentPerWeek=fx(pct, 6),
                       displayKgPerWeek=fx(abs(loss), 2), displayPercentPerWeek=fx(abs(pct), 2),
                       direction='loss' if rnd(loss, 2) > 0 else ('gain' if rnd(loss, 2) < 0 else 'noChange'))
        res.append(row)
    return pts, res

catalog = [
 {"id": "rate.nhs.2023", "kind": "band", "metric": "weightLossRate", "nativeUnit": "kgPerWeek", "lower": "0.5", "upper": "1.0",
  "lowerInclusive": True, "upperInclusive": True, "displayDecimals": 2, "populationKey": "adultsGeneralUK",
  "sourceUrl": "https://www.nhs.uk/live-well/healthy-weight/managing-your-weight/tips-to-help-you-lose-weight/",
  "sourceSummary": "aim to lose 1 to 2lbs, or 0.5 to 1kg, a week", "sourceReviewed": "2023-03-17", "accessed": "2026-09-15"},
 {"id": "rate.cdc.2025", "kind": "band", "metric": "weightLossRate", "nativeUnit": "lbPerWeek", "lower": "1", "upper": "2",
  "lowerInclusive": True, "upperInclusive": True, "displayDecimals": 2, "populationKey": "adultsGeneralUS",
  "sourceUrl": "https://www.cdc.gov/healthy-weight-growth/losing-weight/index.html",
  "sourceSummary": "a gradual, steady pace - about 1 to 2 pounds a week", "sourceReviewed": "2025-01-17", "accessed": "2026-09-15"},
 {"id": "bmi.who.adult", "kind": "band", "metric": "bmi", "nativeUnit": "kgPerM2", "lower": "18.5", "upper": "25.0",
  "lowerInclusive": True, "upperInclusive": False, "displayDecimals": 1, "populationKey": "adults18International",
  "sourceUrl": "https://www.who.int/news-room/fact-sheets/detail/obesity-and-overweight",
  "sourceSummary": "adults: overweight BMI >= 25, obesity BMI >= 30; underweight BMI < 18.5 (GHO indicator)", "sourceReviewed": "2025-12-08", "accessed": "2026-09-15"},
 {"id": "bmi.cdc.adult", "kind": "band", "metric": "bmi", "nativeUnit": "kgPerM2", "lower": "18.5", "upper": "25.0",
  "lowerInclusive": True, "upperInclusive": False, "displayDecimals": 1, "populationKey": "adults20US",
  "sourceUrl": "https://www.cdc.gov/bmi/adult-calculator/bmi-categories.html",
  "sourceSummary": "adults 20 and older: healthy weight 18.5 to less than 25", "sourceReviewed": "2024-03-19", "accessed": "2026-09-15"},
 {"id": "bmi.nice.ng246.lowerThreshold", "kind": "threshold", "metric": "bmi", "nativeUnit": "kgPerM2", "lower": None, "upper": "23.0",
  "lowerInclusive": True, "upperInclusive": False, "displayDecimals": 1, "populationKey": "adultsUKLowerThresholdBackgrounds",
  "sourceUrl": "https://www.nice.org.uk/guidance/ng246/chapter/Identifying-and-assessing-overweight-obesity-and-central-adiposity",
  "sourceSummary": "rec 1.9.11: South Asian, Chinese, other Asian, Middle Eastern, Black African or African-Caribbean background: lower thresholds, overweight BMI 23 to 27.4, obesity 27.5 or above; no lower range stated", "sourceReviewed": "2026-01-08", "accessed": "2026-09-15"},
 {"id": "bmi.nice.ng246.general", "kind": "band", "metric": "bmi", "nativeUnit": "kgPerM2", "lower": "18.5", "upper": "25.0",
  "lowerInclusive": True, "upperInclusive": False, "displayDecimals": 1, "populationKey": "adultsUKGeneral",
  "sourceUrl": "https://www.nice.org.uk/guidance/ng246/chapter/Identifying-and-assessing-overweight-obesity-and-central-adiposity",
  "sourceSummary": "rec 1.9.10: healthy weight BMI 18.5 to 24.9", "sourceReviewed": "2026-01-08", "accessed": "2026-09-15"},
 {"id": "bmi.ksso.2022", "kind": "band", "metric": "bmi", "nativeUnit": "kgPerM2", "lower": "18.5", "upper": "23.0",
  "lowerInclusive": True, "upperInclusive": False, "displayDecimals": 1, "populationKey": "koreanAdults18",
  "sourceUrl": "https://doi.org/10.7570/jomes23031",
  "sourceSummary": "KSSO 2022 update: overweight BMI >= 23, obesity BMI >= 25 (Korean adults); Table 1 normal 18.5-22.9", "sourceReviewed": "2023-06-01", "accessed": "2026-09-15"},
 {"id": "bmi.jasso", "kind": "band", "metric": "bmi", "nativeUnit": "kgPerM2", "lower": "18.5", "upper": "25.0",
  "lowerInclusive": True, "upperInclusive": False, "displayDecimals": 1, "populationKey": "japanJasso",
  "sourceUrl": "https://www.jasso.or.jp/data/magazine/pdf/chart_A.pdf",
  "sourceSummary": "JASSO himando bunrui: normal weight 18.5 <= BMI < 25", "sourceReviewed": "undated", "accessed": "2026-09-15"},
]

def band_bounds_kg(entry):
    lo = None if entry['lower'] is None else float(entry['lower'])
    up = float(entry['upper'])
    if entry['nativeUnit'] == 'lbPerWeek': lo, up = lo * LB, up * LB
    return lo, up

def member(value, entry):
    dp = entry['displayDecimals']
    lo, up = band_bounds_kg(entry)
    v, u = rnd(value, dp), rnd(up, dp)
    if entry['kind'] == 'threshold':
        above = v > u or (v == u and not entry['upperInclusive'])
        return {'roundedValue': fx(value, dp), 'roundedLower': None, 'roundedUpper': fx(up, dp),
                'position': 'atOrAboveThreshold' if above else 'belowThreshold'}
    l = rnd(lo, dp)
    below = v < l or (v == l and not entry['lowerInclusive'])
    above = v > u or (v == u and not entry['upperInclusive'])
    return {'roundedValue': fx(value, dp), 'roundedLower': fx(lo, dp), 'roundedUpper': fx(up, dp),
            'position': 'below' if below else ('above' if above else 'inside')}

cat = {c['id']: c for c in catalog}

S = lambda i, inst, v, src='manual', **k: dict(id=i, instant=inst, kg=v, source=src, **k)
rate_cases = []
c1 = [S('w1', '2026-08-01T23:00:00Z', 92.0), S('w2', '2026-08-09T00:00:00Z', 91.2), S('w3', '2026-08-16T00:30:00Z', 90.5),
      S('w4', '2026-08-20T00:00:00Z', 90.3), S('w5', '2026-08-23T00:00:00Z', 89.9)]
c2 = [S('g1', '2026-07-01T00:00:00Z', 95.0), S('g2', '2026-08-15T00:00:00Z', 93.0), S('g3', '2026-08-22T00:00:00Z', 92.6)]
c3 = [S('d1', '2026-03-07T13:00:00Z', 90.718474, 'imported'), S('d2', '2026-03-07T23:00:00Z', 91.17206637, 'imported'),
      S('d3', '2026-03-14T12:00:00Z', 90.9), S('d4', '2026-03-21T12:00:00Z', 91.4)]
c4 = [S('t1', '2026-05-24T14:00:00Z', 80.0, 'imported'), S('t2', '2026-05-31T15:30:00Z', 79.6, 'imported'),
      S('t3', '2026-05-31T15:30:00Z', 79.5, 'manual'), S('t4', '2026-05-31T14:00:00Z', 79.9, 'imported', hidden=True),
      S('t5', '2026-05-31T15:40:00Z', 12.0, 'imported', eligible=False)]
c6 = [S('s1', '2026-09-01T00:00:00Z', 88.0), S('s2', '2026-09-08T00:00:00Z', 88.0)]
for cid, zone, samples, note in [
    ('rate.basicKoreaTrailingWindow', 'Asia/Seoul', c1, 'start = latest earlier daily point >= 7 days back; 08-20 skips 08-16 (4 days) and uses 08-09 (11 days)'),
    ('rate.gapLongerThan28DaysBreaksSeries', 'Asia/Seoul', c2, 'no interpolation across a 45-day gap; line segment breaks'),
    ('rate.dstSameDayLastWinsAndGain', 'America/New_York', c3, 'kg input (200 lb and 201 lb rows already converted at platform read); 2026-03-08 DST start; gap counted in local calendar days; gain reported as direction gain'),
    ('rate.zoneDayBoundaryTieHiddenIneligible', 'Asia/Seoul', c4, '15:30Z is next local day in Seoul; same-instant tie prefers manual; hidden and ineligible imports excluded'),
    ('rate.noChange', 'Asia/Seoul', c6, 'zero change is noChange, not loss'),
]:
    pts, res = rates(samples, zone)
    rate_cases.append({'id': cid, 'zone': zone, 'note': note, 'input': {'minGapDays': 7, 'maxGapDays': 28, 'samples': samples},
                       'expected': {'dailyPoints': [{'localDate': p['localDate'], 'sampleId': p['sampleId'], 'kg': fx(p['kg'], 6)} for p in pts], 'rates': res}})

band_cases = []
for cid, ref, val in [
    ('band.nhs.lowerEdgeInclusive', 'rate.nhs.2023', 0.5), ('band.nhs.roundsUpIntoBand', 'rate.nhs.2023', 0.499),
    ('band.nhs.upperEdgeInclusive', 'rate.nhs.2023', 1.004), ('band.nhs.binaryTieRoundsAbove', 'rate.nhs.2023', 1.005),
    ('band.nhs.gainIsBelow', 'rate.nhs.2023', -0.3),
    ('band.cdc.poundBoundsRounded', 'rate.cdc.2025', 0.451), ('band.cdc.aboveUpper', 'rate.cdc.2025', 0.915),
    ('band.ksso.insideTop', 'bmi.ksso.2022', 22.9), ('band.ksso.roundsToExclusiveUpper', 'bmi.ksso.2022', 22.95),
    ('band.ksso.roundsUpToLower', 'bmi.ksso.2022', 18.45), ('band.ksso.below', 'bmi.ksso.2022', 18.4),
    ('band.who.upperExclusive', 'bmi.who.adult', 25.0), ('band.who.inside', 'bmi.who.adult', 24.94),
    ('band.niceThreshold.atOrAboveAt23', 'bmi.nice.ng246.lowerThreshold', 23.0), ('band.niceThreshold.roundsUpTo23', 'bmi.nice.ng246.lowerThreshold', 22.95),
    ('band.niceThreshold.below', 'bmi.nice.ng246.lowerThreshold', 22.94), ('band.jasso.inside', 'bmi.jasso', 24.9),
]:
    band_cases.append({'id': cid, 'referenceId': ref, 'value': val, 'expected': member(val, cat[ref])})

pct_band = []
for cid, ref, startKg in [('percentBand.nhsAt92kg', 'rate.nhs.2023', 92.0), ('percentBand.cdcAt68kg', 'rate.cdc.2025', 68.0388555)]:
    lo, up = band_bounds_kg(cat[ref])
    pct_band.append({'id': cid, 'referenceId': ref, 'intervalStartKg': startKg,
                     'expected': {'lowerPercentPerWeek': fx(lo / startKg * 100, 6), 'upperPercentPerWeek': fx(up / startKg * 100, 6),
                                  'displayLower': fx(lo / startKg * 100, 2), 'displayUpper': fx(up / startKg * 100, 2)}})

def bmi(wk, h):
    if wk is None or h is None: return None
    if not (20.0 <= wk <= 400.0) or not (30.0 <= h <= 280.0): return None
    m = h / 100
    return wk / (m * m)
bmi_cases = []
for cid, w, h in [('bmi.kgCm', 92.0, 170.0), ('bmi.recordReadFromPoundRow', 90.718474, 180.0), ('bmi.missingHeight', 92.0, None),
                  ('bmi.heightOutOfRange', 70.0, 25.0), ('bmi.weightOutOfRange', 19.9, 150.0), ('bmi.exactBoundaryValue', 72.25, 170.0)]:
    v = bmi(w, h)
    bmi_cases.append({'id': cid, 'input': {'weightKg': w, 'heightCm': h},
                      'expected': None if v is None else {'bmi': fx(v, 6), 'display': fx(v, 1)}})

units = [{'id': 'unit.lbToKg', 'value': 1, 'from': 'lb', 'to': 'kg', 'expected': fx(LB, 8)},
         {'id': 'unit.lb150ToKg', 'value': 150, 'from': 'lb', 'to': 'kg', 'expected': fx(150 * LB, 8)},
         {'id': 'unit.kgToLb', 'value': 90.0, 'from': 'kg', 'to': 'lb', 'expected': fx(90.0 / LB, 8)}]

def target_validate(metric, unit, lo, up):
    rules = {('weightLossRate', 'kgPerWeek'): (0.01, 5.0, 2), ('weightLossRate', 'percentPerWeek'): (0.01, 5.0, 2), ('bmi', 'kgPerM2'): (10.0, 60.0, 1)}
    if (metric, unit) not in rules: return 'unsupportedUnit'
    mn, mx, dp = rules[(metric, unit)]
    if lo is None or up is None: return 'missingBound'
    import re
    for s in (lo, up):
        if not re.fullmatch(r'\d{1,3}(\.\d{1,%d})?' % dp, s): return 'invalidDecimal'
    a, b = float(lo), float(up)
    if a < mn or b > mx: return 'outOfRange'
    if a > b: return 'lowerAboveUpper'
    return 'valid'
targets = []
for cid, m, u, lo, up in [('target.kgValid', 'weightLossRate', 'kgPerWeek', '0.3', '0.8'), ('target.singleValueAllowed', 'weightLossRate', 'kgPerWeek', '0.5', '0.5'),
                          ('target.lowerAboveUpper', 'weightLossRate', 'kgPerWeek', '0.9', '0.4'), ('target.tooManyDecimals', 'weightLossRate', 'kgPerWeek', '0.125', '0.5'),
                          ('target.percentOutOfRange', 'weightLossRate', 'percentPerWeek', '0.5', '5.5'), ('target.missingUpper', 'weightLossRate', 'percentPerWeek', '0.5', None),
                          ('target.bmiValid', 'bmi', 'kgPerM2', '21.0', '24.5'), ('target.bmiTwoDecimals', 'bmi', 'kgPerM2', '21.05', '24.5'),
                          ('target.bmiWrongUnit', 'bmi', 'kgPerWeek', '21.0', '24.5'), ('target.zeroBelowMinimum', 'weightLossRate', 'kgPerWeek', '0', '0.5')]:
    targets.append({'id': cid, 'input': {'metric': m, 'unit': u, 'lower': lo, 'upper': up}, 'expected': target_validate(m, u, lo, up)})

def minus_years(d, n):
    # java.time LocalDate.minusYears / Foundation Calendar byAdding .year: Feb 29 -> Feb 28
    try: return d.replace(year=d.year - n)
    except ValueError: return d.replace(year=d.year - n, day=28)
def plus_years(d, n):
    try: return d.replace(year=d.year + n)
    except ValueError: return d.replace(year=d.year + n, day=28)
def min_start(end):
    # earliest start both validators accept: start + 5 years >= end
    s = minus_years(end, 5)
    if plus_years(s, 5) < end: s = s + timedelta(days=1)
    return s

PRESETS = [('oneMonth', 30), ('threeMonths', 90), ('sixMonths', 180), ('oneYear', 365)]
def zoom(spanDays, endDate, today, scale=1.0, panDays=0):
    end = date.fromisoformat(endDate); td = date.fromisoformat(today)
    end = min(end + timedelta(days=panDays), td)
    maxSpan = (end - min_start(end)).days
    raw = min(max(spanDays / scale, 7.0), float(maxSpan))
    span = None
    for name, p in PRESETS:
        if abs(raw - p) <= 0.15 * p: span = p; break
    if span is None: span = int(math.floor(raw + 0.5 + EPS))
    span = min(span, maxSpan)
    start = end - timedelta(days=span)
    preset = next((n for n, p in PRESETS if p == span), None) if end == td else None
    return {'period': preset or 'custom', 'spanDays': span, 'start': start.isoformat(), 'end': end.isoformat(), 'rateLookbackStart': (start - timedelta(days=28)).isoformat()}
zooms = []
for cid, span, end, scale, pan, today in [(c + ('2026-09-15',)) if len(c) == 5 else c for c in [('zoom.outNoSnap', 30, '2026-09-15', 0.5, 0), ('zoom.outSnapsToThreeMonths', 30, '2026-09-15', 0.35, 0),
                                   ('zoom.inClampsToSevenDays', 90, '2026-09-15', 20.0, 0), ('zoom.outClampsToFiveYears', 365, '2026-09-15', 0.1, 0),
                                   ('zoom.snapWhenEndNotTodayStaysCustom', 30, '2026-08-31', 1.05, 0), ('zoom.unchanged', 90, '2026-09-15', 1.0, 0),
                                   ('zoom.panForwardClampsToToday', 30, '2026-09-10', 1.0, 10), ('zoom.panBackKeepsSpan', 180, '2026-09-15', 1.0, -20),
                                   ('zoom.outClampsLeapDay', 365, '2028-02-29', 0.1, 0, '2028-02-29'),
                                   ('zoom.panOntoLeapDayReclampsSpan', 1827, '2028-03-01', 1.0, -1, '2028-03-01')]]:
    zooms.append({'id': cid, 'input': {'today': today, 'spanDays': span, 'end': end, 'cumulativeScale': scale, 'panDays': pan}, 'expected': zoom(span, end, today, scale, pan)})

settings = []
for cid, row, exp in [
    ('setting.offDefault', None, {'effective': 'none'}),
    ('setting.official', {'metric': 'bmi', 'mode': 'official', 'officialReferenceId': 'bmi.ksso.2022'}, {'effective': 'official', 'referenceId': 'bmi.ksso.2022'}),
    ('setting.officialWrongMetric', {'metric': 'bmi', 'mode': 'official', 'officialReferenceId': 'rate.nhs.2023'}, {'effective': 'invalid'}),
    ('setting.unknownReferenceFromNewerCatalog', {'metric': 'bmi', 'mode': 'official', 'officialReferenceId': 'bmi.example.future'}, {'effective': 'unavailable'}),
    ('setting.personal', {'metric': 'weightLossRate', 'mode': 'personal', 'personalUnit': 'percentPerWeek', 'personalLower': '0.4', 'personalUpper': '0.9'}, {'effective': 'personal'}),
    ('setting.personalInvalidRestoredRejected', {'metric': 'weightLossRate', 'mode': 'personal', 'personalUnit': 'kgPerWeek', 'personalLower': '2', 'personalUpper': '1'}, {'effective': 'invalid'}),
    ('setting.unsupportedMetric', {'metric': 'bodyFat', 'mode': 'official', 'officialReferenceId': 'bmi.who.adult'}, {'effective': 'invalid'}),
]:
    settings.append({'id': cid, 'row': row, 'expected': exp})

fixture = {
  'fixture': 'body_chart_references', 'version': 2, 'accessed': '2026-09-15',
  'conventions': {
    'numbers': 'expected decimal strings; compare parsed Double within 5e-7 for 6-dp values; display strings must match exactly',
    'rounding': 'halfUpEpsilon: sign(x) * floor(abs(x) * 10^dp + 0.5 + 1e-9) / 10^dp',
    'poundToKilogram': '0.45359237',
    'sampleUnits': 'engine input is kilograms only; platforms convert at read (Android DoseWeekRepository mapManualBodyRecord/mapBodyRecord, iOS valueSI); the engine never converts sample units',
    'dayKey': 'local calendar date of instant in the case zone; every body sample has an instant (no date-only samples exist on either platform)',
    'dailyWinner': 'max of (instant ISO string, source manual=1 imported=0, id); hidden and ineligible samples excluded',
    'rateStart': 'latest earlier daily point with gapDays >= minGapDays; if gapDays > maxGapDays status gapTooLong; none status insufficientHistory',
    'lossKgPerWeek': '(startKg - endKg) * 7 / gapDays; positive means loss',
    'lossPercentPerWeek': 'lossKgPerWeek / startKg * 100 (denominator = interval starting weight, CHART-20260913-04)',
    'direction': 'sign of lossKgPerWeek rounded to 2 dp: >0 loss, <0 gain, 0 noChange',
    'bandMembership': 'kind band: round value and bounds to displayDecimals then compare using inclusivity -> inside|above|below; lb bounds converted to kg first. kind threshold: lower is null, no fill, round value and upper -> atOrAboveThreshold|belowThreshold',
    'zoom': 'end = min(end + panDays, today) first; minStart = end minusYears 5 (Feb 29 -> Feb 28), plus 1 day if minStart plusYears 5 < end; maxSpan = days(minStart, end); raw = clamp(spanDays / cumulativeScale, 7, maxSpan); snap to preset p when abs(raw-p) <= 0.15p else halfUpEpsilon integer; span = min(span, maxSpan); start = end - span; preset only when end == today; rateLookbackStart = start - 28 days',
    'settingResolution': 'no row -> none; mode official with id absent from catalog -> unavailable; id present but catalog metric differs from row metric, metric not in {weightLossRate,bmi}, or personal target not valid -> invalid; else official or personal',
    'metricsWithoutReferences': ['bodyFat', 'leanMass', 'waist', 'height']
  },
  'referenceCatalog': catalog,
  'unitConversion': units,
  'bmiFromSameRecord': bmi_cases,
  'weeklyRate': rate_cases,
  'bandMembership': band_cases,
  'percentBandConversion': pct_band,
  'personalTargetValidation': targets,
  'referenceSettingResolution': settings,
  'zoom': zooms,
}
out = json.dumps(fixture, indent=2, ensure_ascii=True, sort_keys=False) + '\n'
path = '/Users/wonyoungchoi/Documents/Coding Work/DoseWeek_Continuation_2026-09-15/designs/fixtures/body_chart_references_v2.json'
open(path, 'w', newline='\n').write(out)
import hashlib; print('sha256', hashlib.sha256(out.encode()).hexdigest(), len(out))
for c in rate_cases: print(c['id'], json.dumps(c['expected']['rates']))
for c in band_cases: print(c['id'], c['expected'])
for c in pct_band + bmi_cases + zooms: print(c['id'], c['expected'])
print([ (t['id'], t['expected']) for t in targets])
