# DoseWeek native calendar sync — implementation design (v1)

Date: 2026-09-15. Status: DESIGN, read-only research, **revision 2** (review fixes, see "Review log" at the end).
No repository edited, built, or run.
Sources read: iOS `/private/tmp/doseweek-v11-20260913/ios` @ `4c3e594` (revision 2 re-checked at `7e8681b`, one
commit later, touching none of the cited files), Android
`/private/tmp/doseweek-v11-20260913/android` @ `79bb210` (main), both `AGENTS.md` and
`docs/ARCHITECTURE.md`, `calendar-integration-research.md` (2026-09-13), `STATE.json` decisions
CALENDAR-20260913-17/-18/-19, SCHEDULE-20260913-16, UX-20260913-09, MAINTAINABILITY-20260913-15.

Deliverables:
- this file
- `designs/fixtures/calendar_sync_reconcile_v4.json` — 84 cases (387,307 bytes), SHA-256
  `e4b0c5dfcbd3a927ca2411ad1ce411ebf53402f55b8fc2f100f5ae573358b481`. It supersedes
  `calendar_sync_reconcile_v3.json` (73 cases, 354,937 bytes, `c0286eb12c51f0e0705f62486f19c4b208394dbe545ba7cca949851a2ae790dc`) and
  `calendar_sync_reconcile_v1.json` (56 cases, 306,129 bytes, `ae918c71958b6ddd74145b94c76924abd12cae43608d77cebe043460612172fb`),
  both left in place unchanged after the core-engine lanes copied them; v4 cases 1–73 are the v3 cases (1–56 the v1 cases), unchanged
  except the one listed in the file's `changedFromV3` (review log, fixture v4). Revision 2 had replaced the earlier 38-case file (`db6a85bd…`) in place before any copy.
- `designs/fixtures/gen_calendar_sync_fixture_v4.py` — the reference planner (the executable form of section 6)
  that generated the fixture. Re-run it to regenerate; it prints the hash. Two regenerations are byte-identical.
  `--v1` and `--v3` reproduce v1 and v3 byte for byte (`plan(inp, version=3)` keeps the three v3 branches for that mode only).
  The v3 generator `gen_calendar_sync_fixture.py` stays in place unchanged. All fixture SHAs: `designs/fixtures/v4.sha256` (v3: `v3.sha256`).
  Checks in the scratchpad (`…/scratchpad/calendar-sync/`): `check_idempotent.py` (apply the ops, re-plan, expect
  zero ops) 0 failures on every synced reconcile case; `check_review_scenarios.py` (the reviewer's multi-step
  probes: keep→re-enable, reinstall with an edited event, 3-step cap churn, read-only re-pick) 0 failures.

---

## 1. Decisions applied (not re-asked)

| Decision | Applied as |
|---|---|
| CALENDAR-17 opt-in create/update/delete, both platforms | Off by default. Settings toggle → disclosure → permission → calendar picker → reconcile. |
| CALENDAR-18 iCloud, Samsung, Google | No provider-specific code. iOS: any EventKit calendar that accepts events (iCloud, local, Google account added to iOS). Android: any CalendarContract calendar with contributor+ access (Google, Samsung, local). The picker names the account; the app never claims a provider brand it can't verify. |
| CALENDAR-19 Apple proceed, iCloud automatic | Implemented with minimal content. No claim of App Store approval. The 5.1.3(ii) risk is recorded (§11), not treated as resolved. |
| Private generic title default | `titleMode = generic` → "Personal reminder". `descriptive` ("Injection day") is opt-in with a warning. Never medication, dose, site, notes or values. |
| Selected writable calendar | Explicit user pick. No silent fallback to `defaultCalendarForNewEvents` / primary calendar. |
| App-owned events only | Ownership proven by a local link plus an exact opaque marker. No title/time matching. The whole calendar is never deleted. |
| Permission-loss handling | Gate state `permissionLost`: no writes, links kept, visible status with Open Settings. |
| Idempotent reconciliation | Pure planner (§6), shared fixture, marker adoption closes crash windows. |
| SCHEDULE-16 explicit-date mode | Planner consumes **persisted occurrences**, not cadence. Interval and explicit-date plans go through one path, and the fixture covers both. |

Out of scope for v1: recurring series (RRULE), reading or writing non-DoseWeek events, calendar → app
back-sync (an event edit never records or changes a dose), background sync while the app is
closed, creating a new calendar, EventKitUI one-off add, direct CalDAV/Google API/OAuth.

## 2. Verified platform facts

### iOS (SDK `iPhoneOS26.5.sdk`, EventKit headers)
- `EKEventStore.h:84` `requestFullAccessToEventsWithCompletion:` (iOS 17+). `:86` write-only variant.
  `EKTypes.h:31-32` `EKAuthorizationStatusFullAccess`, `EKAuthorizationStatusWriteOnly`.
  `:34` `EKAuthorizationStatusAuthorized` is deprecated.
- Write-only lets the app create events but not read them, including events it created itself.
  Listing calendars returns one virtual calendar. So update/delete needs **full access** + `NSCalendarsFullAccessUsageDescription`.
  On iOS 17+, a missing key makes iOS deny the request automatically.
  Sources: https://developer.apple.com/documentation/eventkit/accessing-the-event-store (fetched via the
  `developer.apple.com/tutorials/data/documentation/eventkit/accessing-the-event-store.json` form),
  https://developer.apple.com/documentation/bundleresources/information-property-list/nscalendarsfullaccessusagedescription
  — accessed 2026-09-15.
- `EKEvent.h:48-60` `eventIdentifier` "will likely change" when the calendar changes, and may change after sync.
  If `eventWithIdentifier:` returns nil, the event was deleted. `EKCalendarItem.h:36-41`: item identifiers
  are not sync-proof. `calendarItemExternalIdentifier` can be duplicated.
- `EKEventStore.h:318-331` `predicateForEventsWithStartDate:endDate:calendars:` is capped at a **4-year span**.
- `EKEventStore.h:462-475` `EKEventStoreChangedNotification` also fires when access changes.
- `EKCalendar.h:86` `allowsContentModifications`; `:100` `isImmutable` covers calendar properties, not
  event writes. `:130` `allowedEntityTypes`. `EKSource.h:19-20` `sourceIdentifier`, `sourceType`.
  `EKTypes.h:176-182` `EKSourceType` (`CalDAV` covers both iCloud and other CalDAV → never label a
  calendar "iCloud" from the enum).
- `EKCalendarItem.h:78-84,101` `location`, `notes`, `URL`, `timeZone`, `alarms`. `EKError.h` includes
  `EKErrorCalendarReadOnly`, `EKErrorEventStoreNotAuthorized`, `EKErrorCalendarDoesNotAllowEvents`, `EKErrorEventNotMutable`.
- The iOS repo today has no EventKit and no `NSCalendars*` key (`DoseDay/Resources/Info.plist`).
  `InfoPlist.xcstrings` holds 4 keys × 17 locales.

### Android (SDK `platforms/android-37.0`, `sources/android-37.0/android/provider/CalendarContract.java`)
- `Events` insert requires `dtstart`, `dtend` (non-recurring), `eventTimezone` and `calendar_id` (`:1646-1654`).
  `calendar_id` should not change after insert (`:1690`). App-writable columns include `TITLE, DESCRIPTION, DTSTART, DTEND,
  EVENT_TIMEZONE, ALL_DAY, ACCESS_LEVEL, AVAILABILITY, CUSTOM_APP_PACKAGE, CUSTOM_APP_URI, UID_2445`
  (`:1693-1722`). Sync-adapter only: `DIRTY, MUTATORS, _SYNC_ID, SYNC_DATA1..10` (`:1723-1738`).
- App delete sets `deleted=1` and removes instances; only a sync adapter removes the row (`:1665-1671`).
  → Always query `DELETED = 0`, and never describe a local delete as removed from the server.
- `Calendars.CALENDAR_ACCESS_LEVEL` (`:448`): `CAL_ACCESS_CONTRIBUTOR = 500`, `EDITOR = 600`, `OWNER = 700`,
  `ROOT = 800`. `VISIBLE :479`, `SYNC_EVENTS :493`. `ACCOUNT_TYPE_LOCAL = "LOCAL" :230`.
  `Events.ACCESS_PRIVATE = 2 :1200`. `AVAILABILITY_FREE` (`AVAILABILITY_BUSY = 0 :1221`).
- `Reminders`: `EVENT_ID, MINUTES, METHOD` all required on insert (`:2321`). Only `METHOD_DEFAULT/ALERT` are processed on device.
- Permissions: `READ_CALENDAR` to read, `WRITE_CALENDAR` to insert/update/delete. Source:
  https://developer.android.com/identity/providers/calendar-provider (accessed 2026-09-15).
- Google Calendar's "Share Google Calendar data with other apps" setting (Calendar app → Settings →
  General) controls whether Google calendars are exposed through the Calendar Provider. The page does not state the default.
  https://support.google.com/calendar/answer/16089827?hl=en (accessed 2026-09-15).
- The Android repo today: no calendar permission. `ALLOWED_MANIFEST_PERMISSIONS` is an exact allowlist
  (`scripts/check_invariants.py:74`). DB version 11 (`DoseWeekDatabase.kt:736`). Device-local tables
  `external_sync_state` and `cloud_backup_state` are excluded from backup by `DEVICE_LOCAL_INTEGRATION_FIELDS` (`:1881`).

### Store / policy (accessed 2026-09-15)
- Apple 5.1.3(ii): apps "may not store personal health information in iCloud". 5.1.1(ii): purpose
  strings must "clearly and completely describe your use of the data"; withdrawal must be easy.
  https://developer.apple.com/app-store/review/guidelines/
- Apple "Collect" = "transmitting data off the device in a way that allows you and/or your third-party
  partners to access it for a period longer than … real time". https://developer.apple.com/app-store/app-privacy-details/
- Play Data safety: sharing includes on-device transfer to another app. Exceptions include user-initiated
  actions / prominent disclosure with consent. The data types include "Calendar events" and "Health info".
  https://support.google.com/googleplay/android-developer/answer/10787469
- Play permissions policy: request in context. Calendar is not among the groups with a declaration form
  (SMS/Call Log, All files, Health Connect, …). https://support.google.com/googleplay/android-developer/answer/9888170

## 3. Product behaviour

### 3.1 Event content (both platforms, fixed)
| Field | Value |
|---|---|
| title | `generic` "Personal reminder" (default) / `descriptive` "Injection day", localized at write time |
| start | occurrence `scheduledAt`, floored to whole seconds |
| end | start + 30 min |
| time zone | occurrence `scheduledTimeZone` (iOS `EKEvent.timeZone`; Android `EVENT_TIMEZONE` + `EVENT_END_TIMEZONE`) |
| all-day | false |
| notes / description / location | empty (iOS nil; Android not written) |
| alarms | none (iOS `alarms = nil`; Android no `Reminders` rows, `HAS_ALARM` not written) — see Q3 |
| availability | free (iOS `.free` only if `supportedEventAvailabilities` contains free; Android `AVAILABILITY_FREE`) |
| visibility | Android `ACCESS_LEVEL = ACCESS_PRIVATE`; iOS has no equivalent |
| ownership marker = slot key | `dw1-<planId lowercase>-<scheduled epoch seconds>`. iOS `URL = doseday://calendar-event/<slotKey>`. Android `CUSTOM_APP_PACKAGE = com.wonyoungchoi.doseweek`, `CUSTOM_APP_URI = doseweek://calendar-event/<slotKey>` |

**Why a slot key, not the occurrence UUID.** A plan append regenerates unresolved rows with new UUIDs at
the same instants (AGENTS rule 6 / Android hard rule 11). iOS restore also regenerates future rows through
`BackupRestoreSchedulePlanner.seeds`. An occurrence-UUID key would delete and recreate events on every dose
change, resurrect user-deleted events, and fail to adopt after restore. The slot key stays the same across all of those
(fixture `regenerated_rows_same_instant_noop`, `restore_or_reinstall_adopts_marker_event`). This aligns with
`schedule-explicit-dates.md` §8.3 (plan + instant key). Deviation: no hash and no zone in the key. The key adds nothing
beyond the random plan UUID and the start time the event already shows, and DoseDayCore stays Foundation-only
(no CryptoKit). A zone relabel at the same instant becomes an `update`, not delete+create. Two devices syncing
one iCloud calendar converge on one event per slot. iOS `MainTabView.onOpenURL` (`scheme == "doseday"`)
routes host `calendar-event` to Today only (it never records; hard rule 5).
Android declares no `ACTION_HANDLE_CUSTOM_EVENT` filter in v1.

### 3.2 Which occurrences get events
Unresolved occurrences (`scheduled, due, needsReview`) with `scheduledAt ∈ [now−24h, now+84d)`, sorted by
(instant, id), capped at the **24** earliest. Also excluded: slots inside a verified pack's minimum interval
after the latest administration (the iOS `occurrencesOutsideMinimumInterval` rule, moved into the shared
planner so Android gets the same behaviour). The 24h look-back matches the notification follow-up window.
The 24 cap matches iOS `NotificationService.maxScheduledOccurrences`. Constants are pinned in the fixture.

**Planner input assembly (identical on both platforms; the planner is the only filter).** The adapter reads its own
occurrence rows — it never reuses the notification page (iOS cuts that page to 24 rows *before* the gate,
`ScheduleRefreshCoordinator.swift:301-306` vs `:226`) or `lastLoaded` (Android reads from `Instant.EPOCH`).
- iOS: `modelActor.fetchOccurrences(forPlanID:, in: DateInterval(start: now − 24h, end: now + 84d), limit: 1000,
  includeResolved: false)` (`BoundedClinicalFetching.swift:275`; start inclusive, end exclusive, sorted by instant then id).
- Android: `repository.upcomingOccurrences(planId, from = now − 24h, limit = 1000)` (`DoseWeekRepository.kt:497`;
  `scheduled_at >= from`, unresolved only, ascending; `validateLimit` allows 1..1000). Rows past `now + 84d` may be
  included; the planner drops them.
- Both pass every returned row, the latest administration instant and the verified-pack minimum interval (or no gate).
  If the page is full (1000 rows) and its last row is before `now + 84d`, the input is incomplete: skip the reconcile,
  no writes, `lastFailureCode = inputTruncated` (unreachable for injection cadences; ≥ 11.8 rows/day).
- Why all rows and not 24: tombstones and event-less detached links stay while their slot is **live** (unresolved,
  inside `[now−24h, now+84d)`), even when the cap or the gate keeps the slot out of `desired`. A 24-row input would
  forget them and recreate user-deleted events (review R2/R5).

### 3.3 Settings flow (UX-09: one row, details on demand)
1. Settings → Integrations/Calendar row "Add injection days to calendar" (off).
2. Toggle on → disclosure sheet (§10 keys `disclosure.*`): what is written, the account may sync it to its server
   and to anyone the calendar is shared with, automatic updates, never medication/dose/notes, how to turn off.
   Continue / Cancel.
3. Permission. iOS: `requestFullAccessToEvents()`. Android: `RequestMultiplePermissions(READ_CALENDAR, WRITE_CALENDAR)`.
   Denied → toggle stays off, with a status line and Open Settings.
4. Calendar picker. Only calendars that accept events, grouped by account. Local calendars get the badge "On this
   device only". Android shows a Google-sharing hint when the list is empty or lacks Google accounts.
5. Save state `enabled=true` with the picked calendar → immediate reconcile → status "Up to date · N events".
6. Row detail: title mode, Change calendar, Update now, status, detached/orphan notes, and "Remove leftover events"
   when the orphan count is above 0.
7. Toggle off → dialog: "Turn off and remove upcoming events" (teardownRemoveFuture) / "Turn off and keep
   events" (teardownKeep) / Cancel. Without access, only keep is offered, with the `disable.noPermission` copy.

### 3.4 State machine (persisted `enabled` + derived gate)
```
            toggle on + disclosure ok
  OFF ─────────────────────────────────▶ REQUESTING_ACCESS
   ▲                                        │granted full         │denied/writeOnly
   │                                        ▼                     └──▶ OFF (status permissionDenied)
   │                                  PICKING_CALENDAR ──cancel──▶ OFF
   │                                        │picked writable
   │ teardownKeep / teardownRemoveFuture    ▼
   ├──────────────────────────────────── ENABLED ◀──────────────── access regained / calendar re-picked
   │                                        │ each reconcile → gate:
   │                                        ├─ permissionLost        (access ≠ full)      no writes, links kept
   │                                        ├─ calendarUnavailable   (id/source/account gone) → CTA re-pick
   │                                        ├─ calendarReadOnly      (no longer writable)      → CTA re-pick
   │                                        └─ synced / failed(code) (provider error mid-apply; retry next trigger)
   └── delete-all data: best-effort teardownRemoveFuture, then state removed regardless
```
`permissionRequired` appears only if state says enabled but access was never asked (e.g. an iOS
reinstall without a state file is impossible, but a fixture guards it). Planner status values:
`off, permissionRequired, permissionLost, calendarNotSelected, calendarUnavailable, calendarReadOnly, synced`.
`failed` is adapter-level: the last apply threw. It is persisted as `lastFailureCode` (≤64 chars, no PHI).
`cleanupOrphans` is allowed while OFF (an explicit user action for leftover events); it reports `off` afterwards, never
`synced` (CORE-20260915-04). iOS `restricted` access is `permissionLost` (CORE-20260915-08).

## 4. Module and file ownership

### 4.1 Shared contract
The planner is pure and deterministic. Inputs: mode, now, config, occurrences, links, observed events, optional minimum-interval gate.
Output: status + ordered operations + links after.
Config carries two adapter-built lists that are easy to get wrong:
- `calendars`: descriptors `{id, available, writable}` for the selected calendar **and every `calendarId` referenced by a
  link** (not only the picker list, which hides read-only calendars). A missing descriptor means unavailable.
- `knownAppTitles`: every title text the app can have written — the 34 strings of §10.2 (17 locales × 2 modes), a frozen
  constant in the adapter (`CalendarSyncTitles.all`), not read from the current locale. Renaming a title later means
  **appending** the new text; old texts are never removed. A unit test in each repo pins the list against §10.2.

Operations: `create`, `update`, `delete{reason}`, `forget{reason}`, `relink`, `tombstone`, `detach{eventId}`,
`adopt{eventId, state: active|detached}`. Reasons: `keep, past, eventMissing, userModified, teardown, notDesired,
slotGone, calendarChanged, calendarNotWritable, duplicateMarker, orphan`. Swift and Kotlin are line-for-line ports of
`gen_calendar_sync_fixture_v4.py::plan`. Each repo holds a **byte-identical copy** of the fixture, and its invariant
checker pins the SHA-256 above. Changing behaviour means a new version file (next `…_v5.json`) in both repos in the same wave.

### 4.2 iOS (`/private/tmp/doseweek-v11-20260913/ios`)
| File (new unless noted) | Owns |
|---|---|
| `Packages/DoseDayCore/Sources/DoseDayCore/CalendarSyncPlanner.swift` | Pure planner + value types (`CalendarSyncInput`, `CalendarSyncOperation`, `CalendarSyncLink`, `CalendarSyncStatus`). Foundation only. |
| `Packages/DoseDayCore/Tests/DoseDayCoreTests/CalendarSyncPlannerFixtureTests.swift` | Loads fixture, asserts every case. Add one deliberately failing mutation proof per AGENTS "prove it can fail". |
| `Packages/DoseDayCore/Tests/DoseDayCoreTests/Fixtures/calendar_sync_reconcile_v4.json` + `Package.swift` test target `resources: [.copy("Fixtures")]` (edit) | Shared fixture copy. |
| `DoseDay/Domain/Services/CalendarSyncing.swift` | Framework-free protocol `CalendarEventStoreGateway` + DTOs (`CalendarDescriptor{id, sourceID, title, accountTitle, isLocalOnly, allowsEvents, writable}`, `ObservedCalendarEvent`, `CalendarAccessState`). |
| `DoseDay/Data/Services/EventKitCalendarGateway.swift` | **Only file importing EventKit** (new guard `check_eventkit_is_isolated`). One `EKEventStore` per app session. It requests full access, lists calendars (`calendars(for: .event)` filtered by `allowsContentModifications` and `allowedEntityTypes ∋ .event`), reads `event(withIdentifier:)`, marker search via `predicateForEvents(windowStart: now−24h, end: now+400d, calendars:[selected])` filtered by `URL.scheme == "doseday" && host == "calendar-event"`, writes with `save(_:span:.thisEvent, commit:false)` / `remove(_:span:.thisEvent, commit:false)` then `commit()` per batch of ≤ 25, and maps `EKError`. |
| `DoseDay/Data/Services/CalendarSyncStateStore.swift` | Device-local JSON `Application Support/calendar-sync-state.json` via existing `SensitiveFileStore.replaceProtectedFile` (complete protection, excluded from backup). Add `calendarSyncStateURL` to `SensitiveStoragePolicy` (edit) and to `protectExistingArtifacts` (edit). |
| `DoseDay/Domain/Services/CalendarSyncCoordinator.swift` | `@MainActor`. Loads state, builds planner input, applies ops **in order**, persists links after each create (event id) and at batch end, and publishes `CalendarSyncStatusDTO`. It keeps a single-flight generation like `ScheduleRefreshCoordinator` (cancel old, join, re-plan). |
| `DoseDay/Domain/Services/ScheduleRefreshCoordinator.swift` (edit) | In `performSync`, after `loadSnapshot` succeeds and **before** the notification-permission early returns, call `CalendarSyncCoordinator.reconcile(planID: snapshot.plan.id, latestAdministrationAt: snapshot.latestAdministrationAt, policy:)`. No-plan branch → reconcile with `[]` (future events deleted). Fetch error → skip (same as today). **Do not** pass `snapshot.occurrences` (24-row page, pre-gate). The coordinator does its own §3.2 fetch (limit 1000, `[now−24h, now+84d)`) with the same `syncID` currency checks. |
| `DoseDay/Features/Settings/CalendarSyncSection.swift`, `CalendarPickerSheet.swift`, `CalendarSyncDisclosureSheet.swift` | UI with `GlassCard`/`ThemedRow`, `CappedScaledMetric`, `accessibilityIdentifier("settings.calendarSync.*")`. |
| `DoseDay/Features/Settings/SettingsViewModel.swift` (edit) | Toggle/picker/title/disable intents. `resetAllDataSerialized` → `CalendarSyncCoordinator.teardown(.removeFuture, timeout: 10s)` before the store erase, then delete the state file. |
| `DoseDay/Features/Settings/SettingsView.swift` (edit) | Insert `calendarSyncSection` after `notificationsSection`. |
| `DoseDay/App/DoseDayApp.swift` (edit) | `scenePhase == .active` → `CalendarSyncCoordinator.refreshAccessAndReconcile()` (catches revocation / Calendar-app edits). |
| `DoseDay/Features/Navigation/MainTabView.swift` (edit) | `doseday://calendar-event/*` → Today tab, no action. |
| `DoseDay/Resources/Info.plist` + `InfoPlist.xcstrings` (edit) | `NSCalendarsFullAccessUsageDescription`, 17 locales (§10.3). |
| `DoseDay/Resources/Localizable.xcstrings` (edit) | `calendarSync.*` keys (§10.1). Add `calendarSync.*` to the AGENTS rule 2 namespace list (edit). |
| `scripts/check_invariants.py` (edit) | EventKit isolation; purpose key present in 17 locales; fixture SHA pin; no `notes`/`location`/`addAlarm` writes in the gateway (regex guard); `calendar-sync-state` absent from `BackupPlaintextPayload`. Regenerate the pbxproj with `generate_project.py`. |
| `DoseDayTests/CalendarSyncCoordinatorTests.swift`, `DoseDayUITests/CalendarSyncSettingsUITests.swift` | Fake gateway; UI flow with `-uitest-fake-calendar` hook (DEBUG only). Coordinator test: input is the §3.2 fetch, not the notification page (a 30-slot daily plan with a tombstone on slot 24 keeps it). |
| `DoseDay/Domain/Services/CalendarSyncTitles.swift` | Frozen `all` list (§10.2, 34 texts) for `knownAppTitles`; unit test pins it. |
| `docs/DESIGN_IMPORT.md` (edit) | Line 34 row 3g and "The one deferral: Apple Calendar" (`:127-160`): mark **superseded by owner decision CALENDAR-20260913-19** (opt-in, generic title, user-picked calendar, app-owned events). Keep the 5.1.3(ii) reasoning as the recorded risk; do not delete history. |
| `docs/ROADMAP.md` (edit) | Item 2b (`:463`) "deliberately not built" → built as opt-in calendar sync, link to this design and CALENDAR-19, risk unresolved. |
| `AGENTS.md` (edit) | `:542` "the one thing that was not built (Apple Calendar)" → rewrite; add EventKit isolation + calendar-sync invariants to the rules list. |
| `docs/APP_STORE.md`, `docs/ASC_ANSWER_SHEET.md` (edit) | App Privacy stays `Data Not Collected` (§11.1 interpretation); add a 5.1.3(ii) calendar note next to §5a (`APP_STORE.md:1418`) and the Review Notes candidate. `ASC_ANSWER_SHEET.md:50` add the calendar-access row. |
| `docs/MARKET_COMPLIANCE.md`, `docs/ANDROID_PARITY_NOTES.md`, `docs/ARCHITECTURE.md`, `docs/CURRENT_HANDOFF.md` (edit) | Compliance note (`:225`), shared invariants (slot key, detach/tombstone, no back-sync), module map, handoff per MAINTAINABILITY-20260913-15. |

### 4.3 Android (`/private/tmp/doseweek-v11-20260913/android`, package root `com/wonyoungchoi/doseweek`)
| File (new unless noted) | Owns |
|---|---|
| `domain/CalendarSyncPlanner.kt` | Pure Kotlin port (java.time only). |
| `app/src/test/java/com/wonyoungchoi/doseweek/domain/CalendarSyncPlannerFixtureTest.kt` + `app/src/test/resources/calendar_sync_reconcile_v4.json` (new resources dir) | Fixture copy + JVM test. **JSON reader: `com.wonyoungchoi.doseweek.data.drive.DriveJson`** (`data/drive/DriveJson.kt`). Verified JVM-pure: imports only `java.nio.*`; its KDoc states `org.json` is a stub on the JVM test classpath; already unit-tested (`DriveJsonTest.kt`). It is `internal` in the same `app` module, so test sources can use it. Limits fit: `MAX_INPUT_BYTES` 1 MiB (fixture 306 KB), `MAX_DEPTH` 32 (fixture 7), duplicate keys rejected (the generator cannot emit them). Numbers are raw lexemes → `raw.toLong()` / `toDouble()`; booleans via `when (v) { is JsonValue.Bool -> … }`. Load with `javaClass.classLoader!!.getResourceAsStream("calendar_sync_reconcile_v1.json")!!.readBytes()` → `DriveJson.parse(bytes)`. No new test dependency. |
| `data/calendar/CalendarGateway.kt` | Interface + DTOs (framework-free). |
| `data/calendar/CalendarProviderGateway.kt` | **Only file naming `CalendarContract`** (new guard). Calendars query `CALENDAR_ACCESS_LEVEL >= CAL_ACCESS_CONTRIBUTOR AND VISIBLE = 1 AND SYNC_EVENTS = 1`. Event read by `_ID` with `DELETED = 0`. Marker search `CUSTOM_APP_PACKAGE = ? AND CALENDAR_ID = ? AND DELETED = 0 AND DTSTART >= ?` (never reads foreign rows). Writes through `applyBatch` of `ContentProviderOperation` (≤ 25), never with `CALLER_IS_SYNCADAPTER`. `SecurityException` → permissionLost. |
| `data/calendar/CalendarSyncService.kt` | Orchestrates on `Dispatchers.IO`: permission check (`ContextCompat.checkSelfPermission` both), gate, planner, apply, persist through repository. Single-flight `Mutex`. |
| `data/DoseWeekDatabase.kt` (edit) | `DATABASE_VERSION = 12`, `createVersionTwelveTables` (§5.2) in `onCreate` and `onUpgrade (oldVersion < 12)`. |
| `data/DoseWeekRepository.kt` (edit) | `calendarSyncState()`, `saveCalendarSyncState()`, `calendarSyncLinks()`, `applyCalendarSyncLinks(after)` (one transaction). `deleteAllData` also deletes both tables. `deleteAllTables` (restore) must **not** touch them. |
| `app/CalendarPermissionAccess.kt` | Activity-result permission request, like `ReminderNotificationAccess.kt`. |
| `app/DoseWeekViewModel.kt` (edit) | `syncCalendar()` next to every `syncReminders()` call (lines ~991, 997, 2713, 2734, 3226) **but independent of the reminders-off early return**. `resetAllData` runs teardown before `deleteAllDataOperation()`. Foreground: in `onForegrounded()` (`:522`, called from `MainActivity.onStart` `:284`) call `refreshCalendarAccessAndSync()` **right after `refreshReminderSystemAccess()` and before `if (activePlan == null) return`** (`:535`), so record-only users also get revocation and calendar-edit checks. The existing `exclusivePersistenceOperation` early return at the top stays (reset/restore own the store). `syncCalendar()` never reads `lastLoaded`; `CalendarSyncService` reads plan + §3.2 occurrences through the repository on IO. |
| `features/integrations/CalendarSyncSheet.kt`, `features/integrations/CalendarPickerSheet.kt`; `features/settings/SettingsScreen.kt` (edit) | UI in the existing integrations section. |
| `AndroidManifest.xml` (edit) | §11.2 permissions + comment. |
| `res/values*/strings.xml` (17 dirs, edit) | `calendar_sync_*` keys. `settings_integrations_body` currently says "두 연동" → rewrite for three. |
| `scripts/check_invariants.py` (edit) | Add the two permissions to `ALLOWED_MANIFEST_PERMISSIONS`. Add `"calendarSync"`, `"calendar_sync"` to `DEVICE_LOCAL_INTEGRATION_FIELDS`. `CalendarContract` isolation; fixture SHA pin; forbid `CALLER_IS_SYNCADAPTER`, `Reminders.CONTENT_URI`, `DESCRIPTION`, `EVENT_LOCATION` writes. |
| `docs/legal/android-content.json` → `scripts/generate_privacy_strings.py` (edit/regenerate) | Privacy text (§11). |
| `domain/CalendarSyncTitles.kt` | Frozen 34-text list (§10.2) for `knownAppTitles`; JVM test pins it. |
| `docs/PLAY_STORE.md` (edit) | Canonical Play answers (Android AGENTS: "canonical Play answers stay here"). "Data safety" (`:370-380`) says "Data shared: **No**" → record the Q5 answer (Calendar events → Shared, optional, App functionality; Health info too if descriptive titles ship) and the date. |
| `docs/PLAY_CONSOLE_ANSWER_SHEET.md`, `docs/MARKET_COMPLIANCE.md` (edit) | `:287` "no data collected/no data shared" checklist → re-open item for the calendar release; compliance note (`:186` section) for READ/WRITE_CALENDAR. |
| `AGENTS.md`, `docs/ARCHITECTURE.md`, `docs/CURRENT_HANDOFF.md`, `docs/ROADMAP.md` (edit) | Three integrations wording, CalendarContract isolation rule, module map, handoff per MAINTAINABILITY-20260913-15. |
| `app/src/androidTest/.../CalendarProviderGatewayTest.kt` | API 24 + 36 emulator: local calendar created as a **test-only sync adapter** row in `ACCOUNT_TYPE_LOCAL`, CRUD, `DELETED` filter, marker search, permission revoke. |

Not added: WorkManager job, ContentObserver while backgrounded, boot-receiver calendar work (events persist on their own).

## 5. Data model, migration, backup

### 5.1 Link record (both platforms)
| field | type | notes |
|---|---|---|
| slotKey | `dw1-<planId>-<epochSeconds>` (≤ 56 chars) | primary key and external marker. **No FK**: must outlive deleted/regenerated occurrences so their events can be removed |
| calendarId | iOS `calendarIdentifier` / Android `Calendars._ID` as string | |
| eventId | iOS `eventIdentifier` / Android `Events._ID` string, nullable | null while tombstoned or before the create commits |
| state | `active` \| `detached` \| `tombstoned` | |
| writtenStart, writtenEnd | UTC instant, whole seconds | baseline for user-edit detection |
| writtenTitle | string | localized text actually written |
| writtenTimeZone | IANA id | update trigger only (EventKit may normalize, so it is not used for edit detection) |

Retention: `active` links are dropped by both teardown modes. `detached` and `tombstoned` links record a user decision
and **survive teardownKeep and teardownRemoveFuture** (stored while sync is off), so turning sync on again never
overwrites a user-edited event or recreates a user-deleted one. They are forgotten only by reconcile (`slotGone`: slot
resolved, older than the look-back, or belonging to a replaced plan; detached also requires its event gone or past)
or by delete-all-data. Bounded: at most one link per live slot plus future detached events. PHI-free (slot key, times, title text).
Not recoverable after uninstall/reinstall: the state goes with the app, so a slot the user deleted may be created again
after reinstall (edited events are still protected by adopt-as-detached, §6 step 4).

### 5.2 Settings record
`enabled`, `calendarId`, `calendarSourceId` (iOS `source.sourceIdentifier`) or `accountName`+`accountType`
(Android; id reuse after re-adding an account → mismatch → `calendarUnavailable`), `calendarTitleSnapshot`
(for the "removed from %@" copy), `titleMode`, `lastStatus`, `lastSuccessAt`, `lastFailureCode`, `schemaVersion = 1`.
`userEditPolicy` is a product constant (`detach`, Q1) and is not stored.

- **iOS**: one protected JSON file, no SwiftData schema change. This avoids colliding with the parallel
  explicit-dates `DoseDaySchemaV6` (repo head `DoseDaySchemaV5`, `DoseDaySchema.swift:418-426`), stays out of `createBackupPayload` (store-only), and survives no device backup
  (excluded + complete protection). **Not** `AppPreferences`/UserDefaults: those are restored by iCloud device backup and
  would silently re-enable sync on a new phone. That breaks the parity rule "restoring must never re-enable
  an integration". A missing or corrupt file means sync is off.
- **Android**: next free DB version (written "v12" below; `feat/history-import` already sets
  `DATABASE_VERSION = 12`, and `schedule-explicit-dates.md` also plans 12, so take the next free number at merge and never share one).
  Additive, lightweight migration:
```sql
CREATE TABLE calendar_sync_state (
  id INTEGER NOT NULL PRIMARY KEY CHECK (id = 1),
  enabled INTEGER NOT NULL CHECK (enabled IN (0,1)),
  calendar_id INTEGER, account_name TEXT, account_type TEXT,
  calendar_title_snapshot TEXT CHECK (calendar_title_snapshot IS NULL OR length(calendar_title_snapshot) <= 256),
  title_mode TEXT NOT NULL DEFAULT 'GENERIC' CHECK (title_mode IN ('GENERIC','DESCRIPTIVE')),
  last_status TEXT CHECK (last_status IS NULL OR length(last_status) <= 32),
  last_success_at INTEGER, last_failure TEXT CHECK (last_failure IS NULL OR length(last_failure) <= 64));
CREATE TABLE calendar_sync_link (
  slot_key TEXT NOT NULL PRIMARY KEY CHECK (length(slot_key) BETWEEN 42 AND 56 AND slot_key GLOB 'dw1-*'),
  calendar_id INTEGER NOT NULL,
  event_id INTEGER,
  state TEXT NOT NULL CHECK (state IN ('ACTIVE','DETACHED','TOMBSTONED')),
  written_start INTEGER NOT NULL, written_end INTEGER NOT NULL,
  written_title TEXT NOT NULL CHECK (length(written_title) <= 256),
  written_time_zone TEXT NOT NULL,
  CHECK ((state = 'TOMBSTONED' AND event_id IS NULL) OR state != 'TOMBSTONED'));
```
  Migration test: v11 fixture DB → v12 has both tables empty and identical to `onCreate` (existing pattern).
  Rollback: there is no downgrade (`onDowngrade` throws). A release that must revert ships v13 dropping nothing.
- **Backup payloads**: no calendar field on either platform. Use whatever version is current at merge (the
  explicit-dates design reports iOS 7 / Android 8, with 9 planned). Calendar sync adds nothing and bumps nothing. Guards prove absence.
  Restore keeps device-local calendar state. The next reconcile deletes unmodified future events whose slots vanished,
  keeps detached/tombstoned decisions for slots that are still live, and adopts marker events for desired slots
  (active only if untouched, otherwise detached; §6 step 4).

## 6. Reconciliation algorithm (normative; `gen_calendar_sync_fixture_v4.py::plan`)

Constants: `HORIZON=84d, MAX=24, LOOKBACK=24h, DURATION=30min`. Instants floor to whole seconds.
Slot key (= marker) = `dw1-` + lowercase `planId` + `-` + scheduled epoch seconds. The occurrence input carries
`id, planId, scheduledAt, timeZone, status` (`sourceMode` is informational). Sorting uses ordinal string order. An empty `eventId` or `markerKey` counts as absent everywhere: lookup, marker matching, ownership, orphans and cleanup (v3 cases `empty_*`).
Links and teardown ops are processed in slotKey order.

**Modes**: `reconcile`, `teardownRemoveFuture`, `teardownKeep`, `cleanupOrphans`.

**0 Gate** (not for teardownKeep). `reconcile ∧ ¬enabled → off`. `access = notDetermined → permissionRequired`.
Any other non-`full` → `permissionLost` (includes iOS `writeOnly`, `denied`, `restricted`; CORE-20260915-08: `restricted`
exists only on iOS, `EKAuthorizationStatus.restricted`, and Android has no such state — fixture `gate_ios_restricted_is_lost`).
teardownRemoveFuture stops gating here. `selectedCalendarId = nil → calendarNotSelected`. Calendar missing or
unavailable → `calendarUnavailable`. Not writable → `calendarReadOnly`. A gated result has no ops and links unchanged.

**teardownKeep**: `forget(keep)` for every active link. Detached and tombstoned links retained (§5.1). Status off with
counts of the retained links. No provider access needed.

**teardownRemoveFuture**, per link sorted by slotKey:
- non-active → no op, retained
- link's calendar descriptor missing, unavailable or not writable → `forget(calendarNotWritable)` (UI counts it in
  `disable.partial`)
- event by id, else first marker match in the link's calendar
- missing → `forget(eventMissing)`
- modified → `forget(userModified)`
- start < now → `forget(past)`
- else → `delete(teardown)`

Links → retained detached/tombstoned only. Status off with their counts.

**cleanupOrphans** (user-confirmed only): delete every observed event in the selected calendar with a marker,
start ≥ now, whose eventId is in no link and whose marker belongs to no active/detached link. It is an explicit user
action and runs while `enabled` is false too (the gate above still applies); its status is then `off`, never `synced`
(CORE-20260915-04; fixtures `cleanup_orphans_while_disabled_*`). Because a user-edited event keeps its detached link
(CORE-20260915-03), cleanup never deletes it (`cleanup_orphans_keeps_detached_edited_event`). That guarantee is carried
by the retained link only: cleanup has no title or time heuristic, so an unlinked marker event (link state lost by a
reinstall or delete-all before any reconcile adopted it) is an orphan whether or not the user edited it, and a confirmed
cleanup deletes it when its start is in the future (§8 "Cleanup copy must say edited events may be included"; review
log, fixture v4 "still not pinned"). A reconcile before the cleanup adopts such an event as detached only while its
slot is desired (step 4; `reinstall_adopts_*_as_detached`), after which cleanup keeps it; an edited unlinked marker
whose slot is not desired stays a user-confirmable orphan.

**reconcile**:
1. `live` = slot keys of occurrences with unresolved status and `now−24h ≤ t < now+84d` (no gate, no cap).
   `desired` = those rows with `t ≥ latestAdministration + minimumIntervalHours` when the gate is provided with finite positive hours (any other value, such as 0 or negative, plans as if no gate were given; the dose instant is floored to whole seconds and trunc(hours × 3,600,000) ms are added; a slot at that instant is desired); sort (t, id);
   keep the first row per slot key; take 24.
2. `modified(link, ev)` = start ≠ writtenStart ∨ end ≠ writtenEnd ∨ title ≠ writtenTitle ∨ ev.calendar ≠ link.calendar.
3. Per link (sorted by slotKey):
   - **tombstoned**: slot not live → `forget(slotGone)`. Live and an unused marker event for the key exists in the
     selected calendar (user undid the delete) → `detach{eventId}`, baseline := observed. Otherwise keep (never recreate,
     including while the slot is outside the cap or gated).
   - **detached**: slot not live ∧ (event missing ∨ ended, `end ≤ now`) → `forget(slotGone)`; else keep (never touch). An event in
     progress keeps the link (CORE-20260915-03: until its end time passes; v3 judged by `start < now`).
   - **active, link.calendar ≠ selected**: old calendar not writable/unavailable/missing → `forget(calendarNotWritable)`;
     event found ∧ ¬modified ∧ future → `delete(calendarChanged)`; else `forget(calendarChanged)`.
   - **active**: event by id; else first marker match in selected → `relink`.
     - missing: not desired → `forget(eventMissing)`; policy detach → `tombstone`; policy restore → `create`.
     - found, not desired: modified ∧ (detach ∨ moved) → `detach` while `end > now` (link kept detached, baseline unchanged; CORE-20260915-03),
       else `forget(userModified)`; unmodified: future (`start ≥ now`) → `delete(notDesired)`; past → `forget(past)`.
     - found, desired: modified ∧ (detach ∨ moved) → `detach`; restore-policy modified → baseline := observed.
       Then `update` iff written ≠ desired (start, end, title, tz).
4. Each desired slot without a link, in (t, id) order: an unused marker event in the selected calendar → adopt with
   baseline := observed. There is no stored baseline (reinstall, state loss), so compare with what the app could have
   written for this key: `untouched` = start = key instant ∧ end = start + 30 min ∧ title ∈ `knownAppTitles` ∪ {current title}.
   - untouched, or policy restore → `adopt{state: active}` + `update` if it differs (title/zone).
   - otherwise → `adopt{state: detached}`: never written, counted in `detachedCount`.
   No marker event → `create`.
5. Every other selected-calendar marker event not used and not deleted: key held by a non-tombstoned link ∧ future →
   `delete(duplicateMarker)`; else future → counts toward `orphanFutureCount` (never auto-deleted). A tombstone holds no
   key, so a marker event for a tombstoned key is never auto-deleted.
6. Status `synced` with `managedCount` (active, including pending creates), `detachedCount`, `tombstonedCount`, `orphanFutureCount`.

**Apply rules (adapters)**:
- Execute ops in order.
- `create` → persist link with eventId immediately after the provider commit succeeds. A crash between the two
  is healed next run by `adopt`, a double create by `duplicateMarker`.
- Error classes per op:
  - **Gone** (iOS `event(withIdentifier:)` nil before `remove`; Android `delete`/`update` returns 0 rows): `delete` counts
    as done (forget link). `update` → stop, re-plan next trigger (it becomes tombstone/relink).
  - **Permanent for this event/calendar** (iOS `EKErrorCalendarReadOnly`, `EKErrorEventNotMutable`,
    `EKErrorCalendarIsImmutable`, `EKErrorCalendarDoesNotAllowEvents`, all in `EKError.h` of iPhoneOS26.5 SDK): skip that
    op, forget its link (delete/update) or leave it unlinked (create), add it to `notRemovedCount`, **continue the batch**.
    Android has no such typed error, so after any non-`SecurityException` failure the service re-reads the calendar
    descriptors and re-plans once in the same run; the planner then emits `forget(calendarNotWritable)` instead of the
    failing op (fixtures `selected_calendar_changed_old_read_only`, `teardown_remove_future_read_only_calendar`).
  - **Transient / unknown** (commit failure, I/O, `EKErrorInternalFailure`): stop the batch. Links for ops that succeeded
    are persisted, the rest stay as before (status `failed`), next trigger re-plans.
  - **Access** (`EKErrorEventStoreNotAuthorized`, `SecurityException`): stop, status `permissionLost`.
  A re-plan never repeats a failing delete in a calendar that is now read-only, because the planner checks the
  descriptor of every link's calendar. The DB fact write and the calendar write are **never** described as atomic.
- iOS: `commit:false` per op and `commit()` per ≤ 25. If commit throws, reset the store (`EKEventStore.reset`) and
  treat the whole batch as failed. Re-plan detects partial success through markers.
- Android: `applyBatch`. On `OperationApplicationException`, fall back to single ops so partial results are known.
- `delete` never targets an eventId that is not in a link or does not carry our marker (adapter asserts it).

## 7. Triggers and concurrency
- iOS: every `ScheduleRefreshCoordinator.sync` (record/skip/edit/restore/reset/plan creation/launch/settings),
  scene `.active`, toggle/picker/title change, "Update now". Android: the same set via `syncCalendar()` plus
  `onForegrounded()` (before its no-active-plan return; §4.3). Note: iOS `performSync` runs for record-only users
  too (no-plan branch reconciles with `[]`); iOS scene `.active` also calls `refreshAccessAndReconcile()` directly.
- Optional iOS enhancement: observe `EKEventStoreChangedNotification` only while active, 2s debounce. The
  planner's idempotency makes the app's own commits no-ops.
- No background execution. Copy never promises instant updates while the app is closed.
- Store session retirement (iOS `retireCurrentSession`) cancels the in-flight reconcile. Reset/restore paths join it
  before erasing (the same pattern as the notification generation).

## 8. Lifecycle and edge cases

| Situation | Behaviour |
|---|---|
| First enable | Creates up to 24 events (fixture `interval_initial_create`, `explicit_dates_initial_create`, `interval_cap_24_events`). |
| Record dose / skip / edit | Slot resolves → future event deleted, past event left; a new re-anchored slot is created (`plan_change_moves_future_slots`, `resolved_past_event_kept`). |
| Early dose inside minimum interval (verified pack) | Suppressed slot's event deleted (`minimum_interval_gate_suppresses_slot`). |
| Minimum-interval hours unusable (0, negative, NaN, infinite) | No gate, same plan as without one (`minimum_interval_gate_zero_hours_is_no_gate`, `minimum_interval_gate_negative_hours_is_no_gate`); both planners guard it. |
| Plan change / titration / cadence or explicit-date edit | Rows regenerated at the same instants keep their slot key → no-op (`regenerated_rows_same_instant_noop`). Changed instants → delete old future + create new. |
| Two unresolved rows at one plan+instant (transient) | One event (`duplicate_slot_rows_one_event`). |
| Interval ↔ explicit-date mode switch | No special case: occurrence rows only. |
| Horizon roll | Each foreground sync extends the window; cap churn deletes the 25th-slot app event when an earlier slot appears (accepted). User decisions survive churn (`tombstone_kept_when_slot_pushed_past_cap`, `tombstone_kept_when_slot_returns_to_cap`, `detached_event_deleted_kept_through_cap_churn`, `tombstone_kept_while_minimum_interval_gated`). |
| User moves/renames event in calendar app | Detached, never overwritten; still deleted? **No**, left forever (`user_moved_event_detach`, `user_retitled_event_detach`). If the edit is only noticed once the slot has resolved, the link is still detached while the event has not ended (`user_edited_future_event_slot_resolved_detached`, `user_edited_event_in_progress_slot_resolved_detached`); the detached link is forgotten once the event ends (`detached_link_forgotten_once_event_ended`), so the event is never an orphan and cleanup never deletes it (`cleanup_orphans_keeps_detached_edited_event`; CORE-20260915-03). |
| User moves event to another calendar | **Best effort.** iOS: `EKEvent.h` says the id "will likely change" when the calendar changes, and marker search covers only the selected calendar → expected result **tombstone** (`user_moved_event_to_other_calendar_id_changed`); the moved event is left alone. Only if the provider keeps the id → detached (`user_moved_event_to_other_calendar`). Android: `CalendarContract.java:1688-1690` "a calendar_id should not be modified after insertion", many sync adapters misbehave; outcome depends on the calendar app, device-verify. |
| User deletes event | Tombstoned, not recreated for that slot while the slot is live, also across cap churn, gating and turn off/on (`user_deleted_event_tombstone`, `reenable_after_keep_user_deleted`). Forgotten when the slot resolves, passes the look-back, or the plan is replaced (`tombstone_forgotten_*`). User undoes the delete → detached (`tombstoned_event_restored_by_user_detaches`). |
| Turn off with keep, then on again | Unmodified events re-adopted active; user-edited events stay detached; user-deleted slots stay tombstoned (`reenable_after_keep_user_edited`, `reenable_after_keep_user_deleted`). |
| Event id changed by provider sync | Relink by marker (`event_identifier_changed_relink_by_marker`). |
| Reinstall + backup restore (plan id restored; row ids may be regenerated) | Adopt by slot-key marker. Untouched event (app time, app title in any locale) → active, then title/zone update if needed (`restore_or_reinstall_adopts_marker_event`, `reinstall_adopts_other_locale_title_as_active`). Moved, re-timed or renamed event → detached, never written (`reinstall_adopts_user_edited_event_as_detached`, `reinstall_adopts_retimed_only_event_as_detached`). A slot the user deleted before uninstall has no record left and is created again (accepted limit, §13). Sync itself is off after reinstall until the user re-enables. |
| Reinstall without restore / delete-all then re-enable | Old events are orphans. Status shows count + "Remove leftover events" (`orphan_marker_events_counted_not_deleted`, `cleanup_orphans_user_confirmed`). Cleanup copy must say edited events may be included. |
| Two devices, one iCloud/Google calendar | Same markers → adopt, not duplicate. Concurrent create race → `duplicateMarker` delete. |
| Change calendar in app | Old future unmodified events deleted, new calendar populated (`selected_calendar_changed`). Old calendar now read-only or gone → old links forgotten, events left, `changeCalendar.oldReadOnly` note, new calendar still populated (`selected_calendar_changed_old_read_only`, `selected_calendar_changed_old_unavailable`). |
| Turn off | User picks remove-future or keep (`teardown_remove_future`, `teardown_keep_events`). Detached/tombstoned links retained. Link calendar read-only → not removed, counted (`teardown_remove_future_read_only_calendar`). Without access, keep only (`teardown_without_permission`). |
| Delete all data | Best-effort teardownRemoveFuture (10s budget), then state/links deleted regardless. The result dialog reports N not removed. Reset copy states copies on servers/shared calendars follow the provider. |
| Uninstall | App cannot act. Events remain (privacy/support copy says so). iOS state file and Android DB go with the app. |
| Backup restore (same device) | Integration state kept, events reconciled to restored occurrences. Restore never turns sync on. |
| Permission revoked (Settings / Android auto-reset of unused app permissions / process kill) | `permissionLost`, links kept. Regrant resumes without duplicates (`gate_permission_revoked_keeps_links`). |
| iOS downgraded to write-only by user | `permissionLost` (`gate_ios_write_only_is_insufficient`). |
| Account removed / calendar deleted / Google sharing switched off | `calendarUnavailable` → re-pick. Links kept until re-pick (the re-pick runs the calendarChanged path; old events are gone → forget). No fallback. |
| Calendar becomes read-only (shared calendar downgraded) | `calendarReadOnly` → re-pick. The re-pick cannot stall on deletes in the old calendar (`calendarNotWritable` forget, §6 apply rules). |
| Android id reuse after account re-add | account name/type mismatch → `calendarUnavailable`. |
| Time zone travel (floating plan) | Rows regenerate at new instants → old future deleted, new created (`floating_travel_moves_event`). Same instant with a new zone id → `update` (`zone_relabel_same_instant_updates`). The event carries an explicit zone, so it displays correctly anywhere. |
| DST gap/overlap | Instants come from the stored occurrence (already resolved by the engines). End = +30 min absolute. |
| Sub-second store instants | Floored (`subsecond_instant_normalized_noop`). |
| Foreign event at same time/title | Never touched (`foreign_event_never_touched`). |
| Title mode change | Active events updated, detached left (`title_mode_change_updates_active_only`). |
| Locale change | Next reconcile sees writtenTitle ≠ newly localized title → update active events (same mechanism). |
| Record-only / no active plan | No occurrences → future events deleted, past forgotten. |
| App lock on | Reconcile needs no UI and runs anyway (the store is already unlocked in foreground). The calendar shows only the generic title. |
| Duplicate reminders | v1 writes no event alarms, so the app notifications remain the only reminders (Q3). A provider default alert may still apply → device verification. |

## 9. Tests

- **Shared fixture**: both planners pass all 84 cases of `calendar_sync_reconcile_v4.json`, and each repo's invariant pins its SHA-256 (`e4b0c5df…b481`). Tests pin `now` from the fixture.
  Port `check_idempotent.py` as a second loop in each fixture test (apply ops with a perfect fake, re-plan, expect zero ops).
  Production uses the injected `Clock` (Android) / `Date.now` via the coordinator's clock seam (iOS).
- **Unit (fake gateway)**: input assembly (the §3.2 fetch, not the notification page / `lastLoaded`), permanent-error
  skip continues the batch (fake throws read-only on one delete, later creates still run), Android re-plan after a
  failure re-reads descriptors, Android `onForegrounded` with no active plan still refreshes calendar access,
  `CalendarSyncTitles` list equals §10.2, teardown keeps detached/tombstoned rows in storage,
  apply ordering, partial-failure persistence, crash-after-create (fake throws before
  link save → next run adopts), single-flight cancellation, reset teardown timeout, iOS state-file corrupt → off,
  Android v11→v12 migration, restore keeps state, `deleteAllData` clears it, backup payload has no calendar field.
- **Instrumentation (Android API 24, 36)**: gateway CRUD against a test-owned local calendar, `DELETED=0`
  filter, marker search, `SecurityException` mapping after `pm revoke`.
- **iOS app unit** (`run_app_unit_tests.sh DoseDayTests/CalendarSyncCoordinatorTests`). UI (`CalendarSyncSettingsUITests`
  standard + `--ax5` + iPad) with the fake gateway.
- **Owner/physical-device verification (not simulable; never claim PASS from fakes)**:
  - iCloud calendar on 2 Apple devices (marker URL survives sync, id changes)
  - Google account on iOS
  - Google Calendar + Samsung Calendar on a Galaxy
  - Google sharing setting off
  - `customAppPackage/customAppUri` survival after Google/Samsung server round trip and after "clear calendar storage"
  - default-alert behaviour for events with no alarms
  - account removal

## 10. Localization

17 locales: ko, en, ja, de, fr, es, it, nl, pt-PT, pl, sv, hi, pt-BR, ar, zh-Hans, zh-Hant, tr.
Android directories: `values` (ko), `values-en`, `-ja`, `-de`, `-fr`, `-es`, `-it`, `-nl`, `-pt-rPT`, `-pl`, `-sv`, `-hi`,
`-pt-rBR`, `-ar`, `-zh-rCN`, `-zh-rTW`, `-tr`. Keep placeholders identical. Plurals use `%lld` (iOS variations)
and `<plurals>` (Android). Translators produce the remaining 15 locales for §10.1 through the repos' existing
localization scripts. §10.2 and §10.3 are provided here in all 17.

### 10.1 UI keys (iOS `calendarSync.*` / Android `calendar_sync_*`)
| iOS key | Android key | en | ko |
|---|---|---|---|
| calendarSync.header | calendar_sync_header | Calendar | 캘린더 |
| calendarSync.toggle | calendar_sync_toggle | Add injection days to calendar | 주사 예정일을 캘린더에 추가 |
| calendarSync.footer | calendar_sync_footer | Off by default. DoseWeek adds, updates and removes only its own events in the calendar you choose. Your records stay in DoseWeek. | 기본값은 꺼짐입니다. 선택한 캘린더에서 DoseWeek가 만든 일정만 추가·수정·삭제합니다. 기록은 DoseWeek에만 남습니다. |
| calendarSync.disclosure.title | calendar_sync_disclosure_title | Before you turn on calendar sync | 캘린더 연동을 켜기 전에 |
| calendarSync.disclosure.body | calendar_sync_disclosure_body | DoseWeek will write a 30-minute event for each upcoming injection day (up to 24, about 12 weeks ahead) with only a title and time. Medication, dose, site and notes are never written. It updates or removes those events automatically when your schedule changes. If the calendar belongs to an account such as iCloud, Google or Samsung, that provider stores and syncs the events, including to people the calendar is shared with. | 다가오는 주사 예정일마다 제목과 시간만 담은 30분 일정을 최대 24개(약 12주)까지 기록합니다. 약 이름·용량·부위·메모는 쓰지 않습니다. 일정이 바뀌면 해당 일정을 자동으로 수정하거나 삭제합니다. iCloud·Google·삼성 같은 계정 캘린더라면 그 제공자가 일정을 저장·동기화하며, 캘린더를 공유한 사람에게도 보일 수 있습니다. |
| calendarSync.disclosure.continue | calendar_sync_disclosure_continue | Continue | 계속 |
| calendarSync.permission.rationale | calendar_sync_permission_rationale | Calendar access is used to list calendars you can write to and to find, update and remove DoseWeek's own events. Other events are never changed. | 캘린더 권한은 쓸 수 있는 캘린더 목록을 보여 주고 DoseWeek가 만든 일정을 찾아 수정·삭제하는 데만 사용합니다. 다른 일정은 바꾸지 않습니다. |
| calendarSync.picker.title | calendar_sync_picker_title | Choose a calendar | 캘린더 선택 |
| calendarSync.picker.footer | calendar_sync_picker_footer | Only calendars that accept new events are shown. | 새 일정을 추가할 수 있는 캘린더만 표시됩니다. |
| calendarSync.picker.localOnly | calendar_sync_picker_local_only | On this device only | 이 기기에만 저장 |
| calendarSync.picker.empty | calendar_sync_picker_empty | No calendar that accepts new events was found. | 새 일정을 추가할 수 있는 캘린더가 없습니다. |
| — (Android only) | calendar_sync_picker_google_hint | Google calendars missing? In Google Calendar, open Settings › General and allow sharing calendar data with other apps. | Google 캘린더가 보이지 않나요? Google 캘린더 앱의 설정 › 일반에서 다른 앱과 캘린더 데이터 공유를 켜세요. |
| calendarSync.titleMode.header | calendar_sync_title_mode_header | Event title | 일정 제목 |
| calendarSync.titleMode.generic | calendar_sync_title_mode_generic | Private (“%@”) | 비공개 (“%@”) |
| calendarSync.titleMode.descriptive | calendar_sync_title_mode_descriptive | Descriptive (“%@”) | 설명형 (“%@”) |
| calendarSync.titleMode.warning | calendar_sync_title_mode_warning | Anyone who can see this calendar can see this title. | 이 캘린더를 볼 수 있는 사람은 제목도 볼 수 있습니다. |
| calendarSync.event.title.generic | calendar_sync_event_title_generic | Personal reminder | 개인 알림 |
| calendarSync.event.title.descriptive | calendar_sync_event_title_descriptive | Injection day | 주사 예정일 |
| calendarSync.status.synced | calendar_sync_status_synced (plurals) | Up to date · %lld events | 최신 상태 · 일정 %lld개 |
| calendarSync.status.permissionLost | calendar_sync_status_permission_lost | Calendar access is off. DoseWeek can't update or remove its events until you allow full access. | 캘린더 권한이 꺼져 있어 DoseWeek 일정을 수정하거나 삭제할 수 없습니다. 전체 접근을 허용해 주세요. |
| calendarSync.status.calendarUnavailable | calendar_sync_status_calendar_unavailable | The chosen calendar is no longer available. Choose another calendar. | 선택한 캘린더를 더 이상 사용할 수 없습니다. 다른 캘린더를 선택하세요. |
| calendarSync.status.calendarReadOnly | calendar_sync_status_calendar_read_only | The chosen calendar no longer accepts new events. Choose another calendar. | 선택한 캘린더에 더 이상 일정을 추가할 수 없습니다. 다른 캘린더를 선택하세요. |
| calendarSync.status.failed | calendar_sync_status_failed | The last update didn't finish. DoseWeek will try again when you next open the app. | 마지막 업데이트를 마치지 못했습니다. 다음에 앱을 열 때 다시 시도합니다. |
| calendarSync.status.userChanged | calendar_sync_status_user_changed (plurals) | %lld events you changed or deleted in your calendar app are left as they are. | 캘린더 앱에서 바꾸거나 삭제한 일정 %lld개는 그대로 둡니다. |
| calendarSync.status.orphans | calendar_sync_status_orphans (plurals) | %lld earlier DoseWeek events have no matching schedule. | 일정과 연결되지 않은 이전 DoseWeek 일정이 %lld개 있습니다. |
| calendarSync.action.removeOrphans | calendar_sync_action_remove_orphans | Remove leftover events | 남은 일정 삭제 |
| calendarSync.removeOrphans.confirm | calendar_sync_remove_orphans_confirm (plurals) | Remove %lld upcoming DoseWeek events from this calendar? Events you edited may be included. | 이 캘린더에서 다가오는 DoseWeek 일정 %lld개를 삭제할까요? 직접 수정한 일정이 포함될 수 있습니다. |
| calendarSync.action.openSettings | calendar_sync_action_open_settings | Open Settings | 설정 열기 |
| calendarSync.action.changeCalendar | calendar_sync_action_change_calendar | Change calendar | 캘린더 변경 |
| calendarSync.action.syncNow | calendar_sync_action_sync_now | Update now | 지금 업데이트 |
| calendarSync.changeCalendar.body | calendar_sync_change_calendar_body | Upcoming DoseWeek events will be removed from “%@” and added to the new calendar. | 다가오는 DoseWeek 일정이 “%@”에서 삭제되고 새 캘린더에 추가됩니다. |
| calendarSync.changeCalendar.oldReadOnly | calendar_sync_change_calendar_old_read_only | DoseWeek can't remove its events from “%@” because that calendar no longer accepts changes. Delete them in your calendar app if you want. | “%@” 캘린더를 더 이상 수정할 수 없어 DoseWeek 일정을 삭제하지 못했습니다. 필요하면 캘린더 앱에서 삭제하세요. |
| calendarSync.disable.title | calendar_sync_disable_title | Turn off calendar sync? | 캘린더 연동을 끌까요? |
| calendarSync.disable.body | calendar_sync_disable_body | Choose what happens to upcoming DoseWeek events. Past events and events you changed stay. | 다가오는 DoseWeek 일정을 어떻게 할지 선택하세요. 지난 일정과 직접 바꾼 일정은 남습니다. |
| calendarSync.disable.remove | calendar_sync_disable_remove | Turn off and remove upcoming events | 끄고 예정 일정 삭제 |
| calendarSync.disable.keep | calendar_sync_disable_keep | Turn off and keep events | 끄고 일정 유지 |
| calendarSync.disable.noPermission | calendar_sync_disable_no_permission | Without calendar access DoseWeek can't remove its events. You can turn sync off and delete them in your calendar app. | 캘린더 권한이 없어 일정을 삭제할 수 없습니다. 연동을 끄고 캘린더 앱에서 직접 삭제할 수 있습니다. |
| calendarSync.disable.partial | calendar_sync_disable_partial (plurals) | %lld events could not be removed. Delete them in your calendar app. | 일정 %lld개를 삭제하지 못했습니다. 캘린더 앱에서 삭제하세요. |
| calendarSync.reset.note | calendar_sync_reset_note | Upcoming DoseWeek calendar events are removed when possible. Copies already synced by your calendar account follow that account's own sync. | 가능하면 다가오는 DoseWeek 캘린더 일정도 삭제합니다. 캘린더 계정이 이미 동기화한 사본은 해당 계정의 동기화를 따릅니다. |
| calendarSync.restore.note | calendar_sync_restore_note | Calendar sync settings are not included in backups. Turn it on again on this device if you want. | 캘린더 연동 설정은 백업에 포함되지 않습니다. 필요하면 이 기기에서 다시 켜세요. |

### 10.2 Written event titles, all 17 (strings stored in users' calendars)
| locale | generic | descriptive |
|---|---|---|
| ko | 개인 알림 | 주사 예정일 |
| en | Personal reminder | Injection day |
| ja | 個人的なリマインダー | 注射予定日 |
| de | Persönliche Erinnerung | Injektionstag |
| fr | Rappel personnel | Jour d’injection |
| es | Recordatorio personal | Día de inyección |
| it | Promemoria personale | Giorno dell’iniezione |
| nl | Persoonlijke herinnering | Injectiedag |
| pt-PT | Lembrete pessoal | Dia da injeção |
| pl | Osobiste przypomnienie | Dzień wstrzyknięcia |
| sv | Personlig påminnelse | Injektionsdag |
| hi | निजी रिमाइंडर | इंजेक्शन का दिन |
| pt-BR | Lembrete pessoal | Dia da injeção |
| ar | تذكير شخصي | يوم الحقن |
| zh-Hans | 个人提醒 | 注射日 |
| zh-Hant | 個人提醒 | 注射日 |
| tr | Kişisel hatırlatıcı | Enjeksiyon günü |

### 10.3 `NSCalendarsFullAccessUsageDescription` (InfoPlist.xcstrings, all 17; candidate for guard pinning)
- **en**: DoseWeek uses full calendar access only when you turn on Calendar sync: it adds, updates and removes the events it created for your upcoming injection days in the calendar you choose. Full access is needed to find those events again. Other events are never changed, and nothing is sent to the developer.
- **ko**: 캘린더 연동을 켠 경우에만 전체 캘린더 접근을 사용합니다. 선택한 캘린더에서 DoseWeek가 만든 주사 예정일 일정을 추가·수정·삭제하며, 그 일정을 다시 찾기 위해 전체 접근이 필요합니다. 다른 일정은 변경하지 않으며 개발자에게 아무것도 전송하지 않습니다.
- **ja**: DoseWeekは、カレンダー連携をオンにした場合にのみカレンダーへのフルアクセスを使用し、選択したカレンダーでDoseWeekが作成した注射予定日のイベントを追加・更新・削除します。これらのイベントを再度見つけるためにフルアクセスが必要です。ほかのイベントは変更せず、開発者には何も送信しません。
- **de**: DoseWeek nutzt den vollen Kalenderzugriff nur, wenn du die Kalendersynchronisierung einschaltest: Die App fügt im gewählten Kalender die von ihr erstellten Termine für deine nächsten Injektionstage hinzu, aktualisiert und entfernt sie. Voller Zugriff ist nötig, um diese Termine wiederzufinden. Andere Termine werden nie geändert, und nichts wird an den Entwickler gesendet.
- **fr**: DoseWeek utilise l’accès complet au calendrier uniquement si vous activez la synchronisation : l’app ajoute, modifie et supprime, dans le calendrier choisi, les événements qu’elle a créés pour vos prochains jours d’injection. L’accès complet est nécessaire pour retrouver ces événements. Les autres événements ne sont jamais modifiés et rien n’est envoyé au développeur.
- **es**: DoseWeek usa el acceso completo al calendario solo si activas la sincronización: añade, actualiza y elimina en el calendario que elijas los eventos que creó para tus próximos días de inyección. Se necesita acceso completo para volver a encontrar esos eventos. Nunca modifica otros eventos y no envía nada al desarrollador.
- **it**: DoseWeek usa l’accesso completo al calendario solo se attivi la sincronizzazione: aggiunge, aggiorna e rimuove nel calendario scelto gli eventi che ha creato per i tuoi prossimi giorni di iniezione. L’accesso completo serve per ritrovare quegli eventi. Gli altri eventi non vengono mai modificati e nulla viene inviato allo sviluppatore.
- **nl**: DoseWeek gebruikt volledige agenda-toegang alleen als je agendasynchronisatie aanzet: de app voegt in de gekozen agenda de afspraken die ze voor je komende injectiedagen heeft gemaakt toe, werkt ze bij en verwijdert ze. Volledige toegang is nodig om die afspraken terug te vinden. Andere afspraken worden nooit gewijzigd en er wordt niets naar de ontwikkelaar gestuurd.
- **pt-PT**: A DoseWeek só usa o acesso total ao calendário se ativar a sincronização: adiciona, atualiza e remove, no calendário escolhido, os eventos que criou para os seus próximos dias de injeção. O acesso total é necessário para voltar a encontrar esses eventos. Os outros eventos nunca são alterados e nada é enviado ao programador.
- **pl**: DoseWeek korzysta z pełnego dostępu do kalendarza tylko po włączeniu synchronizacji: dodaje, aktualizuje i usuwa w wybranym kalendarzu utworzone przez siebie wydarzenia dla nadchodzących dni wstrzyknięć. Pełny dostęp jest potrzebny, aby ponownie odnaleźć te wydarzenia. Inne wydarzenia nigdy nie są zmieniane i nic nie jest wysyłane do dewelopera.
- **sv**: DoseWeek använder full kalenderåtkomst bara när du slår på kalendersynkronisering: appen lägger till, uppdaterar och tar bort de händelser den skapat för dina kommande injektionsdagar i den kalender du väljer. Full åtkomst behövs för att hitta händelserna igen. Andra händelser ändras aldrig och inget skickas till utvecklaren.
- **hi**: DoseWeek पूरी कैलेंडर पहुंच का उपयोग केवल तब करता है जब आप कैलेंडर सिंक चालू करते हैं: यह आपके चुने हुए कैलेंडर में आपके आने वाले इंजेक्शन के दिनों के लिए अपने बनाए इवेंट जोड़ता, अपडेट करता और हटाता है। उन इवेंट को फिर से ढूंढने के लिए पूरी पहुंच ज़रूरी है। दूसरे इवेंट कभी नहीं बदले जाते और डेवलपर को कुछ नहीं भेजा जाता।
- **pt-BR**: O DoseWeek só usa o acesso total à agenda quando você ativa a sincronização: ele adiciona, atualiza e remove, na agenda escolhida, os eventos que criou para seus próximos dias de injeção. O acesso total é necessário para encontrar esses eventos novamente. Outros eventos nunca são alterados e nada é enviado ao desenvolvedor.
- **ar**: يستخدم DoseWeek الوصول الكامل إلى التقويم فقط عند تشغيل مزامنة التقويم: فهو يضيف الأحداث التي أنشأها لأيام الحقن القادمة ويحدّثها ويحذفها في التقويم الذي تختاره. ويلزم الوصول الكامل للعثور على هذه الأحداث مجددًا. ولا يغيّر أي أحداث أخرى ولا يرسل أي شيء إلى المطوّر.
- **zh-Hans**: 仅当你开启日历同步时，DoseWeek 才会使用完整日历访问权限：在你选择的日历中添加、更新和删除它为你即将到来的注射日创建的日程。需要完整访问权限才能再次找到这些日程。其他日程绝不会被更改，也不会向开发者发送任何内容。
- **zh-Hant**: 僅在你開啟行事曆同步時，DoseWeek 才會使用完整行事曆取用權限：在你選擇的行事曆中新增、更新和刪除它為你即將到來的注射日建立的活動。需要完整取用權限才能再次找到這些活動。其他活動絕不會被更改，也不會傳送任何內容給開發者。
- **tr**: DoseWeek, tam takvim erişimini yalnızca takvim eşitlemeyi açtığınızda kullanır: seçtiğiniz takvimde yaklaşan enjeksiyon günleriniz için oluşturduğu etkinlikleri ekler, günceller ve siler. Bu etkinlikleri yeniden bulmak için tam erişim gerekir. Diğer etkinlikler asla değiştirilmez ve geliştiriciye hiçbir şey gönderilmez.

Translation review: these follow the existing HealthKit string register. zh-Hant uses 行事曆/取用 (Taiwan) and zh-Hans uses 日历/日程.
The AGENTS invariant should pin that each locale contains its "never changed" clause, as with HealthKit.

## 11. Privacy, permissions, store text candidates

### 11.1 iOS
- Info.plist: add only `NSCalendarsFullAccessUsageDescription` (not WriteOnly, not legacy `NSCalendarsUsageDescription`).
  PrivacyInfo.xcprivacy: no required-reason API change.
- In-app privacy (`privacy.section1.body` and the sections for export/notifications/deletion, 17 locales). Candidate addition (en):
  "Optional calendar sync (off by default): if you turn it on, DoseWeek writes a title (“Personal reminder” unless
  you choose “Injection day”) and a time for each upcoming injection day to the calendar you select, and updates
  or removes those events automatically. The events are stored by that calendar's account (for example iCloud,
  Google or Samsung), may sync to your other devices and to anyone the calendar is shared with, and are not sent to
  the developer. Turning sync off lets you remove upcoming events. Deleting DoseWeek data removes them when calendar
  access still allows it. Copies already synced by the calendar provider follow that provider."
- Legal site `legal/privacy/index.html` (ko/en/ja) + `support/index.html`: the same facts plus how to turn off,
  change calendar, and remove leftovers. Update the dated policy only when it ships.
- Repository docs that currently say the opposite and must change in the same wave (file map §4.2): `docs/DESIGN_IMPORT.md`
  (`:34`, `:127-160` "The one deferral") and `docs/ROADMAP.md` (`:463` "deliberately not built") → superseded by
  CALENDAR-20260913-19, 5.1.3(ii) reasoning kept as the open risk; `AGENTS.md:542`; `docs/APP_STORE.md` (§5a boundary
  note, `:1418`), `docs/ASC_ANSWER_SHEET.md`.
- App Privacy (candidate, owner confirms in ASC): keep **Data Not Collected**. The developer and partners cannot access the calendar
  data (Apple's "collect" definition). This is an interpretation, stated as such.
- Review Notes candidate: "Calendar sync is optional and off by default. After an in-app explanation, the user
  grants full calendar access and picks a calendar. The app then writes only generic events (default title
  “Personal reminder”, start time, 30 minutes; no medication, dose or notes) and updates/removes only events it
  created, identified by an app URL. Full access is required because write-only access cannot find or update
  existing events. Nothing is sent to the developer."
- Policy risk (not resolved): 5.1.3(ii) iCloud PHI. Owner authorized the implementation (CALENDAR-19). No approval claimed.
  The generic default title + no clinical fields is the mitigation. A reviewer rejection is possible; fallback = local
  calendars only (the picker filter `isLocalOnly`), a one-line change.

### 11.2 Android
```xml
<!-- Optional calendar sync, off until the user turns it on in Settings: reads the list of calendars
     and DoseWeek's own marked events, and inserts/updates/deletes only those events. -->
<uses-permission android:name="android.permission.READ_CALENDAR" />
<uses-permission android:name="android.permission.WRITE_CALENDAR" />
```
- The invariants allowlist and `AGENTS.md` "exactly two optional integrations" wording become three (hard rule 1 text,
  ARCHITECTURE mermaid gets `DATA -. own events only, after consent .-> CAL[System Calendar Provider]`). No INTERNET change.
- Privacy (`docs/legal/android-content.json` → regenerate): same facts as iOS. `settings_integrations_body` → "All
  three integrations are optional…".
- Play Data safety (owner Console action; see Q5): recommended answer is Data type **Calendar events** → *Shared* (on-device
  transfer to the calendar app/provider), optional, purpose App functionality. Not collected. If descriptive
  titles ship, also mark **Health info** shared. Listing/release note candidate: "New: optional calendar sync —
  add your upcoming injection days to a Google, Samsung or device calendar with a private title. Off by default;
  DoseWeek changes only the events it created."
- Permissions Declaration Form: not expected for calendar (policy page lists other groups). Verify in Console.
- Canonical record: the chosen Data safety answer goes into `docs/PLAY_STORE.md` "Data safety" (today `:376`
  "Data shared: **No**", recorded for code 6) with date and release, plus `docs/PLAY_CONSOLE_ANSWER_SHEET.md` (`:287`)
  and `docs/MARKET_COMPLIANCE.md`. Android AGENTS: "canonical Play answers stay" in `PLAY_STORE.md`.

## 12. Open questions — facts, options, recommendation (implement the recommendation now; reversible)

- **Q1 User edits in the calendar app.** Facts: the app is the clinical source of truth, and a calendar edit can't
  record anything.
  - A: detach, never overwrite, don't recreate deleted.
  - B: restore to the schedule.
  - **Rec A** (least surprise, no fight with the user). The planner supports both (`userEditPolicy`), and the fixture pins both.
  - Scope of A (revision 2): holds across cap churn, gating, turn off/on, restore and reinstall for edits. One limit: a
    delete made before uninstall is not remembered after reinstall (no state survives), so that slot is created again.
- **Q2 Resolved slots.**
  - A: delete future ones, leave past ones.
  - B: delete all, including past.
  - C: keep all.
  - **Rec A**. Past events are history the user may rely on, and deleting them rewrites the past. Future resolved events would mislead.
- **Q3 Event alerts.**
  - A: none; app notifications stay the one reminder.
  - B: an alert at start time.
  - **Rec A** (avoids duplicates, and alerts show the title on the lock screen). A provider default alert may still apply: verify on device.
- **Q4 Title options.**
  - A: generic default + opt-in descriptive.
  - B: generic only.
  - **Rec A** ("default" in the decision implies a choice). B lowers Play/Apple risk.
- **Q5 Play Data safety.**
  - A: declare Calendar events shared.
  - B: rely on the user-initiated/prominent-disclosure exception.
  - **Rec A**: automatic ongoing updates weaken the exception argument; declaring is accurate and low-cost.
- **Q6 Window.**
  - A: 84 days / 24 events.
  - B: the full 26-week generated horizon.
  - **Rec A**: bounded writes, and it matches the notification budget.

## 13. Risks
- Apple 5.1.3(ii) rejection for iCloud calendars (§11.1 fallback).
- Adoption after restore assumes the treatment plan UUID round-trips through backup on both platforms. Verify
  `TreatmentPlanDTO.id` (iOS) and `treatment_plan.id` (Android payload) before relying on it. If a restore mints new
  plan ids, old events become orphans (user-confirmed cleanup), never duplicates of kept slots.
- Switching to a new plan (new plan id) at identical instants deletes and recreates events. Accepted.
- Google/Samsung sync adapters may not round-trip `customAppPackage/customAppUri`. The marker is then lost after a server
  resync, and relink/adopt fails (tombstone or duplicate). Mitigation: the Android `_ID` stays stable in the local provider; verify on device.
  If the marker is lost, fallback option: `UID_2445` marker (also app-writable), device-verified.
- iOS `URL` visible in the event detail (shows `doseday://…`, which hints at the app). Accepted as the ownership proof.
- The iOS full access OS prompt shows the ability to read all events. The app limits itself by code, and the copy must not claim OS-level limits.
- Provider default alerts may duplicate reminders.
- Android auto-reset of unused permissions → `permissionLost` surprise.
- Samsung-account-only calendars unverified.
- Parallel explicit-dates work may renumber the iOS schema or Android DB v12. Calendar sync needs no iOS schema change. On Android,
  coordinate the version number (take the next free version at merge).
- Fixture drift between repos (SHA pin guard mitigates).
- The EKEventStore commit batch fails partially → re-plan via markers. Never report "removed" without provider success.
- Calendar-level visibility: shared/family calendars expose even generic events.
- Reinstall forgets user deletions (tombstones live in app-local state) → those slots are recreated once. Edits are safe.
- `knownAppTitles` drift: if a title translation changes without appending the old text, untouched old events are adopted
  as detached (safe, but no longer managed). Guard: the frozen list test in both repos.
- Retained detached/tombstoned links while sync is off are a small device-local table/file; delete-all removes them.
- Android read-only detection relies on re-reading descriptors after a failure (no typed provider error); a calendar
  that reports contributor access but rejects writes would loop `failed` → device-verify on Samsung/Google shared calendars.

## 14. Implementation order
1. Planner + fixture tests in both repos (iOS DoseDayCore, Android domain; Android reads JSON with `DriveJson`) — green on
   all 73 v3 cases plus the idempotency loop, red proof; `CalendarSyncTitles` frozen lists.
2. Storage: iOS state file + policy URL; Android DB v12 + repository + migration test; backup-absence guards.
3. Gateways (EventKit / CalendarContract) behind protocols + isolation guards + fake gateways.
4. Coordinators/services + trigger wiring (ScheduleRefreshCoordinator / ViewModel), reset/restore/teardown paths.
5. Settings UI (disclosure, permission, picker, status, disable dialog, orphan cleanup) + 17-locale strings + Info.plist key.
6. Manifest permissions + allowlist; privacy text (app + legal site); store/Data safety/Review Notes drafts.
7. Full CI both repos; Android instrumentation API 24/36; owner physical-device matrix (§9); update the docs named in
   §4.2/§4.3/§11 (iOS DESIGN_IMPORT, ROADMAP, AGENTS, APP_STORE, ASC_ANSWER_SHEET, MARKET_COMPLIANCE, ANDROID_PARITY_NOTES,
   ARCHITECTURE, CURRENT_HANDOFF; Android PLAY_STORE, PLAY_CONSOLE_ANSWER_SHEET, MARKET_COMPLIANCE, AGENTS, ARCHITECTURE,
   ROADMAP, CURRENT_HANDOFF).

## Review log (revision 2, 2026-09-15)

Each finding was re-checked against the reference planner, the repositories and the SDK headers. All 9 confirmed and
fixed; none rejected. Partial deviations from the suggested fix are noted.

| # | Finding | Verification | Outcome |
|---|---|---|---|
| R1 | Re-enable after keep / reinstall overwrote user-edited events and recreated deleted ones | Reviewer `probe2.py` rerun on the old planner: `[adopt ev-61, update ev-61]` and `create` confirmed | **Fixed, both suggested fixes.** Teardown keeps detached/tombstoned links (§5.1, §6). Adopt without a link checks start = key instant, end = +30 min, title ∈ `knownAppTitles`; otherwise `adopt{state: detached}` (§6 step 4). New config `knownAppTitles` so a locale change while off still re-adopts untouched events. Cases `reenable_after_keep_user_edited`, `reenable_after_keep_user_deleted`, `reinstall_adopts_*`, `reinstall_restore_policy_adopts_edited_event`. Residual limit: reinstall cannot remember deletions (documented §8, §12 Q1, §13). |
| R2 | Tombstone forgotten on cap churn / gate, deleted event recreated | Reviewer `probe.py` 3-step run on the old planner: step 3 `create …-1792843200` confirmed | **Fixed.** New `live` set (unresolved, in window, before gate/cap). Tombstones and event-less detached links forgotten only when not live (`slotGone`). Also found and fixed: a marker event reappearing for a tombstoned key would have been deleted as `duplicateMarker` → now `detach`. Cases `tombstone_kept_*`, `tombstone_forgotten_*`, `tombstoned_event_restored_by_user_detaches`, `detached_event_deleted_kept_through_cap_churn`. |
| R3 | Re-pick after read-only stalls on delete in old calendar | Old planner output `[delete ev-99 calendarChanged, create cal-new]`; old apply rule stops batch; `EKErrorCalendarReadOnly`/`EKErrorEventNotMutable` present in `EKError.h` | **Fixed, both.** Planner checks every link calendar's descriptor → `forget(calendarNotWritable)` (reconcile and teardownRemoveFuture). Apply rules classify errors; permanent ones skip and continue; Android re-reads descriptors and re-plans once. New key `changeCalendar.oldReadOnly`. Cases `selected_calendar_changed_old_read_only`, `…_old_unavailable`, `teardown_remove_future_read_only_calendar`. |
| R4 | Android foreground trigger misnamed; no-plan users skipped | `DoseWeekViewModel.kt:522-537` returns at `if (activePlan == null) return` before `loadPersistedState`; `MainActivity.kt:282-285` `onStart` → `onForegrounded()` | **Fixed** (§4.3, §7): call in `onForegrounded` after `refreshReminderSystemAccess()`, before the plan return. |
| R5 | iOS/Android planner inputs differ (24-row pre-gate page vs uncapped) | `ScheduleRefreshCoordinator.swift:301-306` limit `maxScheduledOccurrences` (=24, `NotificationService.swift:142`), gate at `:226`; Android `syncReminders` uses `lastLoaded.unresolvedOccurrences` (`:2770`, from `Instant.EPOCH`, limit 100) | **Fixed** by one input spec (§3.2): own fetch on both, from now−24h, limit 1000, planner filters. Required anyway by R2 (live set needs rows beyond the cap). |
| R6 | Docs stating the opposite missing from file map | iOS `DESIGN_IMPORT.md:34,127-160`, `ROADMAP.md:463`, `AGENTS.md:542`; Android `PLAY_STORE.md:376` "Data shared: **No**"; MAINTAINABILITY-20260913-15 scope requires docs after implementation | **Fixed**: rows in §4.2, §4.3, notes in §11.1/§11.2, step 7. Also added `APP_STORE.md`, `ASC_ANSWER_SHEET.md`, `PLAY_CONSOLE_ANSWER_SHEET.md`, `MARKET_COMPLIANCE.md` (both). |
| R7 | Wrong iOS schema number | `DoseDaySchema.swift:418-426` head V5; `schedule-explicit-dates.md` plans V5→V6 | **Fixed** (§5.2). |
| R8 | Move-to-other-calendar over-claimed | `EKEvent.h:54-57` (iPhoneOS26.5): id "will likely change" on calendar change; `CalendarContract.java:1688-1690` calendar_id should not be modified | **Fixed**: §8 row now best effort; new case `user_moved_event_to_other_calendar_id_changed` → tombstone; old case relabelled as provider-kept-id. |
| R9 | Android fixture JSON reader undecided | `app/build.gradle.kts` test deps junit + coroutines-test only; `DriveJson.kt` imports only `java.nio.*`, `internal` in module `app`, KDoc notes `org.json` stub; `DriveJsonTest.kt` exists | **Fixed**: use `DriveJson`, limits checked (1 MiB / depth 32 vs 306 KB / 7), load snippet in §4.3. No new dependency. |

### Fixture v3 (2026-09-15, core-engines parity closure)

Both core-engine lanes copied v1 (iOS `ios-core` 7274d52, Android `android-core` a0c3398), so the change is a new file, `calendar_sync_reconcile_v3.json` (73 cases, 354,937 B, `c0286eb1…90dc`); there is no v2.

- **Coordinator decisions.** CORE-20260915-01 (personal target membership) and CORE-20260915-02 (explicit-date occupancy) do not change this planner: it reads persisted rows only and never decides occupancy. They are recorded in `body-chart-references.md` and `schedule-explicit-dates.md`.
- **Reference change.** Minimum-interval hours that are not a finite positive number mean no gate. Both planners implement this: iOS 7274d52, Android a0c3398. v1 raised an error on NaN and infinity, and for 0 or negative hours it used the raw arithmetic, which neither platform does. `--v1` reproduces v1 byte for byte; `check_idempotent.py` on v3: 0 failures.
- **Added (17).**
  - Gate hours 0 and −1.
  - Whole-second floor of the dose instant, with the boundary inclusive.
  - Fractional hours truncated to milliseconds.
  - Look-back start inclusive.
  - An event at exactly now counts as future (delete and orphan).
  - Upper-case plan id.
  - Sub-second observed event times.
  - The two branches no v1 case reached: an active link with no event for a resolved slot → `forget(eventMissing)`, and an edited event for a resolved slot → `forget(userModified)`, checked before the past check. The second has restore-policy variants.
  - Empty `eventId` or `markerKey` in reconcile, cleanup and teardown.
  - Teardown without a selected calendar.
- **Not pinned.**
  - NaN or infinite hours (no JSON form).
  - iOS access `restricted`: Android has no such state; the reference gives `permissionLost`.
  - A *future* user-edited event whose slot resolved. It is forgotten (`userModified`), but the next reconcile counts it as an orphan, so `orphanFutureCount` goes 0 → 1 with zero operations, and a confirmed cleanup would delete the user's edited event. This breaks both repos' idempotency loops and needs a decision, for example keeping a detached link until the event passes (DESIGN-20260915-04). The fixture pins only the past-event variant.
  - `cleanupOrphans` while sync is disabled: it runs and reports `synced`, and the product meaning is unconfirmed.
  - Duplicate observed event ids or link slot keys: last-wins maps.
  - Ordinal order above the Basic Multilingual Plane: Swift compares scalars, Kotlin UTF-16.
  - A link with an empty `eventId` holds no key in the duplicate trim; all three implementations agree.

### Fixture v4 (2026-09-15, coordinator decisions CORE-20260915-03, -04, -08)

New file `calendar_sync_reconcile_v4.json` (84 cases, 387,307 B, `e4b0c5df…b481`, sums in `v4.sha256`); v3 and v1 files and the v3 generator untouched. Generator `gen_calendar_sync_fixture_v4.py`; `--v1` and `--v3` regenerate the earlier files byte for byte (checked; the three v3 branches live behind `plan(inp, version=3)` for those modes only). Two runs are byte-identical. `check_idempotent.py` on v4: 0 failures.

- **Coordinator decisions.** CORE-20260915-03: a user-edited event whose slot has resolved keeps its detached link until the event's end time passes; cleanupOrphans never deletes a user-modified event (DESIGN-20260915-04); reconcile status stays idempotent. CORE-20260915-04: cleanupOrphans is an explicit user action and may run while sync is disabled; the status afterwards is disabled (`off`), never `synced`. CORE-20260915-08: iOS `restricted` maps to `permissionLost`; Android has no such state. These close three "not pinned" items of the v3 entry.
- **Reference changes (§6).**
  - Active link, event found, slot not desired, modified ∧ (detach ∨ moved): `detach` while `end > now` (link kept, state detached, baseline unchanged); `forget(userModified)` only once `end ≤ now`. The detached event is in `used_events`, so it is never counted as an orphan in the same run.
  - Detached link, slot not live: forgotten when the event is missing or **ended** (`end ≤ now`); v3 used `start < now`. No v3 case had an event in progress, so nothing else changes.
  - cleanupOrphans: status `off` when `enabled` is false, else `synced`; the gate (access, selected calendar) still runs first.
  - The gate already mapped `restricted` to `permissionLost`; v4 pins it with a case.
- **`changedFromV3` (one case, id kept).** `restore_policy_moved_calendar_slot_resolved_forgotten`: input identical; v3 `forget(userModified)`, no link, `detachedCount` 0 → v4 `detach ev-263`, link kept detached, `detachedCount` 1. A calendar move is a user edit (`modified` includes `calendarId`) and the event is future, so CORE-20260915-03 applies under the restore policy too; its description now says so. Canonical-JSON compare of the 73 shared cases: this is the only difference. The generator asserts that the set of v3 cases whose v3 and v4 plans differ equals this list.
- **Added (11).** The detach on a resolved slot (moved + renamed, future), the second reconcile after it (zero ops, same status: the v3 idempotency break is closed), cleanup with that detached link (deletes the unowned marker event only), a title-only edit with a cancelled slot, an edited event in progress (detached), an edited event that ends exactly now (forgotten, `end ≤ now`), a detached link with an event in progress (kept) and one whose event ended exactly now (forgotten `slotGone`), cleanup while disabled (deletes the orphan, keeps detached and past events, status `off`), cleanup while disabled without access (`permissionLost`, nothing deleted), and `access: restricted`.
- **Consumers.** Both planners port the three branches; the iOS adapter maps `EKAuthorizationStatus.restricted` to the planner's `permissionLost` input (`access` value `restricted`); the Android adapter has no such state and documents it. The app's cleanup entry point must not refuse the mode because `enabled` is false (the planner's gate still decides access and calendar), and the status it stores afterwards is `off`; when the row detail shows "Remove leftover events" while off is a UI question outside this fixture.
- **Still not pinned.** NaN or infinite hours (no JSON form). Duplicate observed event ids or link slot keys (last-wins maps). Ordinal order above the Basic Multilingual Plane. An unlinked marker event that looks edited (no baseline after reinstall or delete-all) with a slot that is not desired: it stays a user-confirmable orphan, as in v3 (§8, "Cleanup copy must say edited events may be included"); the CORE-20260915-03 guarantee is carried by the retained link.
