# DoseWeek global meal / nutrition app integration — build design (iOS + Android)

Date 2026-09-15 (rev 2 after review; see §21 Review log). Read-only design. No repo edited, built or run. Status of every row here: `DESIGN_ONLY / NOT_RUN`.
Version rule: this file uses symbolic versions only — Android `DB_N` / `PAYLOAD_VERSION_WITH_NUTRITION`, iOS `DoseDaySchemaV{N}` / `payload WITH_NUTRITION`. Concrete numbers come from the integrator ledger (§5.3), never from this file.
Audience: implementation agents. Binding sources win over this file on conflict: `DoseWeek_Final_v11_2026-09-13/specs/GLOBAL_NUTRITION_AND_STORAGE.md` (spec), `02_NEW_FEATURES_BOTH_PLATFORMS.md` §1/3B/4/5, `contracts/nutrition_contract_v3.json`, `nutrition_semantics_v1.json`, `food_localization_contract_v2.json`, goldens, `requirements/acceptance_registry.json`, each repo `AGENTS.md`.

---

## 0. Observed baseline (verified by reading code, 2026-09-15)

| Fact | Android | iOS |
|---|---|---|
| Worktree / HEAD | `/private/tmp/doseweek-v11-20260913/android` detached `origin/main` `79bb210` | `/private/tmp/doseweek-v11-20260913/ios` `codex/v11-bugfix` `7e8681b` at rev 2 (was `4c3e594` at rev 1; calendar-bound fix agent moving) |
| DB / schema | `data/DoseWeekDatabase.kt` `SQLiteOpenHelper`, `DATABASE_VERSION = 11`, additive `onUpgrade` steps, `onDowngrade` throws | `DoseDay/Data/Persistence/DoseDaySchema.swift` `CurrentDoseDaySchema = DoseDaySchemaV5` (origin/main: V3), lightweight stages V1→V5 |
| Import branch | `android-import` `feat/history-import` `197d9f3`: DB **12**, backup payload **9**, `app/src/main/assets/history_import_contract_v1.json`, `data/historyimport/HistoryImportStore.kt` (SQLite staging + receipts), unfinished | `ios-import` `feat/history-import` = `4c3e594`, no commits but **uncommitted** diff: `DoseDaySchemaV6`, `currentPayloadVersion = 8`, `PreMigrationStoreSnapshot.swift` (`StoreVersion.v5`, `current = "6.0.0"`, schema list + manifest allowlist += v5), `StoreSessionController.canonicalRestoreGraphData` (+ `historyImportProvenance` sorted), validator `maxHistoryImportProvenance` |
| Sibling stage-2 designs claiming the same next numbers | `calendar-sync.md` DB 12; `schedule-explicit-dates.md` DB 12 / payload 9; `body-chart-references.md` DB 12 / payload 9 | `schedule-explicit-dates.md` V6 / payload 8; `body-chart-references.md` V6 / payload 8 |
| Backup budgets (bind nutrition sizing, §6.1) | `DoseWeekBackupContract.MAX_ENVELOPE_BYTES = 16 MiB`, `MAX_PLAINTEXT_BYTES = 16 MiB − 1,024`, `MAX_TOTAL_ROWS = 500_000` (codec `BackupPayloadCodec.kt:611`, validator `BackupModels.kt:803`); binary codec `writeString` = int length + UTF-8; storage `DoseWeekBackupStorageFailure.FILE_TOO_LARGE`; Drive `CloudBackupFailure` has no too-large member | `BackupPayloadValidationLimits.maxTotalRows = 50_000` (shared), `maxTotalTextUTF8Bytes = 16 MiB`; `BackupCryptoLimits.maxCiphertextBytes = 32 MiB`, `maxEnvelopeJSONUTF8Bytes = 48 MiB`; `encrypt` over-size → generic `BackupCryptoError.encryptionFailed` |
| Backup | `data/BackupModels.kt` `DoseWeekBackupContract.PAYLOAD_VERSION = 8`, per-feature `PAYLOAD_VERSION_WITH_*` gates, `data/BackupPayloadCodec.kt`, validator `DoseWeekBackupValidator` (BackupModels.kt), restore `DoseWeekRepository.replaceAllDataFromBackup` (validate → one transaction → `deleteAllTables` → inserts → FK check), `BackupRestoreStage` fault injector in `DoseWeekBackupService.kt` | `BackupCryptoService.currentPayloadVersion = 7` (origin/main: 5), `BackupPlaintextPayload` optional additive arrays, `BackupPayloadValidator.swift`, `DoseDayModelActor.restoreBackup(payload:)`, `resetAllLocalData()` |
| Transaction boundary | `database.writableDatabase.inTransaction { }` in `DoseWeekRepository` | private `withSaveTransaction(trackBackupChange:)` in `DoseDayModelActor.swift` (+ guard `check_model_actor_saves_roll_back_pending_changes`) |
| Generation / staleness | none for app data; `edit_token` compare tokens (DB11); `expectedLiveStateDigest` on restore | `BackupMutationStateEntity.generationID/revision` (rotated on reset/wrap), `requireActiveStoreSession()` / `isStoreSessionRetired` |
| Drive dirty detection | `CloudBackupService.backupNow(force=false)` compares SHA-256 of encoded backup snapshot (`backupStateDigest`) with `cloud_backup_state.last_success_digest` → `UNCHANGED`; periodic `CloudBackupWork` | n/a (file backup; `BackupMutationState` revision drives Today reminder) |
| Existing drafts | `app/DoseWeekDrafts.kt`: sheet drafts in Activity saved instance state (Serializable). **Not allowed for meal PHI** (spec §4, 02 §5) | view-model state; SwiftData store has complete protection + backup exclusion (`SensitiveStoragePolicy.swift`) |
| Protected-draft precedent | import branch: `history_import_session` table + `HistoryImportDraftCodec` (DriveJson), `pendingResult/acknowledgeResult` | none yet |
| CSV | `data/export/HistoryCsvFormatter.kt` (formula prefixes incl. full-width, tab neutralizer), `PreparedDocumentExportStore.kt`, `DocumentExportPhase.TOO_LARGE` | `ExportService.generateCancellableCSV`, BOM, `csvSafe` apostrophe prefix, 20,000 row / 8 MiB budgets |
| Number / time input | `common/formatting/LocalizedInputParser.kt` (`normalizeDigits` reusable; `parseDecimal` Double → not for nutrition), `common/time/ExactLocalTimeResolver.kt`, `designsystem/components/TemporalInputField.kt` | `Domain/Services/LocalizedDecimalInput.swift` (Double → not for nutrition), `ExactEditTimeResolver.swift`, `DesignSystem/Components/ConfirmedDateTimePicker.swift` |
| Navigation | `MainTab { TODAY, BODY, HISTORY, SETTINGS }`; Body = `BodyMetricUi` chips + `SegmentedChoice` period; guard: every `features/**/*Screen.kt` must use `ReadableContent` | tabs Today/Body/History/Settings (+record/estimate routes); `BodyView` metric chips |
| Localization | `res/values` (ko base) + 16 `values-*` (`zh-rCN`=zh-Hans, `zh-rTW`=zh-Hant, `pt-rBR`, `pt-rPT`); per-feature file precedent `history_import.xml` | `Localizable.xcstrings`, `REQUIRED_LOCALES` 17 in `scripts/check_invariants.py`, namespace list in AGENTS rule 2 |
| Resources in bundle | `app/src/main/assets/` (import branch creates it) | `scripts/generate_project.py` bundles only `.xcstrings/.xcassets/.plist/.xcprivacy` + `resource_folders` (currently a test fixture folder); JSON under `DoseDay/` needs a folder entry |
| Existing nutrition code | none (grep `nutrition|meal|kcal`: no hits in Android; 2 unrelated iOS hits) → no shipped calculationRevision 2 data; legacy reader list is empty | same |
| Calculators | `nutrition-prep/kotlin-calculator/src/{NutritionCalculator.kt,NutritionSemantics.kt}` package `doseweek.nutrition`, 69/69 JVM (40 C + 8 S + 21 boundary) | `nutrition-prep/swift-calculator/Sources/NutritionCalculator/{NutritionCalculator,NutritionContract,UnsignedDecimalInteger,NutritionSemantics}.swift`, 14 XCTest core PASS, semantic run pending |
| Data release | `android-nutrition-data` HEAD `79bb210` + **untracked** `nutrition-data/{pipeline,contracts,config,aliases/machine-draft,fixtures/queries,releases,reports,tests}` (23 files; `releases/`, `fixtures/queries/` empty), no `docs/NUTRITION_DATA_RELEASE.md`. Pipeline reference already defines search rules: `pipeline/localization.py` `SEARCH_RULES_REVISION = 1` + `pipeline/search.py` ranking (§10). Release layout below still an ASSUMPTION (A-REL), re-derive at freeze | consumer only |

Assumption tags used below: **A-REL** (release file layout), **A-SRCH** (normalization rev 1 if the release does not define one), **A-VER** (version numbers depend on merge order).

---

## 1. Decided rules applied (no re-ask)

- Entry: Body tab section switch "Body / Meals" + small Today entry (spec §1). No forced onboarding, no permission, no account.
- Two entry modes: `scaled` (search → exact item → basis/source → amount → save) and `direct_total` (name + known consumed totals; blanks = unknown; name-only = all unknown).
- Date required; time optional (`date` precision: instant/offset/localTime null). "Now" only when user taps it. `createdAt` ≠ meal time. Meal kind optional → `unspecified`.
- Exact arithmetic rev 3, canonical 12 dp HALF_UP per item, sum canonical, display kcal 0 dp / macros 1 dp; semantic grouping by reviewed `definitionKey`; state precedence from `nutrition_semantics_v1.json`.
- Snapshots immutable; copy = new meal + new operationId keeping old snapshot; catalog/favorite edits never rewrite meals.
- Offline bundled read-only catalog; no runtime download/translation/network; Android assets = single writer; iOS consumes identical `dataReleaseId`.
- uiLocale / searchLocales / selectedFoodMarkets / sourceLocale independent; device region = first suggestion only; no location/IP.
- Protected drafts, operationId + payloadDigest persisted before commit, storeGeneration invalidation, unsaved drafts excluded from totals/CSV/PDF/backup.
- Reuse existing envelope/KDF/validator; no crypto change. No cross-platform backup. No meal PDF; existing PDF export UI must state meals are not included. Plain CSV is not called encrypted.
- Owner UX decision UX-20260913-09 (simple primary controls, nothing removed) and DESIGN-20260913-13 (keep design system) shape the UI section. MAINTAINABILITY-20260913-15 → feature modules + docs.

---

## 2. Architecture overview

```mermaid
graph TD
  subgraph Shared inputs [identical bytes on both platforms]
    C[runtime contracts: nutrition_contract_v3, semantics_v1, food_localization_v2]
    GT[test-only: nutrition_golden_v3, nutrition_semantic_golden_v1, query vectors, synthetic releases]
    R[food data release dataReleaseId: manifest, providers, aliases+keys, coverage, definitions, identity map, search rules]
    PX[designs/fixtures/nutrition-day-presentation-cases.v1.json → copied as app test fixture]
  end
  subgraph Pure [no DB, no UI, no clock]
    CALC[NutritionCalculator rev3]
    SEM[NutritionSemantics v1]
    PRES[DayNutritionPresentation]
    NORM[FoodSearchNormalizer rev1]
    RANK[FoodSearchRanker]
    DEC[NutritionDecimalInput locale→ASCII]
  end
  subgraph Data
    REL[FoodDataRelease reader+verifier]
    IDX[FoodCatalogIndex in-memory per searchLocales]
    STORE[Meal store: meals, items, favorites, drafts, receipts, generation]
    BK[Backup payload +nutrition section / validator]
    CSV[MealCsvExporter v1]
  end
  subgraph Feature
    VM[Meals / MealEditor controllers]
    UI[Body→Meals day view, editor, search, amount, direct entry, settings, sources]
  end
  C --> CALC & SEM
  GT -. tests only .-> CALC & SEM & RANK
  R --> REL --> IDX
  NORM --> IDX
  RANK --> IDX
  UI --> VM --> STORE
  VM --> IDX
  VM --> CALC
  STORE --> CALC
  STORE --> SEM --> PRES
  BK --> STORE
  CSV --> STORE
```

Rules: composables/SwiftUI views never touch persistence; all meal writes through the single repository/model-actor boundary; controllers own draft checkpoints; pure layer is locale-/clock-free except `NutritionDecimalInput` (explicit locale parameter).

---

## 3. Data model (logical, identical meaning on both platforms)

### 3.1 Meal
| Field | Type | Rule |
|---|---|---|
| id | UUID | new per logical meal (create, copy) |
| localDate | `yyyy-MM-dd` | required; grouping key (never re-derived from device zone) |
| timePrecision | `date` \| `instant` | |
| localTime | `HH:mm[:ss]` \| null | null iff `date` |
| instantUtc | epoch ms \| null | null iff `date` |
| utcOffsetSeconds | int \| null | null iff `date`; for `instant` must satisfy `instantUtc + offset == localDate+localTime` (pure arithmetic check, no tz-rules lookup on restore) |
| zoneId | IANA id | required for both precisions (recording context); not used to move dates |
| mealKind | `breakfast\|lunch\|dinner\|snack\|unspecified` | contract `entry.mealKinds` |
| editToken | 32 hex | rotated on every committed update (Android DB11 `edit_token` style); iOS: `revision Int64` |
| createdAt / updatedAt | epoch ms | system timestamps, never meal time |

Invariant (DB CHECK on Android, validator on both): `(timePrecision='date' AND localTime IS NULL AND instantUtc IS NULL AND utcOffsetSeconds IS NULL) OR (timePrecision='instant' AND all three NOT NULL)`.
Date edit = explicit user action that clears time fields (contract `time.dateEdit`). New time input: DST gap rejected; overlap requires offset choice (reuse `ExactLocalTimeResolver` / `ExactEditTimeResolver`).

### 3.2 MealItem (immutable snapshot)
| Field | Rule |
|---|---|
| id, mealId, position (1…100) | UI and validator cap 100 items/meal (far below calculator 10,000) |
| entryMode | `scaled` \| `direct_total` |
| origin | `catalog` \| `favorite_template` \| `direct` |
| displayName (≤ 200 UTF-16 units, NFC not applied to stored text) | name shown when added |
| logicalFoodId, providerId, sourceFoodId, sourceVersion, catalogSha256, packReleaseId | null for direct; queryable columns (favorites/recents/identity) |
| definitionKey per nutrient (4) | reviewed key or null |
| canonical per nutrient (4) | ASCII `^(0|[1-9][0-9]{0,11})\.[0-9]{12}$` or null |
| calculationRevision | 3 (only accepted value) |
| sourceSnapshotId | SHA-256 hex of a `nutrition_source_snapshot` row (§3.2.1); required for `scaled`, null for `direct_total` |
| itemJson (≤ 16 KiB UTF-8) | canonical item part (§3.2.1). Logical snapshot = canonical JSON `doseweek.meal_item_snapshot` rev 1: `food{…attribution fields from food_localization_contract sourceAttribution.required}`, `calcInput` (exact DTO), `sourceNutrients{raw, qualifier, sourceName, sourceNutrientId}` incl. `energyKJ`, `definitionKeys`, `mappingRevision`, `canonical`. Assembled example: `designs/fixtures/nutrition-meal-item-snapshot.v1.example.json` |
| energy/protein/carbohydrate/fat canonical + definitionKey columns | derived query cache rebuilt from the assembled snapshot on write and restore; never in backup |

Covers contract `snapshot.contains` (food_name, origin, source_basis, consumed_amount_or_direct_total, source_nutrients, raw_qualifiers, serving_equivalent, canonical_nutrients, calculation_revision, logical_food_id, observed_source_id, source_version, energy_selection_ref, nutrient_definition_keys).
Write rule: repository re-runs calculator on `calcInput` once and stores its result; UI preview numbers are never persisted. Restore rule: re-run and require byte-equal canonical; mismatch = reject (no silent fix).

#### 3.2.1 Snapshot storage split (rev 2, backup growth)
Logical snapshot unchanged (fixture = assembled view). Stored and backed up as two immutable parts; assembled bytes derived, never stored twice:
- **Source part** `doseweek.meal_source_snapshot` rev 1 = `{food, sourceNutrients, definitionKeys, mappingRevision, calcInputSource{basis, nutrients, energyKJ, servingEquivalent}}`, canonical JSON (fixture notes), ≤ 16 KiB, id = SHA-256 of canonical bytes. Content-addressed: same food/version/displayName/values → one row shared by all items. Never updated; deleted only in the transaction that removes its last referencing item.
- **Item part** = `{schema, schemaRevision, calculationRevision, entryMode, origin, calcInputConsumed{mode, consumed}, canonical}`. Direct items: whole direct snapshot in item part, no source part.
- Assemble: disjoint key merge, `calcInput = calcInputSource ∪ calcInputConsumed`, canonical JSON. Key collision / unknown key = corrupt. Pure `MealSnapshotCodec` both platforms; test: assembled fixture ⇄ split parts round-trip byte-equal.
- Measured (`designs/fixtures/nutrition-backup-size-model.v1.json`): scaled item 1,899 B assembled → item part 338 B + shared source 1,590 B. Heavy use backup/yr: Android 6.87 → 2.43 MiB; iOS 8.57 → 2.94 MiB (§6.1).

Direct-entry mapping:
- kcal typed → `nutrients.energyKcal = value`; kJ typed (explicit unit toggle) → `energyKJ = value`, `energyKcal = null` (user-chosen nutritional kJ, contract manualEntry) → calculator ÷ 4.184.
- energy definitionKey `energy_as_reported` iff energy value present; protein/carbohydrate/fat definitionKey always **null** (semantics: manual macros stay definition-unknown).
- Qualified/trace catalog values (`<LOQ`, trace, not detected, "") → numeric null, raw + qualifier kept (I05).

### 3.3 NutritionFavorite
`id` (immutable), `kind` `catalog_food|direct_template`, `label`, `templateSnapshotJson` (catalog: food identity + source basis/nutrients/serving, no consumed amount; direct: name + totals DTO), `lastAmountValue/unit` (catalog, optional), `createdAt`, `lastUsedAt`, `sortIndex`. Max 1,000.
Edit = create new favorite id + delete old (immutable ids, F09). Using a catalog favorite: exact identity lookup (`providerId+sourceFoodId+sourceVersion+catalogSha256`) in current release → found: normal; else reviewed identity link → "Updated source available — reselect" (I01); none → "Not in current food list — reselect or use saved values (source version X)" (I02/I04). Never auto-move.
Recent: derived query (last 30 distinct item identities from saved meals; direct items by normalized name+totals digest), no table, local only.

### 3.4 Protected draft (excluded from backup/totals/CSV/PDF/recent)
`draftId` UUID, `kind` `new|edit|copy`, `targetMealId?`, `baseEditToken?`, `storeGeneration`, `editRevision` (in-memory counter at checkpoint), `checkpointRevision`, `payloadJson` (≤ 256 KiB; versioned codec: header fields + items with calcInput/snapshot + in-progress text inputs as typed strings), `operationId?`, `payloadDigest?`, `committedMealId?`, `createdAt`, `updatedAt`. Max 20 drafts; never auto-evicted — creating a 21st shows a "resume or discard existing drafts" sheet.

### 3.5 Operation receipt (device-local, excluded from backup)
`operationId` PK, `payloadDigest` (SHA-256 hex of canonical save payload), `kind` `create|update|delete`, `mealId`, `resultEditToken?`, `storeGeneration`, `committedAt`. Pruned only when no draft references it and older than 30 days.

### 3.6 Store generation
Android: new singleton `nutrition_store_state(id=1, generation TEXT)`; rotated inside `replaceAllDataFromBackup` and `deleteAllData` transactions. iOS: reuse `BackupMutationStateEntity.generationID` (already rotated by `resetAllLocalData` and inside `restoreBackup(payload:)` via `replaceBackupMutationGeneration`, verified in `DoseDayModelActor.swift`) plus `requireActiveStoreSession()`.

### 3.7 Nutrition preferences (non-PHI)
`nutrition.searchLocales` (ordered, subset of 17 app locales; default `[uiLocale]`, unconfirmed), `nutrition.selectedFoodMarkets` (ISO-3166-1 alpha-2, may be empty), `nutrition.marketsConfirmedAt`, `nutrition.regionSuggestionDismissed`. Android `data/DoseWeekPreferences.kt`; iOS `Data/Services/AppPreferences.swift`. uiLocale = app locale (not stored). Backup policy: see Q1.

---

## 4. Write protocol (F01–F05, E02–E04)

States: `EDITING → SAVING → SAVED | RETRYABLE_FAILURE | CONFLICT(stale_edit | payload_changed | generation_changed | meal_deleted)`.

1. Every edit bumps in-memory `editRevision`; checkpoint writer debounced 500 ms and forced on background/stop (Android `ON_STOP`, iOS `scenePhase != .active`) writes draft with `checkpointRevision = editRevision` (never labels unsaved text "saved").
2. Save tap: build canonical save payload `{schema:"doseweek.meal_save",rev:1,meal header,items[calcInput+snapshot sans canonical],kind,targetMealId,baseEditToken}` → `payloadDigest`.
3. Draft step (own transaction): if `draft.operationId != null && draft.payloadDigest == digest` reuse; else new UUIDv4. Persist `operationId,payloadDigest` + current payload. **If this write fails → stop, show retryable error, no meal commit** (spec implementation memo).
4. Commit (single transaction): (a) receipt lookup: same id+digest → return stored result (F01/F02); same id, other digest → `CONFLICT payload_changed`; (b) `generation == draft.storeGeneration` else `CONFLICT generation_changed` (F04); (c) edit: `meal.editToken == baseEditToken` else `CONFLICT stale_edit` (F03) / missing row → `meal_deleted`; (d) calculator over items (validation errors → no write, draft untouched); (e) `INSERT OR IGNORE` source snapshots by hash, write meal + delete-old-items/insert-new-items (update) or insert (create), delete now-unreferenced source snapshots; (f) insert receipt; (g) set `draft.committedMealId`; (h) Android: nothing else; iOS: `withSaveTransaction(trackBackupChange: true)`.
5. UI acknowledges → delete draft (separate small transaction). Relaunch with `committedMealId` draft → show saved meal, delete draft (import `acknowledgeResult` precedent).
6. Delete meal: confirm dialog → op with its own operationId (no draft needed; in-memory opId reused on double tap) → transaction deletes items+meal + now-unreferenced source snapshots + receipt.
7. Conflict UI: keep user draft; offer "Open latest record" / "Save as a new meal" (new operationId, new meal id) / "Keep editing".
8. No global content dedupe: same food twice intentionally = two meals.

Fault seams: Android `NutritionWriteStage { AFTER_DRAFT_OPERATION, AFTER_MEAL_ROW, AFTER_FIRST_ITEM, BEFORE_RECEIPT, AFTER_COMMIT_BEFORE_RETURN }` injector parameter (same pattern as `BackupRestoreStage`); iOS actor-internal `NutritionWriteFaultInjector` closure (same pattern as `SensitiveFileStore` overrides), test-only construction.

---

## 5. Persistence and migration

### 5.1 Android (SQLite helper; no Room)
New file `data/nutrition/NutritionSchema.kt`: `internal fun createNutritionTables(db)` with byte-identical statements used by `onCreate` and the upgrade step.

```sql
CREATE TABLE meal (
  id TEXT NOT NULL PRIMARY KEY CHECK (length(id)=36),
  local_date TEXT NOT NULL CHECK (local_date GLOB '[0-9][0-9][0-9][0-9]-[0-1][0-9]-[0-3][0-9]'),
  time_precision TEXT NOT NULL CHECK (time_precision IN ('date','instant')),
  local_time TEXT, instant_utc_ms INTEGER, utc_offset_seconds INTEGER CHECK (utc_offset_seconds IS NULL OR utc_offset_seconds BETWEEN -64800 AND 64800),
  zone_id TEXT NOT NULL CHECK (length(zone_id) BETWEEN 1 AND 64),
  meal_kind TEXT NOT NULL CHECK (meal_kind IN ('breakfast','lunch','dinner','snack','unspecified')),
  edit_token TEXT NOT NULL CHECK (length(edit_token)=32),
  created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL,
  CHECK ((time_precision='date' AND local_time IS NULL AND instant_utc_ms IS NULL AND utc_offset_seconds IS NULL)
      OR (time_precision='instant' AND local_time IS NOT NULL AND instant_utc_ms IS NOT NULL AND utc_offset_seconds IS NOT NULL)));
CREATE INDEX meal_by_date ON meal(local_date, instant_utc_ms, id);
CREATE TABLE nutrition_source_snapshot (id TEXT NOT NULL PRIMARY KEY CHECK (length(id)=64), source_json TEXT NOT NULL CHECK (length(CAST(source_json AS BLOB)) <= 16384));
CREATE TABLE meal_item (
  id TEXT NOT NULL PRIMARY KEY, meal_id TEXT NOT NULL REFERENCES meal(id) ON DELETE CASCADE,
  position INTEGER NOT NULL CHECK (position BETWEEN 1 AND 100),
  entry_mode TEXT NOT NULL CHECK (entry_mode IN ('scaled','direct_total')),
  origin TEXT NOT NULL CHECK (origin IN ('catalog','favorite_template','direct')),
  display_name TEXT NOT NULL CHECK (length(display_name) BETWEEN 1 AND 200),
  logical_food_id TEXT, provider_id TEXT, source_food_id TEXT, source_version TEXT, catalog_sha256 TEXT, pack_release_id TEXT,
  energy_kcal TEXT, protein_g TEXT, carbohydrate_g TEXT, fat_g TEXT,                                  -- derived, not backed up
  energy_definition_key TEXT, protein_definition_key TEXT, carbohydrate_definition_key TEXT, fat_definition_key TEXT, -- derived
  calculation_revision INTEGER NOT NULL CHECK (calculation_revision = 3),
  source_snapshot_id TEXT REFERENCES nutrition_source_snapshot(id),
  item_json TEXT NOT NULL CHECK (length(CAST(item_json AS BLOB)) <= 16384),
  CHECK ((entry_mode='direct_total' AND source_snapshot_id IS NULL) OR (entry_mode='scaled' AND source_snapshot_id IS NOT NULL)),
  UNIQUE (meal_id, position));
CREATE INDEX meal_item_by_source ON meal_item(source_snapshot_id);
CREATE TABLE nutrition_favorite (id TEXT PRIMARY KEY, kind TEXT NOT NULL CHECK (kind IN ('catalog_food','direct_template')), label TEXT NOT NULL, template_snapshot_json TEXT NOT NULL, last_amount_value TEXT, last_amount_unit TEXT CHECK (last_amount_unit IS NULL OR last_amount_unit IN ('g','mL','serving')), logical_food_id TEXT, provider_id TEXT, source_food_id TEXT, source_version TEXT, catalog_sha256 TEXT, created_at INTEGER NOT NULL, last_used_at INTEGER, sort_index INTEGER NOT NULL);
CREATE TABLE nutrition_draft (id TEXT PRIMARY KEY, kind TEXT NOT NULL CHECK (kind IN ('new','edit','copy')), target_meal_id TEXT, base_edit_token TEXT, store_generation TEXT NOT NULL, checkpoint_revision INTEGER NOT NULL, payload_json TEXT NOT NULL CHECK (length(CAST(payload_json AS BLOB)) <= 262144), operation_id TEXT, payload_digest TEXT CHECK (payload_digest IS NULL OR length(payload_digest)=64), committed_meal_id TEXT, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);
CREATE TABLE nutrition_operation (operation_id TEXT PRIMARY KEY, payload_digest TEXT NOT NULL CHECK (length(payload_digest)=64), kind TEXT NOT NULL CHECK (kind IN ('create','update','delete')), meal_id TEXT NOT NULL, result_edit_token TEXT, store_generation TEXT NOT NULL, committed_at INTEGER NOT NULL);
CREATE TABLE nutrition_store_state (id INTEGER PRIMARY KEY CHECK (id = 1), generation TEXT NOT NULL);
```
(Canonical-value CHECKs: validated in Kotlin before insert; SQLite GLOB can't express the full pattern cleanly — validator + test.) Upgrade step inserts `nutrition_store_state(1, random UUID)`.

Code changes: `DoseWeekDatabase.kt` (version, `onCreate` call, `if (oldVersion < N) createNutritionTables(db)`); `DoseWeekRepository.kt` `deleteAllTables` (delete meal_item, meal, nutrition_source_snapshot, nutrition_favorite, nutrition_draft, nutrition_operation) and rotate generation in both `replaceAllDataFromBackup` and `deleteAllData`; `backupSnapshot` adds sorted nutrition arrays (meals `ORDER BY local_date, id` / items `meal_id, position` / source snapshots `id` / favorites `id`); derived columns not exported.
Store class: `data/nutrition/MealStore.kt` (own `transaction {}` over the same `DoseWeekDatabase`, like `HistoryImportStore`); restore/reset remain owned by `DoseWeekRepository`.

**Sequencing (A-VER):** `DB_N` and `PAYLOAD_VERSION_WITH_NUTRITION` from the ledger (§5.3); fork from the merged predecessor head. Migration proof: `androidTest/.../data/DatabaseMigrationToNutritionTest.kt` (pattern `DatabaseMigrationV11Test.kt`; import precedent `DatabaseMigrationV12Test.kt` untracked in `android-import-data`) opening a schema dump **generated from the merged predecessor head** (never a hand-written numbered dump; test reads the old version from the dump, no literal), asserting all pre-existing rows byte-identical, nutrition tables empty, generation row present, failure mid-step rolls back (SQLiteOpenHelper wraps `onUpgrade` in a transaction). Update existing tests that assert latest version with scoped edits only.

### 5.2 iOS (SwiftData via `DoseDayModelActor`)
New entities `DoseDay/Data/Persistence/Entities/{MealEntity,MealItemEntity,NutritionSourceSnapshotEntity,NutritionFavoriteEntity,NutritionDraftEntity,NutritionOperationReceiptEntity}.swift` with the same fields (Strings for canonical values, `@Attribute(.unique)` ids, `MealEntity.items` relationship `deleteRule: .cascade`, items sorted by `position`). Add `DoseDaySchemaV{N}` = V{N-1} models + 6 entities; `CurrentDoseDaySchema` → V{N}; `.lightweight(V{N-1}→V{N})` (additive entities only).
**Sequencing (A-VER):** `V{N}` / payload `withNutrition` from the ledger (§5.3). Today: bugfix V5/payload 7; `ios-import` uncommitted V6/payload 8.
**Required schema-bump touch points (all five; `ios-import` V6 diff is the precedent):**
1. `DoseDaySchema.swift`: `DoseDaySchemaV{N}`, `CurrentDoseDaySchema`, `.lightweight(V{N-1}→V{N})`.
2. `DoseDay/Data/Services/PreMigrationStoreSnapshot.swift`: `StoreVersion` gains `v{N-1}` (= previous `current` string), `current = "{N}.0.0"`; model-hash detection list += `(.v{N-1}, Schema(versionedSchema: DoseDaySchemaV{N-1}.self))`; manifest `sourceSchema` allowlist += `.v{N-1}`; doc comment range. Without it a V{N-1} store gets no pre-migration recovery copy.
3. `DoseDay/App/StoreSessionController.swift` `canonicalRestoreGraphData`: add `meals`, `mealItems`, `nutritionSourceSnapshots`, `nutritionFavorites` each sorted by `id.uuidString`/hash, plus `nutritionPreferences` if Q1=B. Without it `restored.canonicalGraph == snapshot.canonicalGraph` passes when meals are dropped.
4. `DoseDayModelActor.swift`: `deleteAllEntities()`, restore insert, `createBackupPayload()`.
5. `BackupCryptoService.swift` payload fields/version; `BackupPayloadValidator.swift` limits (§6.1).
Proof: `PreMigrationV{N-1}StoreSnapshotTests.swift` (pattern `PreMigrationV4StoreSnapshotTests.swift`): V{N-1} store detected, manifest accepted. `SchemaMigrationTests`: old store opens, rows preserved, nutrition empty. `MealBackupRestoreTests.restoreVerificationFailsWhenMealDropped` (+ one dropped source snapshot): staged restore fault drops a row → canonical graph mismatch → live store untouched.
Actor methods live **inside `DoseDayModelActor.swift` under `// MARK: - Nutrition`** so they use private `withSaveTransaction` without widening access; entity↔DTO mapping and validation in new `DoseDay/Data/Persistence/NutritionPersistenceMapping.swift`. Draft writes/receipt ack use `withSaveTransaction(trackBackupChange: false)`; meal/favorite mutations `true` (Today backup reminder sees meal changes). `deleteAllEntities()` gains the 6 entities. No `@Query`, no main-context writes (guard).

Rollback note (both): no downgrade path; old app cannot open a `DB_N` / `V{N}` store. Recovery = encrypted backup file restore on a fixed release; nutrition UI may be hidden by a code release but data/restore/export stay. No remote flag.

### 5.3 Version reservation ledger (integrator-owned, all stage-2 designs)
Fact (§0): history import, calendar-sync, schedule-explicit-dates, body-chart-references all claim Android DB 12 / payload 9 and/or iOS V6 / payload 8.
- One ledger for all five designs (proposed `DoseWeek_Continuation_2026-09-15/VERSION_LEDGER.json`, not created here): rows `{feature, platform, dbOrSchema, payload, branch, mergedSha|null}` in merge order.
- Branches read numbers from the ledger at rebase. Constants: Android `PAYLOAD_VERSION_WITH_NUTRITION` (frozen once shipped; gates compare against it, never `PAYLOAD_VERSION`, per `BackupModels.kt` rule); iOS named `withNutrition` constant beside `currentPayloadVersion`.
- Test names never embed numbers: `BackupPayloadNutritionTest`, `DatabaseMigrationToNutritionTest`, `SchemaMigrationTests.testMigrationToNutritionSchema`.
- Two unmerged branches holding one number = merge blocker; renumber the later one first.

---

## 6. Backup payload and restore validation (F06–F08, E08)

Android `DoseWeekBackupContract`: `PAYLOAD_VERSION = PAYLOAD_VERSION_WITH_NUTRITION` (ledger); `SUPPORTED_PAYLOAD_VERSIONS` += it. Codec appends a nutrition section after the last predecessor section: `meals[]`, `nutritionSourceSnapshots[]` (`id, sourceJson`), `mealItems[]` (`id, mealId, position, displayName, sourceSnapshotId?, itemJson`), `nutritionFavorites[]`, `nutritionPreferences?` (per Q1). iOS: `BackupPlaintextPayload` optional `meals`, `nutritionSourceSnapshots`, `mealItems`, `nutritionFavorites`, `nutritionPreferences`; `currentPayloadVersion` = ledger value.
Excluded: drafts, receipts, generation, derived item columns, catalog files, fooddata verification receipts, Drive/HC state.

Decode rules:
- version < WITH_NUTRITION: section absent → empty nutrition (F07).
- version ≥ WITH_NUTRITION: section required; missing/extra keys, trailing data → reject (not "empty").
- Bounds: §6.1 (caps inside shared row budgets; bytes bind first); ≤ 100 items/meal; displayName ≤ 200; itemJson/sourceJson ≤ 16 KiB. Exceed → reject before delete.
- Graph: unique ids; every item.mealId exists; positions 1..n contiguous per meal; no orphan; every `sourceSnapshotId` exists; every source row referenced (unreferenced source → reject).
- Meal: date grammar; precision invariant; zone id syntactically valid and known to platform tz db (unknown id → reject, never remap); instant/offset/local arithmetic consistency; mealKind enum.
- Item: calculationRevision == 3 else `UNSUPPORTED_CALCULATION_REVISION`; `itemJson` and `sourceJson` strict canonical parse (sorted keys, schemaRevision 1); `sourceSnapshotId == SHA-256(sourceJson bytes)` else `SOURCE_HASH_MISMATCH`; assemble (§3.2.1); `calcInput` → calculator (contract errors → reject); calculator output == assembled `canonical` (byte-equal) else `SNAPSHOT_MISMATCH`; derived columns rebuilt from assembled snapshot, never read from file; mode ↔ presence of basis/consumed consistent; direct items have null catalog identity.
- Favorites: kind enum, template parse, calcInput (direct) validates.
- All validation before the first delete (existing Android order; iOS `BackupPayloadValidator` before actor replace). Catalog presence is NOT required (F08).
- After restore: new generation, drafts/receipts deleted in the same transaction; Drive/HC remain disconnected per existing rules.

### 6.1 Size budget and growth (rev 2)
Facts: §0 budget row; `designs/fixtures/nutrition-backup-size-model.v1.json` (heavy use 3 meals + 6 scaled + 3 direct items/day, ≤ 1,500 distinct sources in 10 y, 4 MiB clinical reserve; Android = binary `writeString`, iOS = compact JSON incl. keys).

| Wire form | Android MiB/yr | iOS MiB/yr | y to Android 16 MiB | y to Android 32 MiB | y to iOS 32 MiB ciphertext | y to iOS 16 MiB total text |
|---|---|---|---|---|---|---|
| rev 1 columns + snapshot | 6.87 | 8.57 | 1.7 | 4.1 | 3.3 | 1.4 |
| snapshot only (reviewer option) | 5.55 | 6.47 | 2.2 | 5.0 | 4.3 | 1.9 |
| **split §3.2.1 (chosen)** | 2.43 | 2.94 | 4.0 | **10.5** | **8.6** | 3.2 |

Decision: split form **plus** explicit limit raise, each gated by a boundary test. Envelope format, crypto, KDF unchanged; only limit constants move.
- Android bytes: `MAX_ENVELOPE_BYTES` 16 → 32 MiB (`MAX_PLAINTEXT_BYTES` follows). Gate `BackupSizeBoundaryDeviceTest` (API 24 owned emulator, default heap): encode+encrypt+write, then read+decrypt+validate+restore at cap − 1 KiB; record Java/native heap peak. OOM or flaky → keep 16 MiB (horizon 4.0 y), record in release decision. Old app reading a > 16 MiB file fails at length check instead of version check; acceptable (cannot read `WITH_NUTRITION` anyway), existing invalid-file copy.
- Android rows: `MAX_TOTAL_ROWS = 500_000` unchanged, nutrition counted in it. New `MAX_MEALS = 40_000`, `MAX_MEAL_ITEMS = 120_000`, `MAX_NUTRITION_SOURCE_SNAPSHOTS = 20_000`, `MAX_NUTRITION_FAVORITES = 1_000` (sum 181k ≤ 500k).
- iOS: `maxCiphertextBytes` 32 MiB and `maxEnvelopeJSONUTF8Bytes` 48 MiB unchanged. `maxTotalTextUTF8Bytes` 16 → 32 MiB (plaintext cap already bounds it). `maxTotalRows` 50,000 → 150,000, nutrition counted in `totalRowCount()`. New `maxMeals = 20_000`, `maxMealItems = 60_000`, `maxNutritionSourceSnapshots = 10_000`, `maxNutritionFavorites = 1_000` (sum 91k; clinical keeps 59k ≥ today's 50k). Gate: extend `ExpandedRestoreBudgetTests` / `RestoreBudgetProjectionTests` at new ceilings (validation + staged restore time/memory, oldest supported simulator). Fail → keep 50,000 / 16 MiB text, set `maxMeals = 10_000`, `maxMealItems = 30_000`, `maxNutritionSourceSnapshots = 3_000`, record horizon.
- Creation UX (both): measure plaintext before encrypt; over cap → typed `BACKUP_TOO_LARGE` (Android create-path failure beside `DoseWeekBackupStorageFailure.FILE_TOO_LARGE`; iOS new `BackupCryptoError.payloadTooLarge` replacing generic `encryptionFailed` for this case) → sheet "Backup is too large to create. Your records stay on this device. Export meals as CSV." No file, no partial write. ≥ 80 % of cap → non-blocking warning on Settings backup row.
- Drive (Android): new `CloudBackupFailure.TOO_LARGE` → one localized line; periodic work does not retry the same digest daily; `lastSuccessDigest` untouched.
- Tests: F06/E07 rows §15 (each cap at limit accept, +1 reject before delete; 80 % warning; over cap no file; Drive `TOO_LARGE`); split round-trip; unreferenced / hash-mismatched source rejected.
- Past the horizon (not this release): per-year archive backup; not designed here.

---

## 7. Android Drive dirty revision
No new counter. `backupStateDigest` = SHA-256 of `DoseWeekBackupPayloadCodec.encode(backupSnapshot)`; adding the nutrition section to `backupSnapshot` makes meal create/edit/delete/favorite change the digest, so `backupNow(force=false)` stops returning `UNCHANGED`. Tests (JVM, `data/drive` test pattern): (1) digest unchanged after draft checkpoint + receipt ack only; (2) changed after meal create, edit, delete, favorite add; (3) meal creation/restore never calls `CloudBackupScheduler.enable` nor flips `auto_backup_enabled`; (4) payload over §6.1 cap → `CloudBackupFailure.TOO_LARGE`, no upload, no retry loop on unchanged digest. Existing daily periodic cadence unchanged (spec asks inclusion, not immediate upload).

---

## 8. Meal CSV export v1 (F12, E07)

Entry: Meals day view overflow → "Export meals (CSV)" with date-range picker (reuse History export range UI), plus row in Settings export area. Copy warns: plain, not encrypted, saved records only.
File: `doseweek-meals-v1-<from>-<to>.csv`, UTF-8 with BOM, CRLF, RFC 4180, every field quoted. One row per item (meal with zero items impossible). Header (48 cols, fixed machine names, not localized) — byte fixture `designs/fixtures/meal-csv.v1.example.csv` (BOM + CRLF, 4 data rows incl. `America/New_York` `-04:00` unprefixed and name `'-SUM(A1)` prefixed):
`format, meal_id, meal_local_date, time_precision, meal_local_time, meal_utc_offset, meal_time_zone, meal_instant_utc, meal_kind, item_position, item_id, entry_mode, food_name, original_name, source_locale, food_origin, food_kind, provider_id, source_food_id, source_version, data_release_id, catalog_sha256, logical_food_id, source_region, market_countries, basis_value, basis_unit, consumed_value, consumed_unit, serving_equivalent_value, serving_equivalent_unit, energy_kcal, energy_kcal_state, energy_definition_key, protein_g, protein_g_state, protein_definition_key, carbohydrate_g, carbohydrate_g_state, carbohydrate_definition_key, fat_g, fat_g_state, fat_definition_key, source_energy_kcal_raw, source_energy_kj_raw, source_qualifiers, calculation_revision, license_ref`
- Units in column names; values = stored canonical 12-dp ASCII `.` (no locale, no display rounding); precision disclaimer in export sheet copy.
- Unknown = empty value + `*_state = unknown`; known zero = `0.000000000000` + `known`. Date-only meals: empty time/offset/instant.
- Qualifiers: `field=qualifier;…` raw text preserved (e.g. `<0.03` stays).
- Formula injection (meal CSV v1, identical on both platforms). Two column classes fixed by header name:
  - **Machine columns** — app-produced, grammar-checked right before writing (miss = export fails as a bug, never emitted), never prefixed: `format` literal; `meal_id,item_id` UUID; `meal_local_date` `^\d{4}-\d{2}-\d{2}$`; `meal_local_time` `^\d{2}:\d{2}(:\d{2})?$`; `meal_utc_offset` `^[+-]\d{2}:\d{2}$`; `meal_instant_utc` `^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$`; `time_precision,meal_kind,entry_mode,food_origin,food_kind,*_state,*_unit` enums; `item_position,calculation_revision` `^[1-9]\d*$`; nutrient + `basis_value,consumed_value,serving_equivalent_value` `^(0|[1-9]\d*)(\.\d+)?$`; `catalog_sha256` `^[0-9a-f]{64}$`; empty where nullable. Only `meal_utc_offset` can start with a trigger scalar and its grammar cannot hold a function. Integer-seconds offset rejected: negative seconds also start with `-`.
  - **Text columns** — all others (user/provider text: `food_name, original_name, source_locale, provider_id, source_food_id, source_version, data_release_id, logical_food_id, source_region, market_countries, meal_time_zone, *_definition_key, source_energy_*_raw, source_qualifiers, license_ref`): first non-whitespace/control scalar ∈ `= + - @ ＝ ＋ － ＠` or value begins with TAB/CR/LF → prefix `'`.
  - F12 vectors: `-05:00` and `-04:00` unprefixed; `-SUM(A1)` prefixed; provider raw `-` prefixed; `＋1` prefixed; `+09:00` unprefixed. New formatter per platform; do not modify `HistoryCsvFormatter` / `ExportService.csvSafe` behavior.
- Streaming over the full range, ordered `local_date, instant_utc (nulls last), meal_id, position`; limits: 200,000 rows or 64 MiB → explicit `TOO_LARGE` "choose a shorter range" (never first-page masquerade). Cancel → temp file deleted (Android `PreparedDocumentExportStore`, iOS `generateCancellableCSV` pattern). Drafts excluded.
- Existing PDF/visit summary sheets (`features/history/DocumentExportSheet.kt`, iOS export sheet): add one localized line "Meal records are not included in this PDF."

---

## 9. Food data release consumption (E01, E05, E09, E10, G16, DATA_RELEASE)

### 9.1 Consumer requirements the release must satisfy (A-REL; adapt only `FoodDataReleaseReader` if layout differs)
Assumed root: `android/app/src/main/assets/fooddata/<dataReleaseId>/`. Re-derive at freeze from the data worktree: it separates `nutrition-data/releases/<id>/` (today empty) from `fixtures/queries/`, `aliases/machine-draft/`, `pipeline/`, `tests/`, `reports/`; only `releases/<id>/` content is copied into assets.
| # | Requirement | Assumed file |
|---|---|---|
| R01 | manifest named per contract, no self-hash, lists every file path + SHA-256 + bytes, `dataReleaseId`, contract hashes (`calculationContractHash`, `localizationContractHash`, `semanticsContractHash`), per-provider manifest hashes, alias/coverage hashes, `searchRulesRevision`, `unicodeVersion`, `queryVectorSetSha256` (vectors live outside, R09) | `food-data-release.json` |
| R02 | provider manifests with source URL, version, errata, license/attribution text, normalizer revision, counts | `providers/<providerId>/manifest.json` |
| R03 | one food per line; fields ⊇ `sourceAttribution.required` + `basis{unit,value,meaning}` + nutrients `{value|null, rawAmount, qualifier, definitionKey|null, sourceName, sourceNutrientId}` for the 4 fields + `energyKJ` + confirmed serving equivalents `{unit,value,source}` + cooking/brand descriptors in names; sorted by logicalFoodId; per-provider `catalogSha256` = file hash | `providers/<providerId>/foods.jsonl` (USDA candidate shape in `nutrition-prep/usda/normalized-candidate.json` fits except energy mapping pending) |
| R04 | aliases only `official|reviewed`, `{logicalFoodId, locale, text, reviewStatus, sourceRef}`; zero `machine_draft|unverified` | `aliases/<locale>.jsonl` |
| R05 | coverage per locale row (`uiReady` excluded—app owns) `localizedSearchReady, marketCoverage, providersUsed, licenseStatus, realFoodQueriesPassed, validationStatus, limitations`; per market status `NOT_RUN|BLOCKED|PARTIAL|VERIFIED_FOR_DECLARED_SCOPE` | `coverage/locales.json`, `coverage/markets.json` |
| R06 | reviewed definition keys → closed app label kind (`energy_as_reported`, `protein_total`, `fat_total`, `carbohydrate_total_including_fiber`, `carbohydrate_available_excluding_fiber`, `carbohydrate_monosaccharide_equivalents`, `other_reviewed`) + mapping revision | `semantics/nutrient-definitions.json` |
| R07 | cross-release identity links (official or reviewed, with provenance) | `identity/identity-map.json` |
| R08 | `searchRulesRevision` (normalization + ranking, one number = pipeline `SEARCH_RULES_REVISION`) + per-locale flags; aliases carry precomputed `searchKey`/`foldedKey` | `search/rules.json` (name A-REL) |
| R09 | query vectors per locale (≥20 positive + ≥5 ambiguous/out-of-scope; shape `designs/fixtures/food-search-query-vector.v1.example.json`), **outside the shipped dir**, bound by manifest `queryVectorSetSha256` | data repo `nutrition-data/fixtures/queries/<locale>.json` → app test resources (§16) |
| R10 | no test fixtures, query vectors, goldens, scripts, raw sources, `machine_draft`/`unverified` aliases, API keys, images in release dir | guard: no path segment `queries/ fixtures/ machine-draft/ tests/`, no `*golden*`, no `.py .pyc .xlsx .pdf .zip` |

Missing release → nutrition manual flows ship; `DATA_RELEASE`, G01–G15 search parts, I01–I04 with real data, L-xx search = `BLOCKED` (never private fork).

### 9.2 Android (writer repo; app side)
- `data/nutrition/catalog/FoodDataReleaseReader.kt`: AssetManager streaming reads; path allowlist from manifest (no `..`, no absolute, only `[A-Za-z0-9._/-]`), exactly one release dir.
- `FoodDataReleaseVerifier.kt`: streaming SHA-256 of all manifest files on first catalog open per `(versionCode, dataReleaseId)`; contract hashes compared with `assets/nutrition/contracts/*`; pass → non-PHI prefs receipt; fail → `CatalogUnavailable(reason)` (G12), manual entry unaffected.
- Runtime contracts (shipped): `app/src/main/assets/nutrition/contracts/{nutrition_contract_v3,nutrition_semantics_v1,food_localization_contract_v2}.json`. Goldens test-only (spec §2 "test asset path"): `app/src/test/resources/nutrition/contracts/{nutrition_golden_v3,nutrition_semantic_golden_v1}.json`. JVM tests read both sets (module-relative path, assert exists, never skip) and assert raw + normalized SHA-256 (localization normalized `c4428315…59ca3c`; others from calculator `evidence/fixture-provenance.json`).
- Guard in `scripts/check_invariants.py` (`check_food_data_release`, red+green self-test fixtures): single release dir; manifest file list == files on disk; hashes; no forbidden review states; no `.py/.xlsx/.pdf/.zip`; contracts byte-equal to registry hashes; no `*golden*`, `queries/`, `fixtures/`, `machine-draft/` anywhere under `app/src/main/assets/**`.
- E09 release gate: `./gradlew bundleRelease` then list `base/assets/fooddata/**` in the AAB and compare to manifest; whole AAB listing has no `*golden*`/`queries`/`fixtures`/`machine-draft` entry; instrumentation test opens assets via AssetManager on API 24/36.

### 9.3 iOS (consumer)
- New `scripts/import_food_data_release.py --android-repo <path> --release <dataReleaseId>`: validate manifest + paths; hash every source file; compare contract hashes with `DoseDay/Resources/NutritionContracts/*`; copy to `DoseDay/Resources/FoodData/.staging-<id>-<pid>/`; re-hash staged bytes; atomic rename to `DoseDay/Resources/FoodData/<id>/`; only then remove previous release dir; write `DoseDay/Resources/FoodData/RELEASE_LOCK.json {dataReleaseId, manifestSha256, fileCount, totalBytes, sourceRepository, sourceCommit}`; run `generate_project.py`. Any failure → delete staging only, keep old release (E05).
- `scripts/generate_project.py`: add `app_root / "Resources" / "FoodData"` and `app_root / "Resources" / "NutritionContracts"` to `resource_folders` (verified: members become `folder` file refs in the Resources phase of the target whose root holds them; today only `DoseDayTests/Fixtures/LegacyBodyStoreFixtures`, commented "never the shipping app"). `NutritionContracts` = runtime contracts only. Goldens, query vectors, synthetic test releases → `DoseDayTests/Fixtures/Nutrition/` (new test-bundle `resource_folders` entry) and `Packages/DoseDayCore/Tests/DoseDayCoreTests/Fixtures/Nutrition/` (`#filePath`; `Package.swift` declares no resources). Regenerate, never hand-edit pbxproj.
- `scripts/check_invariants.py`: `check_food_data_release_lock` (lock ↔ manifest ↔ file hashes, no staging dirs, no extra files, forbidden review states, not referenced by `DoseDayWidgets`), with negative probes.
- Runtime: `DoseDay/Data/Services/FoodDataRelease.swift` (reader + first-open verification receipt in `AppPreferences` keyed by `CFBundleVersion+dataReleaseId`).
- E09: app unit test loads `Bundle.main` `FoodData/RELEASE_LOCK.json` and verifies; release archive inspection lists `DoseWeek.app/FoodData/<id>/` files vs manifest and finds no `*golden*`/`queries`/`fixtures`/`machine-draft` in `DoseWeek.app` (also `check_invariants` guard on source tree).
- DoseDayCore tests read runtime contracts from `DoseDay/Resources/NutritionContracts/*.json` and goldens from `Packages/DoseDayCore/Tests/DoseDayCoreTests/Fixtures/Nutrition/`, both `#filePath`-relative (one copy each per repo).

CROSS_PLATFORM/DATA_RELEASE evidence: both repos' `food-data-release.json` SHA-256 equal + contract hashes equal + search result hashes equal (§16); file equality alone ≠ app parity.

---

## 10. Offline search

### 10.1 Search rules = release-bound `searchRulesRevision` (normalization + ranking)
Authority: frozen release `search/rules.json` + pipeline reference (`nutrition-data/pipeline/localization.py`, `search.py`). App ports the reference exactly, invents no rule. Unknown `searchRulesRevision` in release or vector file → `CatalogUnavailable(UNSUPPORTED_SEARCH_RULES)`, search hidden, manual entry OK. Alias keys precomputed in release; runtime normalizes only the query, so the query function must be byte-identical in Python, Kotlin, Swift. Stored/displayed names untouched.
Observed draft r1 (untracked pipeline 2026-09-15; re-read at freeze), `primary_key(text, locale)`:
1. NFKC (Kotlin `java.text.Normalizer.Form.NFKC`; Swift `precomposedStringWithCompatibilityMapping`).
2. Drop `FORMAT_CONTROLS`: U+00AD, 061C, 0640 (tatweel), 180E, FEFF, 200B–200F, 202A–202E, 2060–2064, 2066–2069.
3. General category `Nd` → ASCII digit.
4. Locale `tr`: `I→ı`, `İ→i`.
5. Lowercase: context-free table (below).
6. Pipeline `SEPARATORS` set and whitespace → space; collapse; trim.
`folded_key`: NFD, drop U+0300–036F after a Latin base (≤ U+024F or U+1E00–1EFF), NFC, katakana U+30A1–30F6 → −0x60. r1 has no bigrams, no zh-Hans↔zh-Hant, no stemming, no brand/number removal.
**Lowercase (parity fix, hand to data agent before freeze):** per code point `Lowercase_Mapping` = `UnicodeData.txt` simple lowercase + `SpecialCasing.txt` unconditional entries (U+0130 → `i̇`), then fold U+03C2 ς → U+03C3 σ. Implement as generated table (`NutritionLowercaseTable.kt` / `.swift` / pipeline), from release `unicodeVersion`. Do not use: Kotlin `lowercase(Locale.ROOT)` / Java `toLowerCase` (JDK Final_Sigma context), Foundation `lowercased(with:)` (verified `ΟΔΟΣ` → `…ς`), Python `str.lower()` (verified `…ς`), stdlib Swift `lowercased()` (verified per-scalar `σ` today, but not a pinned table). Until pipeline uses the same table (r1-final or r2), vectors with `Σ` are parity-blocked and logged, not silenced.
Unicode drift: release guard rejects alias-key scalars unassigned in Unicode 8.0 (API 24 ICU) or whose NFKC differs between 8.0 and `unicodeVersion`; newer query scalars pass unchanged on both platforms (match no key).
E06 edge vectors: `İ I ı i` (tr, non-tr), word-final `Σ`, `ß`, `Ａ１`, half-width `ｶﾞ`, tatweel, ZWJ, Arabic-Indic + Devanagari digits, combining vs precomposed Latin.

### 10.2 Index (runtime-built, in memory, off main thread)
- On first search open: load compact food table for the release (ordinal, logicalFoodId, identity, originalName, sourceLocale, foodKind, sourceRegion, marketCountries, basis, byte offset into foods.jsonl). Detail read lazily by offset on selection.
- For each `searchLocale`: release `aliases/<locale>` (provider original names are already `official` aliases, pipeline `official_aliases`) with precomputed `searchKey`/`foldedKey`; entries `(key, foldedKey, foodOrdinal, statusRank, aliasId)`; sorted key array for exact/prefix binary search; token arrays for token-prefix; substring tier = scan of the locale key list (add an index only if §14 fails; results identical).
- Rebuilt only when `searchLocales` or `dataReleaseId` changes; cached for process lifetime. Markets never affect index content (all markets searchable; markets only rank + label).
- While building: favorites/recent visible immediately; query field accepts input; results show progress.

### 10.3 Match and rank (E06 deterministic)
Port of release ranking (observed draft r1 `search.py`), versioned by `searchRulesRevision`:
- Tier per alias: primary key 0 exact, 1 prefix, 2 every query token prefixes some key token, 3 substring; else same tests on folded keys + 4 (4–7); else no hit.
- Per food best alias by `(tier, statusRank official 0 / reviewed 1, key length in code points, key, aliasId)`.
- Result order `(tier, marketRank, statusRank, key length, providerId, sourceFoodId)`; `marketRank` 0 if no markets selected or `marketCountries ∩ selected ≠ ∅`, else 1 (row label "Reference · other market" when markets selected and rank 1). `sourceRegion` unused in r1. Search locales iterated sorted.
- All string compares by Unicode code point: Kotlin compare `codePoints()` sequences (not UTF-16 `compareTo`); Swift compare `unicodeScalars` (not `String <`).
- Rev 1 ideas (3-level market class, bigram tier, sourceVersion/logicalFoodId tie-breaks) dropped unless the release adopts them under a new revision.
Cap 50 (+ "Show more" to 200). No auto-select ever; brand/market variants never merged; empty/weak query → "Enter directly with ‹query›" row always last and on zero results (query prefilled).

### 10.4 Request lifecycle (G17)
Debounce 250 ms. `requestKey = (normalizedQuery, searchLocales, selectedFoodMarkets, dataReleaseId, storeGeneration, requestSeq)`; Android: cancel previous coroutine Job, apply result only if key == latest; iOS: `FoodSearchService` actor + `Task` cancellation, `@MainActor` apply only for latest key. Locale/market change invalidates in-flight; selection/draft never overwritten by late results.

### 10.5 Display name rule (G03/G04)
UI shows alias for `uiLocale` if official/reviewed exists in current release for the exact identity; else original name + "Not translated · ‹source language›". Saved items: same lookup by exact identity; if absent, snapshot `displayName`/`originalName`. Numbers/ids never change with language.

### 10.6 Markets / languages UI (independence)
Settings → Meals → "Food markets" (multi-select countries from `coverage/markets.json` with status text: Verified for declared scope / Partial / Not available), "Search languages" (multi-select 17 locales, default `[uiLocale]`), "Food data sources" (provider, version, license, attribution strings verbatim — needed for CC BY providers). First search open with no market chosen: one dismissible suggestion chip "Show foods sold in ‹device region›?" [Use] [Choose]; never auto-applied; direct entry always available. Changing UI language/travel/restore never mutates markets silently.

---

## 11. Calculation, amounts, display

- Port calculators unchanged in logic: Android `domain/nutrition/NutritionCalculator.kt`, `NutritionSemantics.kt` (package rename to `com.wonyoungchoi.doseweek.domain.nutrition`; `fromDecoded` fed by a DriveJson→`Map<String,Any?>` adapter converting `JsonValue.Number.raw` to `BigDecimal`, strings/bools preserved; the adapter lives in `data/nutrition/NutritionContractAssets.kt`). iOS `Packages/DoseDayCore/Sources/DoseDayCore/Nutrition/` (4 files, `public` API kept). Add one public helper each for single-value display (reuse internal aggregate). Re-run C01–C40, S01–S08, boundary checks in-repo.
- `DayNutritionPresentation` (pure, both): engine result → `NO_RECORDS | NOT_RECORDED | COMPLETE | KNOWN_SUBTOTAL | SEPARATE_DEFINITIONS`; rule + 12 cases in `designs/fixtures/nutrition-day-presentation-cases.v1.json` (verified against the engine logic in Python: 12/12). Copy into each repo as test fixture (Android `app/src/test/resources/nutrition/`, iOS `Packages/DoseDayCore/Tests/DoseDayCoreTests/Fixtures/` via `#filePath`). Contract gap noted: semantic golden has no `definitionKey=null,value=null` case; engine returns `definition_unknown`; presentation maps to NOT_RECORDED/KNOWN_SUBTOTAL without changing contract or engine.
- Amount units offered: `g`/`mL` only if equal to basis unit; `serving` if basis is serving or the food has a confirmed `servingEquivalent` in the basis physical unit. Cup/piece/bowl never offered. g↔mL never converted. Unknown conversion → message + "Switch to direct entry" (contract `unknownConversion`).
- Edible-portion basis → helper text "Weight of the edible part" (MEXT/USDA `basis.meaning`).
- `NutritionDecimalInput(locale)` new (Android `common/formatting/NutritionDecimalInput.kt` reusing `LocalizedInputParser.normalizeDigits`; iOS `Domain/Services/NutritionDecimalInput.swift`): trim only surrounding whitespace; digits normalized (Arabic-Indic, Devanagari, full-width); exactly the locale's decimal separator allowed (either `.` or `,` per `DecimalFormatSymbols`/`Locale.decimalSeparator`); any grouping separator or the other separator → error `nutrition_error_number_format` (`1,5` in `en` rejected, `1.234` in `de` rejected — no guessing); result must match contract pattern (≤6 int, ≤6 frac, no leading zeros except `0`) else `nutrition_error_number_range`; invalid input keeps draft text. Paste validated identically. Locale switch while typing: re-validate with new locale, never reinterpret silently (value stays as typed text, error shown if invalid).
- Display: format the ASCII display string exactly — Android `BigDecimal(display)` + `DecimalFormat` (min=max fraction = scale, locale digits); iOS `Decimal(string:locale: nil)` + `Decimal.FormatStyle.number.precision(.fractionLength(scale)).locale(locale)`. Unit strings from resources (`kcal`, `g`). Tests: `0.05`→`0.1`, `999999999999.9`, ar/hi digits, RTL isolation (`⁨…⁩` / Compose `TextDirection.Content`) around numbers+units.
- Day totals limit: > 10,000 items in one localDate → state "Too many items to total for this day" (records still listed/editable/exportable) (E07).

---

## 12. UI flows

Design system reused (Android `GlassCard`/`SegmentedChoice`/`ReadableContent`/sheets; iOS `GlassCard`, `ThemedRow`, `PrimaryCTAButton`, `ThemePalette`, `CappedScaledMetric`). Every new Android `*Screen.kt` wraps `ReadableContent` (guard). No new tab.

### 12.1 Entry points
- Body tab header: `SegmentedChoice` "Body | Meals" (Android new `BodySectionUi { MEASUREMENTS, MEALS }` in `DoseWeekUiModels.kt`; iOS `BodyView` section `Picker(.segmented)`); selection persisted in Android `DoseWeekDrafts.selectedBodySection` (non-PHI) / iOS `@SceneStorage`.
- Today: compact card "Meals today" → `No meals recorded` / `1,240 kcal known · 1 item not recorded` + "Add" → opens editor for today. Card hidden by nothing; no numbers on widget/notification/lock surfaces.

### 12.2 Meals day view
Date header with previous/next + system date picker (reuse `TemporalInputField`/`ConfirmedDateTimePicker`). Totals card (energy row + protein/carbohydrate/fat rows via presentation kinds; SEPARATE_DEFINITIONS expands to labeled groups and "unspecified definition" item values). Meal list: timed meals by local time, then "Time not recorded" section; each row: kind label, time or "No time", item names (2 lines), energy presentation. Row tap → meal detail sheet: items with source badge ("USDA · US · per 100 g edible portion", "Entered by you"), Edit, Copy to…, Add items to favorites, Delete (confirm). Empty state: "No meals recorded" + Add meal + "Choose food markets (optional)". Draft banner: "Unsaved meal from ‹date›" [Resume] [Discard].

### 12.3 Meal editor (new / edit / copy)
Header: Date (required), Time segmented `No time | Set time | Now` (Now fills current instant and zone explicitly; Set time → system time picker; DST gap error assertive + save disabled; overlap radio of numeric offsets), Kind chips (`Not specified` default).
Items list (reorder optional: no; delete per item swipe/overflow; tap to edit amount/values) + two buttons: **Search food**, **Enter directly**. Live meal subtotal (preview only).
Save button (explicit; disabled while invalid/saving; label "Saving…" with polite live region); errors inline; retryable failure banner "Couldn't save. Your entries are kept." [Retry]; conflict sheet (§4.7).
Close/back with changes → dialog: **Keep draft** / **Discard** (destructive) / **Continue editing**.

### 12.4 Search
Field (IME composition counted; Korean syllable composition not blocked), chips row "Markets: JP, KR · Search: 한국어" → settings sheet. Tabs/segments: Results | Favorites | Recent. Row: name (alias/original + not-translated marker), secondary: provider · region · foodKind/brand, basis, "Reference · other market" label when marketClass 2. Coverage footer for selected markets (PARTIAL disclosure). Catalog unavailable banner: "Food list unavailable on this device. You can still enter food directly." Search failure/no result: "Enter ‹query› directly".
### 12.5 Amount (scaled)
Food detail: names (original + alias + language), source/version/attribution link, basis ("per 100 g edible portion"), per-basis nutrient values with qualifiers shown verbatim (`<0.03`, "Not reported"), definition labels. Amount field + unit chips; live computed kcal/macros for consumed amount; "Add to meal"; star = favorite.
### 12.6 Direct entry
"Enter what you ate — totals for the whole portion". Name (required), Energy + unit toggle `kcal | kJ`, Protein g, Carbohydrate g, Fat g (all optional, placeholders "Unknown"). Note under macros: "Leave blank if you don't know." Save to meal. Star = favorite template.
### 12.7 Favorites / copy
Favorites list: use → catalog template goes to Amount (identity checks §3.3), direct template adds item prefilled (editable). Copy meal → date picker → editor kind `copy` (new draft, new operationId on save), items keep snapshots; time defaults `No time` on the new date; amounts editable (recalculated from the snapshot's source values, not the latest catalog). "Use latest food data" = remove + search again (explicit).
### 12.8 Compact vs wide
- Compact (Android width < 600 dp; iOS horizontal `.compact`): single-pane stack: day view → detail sheet → full-screen editor → pushed search → amount.
- Wide (Android ≥ 840 dp or Fold inner/tablet; 600–839 dp: single pane with wider readable column; iOS `.regular`): day view list + meal detail pane; editor as one window with two columns (left search/favorites/recent/direct form, right meal composition + the only Save button). Fold/unfold, rotation, split resize: editor state from controller + draft id; no second save path; focus preserved on the field that had it when possible.
- Keyboard/large text: scroll-to-focused field, Save/Cancel reachable (bottom bar above IME with `imePadding` / iOS safeAreaInset), AX5 / 200% font checks, 48 dp / 44 pt targets, TalkBack/VoiceOver labels on nutrient rows read value + unit + state ("Protein, 20.0 grams known, 1 item not recorded").

### 12.9 Privacy surfaces
No meal content in widget snapshot, notifications, logs, analytics, SavedState payloads (Android `DoseWeekDrafts` holds only `mealDraftId: String?` + section enum), App Group. App lock: existing Android `FLAG_SECURE` when lock enabled and iOS RootView shield on scenePhase cover meal screens (F11 test with lock on).

---

## 13. Localization keys (17 locales; Android `res/values*/nutrition.xml`, iOS `Localizable.xcstrings` namespace `nutrition.*` — add `nutrition.*` to AGENTS rule 2 namespace line)

Android name → iOS key = replace `nutrition_` prefix with `nutrition.` and `_` word separators with `.` groups as listed. Plurals: Android `<plurals>`, iOS plural variations formatted with `locale:`. Placeholders identical sets across locales (both guards).

| Group | Keys (Android names) |
|---|---|
| Entry/nav (6) | `nutrition_section_body`, `nutrition_section_meals`, `nutrition_today_card_title`, `nutrition_today_card_add`, `nutrition_day_add_meal`, `nutrition_day_empty` ("No meals recorded") |
| Day totals (14) | `nutrition_total_energy`, `nutrition_total_protein`, `nutrition_total_carbohydrate`, `nutrition_total_fat`, `nutrition_total_not_recorded` (plural, %d items), `nutrition_total_known_subtotal` (%1$s value, %2$d known), `nutrition_total_missing_items` (plural), `nutrition_total_separate_definitions`, `nutrition_total_unspecified_definition_item`, `nutrition_total_too_many_items`, `nutrition_unit_kcal`, `nutrition_unit_kj`, `nutrition_unit_g`, `nutrition_unit_ml` |
| Definition labels (7) | `nutrition_definition_energy_as_reported`, `nutrition_definition_protein_total`, `nutrition_definition_fat_total`, `nutrition_definition_carbohydrate_total_including_fiber`, `nutrition_definition_carbohydrate_available_excluding_fiber`, `nutrition_definition_carbohydrate_monosaccharide_equivalents`, `nutrition_definition_other_reviewed` (%1$s source name) |
| Meal header (14) | `nutrition_meal_date`, `nutrition_meal_time`, `nutrition_meal_time_none`, `nutrition_meal_time_set`, `nutrition_meal_time_now`, `nutrition_meal_time_not_recorded_section`, `nutrition_meal_kind_breakfast`, `…_lunch`, `…_dinner`, `…_snack`, `…_unspecified`, `nutrition_meal_dst_gap_error`, `nutrition_meal_dst_overlap_choose`, `nutrition_meal_date_change_clears_time` |
| Editor (16) | `nutrition_editor_title_new`, `…_title_edit`, `…_title_copy`, `nutrition_editor_search_food`, `nutrition_editor_enter_directly`, `nutrition_editor_items`, `nutrition_editor_remove_item`, `nutrition_editor_save`, `nutrition_editor_saving`, `nutrition_editor_saved`, `nutrition_editor_save_failed_retry`, `nutrition_editor_item_limit`, `nutrition_editor_subtotal_preview`, `nutrition_editor_close_keep_draft`, `…_close_discard`, `…_close_continue` |
| Conflict/draft (9) | `nutrition_conflict_title`, `nutrition_conflict_stale_body`, `nutrition_conflict_deleted_body`, `nutrition_conflict_open_latest`, `nutrition_conflict_save_as_new`, `nutrition_draft_banner` (%1$s date), `nutrition_draft_resume`, `nutrition_draft_discard`, `nutrition_draft_limit_reached` |
| Search (18) | `nutrition_search_hint`, `nutrition_search_results`, `nutrition_search_favorites`, `nutrition_search_recent`, `nutrition_search_enter_query_directly` (%1$s), `nutrition_search_no_results`, `nutrition_search_loading_index`, `nutrition_search_catalog_unavailable`, `nutrition_search_reference_other_market`, `nutrition_search_not_translated` (%1$s language), `nutrition_search_original_name` (%1$s), `nutrition_search_markets_chip` (%1$s), `nutrition_search_languages_chip` (%1$s), `nutrition_search_region_suggestion` (%1$s country), `nutrition_search_region_use`, `nutrition_search_region_choose`, `nutrition_search_coverage_partial` (%1$s market), `nutrition_search_show_more` |
| Food detail/amount (15) | `nutrition_food_source` (%1$s provider %2$s version), `nutrition_food_region` (%1$s), `nutrition_food_basis_per` (%1$s value %2$s unit), `nutrition_food_basis_edible_portion`, `nutrition_food_kind_generic`, `…_recipe_reference`, `…_branded`, `…_user_entered`, `nutrition_food_value_not_reported`, `nutrition_food_value_qualified` (%1$s raw), `nutrition_amount_label`, `nutrition_amount_unit_serving`, `nutrition_amount_serving_equivalent` (%1$s), `nutrition_amount_unknown_conversion_switch`, `nutrition_amount_add_to_meal` |
| Direct entry (9) | `nutrition_direct_title`, `nutrition_direct_totals_hint`, `nutrition_direct_name`, `nutrition_direct_energy`, `nutrition_direct_protein`, `nutrition_direct_carbohydrate`, `nutrition_direct_fat`, `nutrition_direct_unknown_placeholder`, `nutrition_direct_blank_means_unknown` |
| Favorites/copy/delete (12) | `nutrition_favorite_add`, `…_remove`, `…_updated_source_available`, `…_not_in_current_list`, `…_use_saved_values` (%1$s version), `…_reselect`, `nutrition_meal_copy_to`, `nutrition_meal_delete`, `nutrition_meal_delete_confirm_title`, `nutrition_meal_delete_confirm_body`, `nutrition_meal_edit`, `nutrition_item_entered_by_you` |
| Errors (6) | `nutrition_error_number_format`, `nutrition_error_number_range`, `nutrition_error_name_required`, `nutrition_error_amount_positive`, `nutrition_error_unit_unsupported`, `nutrition_error_generic_retry` |
| Settings/sources (12) | `nutrition_settings_title`, `nutrition_settings_markets`, `nutrition_settings_markets_none`, `nutrition_settings_search_languages`, `nutrition_settings_market_status_verified`, `…_partial`, `…_blocked`, `…_not_run`, `nutrition_settings_data_sources`, `nutrition_sources_license` (%1$s), `nutrition_sources_attribution_heading`, `nutrition_settings_offline_note` |
| Export/backup (10) | `nutrition_export_csv`, `nutrition_export_range`, `nutrition_export_plain_warning`, `nutrition_export_too_large`, `nutrition_export_precision_note`, `nutrition_pdf_excludes_meals`, `nutrition_backup_saved_records_only`, `nutrition_backup_too_large`, `nutrition_backup_near_limit`, `nutrition_drive_backup_too_large` (Android only) |
| A11y (6) | `nutrition_a11y_nutrient_value` (%1$s name %2$s value %3$s unit), `nutrition_a11y_nutrient_state_missing` (plural), `nutrition_a11y_meal_row` (%1$s kind %2$s time %3$s items), `nutrition_a11y_favorite_toggle`, `nutrition_a11y_search_result` (%1$s name %2$s source %3$s market), `nutrition_a11y_saving` |

≈154 keys × 17 locales. Country and language names: platform `Locale.getDisplayCountry/Language(uiLocale)` (no catalog strings). Translation QA: no English copies; check kcal/g symbols unchanged; tr casing; ar RTL; hi Devanagari; zh-Hant real vocabulary; pt-PT ≠ pt-BR.

---

## 14. Performance budget (initial targets, record device/build/data, never relax after measuring)
| Metric | Target | Method |
|---|---|---|
| Warm query p95 (excl. 250 ms debounce) | ≤ 200 ms | 100 fixed queries from release vectors, 3 search locales + 3 markets selected, release build |
| Initial list usable (favorites/recent + field focusable) | ≤ 1 s from Search open | cold process; index may still build |
| First index build (3 locales) | record; target ≤ 1.5 s mid, report low-end | |
| First-open release hash verification | record; target ≤ 2 s low-end, off main thread | |
| Extra peak memory from catalog feature | ≤ 50 MiB | Android `dumpsys meminfo` PSS delta; iOS Instruments/XCTMetric memory |
| Keyboard/render latency in editor | no dropped-frame regressions vs Body sheet; record | |
| Install size delta | record per platform (APK/AAB assets compressed; iOS bundle) | |
| Day view with 100 items | ≤ 16 ms/frame steady scroll, totals ≤ 50 ms | |
Low-end: Android API 24 emulator (evidence type simulator_runtime, not device claim) + any available low-RAM device; iOS oldest iOS 26 simulator class; physical device rows NOT_RUN unless run. Miss → fix or state in release decision.

---

## 15. Test matrix (registry rows → tests)

Evidence: C/S/I automated_test; F/G/E/L per registry; no python_reference as native evidence.

| IDs | Android (JVM `app/src/test/java/com/wonyoungchoi/doseweek/…`, device `app/src/androidTest/java/…`) | iOS (`Packages/DoseDayCore/Tests/DoseDayCoreTests/Nutrition/`, `DoseDayTests/Nutrition/`, `DoseDayUITests/`) |
|---|---|---|
| C01–C40 | `domain/nutrition/NutritionCalculatorGoldenTest` reads test-resources golden | `NutritionCalculatorGoldenTests` |
| S01–S08 + P09–P12 | `NutritionSemanticsGoldenTest`, `DayNutritionPresentationTest` | same names |
| F01 | `data/nutrition/MealStoreTest.doubleSaveSameOperationSingleMeal` + distinct op → 2 | `MealActorIdempotencyTests` |
| F02 | device `MealProcessDeathTest` (injector AFTER_COMMIT_BEFORE_RETURN → `Process.killProcess`, relaunch, retry → 1 meal) | new actor over same on-disk store after commit without ack → retry returns stored result |
| F03 | stale `edit_token` → CONFLICT, both rows intact | stale revision |
| F04 | restore/reset between draft checkpoint and commit → `generation_changed`; late search result dropped | `requireActiveStoreSession`/generation |
| F05 | injector AFTER_FIRST_ITEM throws `SQLiteFullException` → 0 rows, draft intact, retry OK | injector throws in second item → rollback + discard pending |
| F06 | tampered canonical, wrong key, unsupported version (`PAYLOAD_VERSION_WITH_NUTRITION + 1`), orphan item, unreferenced / hash-mismatched source snapshot, revision 2, each §6.1 cap at limit (accept) and limit + 1 (reject) → reject before delete (live rows equal) | `BackupPayloadValidatorTests` nutrition cases, same boundaries |
| F07 | `DatabaseMigrationToNutritionTest` (dump from merged predecessor head) + restore parameterized over **every** `v ∈ SUPPORTED_PAYLOAD_VERSIONS, v < PAYLOAD_VERSION_WITH_NUTRITION` → nutrition empty, other rows equal | `SchemaMigrationTests` V{N-1}→V{N}, `PreMigrationV{N-1}StoreSnapshotTests`, restore loop over every supported payload version below `withNutrition`, `restoreVerificationFailsWhenMealDropped` |
| F08 | `WITH_NUTRITION` payload restore with `CatalogUnavailable` reader → history, favorites visible; banner | same |
| F09 | swap test release B (fixture in test resources only) → meals unchanged; copy new id; favorite not moved | same |
| F10 | date-only meal + zone change (injected `ZoneId`) → same localDate; gap/overlap via resolver | `ExactEditTimeResolver` based |
| F11 | device: lock on, editor open, background → FLAG_SECURE; recreate → draft recovered by id | UI test shield + relaunch resume |
| F12 | `data/export/MealCsvFormatterTest` vectors (`= + - @ ＝ ＋ － ＠`, TAB, CRLF, quotes, `<0.03`, offsets `-04:00`/`+09:00` unprefixed, `-SUM(A1)` prefixed, machine grammar miss → error), output bytes == `meal-csv.v1.example.csv` (BOM, CRLF), cancel deletes temp | `MealCSVExporterTests` |
| G01–G17 | `data/nutrition/catalog/FoodSearch*Test` with real release (G01,G02,G05–G09,G11,G14) + synthetic test releases (G04,G12,G13,G16) + VM tests (G03,G10 formatting, G15 no-network: invariants + airplane device run, G17 stale results) | mirrors; G15 = `check_invariants` network guard + UI test offline |
| G18 | per-locale device journeys (§16) | per-locale UI journeys |
| I01–I05 | synthetic release fixtures for identity map (I01–I04); I05 real/synthetic LOQ row → snapshot qualifier + null | same |
| E01 | verification-manifest rows with source/resource/release hashes | same |
| E02 | checkpoint vs editRevision test; kill after checkpoint restores checkpoint only | same |
| E03 | draft op write failure → no commit; same id diff digest → conflict | same |
| E04 | receipt+meal one transaction; restore rotates generation, deletes drafts | same |
| E05 | reader rejects missing/hash-mismatch/`../` paths; old release intact | `import_food_data_release.py` unit tests (staging, rename, failure keeps old) + runtime verifier tests |
| E06 | same vectors → identical ordered output across 3 runs, shuffled load order; §10.1 edge vectors incl. word-final `Σ`; unknown `searchRulesRevision` → catalog unavailable | same + cross-platform hash |
| E07 | 10,001 items day → too-many state; 250k-row export → TOO_LARGE; paging all rows; backup at 80 % cap → warning; over cap → `BACKUP_TOO_LARGE`, no file; Drive `CloudBackupFailure.TOO_LARGE`, no retry loop | same (no Drive) |
| E08 | backup preference policy per Q1 | same |
| E09 | AAB asset listing + instrumentation AssetManager; no `*golden*`/`queries`/`fixtures`/`machine-draft` in AAB | archive listing + bundle test; same exclusion |
| E10 | guard rejects machine_draft/unverified alias; PASS requires release review evidence refs | guard |
| E11/E12 | ledger discipline, patch lists incl. untracked assets | same |
| D rows | nutrition screens included in existing adaptive checks (Android `check_large_screen_layout`, Fold/resize tests; iOS iPad/AX5 legs) | |
| APP_BUILD (`native_build`) | `./scripts/run_ci.sh` build legs + `./gradlew bundleRelease` on merged tree, SHA recorded | `./scripts/run_ci.sh` from Terminal window + archive build, SHA recorded |
| APP_REGRESSION (`automated_test`, `simulator_runtime`) | full existing JVM + `run_instrumentation_matrix.sh` on merged tree; executed > 0, skipped 0, no expected-value edits | full `run_ci.sh` unit + UI legs, same rules |
| BACKUP_FLOW (test/sim/device) | J-restore (§16) + existing backup suites + §7 Drive digest tests + §6.1 boundary tests | J-restore + existing backup/restore suites + §6.1 budget tests |
| HEALTH_READ (test/sim/device) | regression leg: existing Health Connect read tests unchanged and passing; nutrition adds no HC permission/record type (manifest diff check) | existing HealthKit read tests passing; no new HealthKit types in entitlements/Info.plist diff |
| LEGAL_COPY (`manual_review`) | owner or legal agent reviews privacy policy / data-safety (meal PHI in backups + Drive), attribution/licence screen strings, store copy; evidence = review note with commit SHA + string ids | same + App Privacy label |

Every new test proven red first (break code, watch fail, restore) per both AGENTS.

---

## 16. 425 locale queries and journeys

- 17 locales × (≥20 positive + ≥5 ambiguous/out-of-scope) = ≥425 vectors authored in data repo `nutrition-data/fixtures/queries/<locale>.json` from adopted foods (distinct per locale, not translated copies), copied to test resources only (Android `app/src/test/resources/nutrition/queries/`, iOS `DoseDayTests/Fixtures/Nutrition/queries/`); each file carries `dataReleaseId` + `searchRulesRevision`; test asserts set hash == manifest `queryVectorSetSha256`.
- Android JVM `FoodSearchQueryVectorTest` (parameterized per locale, real release assets + test-resource vectors) and iOS `FoodSearchQueryVectorTests` (bundle) run the same vectors; assertions: expected IDs within `expectInTopK`, forbidden absent, negatives within allowed set / empty, never auto-select; write `search-results-<platform>-<locale>.json` (ordered top-10 + classes). CROSS_PLATFORM: canonical SHA-256 per locale equal. Counts: executed = vector count, skipped 0. A locale without reviewed aliases/foods → its L-row search part `BLOCKED/PARTIAL` with coverage limitation; manual journey still required.
- UI journeys per locale × layout (Android: compact phone API 24 + API 36, wide = expanded emulator/tablet profile; iOS: iPhone standard, iPhone AX5, iPad):
  - J-manual: Body→Meals → Add → Direct (name + kcal in locale digits/decimal) → Save → relaunch → day view shows → Edit (add protein) → Save → Delete → confirm.
  - J-search: Search locale's first positive query → select → amount → Save → totals presentation correct.
  - J-restore: create meal → encrypted backup → reset → restore → meal present (manual & search item), drafts absent.
  - Locale specifics asserted: ar RTL order of value/unit, hi digits, tr `İ` query, de long labels no overflow, zh-Hant strings, pt-PT vs pt-BR separate strings.
  - Android locale switching via per-app locales in test (precedent `docs/BUGFIX_LOCALE_JOURNEYS.md`); iOS `-AppleLanguages`/`-AppleLocale` launch args + accessibility identifiers `nutrition.*`.
- Evidence rows: `L-xx` (automated_test/simulator_runtime), G18; wide/fold physical rows NOT_RUN unless real device.

---

## 17. Exact file / module ownership

### Android (`app/src/main/java/com/wonyoungchoi/doseweek/`)
New:
- `domain/nutrition/NutritionCalculator.kt`, `NutritionSemantics.kt` (ported), `DayNutritionPresentation.kt`, `MealModels.kt` (Meal, MealItem, MealTime, snapshot DTOs, favorite), `MealSnapshotCodec.kt` (canonical JSON, strict, split/assemble §3.2.1), `MealSavePayload.kt` (digest), `search/FoodSearchNormalizer.kt`, `search/NutritionLowercaseTable.kt` (generated), `search/FoodSearchRanker.kt`
- `common/formatting/NutritionDecimalInput.kt`, `common/formatting/NutritionNumberFormatter.kt`
- `data/nutrition/NutritionSchema.kt`, `MealStore.kt` (meals, items, favorites, drafts, receipts, generation), `NutritionContractAssets.kt`, `MealBackupRows.kt`, `NutritionPreferences` accessors (in `data/DoseWeekPreferences.kt`)
- `data/nutrition/catalog/FoodDataReleaseReader.kt`, `FoodDataReleaseVerifier.kt`, `FoodCatalogIndex.kt`, `FoodSearchEngine.kt`, `FoodIdentityResolver.kt`
- `data/export/MealCsvFormatter.kt`
- `features/nutrition/MealsDayContent.kt`, `MealDetailSheet.kt`, `MealEditorScreen.kt`, `FoodSearchScreen.kt`, `FoodAmountSheet.kt`, `DirectEntrySheet.kt`, `MealDraftDialogs.kt`, `NutritionSettingsScreen.kt`, `FoodDataSourcesScreen.kt`, `NutritionTotalsCard.kt`, `NutritionUiModels.kt`, `MealEditorController.kt`, `MealsController.kt`, `MealDraftCodec.kt`
- `res/values*/nutrition.xml` (17), `app/src/main/assets/nutrition/contracts/{nutrition_contract_v3,nutrition_semantics_v1,food_localization_contract_v2}.json` (runtime only)
- `app/src/main/assets/fooddata/<dataReleaseId>/**` — **owned by data-release agent (`android-nutrition-data`)**, app agents read only
Modified (thin): `data/DoseWeekDatabase.kt`, `data/DoseWeekRepository.kt` (`deleteAllTables`, `backupSnapshot`, `replaceAllDataFromBackup`, `deleteAllData`), `data/BackupModels.kt` (§6.1 limits), `data/BackupPayloadCodec.kt`, `data/drive/CloudBackupState.kt` + `CloudBackupService.kt` (`TOO_LARGE`), `app/DoseWeekViewModel.kt` (wire controllers, refresh, CSV callback), `app/DoseWeekDrafts.kt` (`mealDraftId`, `selectedBodySection`), `app/MainActivity.kt` (CSV CreateDocument launcher), `features/body/BodyScreen.kt`, `features/today/TodayScreen.kt`, `features/navigation/DoseWeekUiModels.kt`, `features/navigation/DoseWeekApp.kt`, `features/settings/SettingsScreen.kt`, `features/history/DocumentExportSheet.kt`, `scripts/check_invariants.py`
Tests: `app/src/test/java/.../domain/nutrition/*`, `.../data/nutrition/*`, `.../data/nutrition/catalog/*`, `.../data/export/MealCsvFormatterTest.kt`, `.../data/BackupPayloadNutritionTest.kt`, `app/src/test/resources/nutrition/**` (goldens, presentation fixture, split round-trip, query vectors, synthetic test releases); `app/src/androidTest/java/.../data/DatabaseMigrationToNutritionTest.kt`, `BackupSizeBoundaryDeviceTest.kt`, `MealStoreDeviceTest.kt`, `app/NutritionJourneyTest.kt`, `app/NutritionLocaleJourneyTest.kt`, `app/FoodDataAssetInclusionTest.kt`
Docs: new `docs/NUTRITION.md`; update `docs/ARCHITECTURE.md` (nutrition flow + data release boundary), `docs/CURRENT_HANDOFF.md`, `docs/IOS_UPDATE_NOTES_CODE3.md`

### iOS
New:
- `Packages/DoseDayCore/Sources/DoseDayCore/Nutrition/{NutritionCalculator,NutritionContract,UnsignedDecimalInteger,NutritionSemantics,DayNutritionPresentation,MealSnapshotCodec,MealSavePayload,FoodSearchNormalizer,NutritionLowercaseTable,FoodSearchRanker}.swift`
- `DoseDay/Data/Persistence/Entities/{MealEntity,MealItemEntity,NutritionSourceSnapshotEntity,NutritionFavoriteEntity,NutritionDraftEntity,NutritionOperationReceiptEntity}.swift`, `DoseDay/Data/Persistence/NutritionPersistenceMapping.swift`
- `DoseDay/Data/Services/{FoodDataRelease,FoodCatalogIndex,FoodSearchService,FoodIdentityResolver,MealCSVExporter,NutritionContractResources}.swift`
- `DoseDay/Domain/Models/Meal.swift` (DTOs), `DoseDay/Domain/Services/NutritionDecimalInput.swift`, `NutritionNumberFormatting.swift`
- `DoseDay/Features/Nutrition/{MealsDayView,MealsViewModel,MealDetailSheet,MealEditorSheet,MealEditorViewModel,FoodSearchView,FoodAmountView,DirectEntryView,MealDraftPrompt,NutritionSettingsView,FoodDataSourcesView,NutritionTotalsCard}.swift`
- `DoseDay/Resources/NutritionContracts/{nutrition_contract_v3,nutrition_semantics_v1,food_localization_contract_v2}.json` (runtime only), `DoseDay/Resources/FoodData/<dataReleaseId>/**` + `RELEASE_LOCK.json` (written only by the import script); test-only `DoseDayTests/Fixtures/Nutrition/**`, `Packages/DoseDayCore/Tests/DoseDayCoreTests/Fixtures/Nutrition/**` (goldens, vectors, presentation, split round-trip)
- `scripts/import_food_data_release.py` (+ its tests under `scripts/` like existing `test_*.mjs`, python unittest)
Modified: `DoseDay/Data/Persistence/DoseDaySchema.swift`, `DoseDayModelActor.swift` (MARK Nutrition + `deleteAllEntities` + restore/payload), `DoseDay/Data/Services/BackupCryptoService.swift` (payload fields/version, `payloadTooLarge`), `BackupPayloadValidator.swift` (§6.1 limits), `DoseDay/Data/Services/PreMigrationStoreSnapshot.swift` (StoreVersion `v{N-1}`/current, hash list, manifest allowlist), `DoseDay/App/StoreSessionController.swift` (`canonicalRestoreGraphData` nutrition arrays sorted), `AppPreferences.swift`, `DoseDay/Features/Body/BodyView.swift`, `BodyViewModel.swift`, `DoseDay/Features/Today/TodayView.swift`, `TodayViewModel.swift`, `DoseDay/Features/Navigation/MainTabView.swift` (own `MealsViewModel` as `@State`), Settings export/views, `Localizable.xcstrings`, `scripts/generate_project.py`, `scripts/check_invariants.py`, `AGENTS.md` (namespace line), regenerated `project.pbxproj`
Tests: `Packages/DoseDayCore/Tests/DoseDayCoreTests/Nutrition/*`, `DoseDayTests/Nutrition/{MealActorIdempotencyTests,MealDraftCheckpointTests,MealBackupRestoreTests,MealCSVExporterTests,FoodDataReleaseTests,FoodSearchQueryVectorTests,FoodSearchStaleResultTests,NutritionDecimalInputTests}.swift`, migration cases in `SchemaMigrationTests.swift`, `PreMigrationV{N-1}StoreSnapshotTests.swift`, §6.1 ceilings in `ExpandedRestoreBudgetTests.swift` / `RestoreBudgetProjectionTests.swift`, `DoseDayUITests/NutritionJourneyUITests.swift`, `NutritionLocaleJourneyUITests.swift`
Docs: `docs/NUTRITION.md`, `docs/ARCHITECTURE.md`, `docs/CURRENT_HANDOFF.md`, `docs/ANDROID_PARITY_NOTES.md`

Concurrency with other worktrees: do not touch `features/historyimport`, `data/historyimport`, calendar-bound iOS files; conflicts expected only in `DoseWeekDatabase.kt`, `DoseWeekRepository.kt`, `BackupModels.kt`, `BackupPayloadCodec.kt`, `DoseWeekViewModel.kt`, `SettingsScreen.kt`, `DoseDaySchema.swift`, `DoseDayModelActor.swift`, `BackupCryptoService.swift`, `BackupPayloadValidator.swift`, `PreMigrationStoreSnapshot.swift`, `StoreSessionController.swift`, `generate_project.py`, `Localizable.xcstrings` → rebase after import merges.

---

## 18. Phased implementation order (each phase: red test first, focused verify, invariants, handoff doc update)

| Phase | Scope | Verify (commands exist in repos) | Exit |
|---|---|---|---|
| P0 | Freeze baselines: iOS bugfix merged to main; all stage-2 predecessors merged or ledger rows reserved (§5.3); data release `dataReleaseId` frozen (may lag → P4/P5 BLOCKED, P1–P3 continue) | `git log`, version constants read | recorded SHAs/versions |
| P1 | Pure core both: port calculators, contracts assets + hash tests, presentation fixture, decimal input, exact formatter, normalizer/ranker units with synthetic vectors | Android `./gradlew testDebugUnitTest --tests '*nutrition*'`; iOS `swift test --package-path Packages/DoseDayCore`; both `python3 scripts/check_invariants.py` | C01–C40, S01–S08, P09–P12 PASS both; boundary checks PASS |
| P2 | Direct-entry vertical: schema/migration, store/actor, drafts, receipts, generation, Body→Meals day view, editor (direct only), edit/delete, Today card, strings (ko+en first in-branch but all 17 before phase exit) | Android JVM + `DatabaseMigrationToNutritionTest` + device store tests on API 24 & 36 (owned emulator per AGENTS); iOS `./scripts/run_app_unit_tests.sh DoseDayTests/…Nutrition…`, focused UI iPhone/AX5/iPad (one xcodebuild at a time) | F01–F05, F10, F11, E02–E04 PASS; save→relaunch→edit→delete journey PASS |
| P3 | Backup/restore payload, validator, Drive digest tests, CSV v1, PDF notice, favorites (direct templates), copy | JVM `BackupPayloadNutritionTest`, Drive digest + `TOO_LARGE` tests, CSV byte-fixture tests; `BackupSizeBoundaryDeviceTest` (API 24); iOS validator/actor tests, `PreMigrationV{N-1}StoreSnapshotTests`, restore-graph drop test, §6.1 budget tests; UI backup journey | F06–F08, F12, E07, E08 PASS |
| P4 | Data release consumption: Android reader/verifier + guard; iOS import script, generator folders, lock guard, bundle tests | `check_invariants.py` red/green; AAB/app archive listing; instrumentation asset test | E05, E09, E10, G16, DATA_RELEASE hashes equal; no goldens/vectors in AAB / .app |
| P5 | Search + scaled entry: index, ranking, lifecycle, amount/serving, catalog favorites, identity resolver, markets/languages settings, sources screen, catalog-unavailable | vector tests (425), G/I tests, perf harness (100 queries) on API 24/36 + iOS simulators | G01–G17, I01–I05, F09, E06 PASS; lowercase table identical in pipeline (else `Σ` vectors parity-blocked); perf rows recorded |
| P6 | 17-locale completion + compact/wide journeys + help/VIS entries + docs/architecture/parity notes | Android `./scripts/run_ci.sh` (+ `run_instrumentation_matrix.sh`), iOS `./scripts/run_ci.sh` from Terminal window (not harness background) | L-ko…L-tr, G18, CROSS_PLATFORM search hashes equal, D rows affected re-run |
| P7 | Final integration on merged tree: `full` profile both, LEGAL_COPY manual_review evidence (§15), remote SHA = build SHA | full CI both, matrix, ledger | `overallComplete` only via full profile |

Stop rule per phase: no expected-value edits, no skips, 0-executed ≠ PASS.

---

## 19. Open product questions (not previously decided; independent work continues)

**Q1 — Backup of food market / search-language preferences (E08).** Facts: spec forbids silent market change on restore; E08 requires an explicit policy; prefs are non-PHI.
- A: Not in backup; device-only. Simple; new phone asks again.
- B: In backup; on restore applied only if this device has no confirmed markets; otherwise keep device values and show backup's values in restore preview.
- Recommend **B**.

**Q2 — Meal deletion history.** Facts: administrations keep revision/audit trail + soft delete; spec requires confirm for irreversible delete, no audit requirement for meals.
- A: Hard delete with confirmation, edits overwrite (snapshots immutable per save), no meal revision table.
- B: Append-only `meal_revision` like administrations + soft delete/restore.
- Recommend **A** (simplicity decision UX-20260913-09; smaller backup/migration surface).

**Q3 — Personal food library.** Facts: spec lists "개인식품" in backup and F09; U06 lists favorites/copy only.
- A: Personal foods = favorites/direct templates (immutable ids), no separate editor.
- B: Separate "My foods" editor with per-basis values (scaled math on user data).
- Recommend **A** this release.

---

## 20. Risks
- Release not built yet (no NUTRITION_DATA_RELEASE.md) → layout assumptions may change reader; search/G/I/L rows BLOCKED until frozen.
- Version collisions: import + 3 sibling stage-2 designs claim DB 12 / payload 9 and V6 / payload 8; only the ledger (§5.3) resolves it.
- Backup growth: split form + raised limits give ≈ 10.5 y (Android 32 MiB) / 8.6 y (iOS) at heavy use; if the API 24 memory gate or iOS budget gate fails, horizon drops to ≈ 4 y and `BACKUP_TOO_LARGE` UX is the floor. Archive split is future work.
- Cross-platform normalization drift: pipeline Python `str.lower()` Final_Sigma vs context-free table; Android API 24 ICU (Unicode 8) NFKC vs newer; vectors must include edge scalars; mismatch blocks CROSS_PLATFORM.
- Semantic golden gap for null key + null value; presentation layer compensates — coordinator should log as parity note, not rewrite contract.
- Memory/time on API 24 low-end for index build + hash verification.
- iOS `DoseDayModelActor.swift` already 4,347 lines; nutrition MARK adds more; alternative (widen `withSaveTransaction` access) touches guard intent.
- Android `DoseWeekViewModel.kt` 7,759 lines; keep controllers in `features/nutrition` and only thin wiring there.
- Localized search readiness per locale depends on reviewed aliases; hi/ar/pl/sv etc. may stay PARTIAL; never claim via direct-entry fallback.
- Owner-level policy on Apple health data in files/backup unchanged; nutrition adds PHI to existing opt-in backups (disclosure/legal copy needed later).

---

## 21. Review log (rev 2, 2026-09-15)

Each issue checked against code/specs, read-only. Verdict → change.

| # | Issue | Verdict | Evidence checked | Change |
|---|---|---|---|---|
| 1 | Backup bounds break limits, no growth plan | **Accepted** | Android `BackupModels.kt:445-458` 16 MiB / `MAX_TOTAL_ROWS 500_000`; iOS `BackupPayloadValidator.swift:73` `maxTotalRows 50_000`, text 16 MiB; `BackupCryptoService.swift:448-449` 48 MiB envelope / 32 MiB ciphertext. Remeasured: scaled item 2,409 B Android / 2,959 B iOS incl. columns → 1.7 y to 16 MiB | §3.2.1 split storage (content-addressed source part), §5.1 SQL, §6 wire form, §6.1 byte model table + caps inside row budgets + raise gated by tests + `BACKUP_TOO_LARGE` + Drive `TOO_LARGE`, §7, §13, §15 F06/E07, new fixture `nutrition-backup-size-model.v1.json`. Reviewer's "snapshot only" option measured insufficient alone (2.2 y), so split + raise chosen |
| 2 | iOS schema bump misses 2 touch points | **Accepted** | `ios-import` uncommitted diff: `PreMigrationStoreSnapshot.swift` (StoreVersion v5, current 6.0.0, schema list, allowlist); `StoreSessionController.swift` `canonicalRestoreGraphData` (+ `historyImportProvenance` sorted); current `canonicalRestoreGraphData` lists only clinical arrays | §5.2 five touch points + drop test, §15 F07, §17 Modified/Tests, §18 P3 |
| 3 | Version plan ignores sibling designs | **Accepted** | `calendar-sync.md` DB 12; `schedule-explicit-dates.md` V6/p8 + DB 12/p9; `body-chart-references.md` V6/p8 + DB 12/p9; `android-import` DB 12 / `PAYLOAD_VERSION = 9` | Symbolic versions throughout, §5.3 ledger, test names without numbers, F07 iterates every supported version below `WITH_NUTRITION`, migration dump from merged predecessor head |
| 4 | Goldens ship in app binary | **Accepted** | rev 1 §9.2 put goldens in `app/src/main/assets`; `generate_project.py:47-49` `resource_folders` comment "never the shipping app"; spec §2 "테스트 자산 경로" | Runtime contracts only in assets/Resources; goldens in `app/src/test/resources`, `DoseDayTests/Fixtures/Nutrition`, DoseDayCore `Tests/.../Fixtures/Nutrition`; AAB/.app/source guards §9.2/§9.3, §15 E09 |
| 5 | Query vectors in shipped release dir; layout stale | **Accepted** | `android-nutrition-data` untracked `nutrition-data/{pipeline,contracts,config,aliases/machine-draft,fixtures/queries,releases,reports,tests}`; `releases/` and `fixtures/queries/` empty | §0 row, §9.1 root re-derive note, R01 `queryVectorSetSha256`, R09 outside dir, R10 guard, §16 test-resource vectors |
| 6 | CSV formula rule vs negative offset | **Accepted, fix variant A** | rev 1 rule hit `meal_utc_offset`; fixture row unprefixed | Machine-column grammar exemption (identical both platforms); integer seconds rejected (negative seconds also start with `-`); F12 vectors |
| 7 | CSV fixture lacks BOM/CRLF | **Accepted** | bytes: BOM absent, CRLF 0 | Regenerated: BOM, CRLF 5, bare LF 0, 48 cols, + row `America/New_York -04:00` / `'-SUM(A1)` |
| 8 | Profile rows unmapped | **Accepted** | registry `profiles.{android,ios}.nutrition` has APP_BUILD, APP_REGRESSION, LEGAL_COPY, HEALTH_READ, BACKUP_FLOW; allowed evidence types read from `allowedEvidenceTypes` (no row descriptions exist) | §15 five rows with evidence types; §18 P7 |
| 9 | Named lowercase APIs differ | **Accepted, extended** | Verified locally: Foundation `lowercased(with:)` `ΟΔΟΣ`→`…ς`; plain Swift `lowercased()` → `σ`; Python `str.lower()` → `ς` (pipeline uses it). Java not installed here; JDK Final_Sigma behavior from JDK spec, not run | §10.1 context-free generated table + ς→σ fold on app **and** pipeline (handoff to data agent); Σ vectors parity-blocked until aligned; Unicode 8 guard for API 24 ICU |
| 10 | Ranking not bound to release | **Accepted, renamed** | spec line 289 (rules tied to data release); pipeline uses one `SEARCH_RULES_REVISION = 1` covering normalization + ranking ("search rules r1, E06") | Single `searchRulesRevision` (matches pipeline) instead of separate `searchRankingRevision`; in release rules file, manifest, vector files; unknown → catalog unavailable. §10.3 now ports pipeline order (rev 1 app-invented order dropped) |

Rejected: none. Partial deviations: #9 fix also applied to pipeline side; #10 one combined revision name, not two.
Also corrected while verifying: §0 iOS HEAD now `7e8681b`; §10.1/§10.3 rev 1 rules (NFC, bigrams, 3-level market class) diverged from the pipeline reference and were replaced.
