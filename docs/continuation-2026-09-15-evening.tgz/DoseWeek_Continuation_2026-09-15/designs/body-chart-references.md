# Body chart references — design (CHART-20260913-01, -03, -04)

Status: DESIGN ONLY. No repo edited, built, or run. Written 2026-09-15; revised 2026-09-15 after review (see §13 Review log).

## Baseline (read before implementing)
- **iOS facts in §1 come from branch `codex/v11-bugfix`, local HEAD `7e8681b`, not from `main`.**
  - `origin/main` `990002d` is an ancestor of that head, but it is older: payload `5` / schema `"5.0"`, `CurrentDoseDaySchema = DoseDaySchemaV3`, envelope case list `3, 4, 5`.
  - The branch has payload `7` / `"7.0"`, `DoseDaySchemaV5`, and case list `3, 4, 5, 6, 7`.
  - STATE.json: `ios.push.mainIntegrated=false`, PR #7 DRAFT, remote branch head `a7df1a5`. `status`: "new feature stage waits for genuine main baseline".
  - **Implement only on merged main. First re-verify every iOS line in §1.**
- **Android facts come from detached `origin/main` `79bb210`.** STATE records `remoteMain 2ccd963`, which is an ancestor (7 commits: Drive and Play provenance, host-guard timing; no Body, backup or DB change). Re-check head before implementing.
- **Version numbers are relative.**
  - iOS: `N_schema` = current `CurrentDoseDaySchema` version number, `P_ios` = current `currentPayloadVersion`.
  - Android: `N_db` = current `DATABASE_VERSION`, `P_and` = current `PAYLOAD_VERSION`.
  - This design adds exactly one of each: `+1`.
  - Values at the time of reading: iOS branch V5 / payload 7 (main V3 / payload 5); Android DB 11 / payload 8.
  - The integrator takes the next free numbers after other stage-2 designs.

Shared fixture: `designs/fixtures/body_chart_references_v4.json`
SHA-256 `7ce4e84f1b2c4751b5de54742fa0e9d74f273a99333fd2aff4aad5f9db90e474` (66852 bytes, ASCII, LF, trailing newline; sums in `designs/fixtures/v4.sha256`).
- Generator (reference implementation, Python 3 + zoneinfo): `designs/fixtures/body_chart_references_v4.generator.py` (`--v2` and `--v3` reproduce v2 and v3 byte for byte).
- v4 supersedes v3 (`535ec345…daaee`, 59635 bytes) and v2 (`16982165…4b27f`, 33872 bytes). v2, v3 and their generators stay in place unchanged, and every v2 and v3 case is the start of its v4 section (`changedFromV3` empty). v3 encodes coordinator decision CORE-20260915-01 (§4.3, §13.1); v4 encodes CORE-20260915-07 (§3.2, §4.3, §4.6, §13.2).
- v1 was deleted: it carried date-only samples, a leap-day zoom defect and a derived NICE band.
- Regenerate only with a version bump; never hand-edit.

---

## 0. Owner decisions in scope (do not re-ask)

| ID | Decision | Design consequence |
|---|---|---|
| CHART-20260913-01 | "둘다 지원 사용자 선택으로". Scope: both platforms; the user chooses an official general reference (source and population stated) or a personal target; pinch period control; landscape chart. | Per-metric reference setting (off / official / personal) on **both** platforms; pinch zoom; landscape. |
| CHART-20260913-03 | "감량률과 BMI 등 기준이 있는 신체 지표". Do not invent universal bands for metrics without applicable standards. | Green band: weekly loss rate and BMI only, on both platforms. Android therefore gains a BMI chart series (decided; no longer an open question). Body fat, lean mass, waist, height: never. |
| CHART-20260913-04 | "둘 다 전환, 주당 kg 기본". The % denominator is the interval starting weight. | Rate engine divides by `startKg`; kg default is a display preference. |

Also applies: DESIGN-20260913-13 (keep the design system; verify small/large text, dark, RTL, all locales, backup).

TRANSFER-20260913-12 (import review must confirm a missing administration time; no date-only model) does **not** concern body samples. It is not a basis for date-only body handling.
- Every body sample on both platforms has a non-optional instant: iOS `BodyMetricCacheEntity.recordedAt: Date`; Android `body_record.recorded_at INTEGER NOT NULL`, `DoseWeekDatabase.kt:192`.
- The engine has no date-only input.

---

## 1. Current state (facts from code; iOS = branch, see Baseline)

### iOS
- `DoseDay/Features/Body/BodyViewModel.swift` (present on main; the branch changes 23 lines: health-failure state, import-limit notice, custom-range calendar accessors):
  - `BodyPeriod` 1M=30, 3M=90, 6M=180, 1Y=365, custom.
  - `SelectedMetric`: weight, bmi, bodyFat, leanMass, waist.
  - Units hard-coded (kg, "", %, cm).
  - `filteredSamples` cutoff `now - days*86400`; `deltaChangeText` = last − first.
  - Fetch limit 500 per metric (`AppleHealthMetricCatalog.maximumCachedSamplesPerMetric`).
  - `loadRequestGeneration` and `fetchProjection(for:in:)` present on main and branch.
- `Components/WeightChartView.swift`:
  - Swift Charts `LineMark` + `PointMark`, catmullRom, `palette.accent`.
  - Height 164pt, capped at 246.
  - Accessibility id `body.chart`.
  - The branch adds `.chartXScale(range: .plotDimension(padding:))`.
- `BodyCustomDateRange.swift`:
  - Inclusive local days; `end <= calendar.date(byAdding: .year, value: 5, to: start)`; end ≤ today.
  - The branch extracts `parseInput` (8 or 10 digits).
- Storage `BodyMetricCacheEntity`: `valueSI` (kg for mass), `recordedAt: Date`, `originRaw`, `hiddenAt`, `deletedAt`.
  - HealthKit imports body mass, body fat, lean mass and waist.
  - BMI is manual only.
  - **No height metric.**
- Schema / backup: branch `DoseDaySchemaV5`, payload 7 / `"7.0"`; main V3, payload 5 / `"5.0"`.
  - Payloads 3…current share one authenticated case in `BackupCryptoService.authenticationMode(for:)` (branch `:835-873`); any other value throws `invalidEnvelope`.
  - `DoseDayTests/SideEffectEditTests.swift:196` pins the literal `payloadVersion == 7`.
- `AppPreferences`: UserDefaults, non-PHI only (rule 14).
- `Resources/Info.plist` (same on main): iPhone `UISupportedInterfaceOrientations` = Portrait only; iPad all four. `DoseDayUITests/OrientationUITests.swift` exists.
- **Theme.** `DoseDay/DesignSystem/ThemePalette.swift` has no green or success token.
  - Tokens: accent, background, card, cardSoft, tabBar, border, opaqueSurface, text, secondaryText, subtleText, hairline, track, chip, figureFill/Stroke, zoneFill/Stroke, plus fixed `severityModerate`/`severitySevere`.
  - No `.green` in `DoseDay`.
  - AGENTS rule 10: "Colours come from `ThemePalette`, never from a literal."
  - `DoseDayTests/ThemeTests.swift` pins contrast per accent/material/appearance.
- 17 locales (`REQUIRED_LOCALES`): ko en ja de fr es it nl pt-PT pl sv hi pt-BR ar zh-Hans zh-Hant tr. `body.*` keys: 49 on branch, 48 on main.

### Android
- `features/navigation/DoseWeekUiModels.kt:713`: `BodyMetricUi` = WEIGHT, WAIST, HEIGHT, BODY_FAT, LEAN_BODY_MASS. No BMI.
  - `BodyPeriodUi` 30/90/180/365/CUSTOM.
  - `BodyChartPointUi(x,y)` normalized.
  - `BodyUiState.bmiLabel` KDoc: "never stored, never backed up, and never labelled with a category".
- **Pound rows are already kg when they reach the chart.**
  - `data/DoseWeekRepository.kt` `mapBodyRecord` and `mapManualBodyRecord` (~2771–2815): `if (storedUnit == WeightUnit.POUND && storedWeight != null) storedWeight * KILOGRAMS_PER_POUND to WeightUnit.KILOGRAM`. KDoc: "The UI, chart, visit-prep, and CSV surfaces label every weight in kilograms."
  - `app/DoseWeekViewModel.kt:5989 renderBodyChart` reads `ManualBodyRecord.weightValue` from that mapping.
  - Imported measurements are stored normalized (kg/cm/%).
  - **Nothing to fix; no unit conversion may be added downstream.**
- `renderBodyChart`: manual + non-hidden imports; min/max-normalized y; 4 axis labels; delta last − first.
- `domain/BodyMassIndex.kt`: `of(weightKg, heightCm)` for the same record only; bounds 20–400 kg, 30–280 cm; `Math.round(x*10)/10`; no category.
- `domain/BodyTrendRange.kt`: `MAX_SPAN_YEARS = 5`; `resolve` returns null when `end.isAfter(start.plusYears(5))`.
- `features/body/BodyScreen.kt` `TrendChart`: Compose `Canvas`, accent path and dots, RTL mirror; no gestures or semantics.
- DB `DATABASE_VERSION = 11` (`DoseWeekDatabase.kt:736`).
- Backup:
  - `BackupModels.kt:399` `PAYLOAD_VERSION = 8`.
  - `SUPPORTED_PAYLOAD_VERSIONS` (`:435`) is built from frozen per-version constants, never from `PAYLOAD_VERSION`.
  - Read by `BackupPayloadCodec.kt:82`, `BackupCrypto.kt:171`, `drive/CloudBackupService.kt:430` and `BackupModels.kt:516`.
  - Pinned as `setOf(1..8)` by `BackupPayloadV4Test.kt:172` and `BackupPayloadV5Test.kt:303`.
- `scripts/check_invariants.py` backup-file guards:
  - `:2022`: `BackupModels.kt` / `BackupPayloadCodec.kt` must not carry device-local integration fields.
  - `:2981`: `check_portable_backup_security`.
  - The SHA-256 at `:283-290` is a Play upload artifact record, unrelated.
- **Theme.** `designsystem/theme/ThemePalette.kt`:
  - `DoseWeekAccent` VIOLET/COBALT/TEAL/AMBER/ROSE/MONO, plus fixed `ClinicalWarningColors`. No green or success token.
  - `app/src/test/.../designsystem/theme/DoseWeekThemeTest.kt` pins contrast.
- `DoseWeekPreferences.kt`: SharedPreferences, non-PHI (hard rule 3). `plan_estimate_reference` is device-local and not backed up.
- No orientation lock. 17 locales: `values` (ko) + ar, de, en, es, fr, hi, it, ja, nl, pl, pt-rBR, pt-rPT, sv, tr, zh-rCN, zh-rTW.
- JVM tests: `org.json` is a stub; use `data/drive/DriveJson.kt`.

### Platform divergence
- **BMI series.** iOS BMI is a typed series. Android BMI is derived per manual record with both weight and height (decided parity, §3.3).

---

## 2. Official sources (accessed 2026-09-15)

Rules:
- Quote the source; state its population; never broaden it.
- **A band is drawn only from a numeric range the source itself states.** A single stated threshold is drawn as a threshold line, never widened into a band.
- Cumulative goals are not weekly rates.

### 2.1 Weight-loss rate (weekly)

| Catalog id | Source & URL | Exact statement | Population | Kind / bounds |
|---|---|---|---|---|
| `rate.nhs.2023` | NHS "Tips to help you lose weight", https://www.nhs.uk/live-well/healthy-weight/managing-your-weight/tips-to-help-you-lose-weight/ (reviewed 17 Mar 2023) | "aim to lose 1 to 2lbs, or 0.5 to 1kg, a week" | UK general public | band 0.5–1.0 kg/wk, inclusive |
| `rate.cdc.2025` | CDC "Losing Weight", https://www.cdc.gov/healthy-weight-growth/losing-weight/index.html (reviewed 17 Jan 2025) | "about 1 to 2 pounds a week" | US general public | band 1–2 lb/wk = 0.45359237–0.90718474 kg/wk, inclusive |

### 2.2 Goals that are not weekly rates (facts only, no band)

| Source | Statement | Population |
|---|---|---|
| NHLBI, https://www.nhlbi.nih.gov/health/educational/lose_wt/recommen.htm (updated 11 Dec 2025) | "losing 5% to 10% of your initial weight over the course of about 6 months" | adults with overweight/obesity |
| KSSO via JKMA 2024 review, https://doi.org/10.5124/jkma.2024.67.4.240 | "체중의 5-10%를 6개월 이내에 감량"; "월평균 2-4 kg" (diet effect) | Korean patients with obesity |
| JASSO 肥満症診療ガイドライン2022 | ≥3% in 3–6 months (secondary summary only; primary PDF image-only) | 肥満症 patients; **not shipped** |

No source is GLP-1/GIP specific; UI says "general population information".

### 2.3 BMI (adult)

| Catalog id | Source & URL | Exact statement | Population | Kind / bounds |
|---|---|---|---|---|
| `bmi.who.adult` | WHO fact sheet, https://www.who.int/news-room/fact-sheets/detail/obesity-and-overweight (8 Dec 2025) + GHO, https://www.who.int/data/gho/data/themes/topics/topic-details/GHO/body-mass-index | "overweight is a BMI greater than or equal to 25"; GHO "BMI < 18.5" underweight | adults 18+ | band 18.5 ≤ BMI < 25.0 |
| `bmi.cdc.adult` | CDC, https://www.cdc.gov/bmi/adult-calculator/bmi-categories.html (19 Mar 2024) | "Healthy Weight 18.5 to less than 25"; "adults 20 and older" | US adults 20+ | band 18.5 ≤ BMI < 25.0 |
| `bmi.nice.ng246.general` | NICE NG246 rec 1.9.10, https://www.nice.org.uk/guidance/ng246/chapter/Identifying-and-assessing-overweight-obesity-and-central-adiposity (updated 8 Jan 2026) | "Classify … if they are not in the groups covered by recommendation 1.9.11: healthy weight: BMI 18.5 kg/m2 to 24.9 kg/m2" | adults not in 1.9.11 groups | band 18.5 ≤ BMI < 25.0, label "18.5–24.9" |
| `bmi.nice.ng246.lowerThreshold` | NICE NG246 rec 1.9.11 (same URL; curl re-read 2026-09-15) | "…use lower BMI thresholds as a practical measure of overweight and obesity: overweight: BMI 23 kg/m2 to 27.4 kg/m2 obesity: BMI 27.5 kg/m2 or above" — **no lower or healthy range stated; 1.9.10 explicitly excludes these groups** | adults with South Asian, Chinese, other Asian, Middle Eastern, Black African or African–Caribbean background | **threshold line at 23.0, no fill** (Q7) |
| `bmi.ksso.2022` | KSSO 2022, https://doi.org/10.7570/jomes23031; Table 1 via JKMA 2024 | "overweight as a BMI ≥23 … obesity as a BMI ≥25"; Table 1 "Normal 18.5-22.9" | Korean adults ≥18 | band 18.5 ≤ BMI < 23.0 |
| `bmi.jasso` | JASSO, https://www.jasso.or.jp/data/magazine/pdf/chart_A.pdf | "18.5≦～＜25 普通体重" | Japan (JASSO) | band 18.5 ≤ BMI < 25.0 |

- KSSO reaffirmed ≥25 in November 2024: https://general.kosso.or.kr/html/?pmode=BBBS0001300004&smode=view&seq=1429
- **WHO 2004 Asian consultation** (https://doi.org/10.1016/S0140-6736(03)15268-3):
  - "WHO BMI cut-off points should be retained as international classifications"
  - action points 23.0/27.5/32.5/37.5
  - Context text only; not a band.

### 2.4 No band: body fat % (insufficient evidence, sex-specific), waist (sex-specific or needs height), lean mass, height.

### 2.5 Colour and contrast source
W3C WCAG 2.2 Understanding SC 1.4.11 Non-text Contrast, https://www.w3.org/WAI/WCAG22/Understanding/non-text-contrast.html (accessed 2026-09-15):
- "The visual presentation of the following have a contrast ratio of at least 3:1 against adjacent color(s): … Graphical Objects";
- for graphs, "you need to discern the lines and shapes".

Consequence: band edges (the non-colour cue) must reach ≥3:1 against the card and against the band fill. Label text ≥4.5:1 (existing app floor).

### 2.6 Source-access limits
- NICE and Lancet returned 403 to WebFetch; read with curl and Europe PMC.
- WHO TRS 894 unreachable.
- MHLW not cited.

### 2.7 Region / standard choice
- **Fact:** device region, language and medication pack do not establish family background.
- **Option A (rec):** no default; the list is sorted by device region; nothing is preselected.
- **Option B:** preselect by region.

---

## 3. Product behaviour

### 3.1 Chart modes
- **Weight:** segmented **Measurements | Weekly change** (transient, default Measurements).
  - Weekly change uses the unit toggle **kg/week | %/week** (preference, default kg) and the reference per §3.2.
- **BMI:** value line + reference per §3.2.
- **Other metrics:** unchanged; no reference row.

### 3.2 Reference setting (per metric `weightLossRate`, `bmi`)
The row reads "Reference: <label> · <source>". Tapping it opens a sheet:
- **Off**
- **Published general reference:** source, population, exact range, reviewed date, "Open source" link.
- **My own target:** lower/upper. Rate: kg/week or %/week. BMI: kg/m². lower == upper draws a single line. The point cue is inclusive at both bounds (CORE-20260915-01, §4.3).

**Drawing (new theme tokens, §3.2.1; no literals):**
- **Band kind:**
  - fill `referenceBandFill` over the plot;
  - dashed `referenceBandEdge` rules at both edges;
  - label in `palette.text` pinned at the leading edge: "18.5–22.9 · KSSO", "0.50–1.00 kg/week · NHS".
  - Half-open bands print the upper bound as the source prints it (22.9 KSSO, 24.9 NICE general, "below 25" WHO/CDC/JASSO).
- **Threshold kind** (NICE 1.9.11 under rec Q7-A):
  - no fill;
  - one dashed `referenceBandEdge` rule at 23.0;
  - label "23 · NICE NG246 1.9.11 lower threshold".
- **Personal target:** band rendering, label "My target".

**Unit mismatch:**
- Official kg/lb band shown in %/week → stepped per-interval band: bounds_% = bounds_kg / startKg × 100, plus the note `body.reference.convertedPercent` (Q1).
- Personal % target shown in kg → × startKg / 100.
- Personal kg target shown in %/week → / startKg × 100, the same formula as the official band (CORE-20260915-07, symmetric).
- Either personal conversion with an interval start weight that is not finite and positive is **unavailable** for that interval: no band, no point cue, no throw (CORE-20260915-07; fixture `targetMembership.*StartUnavailable`).

**Point cue** (band):
- inside = filled circle; above = hollow up-triangle; below = hollow down-triangle.
- Spoken "within / above / below reference range".

**Point cue** (threshold):
- at or above = hollow up-triangle; below = hollow down-triangle.
- Spoken "at or above / below reference line".

**No category words** (normal, overweight, obese, healthy) anywhere (Q4).

**Always-visible disclaimer:** "General population information from <source> for <population>. Not advice about your treatment; your clinician may set a different target." Never "safe"; passes `CLINICAL_LOCALE_PATTERNS`.

#### 3.2.1 Reference colour tokens (both platforms, fixed per appearance, never accent-derived)
The owner asked for green. Neither palette has one; the precedents for fixed non-accent colours are iOS `severityModerate` and Android `ClinicalWarningColors`.

| Token | Light | Dark | Use |
|---|---|---|---|
| `referenceBandEdge` | `#1E7B3C` | `#4CC38A` | dashed edge rules, threshold rule, off-scale marker |
| `referenceBandFill` | `#1E7B3C` @ 0.12 | `#4CC38A` @ 0.16 | band fill |

**Contrast** (WCAG relative luminance; Python, scratchpad; opaque grounds only):
- Light, against white, `#F2F2F5`, `#F4F5F9`, `#EFEFF2`:
  - edge vs surface ≥ 4.63;
  - edge vs fill composited on those ≥ 3.96;
  - text `#101114` vs fill ≥ 14.08.
- Dark, against `#1C1C1E`, `#0B0B0D`, `#07070A`, black, white@0.10 on black:
  - edge ≥ 7.68;
  - edge vs fill ≥ 5.70;
  - text `#F5F5F7` vs fill ≥ 11.60.
- **Not yet proven** on tinted gradient cards over the deepest accent bloom stop. The tests below decide; adjust the hex values, never the floors.

**Ownership:**
- iOS `DoseDay/DesignSystem/ThemePalette.swift`: two `public let` stored properties set in `resolve` by `isDark`.
- Android `designsystem/theme/ThemePalette.kt`: `object ReferenceBandColors { EdgeLight, EdgeDark }` + two `DoseWeekPalette` vals.

**Tests:**
- iOS `ThemeTests` and Android `DoseWeekThemeTest`, for all 6 accents × 3 materials × light/dark:
  - edge ≥3.0 vs the card composited on the deepest bloom stop (reuse the existing "cards keep body and secondary text legible on the deepest bloom stop" helper);
  - edge ≥3.0 vs fill composited on that card;
  - `text` ≥4.5 vs fill on that card.
- Also assert both tokens are identical for every accent (fixed).

**Note:** the TEAL accent line (`#12A594`) is visually close to the green band. The non-colour cues (dashed edges, shapes, label) carry meaning; UI snapshots must include TEAL.

### 3.3 BMI series (decided parity)
- **iOS:** stored manual `bmi` samples (unchanged).
- **Android:** new `BodyMetricUi.BMI` chip, shown when ≥1 manual `body_record` has both weight and height.
  - Point = `BodyMassIndex` of that record's `weightValue` (already kg from `mapManualBodyRecord`; **no further conversion**) and `heightCentimeters`.
  - Never mixes records or imports (hard rule 9).
  - Fixture `bmiFromSameRecord` input is kg only.

### 3.4 Pinch period control
- **Inline card:** pinch only. **Expanded chart:** pinch + horizontal pan.
- Continuous preview; commit on gesture end per §4.6.
- Preset segment selected only if span == preset and end == today; else `custom` via `BodyCustomDateRange` / `BodyTrendRange`, which stay the only validators.
- **Accessibility:** existing segments and date fields remain.
  - iOS `.accessibilityAdjustableAction` (increment = zoom in one preset step).
  - Android `semantics { customActions }`.
  - Both announce `body.chart.visibleRange`.
- **Reduce Motion:** jump, no animation.

### 3.5 Landscape
- **Android:** landscape with height < 480dp → two panes: chart (weight 1.6) | controls (weight 1). State lives in `BodyUiState`. Expand button → `FullScreenSheet`.
- **iOS** (Q5, rec A): expand button → `.fullScreenCover` `BodyChartFullScreenView`.
  - `DoseDay/App/OrientationLock.swift` (`@MainActor @Observable` mask, default `.portrait`).
  - `DoseDayApp` `@UIApplicationDelegateAdaptor`; `application(_:supportedInterfaceOrientationsFor:)` returns the mask (`UIApplication.h:456`).
  - On appear: `.allButUpsideDown`, `setNeedsUpdateOfSupportedInterfaceOrientations()` (`UIViewController.h:376`), `requestGeometryUpdate(.iOS(interfaceOrientations: .landscape))` (`UIWindowScene.h:30`).
  - Restore on disappear.
  - Proven by `OrientationUITests`. If the plist intersects the mask, add landscape to the iPhone plist and keep other screens portrait through the delegate; record which was needed.
- **Full-screen layout:** full-width chart, y labels on, top bar (close, mode, unit, reference), bottom visible-range text, safe areas, capped chrome.

---

## 4. Engines (shared semantics = fixture `conventions`)

### 4.1 Units & rounding
- lb→kg = 0.45359237 exactly; used **only** for catalog bounds in `lbPerWeek` (CDC) and unit-conversion cases.
- **Engine sample input is kg.** Android converts once at repository read; iOS `valueSI` is kg. The engine never converts sample units.
- `halfUpEpsilon(x, dp) = sign(x)·floor(|x|·10^dp + 0.5 + 1e-9)/10^dp`. A zero result is +0, so −0.004 prints 0.00, never −0.00 (fixture `band.*.tinyGain…`, `rate.tinyGainIsNoChange`).
- Display: rate 2 dp; BMI 1 dp.
- Personal targets stored as canonical text.

### 4.2 Weekly rate
1. **Eligible:** manual + imported not hidden and passing the existing validator, with a finite positive kg. A 0 kg or negative sample is dropped before the daily winner is chosen (`rate.nonPositiveWeightsDropped`).
2. **Day key:** local calendar date of the sample instant in the device zone (tests pin the zone).
3. **Daily winner:** max of (instant, manual=1/imported=0, id).
4. **Start:** latest earlier daily point with `gapDays ≥ 7`. None → `insufficientHistory`. `gapDays > 28` → `gapTooLong`; the line breaks.
5. `lossKgPerWeek = (startKg − endKg)·7/gapDays`; `lossPercentPerWeek = lossKgPerWeek/startKg·100`.
6. **Direction** from the 2-dp rounding: loss / gain / noChange. Display the absolute value + direction word.
7. **Lookback:** fetch from `visibleStart − 28 d` (iOS `fetchProjection(for:in:)` interval; Android has all rows).
8. **Headline:** "0.57 kg/week loss · vs Aug 9 (11 days)", or the status text.
9. Existing `isSelectedPeriodHistoryIncomplete` notice still applies.

### 4.3 Reference membership
- `kind: band`: round the value and the bounds (lb → kg first) to `displayDecimals`; compare with inclusivity → `inside | above | below`.
- `kind: threshold`: `lower = null`; round the value and upper → `atOrAboveThreshold` (v > u, or v == u and not upperInclusive) else `belowThreshold`.
- **Personal target (CORE-20260915-01).** Inclusive at both bounds. The value and the bounds are compared in the chart unit after conversion; a %/week target in kg mode uses bound × startKg / 100, and a kg/week target in % mode uses bound / startKg × 100 (§3.2; CORE-20260915-07, symmetric). Both are rounded to the target rule's decimals (rate 2, BMI 1), the same rounding as official bands → `inside | above | below`. lower == upper draws a single line, and a value on it is `inside`. A conversion whose interval start weight is not finite and positive makes the target unavailable for that interval (fixture expected `null`): nothing drawn, nothing thrown, on both platforms (iOS `kilogramsPerWeek(fromPercentPerWeek:)` / `percentPerWeek(fromKilogramsPerWeek:)` return nil; Android `percentToKilogramsPerWeek` / `kilogramsToPercentPerWeek` replace their `require` with a nullable result). Fixture section `personalTargetMembership` (29 cases).
- **Percent band** (DESIGN-20260915-10): none for a BMI reference, a threshold, or a start weight that is not finite and positive (`percentBand.*HasNone`).

### 4.4 Setting resolution
- No row → `none`.
- Official id not in catalog → `unavailable` (row preserved, notice).
- Order: an official row without an id → `invalid`; an unknown id → `unavailable` before any metric check; official mode ignores personal fields; personal mode ignores the official id and needs a known unit; any other mode → `invalid`.
- → `invalid` (no band, row not rewritten) when any of these holds:
  - the catalog metric ≠ the row metric;
  - the metric is outside {weightLossRate, bmi};
  - the personal target is invalid.

### 4.5 Personal target validation

| Metric / unit | Min | Max | Decimals |
|---|---|---|---|
| weightLossRate kg/week | 0.01 | 5.00 | ≤2 |
| weightLossRate %/week | 0.01 | 5.00 | ≤2 |
| bmi kg/m² | 10.0 | 60.0 | ≤1 |

- Both bounds required; lower ≤ upper.
- Errors: `missingBound`, `invalidDecimal`, `outOfRange`, `lowerAboveUpper`, `unsupportedUnit`.
- Locale parsing reuses the existing strict parsers. Canonical text `[0-9]{1,3}(\.[0-9]{1,dp})?`, ASCII digits only. Check order: unit, both bounds present, grammar, range (lower ≥ min and upper ≤ max only), order.

### 4.6 Zoom
Pure `(today, spanDays, end, cumulativeScale, panDays) → {period, spanDays, start, end, rateLookbackStart}`:
1. `end = min(end + panDays, today)` (**pan first**, so the clamp uses the final end).
2. `minStart = end.minusYears(5)` (Feb 29 → Feb 28, as `LocalDate.minusYears` and `Calendar.date(byAdding: .year, value: -5)` both do). If `minStart.plusYears(5) < end`, `minStart += 1 day`.
3. `maxSpan = days(minStart, end)`; `raw = clamp(spanDays / scale, 7, maxSpan)`. A scale that is not a finite positive number counts as 1: the span is unchanged and the pan still applies (`zoom.zeroScaleKeepsSpan`, `zoom.negativeScaleKeepsSpanPanApplies`). A `spanDays` at or below zero is clamped to 7 by the same rule, never thrown on (CORE-20260915-07; Android `BodyChartWindow.commit` drops its `require(spanDays > 0)`; `zoom.zeroSpanClampsToSevenDays`, `zoom.negativeSpanClampsToSevenDays`).
4. Snap to preset p if |raw − p| ≤ 0.15p; else round half-up to whole days; `span = min(span, maxSpan)`.
5. `start = end − span`; preset only if end == today; `rateLookbackStart = start − 28 d`.

Checked 2026-09-15:
- Swift Foundation gives `2028-02-29 − 5y = 2023-02-28`, `+5y = 2028-02-28`, so the unguarded start is rejected. Start `2023-03-01` is accepted (1826 days).
- Android `BodyTrendRange.resolve` uses the same `plusYears(5)` comparison.
- Fixture cases `zoom.outClampsLeapDay` and `zoom.panOntoLeapDayReclampsSpan`.

### 4.7 State machine
```
ReferenceSetting(metric):
  None --choose official(id)--> Official(id) --id missing after restore/downgrade--> Unavailable(id)
  None --save valid target--> Personal(unit, lo, hi)
  Official|Personal|Unavailable --Off--> None (row deleted)
  Official <--> Personal (row replaced, one transaction)
  restore(backup) --> replace all rows (validated); invalid row rejects whole restore

ChartView (ViewModel):
  metric ∈ chips; mode ∈ {level, rate} (rate only for weight; metric change resets to level)
  rateUnit ∈ {kgPerWeek, percentPerWeek} (preference)
  window = Preset(p) | Custom(start,end)
  gesture: Idle --pinch--> Pinching(span0,end0,scale) --end--> commit(zoom) --> Idle
           Idle --pan (expanded)--> Panning(end0,days) --end--> commit --> Idle
           Pinching|Panning --metric change | reload | cancel--> Idle (no commit)
  presentation: Inline <--> Expanded
```
A committed zoom bumps iOS `loadRequestGeneration` like `updateCustomRange()`.

---

## 5. Data model, migration, backup

### 5.1 Why DB + backup
- A personal target and a family-background-linked choice are PHI-adjacent. Preferences forbid PHI.
- The user expects them to survive restore.
- The kg/% unit is non-PHI → preference, not backed up.

### 5.2 iOS (on merged main; numbers relative)
- **New** `DoseDay/Data/Persistence/Entities/BodyChartReferenceSettingEntity.swift`:
```swift
@Model public final class BodyChartReferenceSettingEntity {
  @Attribute(.unique) public var metricKey: String      // "weightLossRate" | "bmi"
  public var modeRaw: String                            // "official" | "personal"
  public var officialReferenceID: String?               // ≤64, [a-z0-9.]+
  public var personalUnitRaw: String?                   // "kgPerWeek" | "percentPerWeek" | "kgPerM2"
  public var personalLowerText: String?
  public var personalUpperText: String?
  public var updatedAt: Date
}
```
- `DoseDaySchema.swift`: `DoseDaySchemaV(N_schema+1)` = current models + the entity; `CurrentDoseDaySchema` points to it; add `.lightweight(V N_schema → V N_schema+1)`.
- `DoseDayModelActor`: fetch / save / clear; `withSaveTransaction`; backup mutation state; included in local reset; not touched by Health cache clear.
- `BackupCryptoService.swift`:
  - `BackupPlaintextPayload.bodyChartReferenceSettings: [BackupBodyChartReferenceSetting]?` (older payloads decode nil = no rows).
  - `currentPayloadVersion = P_ios+1`, `currentSchemaVersion = "\(P_ios+1).0"`.
  - **Add `P_ios+1` to the `authenticationMode(for:)` authenticated case list** (branch: `case 3, 4, 5, 6, 7:` → `case 3, 4, 5, 6, 7, 8:`; extend the comment). Without it every new backup throws `invalidEnvelope` on restore.
  - Restore replaces rows in the same transaction.
- `BackupPayloadValidator.swift`: ≤2 rows, unique metric, enums, id pattern, field exclusivity, §4.5; unknown id allowed.
- `AppPreferences.swift`: `bodyRateUnit` (`"body.rateUnit"`, default `"kgPerWeek"`).
- **Tests touched:**
  - `SideEffectEditTests.swift:196` literal `7` → `BackupCryptoService.currentPayloadVersion` or the new literal;
  - new test: an envelope written at `P_ios+1` round-trips through `authenticationMode` and restore;
  - `P_ios` payload decodes with nil settings;
  - `BackupV2MigrationTests.swift:609` (`current+1` rejected) keeps working unchanged.

### 5.3 Android (numbers relative)
- `DoseWeekDatabase.kt`: `DATABASE_VERSION = N_db+1`; `createVersion<N_db+1>Tables(db)` in `onCreate` and `onUpgrade (oldVersion < N_db+1)`:
```sql
CREATE TABLE body_chart_reference_setting (
  metric TEXT NOT NULL PRIMARY KEY CHECK (metric IN ('weightLossRate','bmi')),
  mode TEXT NOT NULL CHECK (mode IN ('official','personal')),
  official_reference_id TEXT CHECK (official_reference_id IS NULL OR length(official_reference_id) BETWEEN 1 AND 64),
  personal_unit TEXT CHECK (personal_unit IS NULL OR personal_unit IN ('kgPerWeek','percentPerWeek','kgPerM2')),
  personal_lower TEXT CHECK (personal_lower IS NULL OR length(personal_lower) BETWEEN 1 AND 8),
  personal_upper TEXT CHECK (personal_upper IS NULL OR length(personal_upper) BETWEEN 1 AND 8),
  updated_at INTEGER NOT NULL,
  CHECK ((mode='official' AND official_reference_id IS NOT NULL AND personal_unit IS NULL AND personal_lower IS NULL AND personal_upper IS NULL)
      OR (mode='personal' AND official_reference_id IS NULL AND personal_unit IS NOT NULL AND personal_lower IS NOT NULL AND personal_upper IS NOT NULL))
)
```
- `DoseWeekRepository.kt`: model; read / upsert / delete; snapshot export + restore replacement.
- `BackupModels.kt`:
  - `BackupBodyChartReferenceRow`; `DoseWeekBackupSnapshot.bodyChartReferenceSettings = emptyList()`;
  - `PAYLOAD_VERSION = P_and+1`;
  - new frozen `PAYLOAD_VERSION_WITH_BODY_CHART_REFERENCES = P_and+1`;
  - **append that constant to `SUPPORTED_PAYLOAD_VERSIONS`** (never `PAYLOAD_VERSION`);
  - legacy versions decode empty; validator per §5.2.
- `BackupPayloadCodec.kt`: gate on `PAYLOAD_VERSION_WITH_BODY_CHART_REFERENCES`; encode/decode after the last section (append-only).
- **Tests touched:** `BackupPayloadV4Test.kt:172` and `BackupPayloadV5Test.kt:303` expected sets gain `P_and+1`; new codec round-trip at `P_and+1`; `P_and` decodes empty.
- `DoseWeekPreferences.kt`: `KEY_BODY_RATE_UNIT = "display.bodyRateUnit"`.
- **Guard impact:** `scripts/check_invariants.py:2022` (new row carries no device-local integration field) and `:2981` (`check_portable_backup_security` file set unchanged). Re-run both; no SHA pin to update there.

### 5.4 Not in backup
Chart mode, zoom, expanded state, rate unit.

---

## 6. File ownership

### iOS (`/private/tmp/doseweek-v11-20260913/ios`, merged main)

| File | Change |
|---|---|
| `Packages/DoseDayCore/Sources/DoseDayCore/BodyChartReferences.swift` (new) | Foundation-only: `BodyReferenceCatalog` (fixture `referenceCatalog`, incl. `kind`), `BodyReferenceRounding.halfUpEpsilon`, `BodyWeeklyRateEngine` (input: id, instant, kg, source, eligible, hidden; injected `Calendar`), `BodyReferencePosition` (band + threshold), `BodyPersonalTargetValidator`, `BodyReferenceSettingResolver`, `BodyChartZoom` |
| `Packages/DoseDayCore/Package.swift` | test target `resources: [.copy("Fixtures")]` |
| `Packages/DoseDayCore/Tests/DoseDayCoreTests/Fixtures/body_chart_references_v4.json` (byte copy) | shared fixture |
| `Packages/DoseDayCore/Tests/DoseDayCoreTests/BodyChartReferencesFixtureTests.swift` (new) | SHA-256 assert; all sections except `bmiFromSameRecord` (present, N/A on iOS) |
| `DoseDay/DesignSystem/ThemePalette.swift` | `referenceBandEdge`, `referenceBandFill` (§3.2.1) |
| `DoseDayTests/ThemeTests.swift` | §3.2.1 contrast tests |
| `DoseDay/Data/Persistence/Entities/BodyChartReferenceSettingEntity.swift` (new), `DoseDaySchema.swift`, `DoseDayModelActor.swift` | §5.2 |
| `DoseDay/Data/Services/BackupCryptoService.swift` (constants + `authenticationMode` case list), `BackupPayloadValidator.swift`, `AppPreferences.swift` | §5.2 |
| `DoseDay/Features/Body/BodyViewModel.swift` | mode, unit, rate series, settings, zoom, lookback, a11y |
| `DoseDay/Features/Body/BodyView.swift` | controls, reference row, expand, disclaimer |
| `DoseDay/Features/Body/Components/WeightChartView.swift` | `RectangleMark` band in `referenceBandFill`; dashed `RuleMark` in `referenceBandEdge`; threshold `RuleMark`; point symbols; `LineMark(series:)` gaps; `.accessibilityChartDescriptor`; `MagnifyGesture` |
| `DoseDay/Features/Body/Components/BodyReferenceSheet.swift` (new) | §3.2 |
| `DoseDay/Features/Body/Components/BodyChartFullScreenView.swift`, `DoseDay/App/OrientationLock.swift` (new), `DoseDay/App/DoseDayApp.swift` | §3.5 |
| `DoseDay/Resources/Localizable.xcstrings` | §7 × 17 |
| `scripts/check_invariants.py` | fixture SHA pin; `body.reference.*` category-word and "safe" guards |
| `scripts/generate_project.py` | run after adding app/test files |
| `DoseDayTests/BodyViewModelReferenceTests.swift` (new), `SideEffectEditTests.swift`, backup tests, `DoseDayUITests/BodyChartReferenceUITests.swift` (new), `OrientationUITests.swift` | §8 |
| `docs/ARCHITECTURE.md`, `docs/ANDROID_PARITY_NOTES.md` | Body section |

### Android (`/private/tmp/doseweek-v11-20260913/android`)

| File | Change |
|---|---|
| `app/src/main/java/com/wonyoungchoi/doseweek/domain/BodyChartReferences.kt` (new) | same engine set; kg-only input; `BodyChartZoom` → `BodyTrendRange` + preset |
| `domain/BodyMassIndex.kt` | add unrounded `raw(weightKg, heightCm)`; `of()` delegates |
| `designsystem/theme/ThemePalette.kt` | `ReferenceBandColors`; `referenceBandEdge`, `referenceBandFill` on `DoseWeekPalette` |
| `app/src/test/.../designsystem/theme/DoseWeekThemeTest.kt` | §3.2.1 contrast tests |
| `data/DoseWeekDatabase.kt`, `DoseWeekRepository.kt` (settings only; **`mapBodyRecord` / `mapManualBodyRecord` unchanged**), `BackupModels.kt` (+ `SUPPORTED_PAYLOAD_VERSIONS`), `BackupPayloadCodec.kt`, `DoseWeekPreferences.kt` | §5.3 |
| `features/navigation/DoseWeekUiModels.kt` | `BodyMetricUi.BMI`; `BodyChartModeUi`; `BodyRateUnitUi`; `BodyReferenceUi` (label, source, population, disclaimer, kind, state); `BodyBandSegmentUi(xStart,xEnd,yLow?,yHigh)`; `BodyChartPointUi` + `position`, `segment`; `visibleRangeLabel`; actions `SelectBodyChartMode`, `SelectBodyRateUnit`, `OpenBodyReference`, `SaveBodyReference`, `ClearBodyReference`, `CommitBodyZoom(scale)`, `CommitBodyPan(days)`, `ToggleBodyChartExpanded` |
| `app/DoseWeekViewModel.kt` `renderBodyChart` | BMI series from `record.weightValue` as-is; rate series; y-range includes band; band/threshold segments; zoom via `BodyTrendRange`; lookback |
| `features/body/BodyScreen.kt` | Canvas band/threshold + dashed edges + shapes; `Modifier.transformable(..., canPan = { false })` inline (foundation 1.12.0 `Transformable.kt:99`); commit on `isTransformInProgress` false (`TransformableState.kt:68`); semantics; two-pane |
| `features/body/BodyReferenceSheet.kt`, `features/body/BodyChartFullScreen.kt` (new) | §3.2, §3.5 |
| `app/src/main/res/values*/strings.xml` (17) | §7 |
| `scripts/check_invariants.py` | fixture SHA pin; copy guards; re-run `:2022`, `:2981` |
| `app/src/test/resources/fixtures/body_chart_references_v4.json` (byte copy) | load via classloader, parse via `DriveJson.parse` |
| `app/src/test/java/com/wonyoungchoi/doseweek/domain/BodyChartReferencesFixtureTest.kt` (new) | all sections |
| `BackupPayloadV4Test.kt`, `BackupPayloadV5Test.kt`, `app/src/test/.../data/BodyChartReferenceBackupTest.kt` (new), `androidTest/.../data/DatabaseMigrationBodyChartReferenceTest.kt` (new), `androidTest/.../features/body/BodyChartReferenceUiTest.kt` (new) | §8 |
| `docs/ARCHITECTURE.md` | Body references, BMI series, rate |

---

## 7. Localization keys (17 locales; iOS key / Android name)

**Rules:**
- no English as translation;
- positional placeholders;
- plural variations (ar 6, pl 4);
- locale number formatting;
- source names are catalog strings.

| # | iOS key | Android name | English source |
|---|---|---|---|
| 1 | body.chart.mode.level | body_chart_mode_level | Measurements |
| 2 | body.chart.mode.rate | body_chart_mode_rate | Weekly change |
| 3 | body.rate.unit.kgPerWeek | body_rate_unit_kg_per_week | kg/week |
| 4 | body.rate.unit.percentPerWeek | body_rate_unit_percent_per_week | %/week |
| 5 | body.rate.value.loss | body_rate_value_loss | %1$@ loss |
| 6 | body.rate.value.gain | body_rate_value_gain | %1$@ gain |
| 7 | body.rate.value.noChange | body_rate_value_no_change | No change |
| 8 | body.rate.window (plural) | body_rate_window (plurals) | vs %2$@ (%1$d days) |
| 9 | body.rate.insufficientHistory | body_rate_insufficient_history | Weekly change needs two measurements at least 7 days apart. |
| 10 | body.rate.gapTooLong | body_rate_gap_too_long | Not calculated across gaps longer than 28 days. |
| 11 | body.reference.row | body_reference_row | Reference: %1$@ |
| 12 | body.reference.none | body_reference_none | None |
| 13 | body.reference.sheet.title | body_reference_sheet_title | Reference range |
| 14 | body.reference.mode.off | body_reference_mode_off | Off |
| 15 | body.reference.mode.official | body_reference_mode_official | Published general reference |
| 16 | body.reference.mode.personal | body_reference_mode_personal | My own target |
| 17 | body.reference.personal.label | body_reference_personal_label | My target |
| 18 | body.reference.personal.lower | body_reference_personal_lower | From |
| 19 | body.reference.personal.upper | body_reference_personal_upper | To |
| 20 | body.reference.personal.error.missingBound | body_reference_personal_error_missing | Enter both values. |
| 21 | body.reference.personal.error.invalidDecimal | body_reference_personal_error_decimal | Use up to %1$d decimal places. |
| 22 | body.reference.personal.error.outOfRange | body_reference_personal_error_range | Enter a value from %1$@ to %2$@. |
| 23 | body.reference.personal.error.lowerAboveUpper | body_reference_personal_error_order | "From" must not be above "To". |
| 24 | body.reference.band.label | body_reference_band_label | %1$@ · %2$@ |
| 25 | body.reference.position.inside | body_reference_position_inside | within reference range |
| 26 | body.reference.position.above | body_reference_position_above | above reference range |
| 27 | body.reference.position.below | body_reference_position_below | below reference range |
| 28 | body.reference.disclaimer | body_reference_disclaimer | General population information from %1$@ for %2$@. Not advice about your treatment; your clinician may set a different target. |
| 29 | body.reference.convertedPercent | body_reference_converted_percent | Converted from kg/week using each interval's starting weight. |
| 30 | body.reference.unavailable | body_reference_unavailable | This reference is not available in this app version. |
| 31 | body.reference.reviewed | body_reference_reviewed | Source reviewed %1$@ |
| 32 | body.reference.openSource | body_reference_open_source | Open source |
| 33 | body.reference.asianActionPointsNote | body_reference_asian_action_points_note | A 2004 WHO expert consultation kept the international cut-offs and did not set separate cut-offs for each Asian population. |
| 34–39 | body.reference.source.{nhs,cdc,who,nice,ksso,jasso} | body_reference_source_{…} | NHS · CDC · WHO · NICE (NG246) · Korean Society for the Study of Obesity · Japan Society for the Study of Obesity |
| 40–47 | body.reference.population.{adultsGeneralUK, adultsGeneralUS, adults18International, adults20US, adultsUKLowerThresholdBackgrounds, adultsUKGeneral, koreanAdults18, japanJasso} | body_reference_population_{…snake} | general public (UK) · general public (US) · adults 18 and over · adults 20 and over (US) · adults with a South Asian, Chinese, other Asian, Middle Eastern, Black African or African-Caribbean family background (UK) · adults not in those groups (UK) · Korean adults 18 and over · Japan (JASSO classification) |
| 48–55 | body.reference.range.{catalog id} | body_reference_range_{id snake} | 0.5–1 kg a week · 1–2 lb a week · 18.5 to below 25 (WHO) · 18.5 to below 25 (CDC) · 18.5–24.9 (NICE 1.9.10) · **23 (NICE 1.9.11 lower threshold)** · 18.5–22.9 (KSSO) · 18.5 to below 25 (JASSO) |
| 56 | body.chart.expand | body_chart_expand | Expand chart |
| 57 | body.chart.close | (reuse `common_close` if present, else body_chart_close) | Close |
| 58 | body.chart.zoomIn | body_chart_zoom_in | Zoom in |
| 59 | body.chart.zoomOut | body_chart_zoom_out | Zoom out |
| 60 | body.chart.visibleRange | body_chart_visible_range | Showing %1$@ – %2$@ |
| 61 | — | body_metric_bmi | BMI (iOS keeps its literal) |
| 62 | body.bmi.sameRecordNote (Android only) | body_bmi_same_record_note | BMI appears for records that include both height and weight. |
| 63 | body.reference.position.atOrAboveLine | body_reference_position_at_or_above_line | at or above reference line |
| 64 | body.reference.position.belowLine | body_reference_position_below_line | below reference line |

Key 53 must not be translated with an overweight/obesity category word: it is the threshold value plus its citation. The catalog test fails if any id lacks a range, population or source key.

---

## 8. Tests

### Shared fixture
- Byte copy of `body_chart_references_v4.json` (66,852 B); assert SHA-256 `7ce4e84f1b2c4751b5de54742fa0e9d74f273a99333fd2aff4aad5f9db90e474` in each test and each `check_invariants.py` (sums in `designs/fixtures/v4.sha256`; generator `body_chart_references_v4.generator.py`, `--v2` / `--v3` reproduce the earlier files byte for byte). The file carries `changedFromV3` (empty for v4).
- **Sections** (v2 counts first; every v2 and v3 case unchanged):
  - `referenceCatalog` (8; ids, kind, bounds, inclusivity, decimals, populationKey);
  - `unitConversion` (3);
  - `bmiFromSameRecord` (6, kg input; Android only);
  - `weeklyRate` (5 + 3 = 8: trailing window; >28-day gap; DST + same-day last-wins + gain; zone boundary + tie + hidden + ineligible; no change; v3: 0/negative kg dropped, tiny gain is noChange, same-instant same-source ordinal id);
  - `bandMembership` (17 + 5 = 22 incl. 4 NICE threshold; v3: −0.004/−0.04 round to +0, −0.005 rounds to −0.01);
  - `percentBandConversion` (2 + 4 = 6; v3 expected null for BMI, threshold, 0 and negative start weight);
  - `personalTargetValidation` (10 + 11 = 21; v3: ASCII grammar, check order, inclusive limits);
  - `referenceSettingResolution` (7 + 10 = 17; v3: resolution order, ignored fields);
  - `zoom` (10 + 5 + 4 = 19 incl. 2 leap-day; v3: 0/negative scale, half-day rounding, snap tolerance edge; v4: `spanDays` 0 and negative clamp to 7, with end not today and with a pan);
  - `personalTargetMembership` (18 + 11 = 29; v3, CORE-20260915-01: kg, percent, percent target in kg mode, lower == upper, BMI; v4, CORE-20260915-07: percent target in kg mode with start 0 / negative → `null`, kg target in percent mode — inside, rounded-lower inclusive, rounds below lower, upper inclusive, rounds above upper, NHS-like bounds at 92 kg equal to `percentBand.nhsAt92kg`, single line — and start 0 / negative → `null`).
- **Comparison:** 6-dp values within 5e-7; display strings exact; zones pinned per case.

### iOS
- Core fixture test.
- **App:**
  - rate mode lookback;
  - reference save / clear / restore;
  - unit default kg;
  - zoom commit writes the custom range;
  - metric switch resets mode;
  - generation guard;
  - lightweight migration current → current+1 (`LegacyBodyStoreFixtures` pattern);
  - `P_ios` payload → nil settings;
  - `P_ios+1` envelope round-trips through `authenticationMode` + restore;
  - validator rejects duplicate or mixed rows;
  - unknown id → unavailable;
  - `ThemeTests` §3.2.1.
- **UI** (standard, `--ax5`, `--device ipad`):
  - KSSO band + disclaimer;
  - NICE 1.9.11 threshold line and label;
  - personal target errors;
  - toggles;
  - adjustable zoom;
  - expand → landscape → close → portrait;
  - Arabic RTL;
  - dark;
  - TEAL accent snapshot.

### Android
- **JVM:**
  - fixture test;
  - `BodyMassIndex` existing tests;
  - **`renderBodyChart`: a POUND `body_record` (via repository read) reaches WEIGHT and BMI points as kg exactly once** (e.g. 200 lb → 90.718474 kg, BMI 28.0 at 180 cm; never 41.15 kg);
  - BMI chip availability;
  - % mode band segments;
  - codec `P_and` → empty, `P_and+1` round-trip;
  - `SUPPORTED_PAYLOAD_VERSIONS` pins updated;
  - validator;
  - `DoseWeekThemeTest` §3.2.1.
- **Instrumented API24 + API36:**
  - DB N_db → N_db+1 migration;
  - pinch `performTouchInput { pinch }`;
  - customActions;
  - landscape two-pane;
  - TalkBack labels;
  - RTL;
  - restore replaces settings.
- **Localization guards:** 17 locales per key; placeholders; plurals; no category words / "safe" in `body.reference.*`.

---

## 9. Edge cases
- **Too few points:** fewer than 2 daily points → `insufficientHistory`. BMI band still drawn with 1 point.
- **Nothing visible:** all points only in the lookback → status text, no empty band alone.
- **Y-domain:** union(data, band or threshold) padded 5%. A band or threshold far from the data is clamped with an off-scale text marker "↓ 18.5–22.9" in `referenceBandEdge`.
- **% stepped band:** a segment spans [previous point x, this point x]. The first segment starts at its interval start.
- **Gain:** a loss band reads `below`. Neutral copy, no celebration.
- **Import cap 500:** arithmetic on loaded rows; the notice stays.
- **Hide / clear Health cache:** recompute; settings untouched.
- **Zone change:** day keys recomputed on reload.
- **Restore:** newer backup with an unknown id → unavailable (preserved). Older backup → none.
- **Catalog changes** → new id; never change the numbers behind a stored id. Changing NICE 1.9.11 from threshold to band after Q7 = new id.
- **Record-only mode:** references work.
- **AX5:** reference row wraps; label moves below the chart on collision.
- **Leap day:** end or today on Feb 29 → §4.6 clamp; both validators accept.
- **Android pound rows:** already kg at read. Any later refactor that reads `body_record` directly must convert once (guarded by the §8 JVM test).

---

## 10. Open questions (facts → 2 options → recommendation)

- **Q1. % mode with an official kg band.**
  - A: stepped converted band + note.
  - B: hide it in % mode.
  - **Rec A.**
- **Q2. Cumulative goals** (NHLBI/KSSO 5–10% in 6 months; JASSO 3%).
  - A: no band v1.
  - B: 6-month cumulative % view.
  - **Rec A.**
- **Q3.** *Resolved, not asked.* Android BMI chip from same-record weight+height is required by CHART-20260913-01 (both platforms) and -03 (BMI). §3.3.
- **Q4. Category words on the band.**
  - A: range + source only.
  - B: source category term.
  - **Rec A.**
- **Q5. iPhone landscape.**
  - A: full-screen chart alone unlocks landscape.
  - B: app-wide.
  - **Rec A.**
- **Q6. Default reference.**
  - A: none; list sorted by region.
  - B: preselect.
  - **Rec A.**
- **Q7. NICE NG246 1.9.11 (lower-threshold groups).**
  - Facts:
    - 1.9.11 states only thresholds: overweight 23–27.4, obesity ≥27.5.
    - 1.9.10's "healthy weight 18.5–24.9" applies to adults "not in the groups covered by recommendation 1.9.11".
    - NICE prints no lower or healthy range for these groups. The owner said "do not invent universal bands".
  - A: threshold line at 23 only (no green fill), label "23 (NICE NG246 1.9.11 lower threshold)", positions at-or-above / below.
  - B: derived band 18.5 to <23, labelled "below 23 (NICE 1.9.11 threshold); 18.5 lower edge from 1.9.10", with the derivation disclosed in the source sheet.
  - **Rec A.** It follows the source-stated rule (§2); the KSSO band already covers Korean adults with a stated 18.5–22.9 range.
  - Fixture v2 encodes A. Choosing B means a new catalog id and fixture v3.

---

## 11. Risks
- **iOS baseline:** facts are from unmerged `codex/v11-bugfix`. If PR #7 changes or is not merged, re-verify §1/§5.2 (schema/payload numbers, `authenticationMode` case list, Body files) on main.
- **Sources:**
  - JASSO weight-loss goal unverified → excluded.
  - WHO band rests on fact sheet + GHO (TRS 894 unreachable).
- **Palette values:** green token hex values are proven only on opaque grounds. Tinted-bloom contrast tests may force darker or lighter values.
- **TEAL accent:** its line is close to the green band; non-colour cues are mandatory.
- **iOS orientation:** unlock depends on the delegate mask vs the plist on 26.5 → UI test decides.
- **Version numbers:** collide with other stage-2 designs → relative numbering; integrator assigns.
- **Copy:** must pass clinical wording guards in 17 locales; "reference range" ≠ "normal range"; NICE threshold label must not become a category word.
- **Gestures:** pinch inside a vertical ScrollView conflicts; inline card is pinch-only.
- **Android head drift:** 79bb210 vs STATE 2ccd963 (ancestor, no Body change) → re-check.
- **Source drift:** sources change; review dates are pinned per id.

## 12. Implementation order
1. Core engines + shared fixture v2 tests (iOS Core, Android domain) — no UI.
2. Theme tokens `referenceBandEdge` / `referenceBandFill` + ThemeTests / DoseWeekThemeTest (all accents × materials × appearances).
3. Android BMI series (same record, `weightValue` as-is) + JVM test "POUND row → kg exactly once" (no conversion code added).
4. Persistence + backup (iOS schema +1, payload +1 incl. `authenticationMode` case; Android DB +1, payload +1 incl. `SUPPORTED_PAYLOAD_VERSIONS` + V4/V5 test pins) + migration/backup tests.
5. Reference sheet + band/threshold rendering + non-colour cues + disclaimer; 17-locale strings + guards.
6. Rate mode + unit preference + lookback.
7. Pinch/pan zoom (leap-day clamp) + accessibility actions.
8. Landscape: Android two-pane + full-screen; iOS cover + orientation lock + OrientationUITests.
9. Full CI both platforms (AX5, iPad, API24/36, RTL, dark, TEAL), docs.

---

## 13. Review log (2026-09-15)

All 9 findings were verified against code or a primary source. **All confirmed; none rejected.**

| # | Finding | Verdict | Evidence checked | Change |
|---|---|---|---|---|
| 1 | Android POUND chart bug claim false | Confirmed | `DoseWeekRepository.kt` `mapBodyRecord` / `mapManualBodyRecord` convert POUND→KILOGRAM at read (KDoc names the chart); `DoseWeekViewModel.kt:5989 renderBodyChart` reads `ManualBodyRecord.weightValue` | Bug claim, fix step, CHANGELOG edge and "values change" risk removed. Added JVM test "POUND row → kg exactly once". Engine and fixture input are now kg-only (rate case renamed `rate.dstSameDayLastWinsAndGain`, BMI case `bmi.recordReadFromPoundRow`), so no second conversion exists anywhere. |
| 2 | iOS facts from unmerged branch | Confirmed | `git show origin/main` (990002d): payload 5 / "5.0", `CurrentDoseDaySchema = DoseDaySchemaV3`, case `3, 4, 5`. Local HEAD 7e8681b (not 4c3e594 as v1 of this doc said): payload 7, V5. STATE `mainIntegrated=false`, PR #7 DRAFT | Baseline section added; versions written relative (`N+1`, `P+1`); main-vs-branch deltas listed in §1. |
| 3 | No green token; colour ownership undefined | Confirmed | iOS `ThemePalette.swift` and Android `ThemePalette.kt` token lists have no green/success; iOS AGENTS rule 10 | §3.2.1: fixed `referenceBandEdge` / `referenceBandFill` tokens on both platforms, hex values with computed WCAG contrast on opaque grounds, W3C SC 1.4.11 cited, ThemeTests / DoseWeekThemeTest contrast tests over all accents × materials × appearances, files in §6, step 2 of §12. |
| 4 | iOS payload +1 restore would throw; Android supported set | Confirmed | `BackupCryptoService.swift:835-873` `case 3, 4, 5, 6, 7` / default throw; `BackupModels.kt:435` set used at `BackupPayloadCodec.kt:82`, `BackupCrypto.kt:171`, `CloudBackupService.kt:430`; also found `SideEffectEditTests.swift:196` literal 7 and `BackupPayloadV4Test.kt:172` / `V5Test.kt:303` set pins | §5.2 case-list edit + round-trip test + literal test update; §5.3 new frozen constant appended to set + pin updates. |
| 5 | Date-only body samples do not exist | Confirmed | TRANSFER-20260913-12 text (administration import, no date-only model); iOS `recordedAt: Date`; Android `recorded_at INTEGER NOT NULL` (:192) | `precision` / `localDate` removed from engine input, conventions, winner key and §0/§4.2. Fixture case `rate.dateOnlyRanksBeforeTimedSameDay` removed (v2). |
| 6 | NICE 18.5–<23 band derived, not stated | Confirmed | NICE NG246 curl re-read: 1.9.11 states only 23–27.4 / ≥27.5; 1.9.10 applies to adults "not in the groups covered by recommendation 1.9.11" (so the 18.5 edge is not even from an applicable rec) | Catalog `kind: threshold` (line at 23, no fill); key 53 relabelled; new position keys 63–64; Q7 with facts, 2 options, rec. Fixture v2 encodes rec A with 3 threshold cases. |
| 7 | Leap-day zoom clamp invalid; generator crash | Confirmed | Python `date(2028,2,29).replace(year=2023)` → ValueError; Swift Foundation run: −5y = 2023-02-28, +5y = 2028-02-28 < end → `BodyCustomDateRange` rejects; `BodyTrendRange.resolve` uses the same `plusYears(5)` test (Java runtime not installed; semantics per `LocalDate` clamp) | §4.6 rule as proposed, plus pan applied **before** the clamp (otherwise a pan onto Feb 29 re-breaks it). Fixture cases `zoom.outClampsLeapDay`, `zoom.panOntoLeapDayReclampsSpan`; Swift check confirms start 2023-03-01 accepted. |
| 8 | Android guard line reference wrong | Confirmed | `check_invariants.py:283-290` = Play `version_code` 9 artifact SHA; `:2022` backup-file integration-field guard; `:2981` `check_portable_backup_security` | §5.3 / §6 point at `:2022` / `:2981`; no SHA pin claim. |
| 9 | Q3 re-asks decided point | Confirmed | CHART-20260913-01 scope "Both platforms"; CHART-20260913-03 "감량률과 BMI 등"; Android `BodyMetricUi` has no BMI | Q3 marked resolved; §0 / §3.3 state the Android BMI chip as decided. |

Other changes made during verification:
- Fixture renamed v1 → v2 (v1 json + generator deleted; SHA `620aa28f…` retired).
- Android head 79bb210 confirmed a descendant of STATE `2ccd963`.

### 13.1 Fixture v3 (2026-09-15, core-engines parity closure)

Both core-engine lanes copied v2 (iOS `ios-core` 7274d52, Android `android-core` a0c3398), so v3 is a new file: `body_chart_references_v3.json`, 59,635 B, `535ec345…daaee`.

- **Coordinator decisions.** CORE-20260915-01 (the personal target "My target" cue is inclusive at both bounds; value and bounds are compared in the chart unit after unit or percent conversion and rounded to the rule's display decimals, as official bands are in §4.3; lower == upper draws a single line) is the new section `personalTargetMembership` and §4.3. CORE-20260915-02 (explicit-date occupancy) belongs to `schedule-explicit-dates.md` and does not touch this file.
- **Reference changes, each matching what both engines already implement.**
  - Samples with kg ≤ 0 are dropped.
  - A zero rounding result is +0.
  - A zoom scale that is not a finite positive number counts as 1.
  - A percent band is null for BMI, a threshold, or a non-positive start weight.
  - Target grammar is `[0-9]`; v2 used Python `\d`, which also accepts other scripts' digits, and no v2 case had any.
  - Setting resolution is computed instead of hand-written. The generator asserts that the 7 v2 expectations are equal.
  - `--v2` reproduces v2 byte for byte.
- **Added.** 3 weeklyRate, 5 bandMembership, 4 percentBandConversion, 11 personalTargetValidation, 10 referenceSettingResolution, 5 zoom, 18 personalTargetMembership.
- **Not pinned.**
  - NaN or infinite kg, scale or start weight (no JSON form).
  - Zoom `spanDays ≤ 0`: Android `require` throws, iOS clamps to 7. This divergence needs a decision.
  - A kg/week personal target shown in %/week mode: §3.2 names only % → kg.
  - A %/week target converted with a non-positive start weight: iOS `kilogramsPerWeek(fromPercentPerWeek:)` returns nil, Android `percentToKilogramsPerWeek` throws.
  - Same-instant ties between ids outside the Basic Multilingual Plane: Swift compares UTF-8, Kotlin UTF-16.
  - `halfUpEpsilon` with more than 9 decimals: Android `require`.

### 13.2 Fixture v4 (2026-09-15, coordinator decision CORE-20260915-07)

New file `body_chart_references_v4.json` (66,852 B, `7ce4e84f…e474`, sums in `v4.sha256`); v2 and v3 files and generators untouched. Generator `body_chart_references_v4.generator.py`; `--v2` and `--v3` regenerate the earlier files byte for byte (checked). Two runs are byte-identical.

- **Coordinator decision.** CORE-20260915-07: zoom `spanDays ≤ 0` clamps to the 7-day minimum (no throw); a %/week target converted to kg with an interval start weight ≤ 0 is unavailable (no throw); a kg/week target shown in % mode converts symmetrically with the interval-start denominator. Same on both platforms. This closes three "not pinned" items of §13.1.
- **Reference changes.** `zoom` already clamped `spanDays ≤ 0` (raw = clamp(spanDays / scale, 7, maxSpan)); the cases pin it. `target_membership` returns `null` instead of raising when a rate conversion has no usable start weight, and gains the kg → % branch (bound / startKg × 100). The generator asserts that the kg → % bounds of an NHS-like 0.5–1.0 kg target at 92 kg equal `percentBand.nhsAt92kg` (0.54–1.09). **No v3 expectation changed** (`changedFromV3` empty; canonical-JSON compare of the 107 shared cases: 0 differences).
- **Added.** `zoom` (4): 0 and −30 days clamp to 7 (`custom`, ending today); 0 with end not today; −1 with a pan (pan still applies). `personalTargetMembership` (11): % target in kg mode at start 0 / −80 → `null`; kg target 0.5–1.0 in % mode at 80 kg (0.625–1.25 → rounded 0.63–1.25): 0.9 inside, 0.625 rounds onto the lower bound (inside), 0.6249 below, 1.25 inside, 1.2551 above; at 92 kg 0.54 inside on the lower bound; 0.5–0.5 at 100 kg single line, 0.504 inside; kg target at start 0 / −80 → `null`.
- **Consumers.** iOS: `BodyReferenceUnits.percentPerWeek(fromKilogramsPerWeek:)` already returns nil for an unusable start; membership must return nil (unavailable) rather than fail. Android: `BodyChartWindow.commit` drops `require(spanDays > 0)`; `percentToKilogramsPerWeek` / `kilogramsToPercentPerWeek` return null (or the membership caller checks the start weight first) instead of `require`.
- **Still not pinned.** NaN or infinite kg, scale, span or start weight (no JSON form). Same-instant ties between ids outside the Basic Multilingual Plane. `halfUpEpsilon` with more than 9 decimals (Android `require`). A BMI target in any unit other than kg/m² (validation already rejects it; no chart conversion exists).
