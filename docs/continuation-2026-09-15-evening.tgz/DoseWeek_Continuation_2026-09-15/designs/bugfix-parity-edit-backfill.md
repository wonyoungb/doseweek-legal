# Bugfix parity: edit and backfill (ED01-ED12, PR01-PR12)

Read-only pass, 2026-09-15 (rev 2 after verifier review; see Review log). iOS `codex/v11-bugfix` @ 93ae0e2 (clean). Android `main` @ 79bb210 (clean).
Requirement sources: `01_BUGFIX_BOTH_PLATFORMS.md` §4-5, `specs/DISCOVERABILITY_AND_HELP.md`, `requirements/review_feedback_cases_v2.json` (ED/PR rows), `acceptance_registry.json` U16/U17, STATE.json decisions `RECORD_ONLY_WITHOUT_TREATMENT_PLAN_20260913`, `RECORD-DRAFT-PROCESS-EXIT`, `DESIGN-20260915-02`.
Paths: `ios:` = `/private/tmp/doseweek-v11-20260913/ios/`, `and:` = `/private/tmp/doseweek-v11-20260913/android/app/src/main/java/com/wonyoungchoi/doseweek/`, `andT:` = `.../android/app/src/androidTest/java/com/wonyoungchoi/doseweek/`. Line numbers are at the SHAs above.

Nothing was built or run. The test states in the table come from `requirements-coverage.json` (CI 4c3e594 for iOS; results from the 79bb210 era for Android), not from a new run.

## Summary table

| ID | Verdict | Deviating side | One-line reason |
|---|---|---|---|
| ED01 | PARITY_OK | - | visible Edit on each admin/body/symptom card, both |
| ED01b | DIVERGENCE | iOS (UI only) | deleted-state Restore and admin Delete are swipe-only on iOS; Android visible buttons |
| ED02 | PARITY_OK | - | same-UUID edit + second-same-day UI test on both (coverage map stale for iOS) |
| ED03 | PARITY_OK | - | in-place update + append revision with reason, both |
| ED04 | DIVERGENCE | iOS | no jump to new date/record after date move; notice only for plan-linked schedule outcomes |
| ED05 | PARITY_OK | - | stale token/expected-event reject + in-flight guard, both |
| ED06 | PARITY_OK | - | reason required (free text both), unchanged save = no revision, both |
| ED07 | PARITY_OK | - | edit never touches inventory ledger, both |
| ED08 | PARITY_OK | - | reanchor only when unique latest; completed/skipped kept, both |
| ED09 | PLATFORM_DIFFERENCE_ALLOWED | - | imported rows read-only both; "correct in original app" in in-app Edit guide both; placement differs |
| ED10 | PLATFORM_DIFFERENCE_ALLOWED | - | Android kind filter + "hides all" + clear; iOS has no History filter to hide records |
| ED11 | DIVERGENCE | iOS (Android partial) | owner decision: draft survives process death; iOS keeps it only in view state |
| ED12 | PARITY_OK | - | same meaning in History/backup; neither CSV carries the revision trail; full round-trip test gap both |
| PR01 | PARITY_OK | - | "Add administration on this date" on any past or today date, both |
| PR02 | PARITY_OK | - | planless fact when no plan governs the date; plan start never moved, both |
| PR03 | DIVERGENCE | iOS (low) | iOS preselects the active plan's medicine even for dates before the plan |
| PR04 | PARITY_OK | - | ordering/latest/interval/recent sites by administeredAt, both |
| PR05 | PARITY_OK | - | older backfill cannot move schedule (unique-latest guard), both |
| PR06 | DIVERGENCE | Android (low) | Android computes scheduleChanged but drops it; only generic "saved" after commit |
| PR07 | PARITY_OK | - | inventory opt-in off by default, linked active plan only, idempotent; copy differs slightly |
| PR08 | PARITY_OK | - | future blocked; short past interval = warning + explicit confirm, both |
| PR09 | DIVERGENCE | iOS | tapped past day prefills local 00:00; toggle alone lets it save untouched = arbitrary midnight. Android blank time |
| PR10 | DIVERGENCE | iOS (UI only) | data guard parity; iOS record-to-missed-slot / reopen-skip is swipe-only |
| PR11 | PARITY_OK | - | request-ID retry = one row; distinct same-day facts kept, both. Edge: changed input after unknown commit handled differently |
| PR12 | UNVERIFIABLE | - | bounded paging honest both; large-volume thresholds/perf not exercised |

Totals over the 24 IDs: 15 PARITY_OK, 2 PLATFORM_DIFFERENCE_ALLOWED, 6 DIVERGENCE (iOS: ED04, ED11, PR03, PR09, PR10; Android: PR06; Android partial on ED11), 1 UNVERIFIABLE. Plus one extra row, ED01b (DIVERGENCE, iOS UI), which covers the deleted state from the 01 §4.1 edit support table.
Rev 1 printed "14 PARITY_OK", but its own table had 15. That count is corrected here.

## Details

### ED01: visible edit entry
- iOS: History day list → event card → visible `common.edit` button `history.editEvent.<uuid>` (`ios:DoseDay/Features/History/HistoryView.swift:773-777`, helper `:951-960`); metric `:881-885`, symptom `:898-901`. Swipe edit is also kept (`:540-546`). Opens `EditAdministrationSheet` (`:173-185`).
- Android: `DayItemCard` visible TextButtons Edit `history.edit.<id>` (`and:features/history/HistoryScreen.kt:533-543`), side effect `:593-597`, body `:643-647`.
- a11y: text labels on both (not icon-only). Strings in 17/17 locales on both (`common.edit`; `common_edit`).
- Tests: iOS `AuditHistoryCorrectionUITests.testVisibleAdministrationEditPreservesIdentityAndAuditWithoutSwipe` (`ios:DoseDayUITests/AuditHistoryCorrectionUITests.swift:111`); Android `SideEffectEditJourneyTest`, `BugfixLocaleJourneyTest[BLOC-*]`.

### ED01b: deleted state and delete action (DIVERGENCE, iOS, UI only)
- Requirement: 01 §4.1 says an action that only works if you know a swipe or long-press is not done (`01_BUGFIX_BOTH_PLATFORMS.md:69`). The edit support table includes the deleted state (`:73`). DISCOVERABILITY says "스와이프/길게 누르기만 유일한 경로가 아니어야 함". This is the same class of issue as PR10, so it gets the same verdict.
- iOS: an administration's Restore (deleted) and Delete (active) exist only in `.swipeActions` (`ios:DoseDay/Features/History/HistoryView.swift:524-538`). A deleted card shows only the `common.status.deleted` badge (`:747-752`). The visible button row renders Edit only when `!event.isDeleted` (`:773-777`), so a deleted card has no visible control apart from Details.
- Android: visible `Restore` TextButton on deleted cards (`and:features/history/HistoryScreen.kt:520-530`, tag `history.restore.<id>`) and visible `Delete` on active cards (`:540-551`, tag `history.delete.<id>`).
- Data meaning is the same on both (soft delete and restore of the same ID). Only the entry point differs.
- Not checked: whether iOS metric and symptom delete are also swipe-only.
- Minimal fix: in `HistoryView.swift` `eventRow`, add a visible Restore button (deleted) and a visible Delete button (active) that reuse the swipe closures (`:525-535`), with identifiers. Add a UI test that restores without swiping.

### ED02: second of several same-day doses
- iOS: edit binds `selectedEventForEdit` = that DTO and actor updates by `id` (`ios:DoseDay/Features/History/HistoryViewModel.swift:483-517`). UI test `testSecondSameDayAdministrationEditPreservesFirstAndBodyNeighbor` (`AuditHistoryCorrectionUITests.swift:164`, added in 42001b7, part of the 8/8 pass at CI 4c3e594). The coverage-map note that this is "not separately established" is stale.
- Android: `UPDATE ... WHERE id = ? AND edit_token = ?` (`and:data/DoseWeekRepository.kt:975-980`). UI test `SameDayAdministrationEditUiTest.editingTheSecondSameDayCardChangesOnlyItsUuidAndPreservesTheFirstAndBodyRecord` (`andT:features/history/SameDayAdministrationEditUiTest.kt:66`). Not in the coverage map.

### ED03: correction keeps identity and audit
- iOS: `updateAdministrationWithScheduleOutcome` appends `AdministrationRevisionEntity` with reason and revisionNumber+1 (`ios:DoseDay/Data/Persistence/DoseDayModelActor.swift:1972-2050`). Not delete→insert. Test `RecordOnlyAdministrationTests.editIdentityAndNoOp` (`ios:DoseDayTests/RecordOnlyAdministrationTests.swift:172-202`).
- Android: `insertRevision` then in-place update (`and:data/DoseWeekRepository.kt:944-981`). Audit inspector `and:features/history/HistorySheets.kt:322-418`.

### ED04: date move → success + find-again path (DIVERGENCE, iOS)
- Requirement (01 §4.1): after a correction moves the record to another date, show a success notice and an entry point that reopens that date/record.
- Android (meets it): on Saved it sets `historySelectedDate`/`historyMonth` to the new date, focuses `historyFocusedAdministrationId`, resets kind filter, shows `UiNotice.ADMINISTRATION_UPDATED*` (`and:app/DoseWeekViewModel.kt:4860-4870`, `savedEditNotice` `:4912-4926`). Test `AuditAdministrationScheduleViewModelTest#aDateCorrectionFindsTheSameFactInItsNewMonthDespiteAnActiveFilter`.
- iOS (deviates): `updateEvent` reloads the current month only and never changes `selectedDate`/`displayedMonth` (`HistoryViewModel.swift:483-528`). `HistoryCorrectionNotice.init` returns nil when `planID == nil` or schedule `.preserved(.sameScheduledDay/.alreadyAligned)` (`ios:DoseDay/Features/History/HistoryCorrectionNotice.swift:9-14`). So:
  - a planless fact, or one whose schedule was already aligned, moves off the day with no notice. The card just disappears.
  - even with a notice, the UI test has to pick the new day by hand (`ios:DoseDayUITests/LatestAdministrationCorrectionUITests.swift:28-30`).
  - The symptom edit path already does the jump (`HistoryViewModel.swift:411-415`), so the pattern exists.
- Impact: the "record vanished" report stays reproducible for planless and aligned edits. The data itself is correct.
- Minimal fix: `ios:DoseDay/Features/History/HistoryViewModel.swift` `updateEvent`. On success, set `selectedDate`/`displayedMonth` to `result.event.administeredAtUTC` before `loadHistory()`, and publish a generic "saved" notice when `HistoryCorrectionNotice` is nil and the date changed. Add a UI test for a planless date move.

### ED05: stale / double submit
- iOS: `expectedEvent` mismatch throws (test `RecordOnlyAdministrationTests.swift:195-201`). `AdministrationEditDraft.canSave` blocks on `isSaving || hasSaved` (`ios:DoseDay/Features/History/Components/EditAdministrationSheet.swift:45-55`). Tests `inFlightEditCannotDuplicate`, `clockBackwardAndABA`, `restoreInvalidatesOpenEditor`.
- Android: snapshot + `edit_token` compare throws `StaleAdministrationEditException` (`DoseWeekRepository.kt:885-890`), shown as `side_effect_edit_stale` (`HistorySheets.kt:278-281`). `isSaving` guard `DoseWeekViewModel.kt:4812`. Tests `AdministrationEditConcurrencyViewModelTest#aSecondEditorCannotOverwriteTheFirstCommittedCorrection`.

### ED06: no-op save / reason
- Both require a non-blank free-text reason: iOS `EditAdministrationSheet.swift:45-47,147-150` (`edit.reason.placeholder`, 17 locales); Android `HistorySheets.kt:212-221`, `DoseWeekViewModel.kt:4799-4805`, repo `:872-874`.
- Both skip writing a revision when nothing changed: iOS actor `:1963-1964` (test `RecordOnlyAdministrationTests.swift:189-193`); Android `DoseWeekRepository.kt:929-941`.
- Neither offers the optional localized quick reasons ("날짜/시간 정정" etc.). The spec says "can", so this is parity, not a gap.

### ED07: edit never re-debits inventory
- iOS: the actor edit path (`DoseDayModelActor.swift:1905-2075`) has no inventory references.
- Android: the update path (`DoseWeekRepository.kt:865-993`) never touches `inventory_ledger`, and the doc comment at `:996-1000` says the ledger is append-only.

### ED08: correction and schedule
- iOS: schedule outcome via `updateAdministrationFromHistoryWithScheduleOutcome` (`ios:DoseDay/Data/Persistence/BoundedClinicalFetching.swift:417`). Messages in `HistoryCorrectionNotice.swift:27-45`. Tests `LatestAdministrationCorrectionTests` (`competitorsPreserveSchedule`, `correctionAppendsFutureOnly`, `failedCorrectionIsAtomic`).
- Android: `correctScheduleDerivedFromAdministration` with `wasUniqueLatest` (`DoseWeekRepository.kt:892,982-991`). Notices map `DoseWeekViewModel.kt:4912-4926`. Tests `AuditCadenceRepositoryTest`, `LatestAdministrationCorrectionTest`.

### ED09: manual vs imported
- Manual body and symptom: in-place edit on both (iOS `HistoryView.swift:186-211`; Android `OpenBodyEdit`/`OpenEditSideEffect`, test `BodyRecordCorrectionViewModelTest.savingACorrectionUpdatesTheSameRowAndNeverAddsASecond`).
- Imported is read-only on both, with no edit control:
  - iOS History lists HealthKit rows without Edit (`HistoryView.swift:881`). In History, "Hide in DoseWeek" is a swipe action (`:612-621`). It is not the only path: the Body imported sheet has a visible hide button `body.health.hide.<id>` (`ios:DoseDay/Features/Body/Components/ImportedMeasurementsSheet.swift:96-102`), with `body.health.hide.explanation` shown as visible text (`:14-18`). The sheet opens from `BodyView.swift:348`.
  - Android History lists only manual body rows (`DoseWeekViewModel.kt:352` `manualBodyRecordHistory`). Imported rows live in the Body imported screen.
- Guidance to correct in the source app exists on both, in the in-app Edit guide:
  - iOS `settings.guide.edit.body` (en): "Imported Apple Health measurements are read-only: correct them in the original app." (`Localizable.xcstrings`; topic `.edit`, `ios:DoseDay/Features/Settings/RecordHelpView.swift:21`). It is reachable from History's help button (`HistoryView.swift:96`), which lists every topic (`RecordHelpView.swift:40-43`).
  - Android `settings_guide_edit_body` (`values-en/strings.xml:771`, ko `values/strings.xml:762`): "...read-only: correct them in the original app." (topic `EDIT`, `and:features/help/RecordHelpSheet.kt:50`). It is reachable from History's help button (`HistoryScreen.kt:115`), which lists every topic (`RecordHelpSheet.kt:93-94`).
- Allowed: the placement of imported rows differs, but the meaning and the guidance are the same.
- Shared low polish (both, optional): the note next to imported data says only that the source is unchanged, not where to correct it. See iOS `body.health.hide.explanation` and Android `health_connect_read_only_note` (`values-en/strings.xml:524`, shown at `and:features/integrations/HealthConnectSheet.kt:82`). Adding "correct it in the original app" there would put the guidance in context. Not a parity gap.

### ED10: filter hides everything
- Android: kind filter row, "records hidden by filter" message, and a visible clear button (`HistoryScreen.kt:153-167, 730-790`; `history_filter_hides_all`, 17/17 locales). Tests `HistoryFilterTest`, `AuditAdministrationScheduleViewModelTest#aDateCorrection...DespiteAnActiveFilter`.
- iOS: History has no kind filter (no filter state in `HistoryViewModel.swift:139-160`), so no user filter can hide a day's records. The empty state is `common.noRecords` (`HistoryView.swift:511-517`).
- Allowed: the requirement only applies where a filter exists.
- Caveat: iOS drops locally hidden HealthKit samples from the query (`BoundedClinicalFetching.swift:79,97`), so a day with only hidden imports reads as "No records" in History. Recovery ("Show all hidden measurements") is on the Body side.

### ED11: draft across failure/process death (DIVERGENCE, iOS; Android partial)
- Owner decision `RECORD-DRAFT-PROCESS-EXIT` (2026-09-15): keep an unfinished administration edit as a protected local draft across process death until Save or Discard. Exclude it from backup, and clear it on delete-all and restore.
- iOS: the draft lives only in `@State private var draft: AdministrationEditDraft` (`EditAdministrationSheet.swift:83`). Nothing else references it (grep). It survives a failed save within the window (test `failedEditPreservesDraftForRetry`), but process death loses it.
- Android: `DoseWeekDrafts.editAdministration` (`and:app/DoseWeekDrafts.kt:30,80`) is written on every state change (`DoseWeekViewModel.kt:486-494`) into `SavedStateDraftStore` (`DoseWeekDrafts.kt:116-120`, wired `DoseWeekViewModel.kt:7682`). On restore it is revalidated against the current snapshot and marked STALE if the data changed (`:3261-3272`). Test `DraftPersistenceViewModelTest` (`andT:app/DraftPersistenceViewModelTest.kt:75,152,174`).
  - Why it is partial: a SavedStateHandle bundle survives only system-initiated process death. The draft is lost on user swipe-away, force stop and reboot, so the decision's "across process death until Save or Discard" is only partly met.
  - No backup: met, because the SavedState bundle is not part of app backup.
  - Clearing on delete-all: met. `resetAllData` replaces the whole UI state with a fresh `DoseWeekUiState` that has no edit draft (`DoseWeekViewModel.kt:6640-6644`). The state observer then rewrites the store (`:484-495`).
  - Clearing on restore: met. `confirmRestore` reloads with `loadPersistedState(UiNotice.BACKUP_RESTORED)` and no `preserveTransientState` (`:7023`). That takes the non-preserving branch (`:3219-3223`), which renders a fresh state (`:3110` record-only, `:3452` plan) with no `editAdministration`, and the observer rewrites the store. On relaunch, a draft whose record is gone is dropped, and a changed snapshot marks it STALE (`:3261-3272`).
- Minimal fix:
  - iOS: persist `AdministrationEditDraft` fields (event id + expected token, dose text, site, instant, zone, note, reason) in a protected, non-backup local store keyed by event id. Restore it in `HistoryView` sheet presentation, revalidate against `expectedEvent`, and clear it on save, cancel, delete-all and restore.
  - Android: if swipe-away and reboot must be covered, back `DoseWeekDraftStore` with a no-backup file. Otherwise record that SavedState is the accepted scope.

### ED12: corrected value across History/export/backup
- iOS: backup validator carries revisions (`maxRevisionNumber`, `DoseDayModelActor.swift:1983-1984`). CSV/PDF export (`ios:DoseDay/Data/Services/ExportService.swift`) has no revision fields, only the current values plus tombstones.
- Android: backup models carry revisions (23 refs in `and:data/BackupModels.kt`). `HistoryCsvFormatter.kt` has no revision fields.
- The meaning matches. Test gap on both sides: no end-to-end edit → relaunch → CSV/PDF → backup → restore check on one record (the coverage map marks both as partial).

### PR01: past-date add entry
- iOS: `history.addOnDate` button above the day list (`HistoryView.swift:491-499`), gated `selectedDate in [1900, now]` (`HistoryViewModel.swift:29-40`), help `RecordHelpButton(topic: .past)` (`HistoryView.swift:96`).
- Android: `history_add_administration` TextButton (`HistoryScreen.kt:143-146`), gated `!selected.isAfter(today)` (`DoseWeekViewModel.kt:3892`), guard `:4006-4008`, help `RecordHelpButton(RecordHelpTopic.PAST)` (`HistoryScreen.kt:115`).
- Neither requires a missed slot. Strings 17/17 on both.
- Tests: iOS `RecordOnlyUITests` (`ios:DoseDayUITests/RecordOnlyUITests.swift:12,119`); Android `HistoricalAdministrationUiTest.anEmptyPastDayOffersTheSameFactEntryWithoutAPlan` (`andT:features/record/HistoricalAdministrationUiTest.kt:14`).
- Small difference: the lower bound. iOS hides the button before 1900; Android shows `record_time_too_early` at validation. Allowed.

### PR02: before install / before plan start
- iOS: a historical entry links to the plan only when that plan has a segment at the chosen instant (`ios:DoseDay/Features/RecordFlow/RecordFlowViewModel.swift:34-40`). Otherwise `recordPlanIndependentAdministration` stores a planless fact with no slot (`DoseDayModelActor.swift:1487-1489, 1624-1650`).
- Android: links only to a plan that governed the date, otherwise `planId=null` (`DoseWeekViewModel.kt:4008-4012, 4206`). The repo rejects a pretend plan link (`DoseWeekRepository.kt:2046-2049`).
- Tests: `HistoricalAdministrationRepositoryTest.commitRejectsFutureFloorWrongMedicationAndPretendPlanBeforeAnyWrite` (`:112`); iOS `firstPlanRaceIsRejected`, `linkedCommitChecksDetachedNeighbor`.

### PR03: different past medicine/dose (DIVERGENCE, iOS low)
- Android: the medicine is preselected only when exactly one plan governed the date (`DoseWeekViewModel.kt:4008-4017`). Otherwise it is empty and the user must choose. Changing medicine clears dose, link and inventory (`:4068-4079`). Test `HistoricalAdministrationUiTest.actualMedicineAndUnitAreSelectableWhileUnknownTimeCannotSave` (`:27`).
- iOS: `loadData` always sets `currentPolicy`/`selectedMedicationID` from the active plan (`RecordFlowViewModel.swift:445-447`), even when the date is before any segment. The dose is filled only if a segment exists (`:441-443`). Save only checks `selectedMedicationID == currentPolicy?.id` (`RecordFlowView.swift:679-683`), which is trivially true. So a pre-plan backfill defaults to today's medicine with no basis, which conflicts with 01 §5.
- Impact is low: the picker is visible (`RecordFlowView.swift:429-452`) and the dose must still be entered.
- Minimal fix: in `RecordFlowViewModel.loadData`, when `isHistoricalEntry` and `plan?.segment(effectiveAt: administeredAt) == nil`, leave `selectedMedicationID`/`currentPolicy` nil (the picker's nil tag "select medication" already exists). Add a unit test.

### PR04: administeredAt, not createdAt
- iOS: neighbor lookups use `administeredAtUTC` (`DoseDayModelActor.swift:1670-1683`), and the reanchor picks the newest by `administeredAtUTC` (`:1765-1773`).
- Android: facts are ordered `administered_at DESC` (`DoseWeekRepository.kt:840,858`); neighbors `nearestAdministrationBeforeOrAt/After` (`:314-318`); recent sites come from that ordering (`DoseWeekViewModel.kt:4022-4025`).
- iOS `recentEvents` (`RecordFlowViewModel.swift:455-460`) calls the bounded overload `fetchAdministrationEvents(for:includeDeleted:in:limit:)` (`ios:DoseDay/Data/Persistence/BoundedClinicalFetching.swift:166`). It sorts `administeredAtUTC` descending, then by `id` (`:181-184`). The unbounded overload in `DoseDayModelActor.swift:2537-2561` sorts the same way, but that is not the one this caller uses.
- Test gap: iOS has no backfill-specific test for site recency (coverage partial).

### PR05: older backfill doesn't push the schedule
- iOS: reanchor returns `.preserved(.notUniqueLatest)` unless the newest fact is at or before this one (`DoseDayModelActor.swift:1765-1773`). It runs after the fact commit, in a second transaction (`:1559-1580`).
- Android: `isUniqueLatestAdministration` guard (`DoseWeekRepository.kt:371-386`). Test `olderLinkedBackfillPreservesScheduleAndInventoryIsExplicitAndExactlyOnce` (`:95`).
- Test gap: iOS has no backfill-specific older-fact test (its latest tests cover edits).

### PR06: backfill becomes latest → tell user (DIVERGENCE, Android low)
- iOS: a post-commit summary shows `record.saved.scheduleUpdated` when the schedule was `.updated`, and blocked/unavailable outcomes need acknowledgement (`RecordFlowViewModel.swift:85-104`; `RecordFlowView.swift:143-160`).
- Android: a pre-save hint appears only when a plan is linked, `record_historical_schedule_note` "may adjust" (`and:features/record/RecordAdministrationDialog.kt:191-197`). After commit only generic `RECORD_SAVED` shows (`DoseWeekViewModel.kt:4233`, text `DoseWeekApp.kt:513`). The repo computes `StoredAdministration.scheduleChanged` (`DoseWeekRepository.kt:393-394`), but `recordAdministrationOperation` returns Unit (`DoseWeekViewModel.kt:292-293`), so the outcome is dropped.
- Impact: the user is told the schedule might change, not whether it did.
- Minimal fix: return `StoredAdministration` from `recordAdministrationOperation` and pick a schedule-updated notice when `scheduleChanged` (reuse `ADMINISTRATION_UPDATED_SCHEDULE_UPDATED` copy or add a record variant). Add a VM test.

### PR07: inventory opt-in
- Default off for backfill: iOS `RecordFlowViewModel.swift:297-300,438-439`; Android `DoseWeekViewModel.kt:4043`.
- Toggle offered only when linked to the active plan: iOS `canDeductInventory` (`:29`), `RecordFlowView.swift:604-620`; Android `:4119-4125`, `RecordAdministrationDialog.kt:230-252`. Planless never deducts (iOS actor `:1627`).
- Deducted exactly once: the request-ID replay returns before the ledger (iOS `DoseDayModelActor.swift:1482-1486,1606-1621`; Android `DoseWeekRepository.kt:299-305`). The normal (non-backfill) default is unchanged on both.
- Copy difference: Android backfill uses a distinct `record_historical_inventory` ("Apply to current inventory: n → m"); iOS reuses `record.inventory.deduct` ("Deduct 1 dose from supply"). The meaning is the same, so treated as allowed; aligning the copy is optional.

### PR08: short interval past / future
- Future blocked:
  - iOS: `isBlocked` if `> now` (`RecordFlowViewModel.swift:413`) and the actor refuses (`DoseDayModelActor.swift:1594-1598`).
  - Android: date guard `DoseWeekViewModel.kt:4008`, `FutureBlocked` (`:4235-4243`), edit `FUTURE` error (`:4793-4796`).
- Past fact inside the interval needs an explicit confirmation:
  - iOS: `requiresRetrospectiveConfirmation` + `safetyOverride` (`RecordFlowViewModel.swift:417-419`), actor `intervalConfirmationRequired` (`:1633-1636`).
  - Android: `ConfirmationRequired`/`pastIntervalConfirmed` (`DoseWeekViewModel.kt:4246-4264`), edit `HistorySheets.kt:224-270`.
- Per the design decision, future dates are blocked and past facts are never blocked. Neither side has "safe to inject" copy.

### PR09: unknown time / DST (DIVERGENCE, iOS)
- Requirement (`review_feedback_cases_v2.json` PR09): "임의 자정/정오 생성 없음; 현재 모델에 필요한 실제 시간 확인; gap/overlap 명시 처리".
- iOS (deviates), chain:
  - Calendar cells are local midnights, built by stepping one day at a time from `startOfMonth` (`ios:DoseDay/Features/History/Components/CalendarMonthView.swift:141-143`). A tap sets `selectedDate = date` (`:250`).
  - `beginHistoricalRecording` passes `historicalDate: selectedDate` (`HistoryViewModel.swift:34-39`). The only exception is today on first open, where `selectedDate` still starts as `.now` (`:12`).
  - `RecordFlowViewModel.init` sets `administeredAt = min(historicalDate, .now)`, which is 00:00 for any tapped past day (`RecordFlowViewModel.swift:297-300`).
  - The `exactTimeConfirmed` toggle resets only when the picker value changes (`RecordFlowView.swift:487-490`; `RecordFlowViewModel.swift:241`). The save gate needs only the toggle (`RecordFlowView.swift:679-683`; `RecordFlowViewModel.swift:412`).
  - Result: the user taps a past day, turns on "actual time" without touching the time, and saves a 00:00 fact that the app made up. (The other `administeredAt` write at `:325` is the `applyPrefill` draft path, not History.)
- iOS DST handling meets the requirement: `.nonexistent`/`.ambiguous` get explicit copy and an offset choice (`ios:DoseDay/DesignSystem/Components/ConfirmedDateTimePicker.swift:250-251,302-313`).
- Android (meets it): backfill time starts blank (`DoseWeekViewModel.kt:4037`) with `record_exact_time_required` (`RecordAdministrationDialog.kt:186-190`), so a time must be entered. Nonexistent/ambiguous get errors plus offset radios (`HistorySheets.kt:104-152`, same resolver for record).
- Minimal fix (iOS): a historical entry from a calendar day starts with no trusted time. Either leave the time unset (placeholder) until the user picks one, or keep the prefill but disable the `exactTimeConfirmed` toggle and Save until the time field has been touched. Locations: `RecordFlowViewModel.swift:297-300` (a flag such as `historicalTimeWasChosen`), `RecordFlowView.swift:478-503` and `:679-683`. Add a UI test: past day, time untouched, toggle on, Save stays disabled.
- Coverage map: iOS PR09 is marked DONE_VERIFIED. That is stale for this case.

### PR10: link to missed/skipped/completed slot (DIVERGENCE, iOS, UI only)
- The data rule is the same on both. A slot is attached only if explicitly requested, unlinked, and scheduled/due/needsReview (iOS `DoseDayModelActor.swift:1496-1506`; Android `and:data/OccurrenceAttachmentPolicy.kt:8-18`). A backfill from History never attaches (iOS `RecordFlowViewModel.swift:183-199`; Android `DoseWeekViewModel.kt:4289`).
- UI differs:
  - iOS: the "Record" action for a missed slot (explicit `occurrenceID`), "Mark skipped" and "Reopen skip" exist only as swipe actions (`HistoryView.swift:556-586`); `missedRow`/`skippedRow` have no visible control (`:805-850`). It is the only caller of `requestRecordFlow(prefillDate:occurrenceID:)` (`:567`).
  - Android: visible Record / Mark skipped / Reopen buttons (`HistoryScreen.kt:560-630`).
- Violates DISCOVERABILITY ("swipe/long-press must not be the only path").
- Minimal fix: add visible buttons in `HistoryView.swift` `missedRow`/`skippedRow`, reusing the existing swipe closures, with identifiers and a UI test.

### PR11: retry vs distinct fact
- iOS: `requestID` is stable across a retry with the same input and regenerated when the input changes (`RecordFlowViewModel.swift:603,616`). The actor replays or rejects a changed replay (`:1606-1621`). Test `requestIdentity`, `committedRetryUsesSameIdentity`.
- Android: dialog `recordId` is fixed per dialog (`DoseWeekViewModel.kt:4026`); `AdministrationRetryPolicy.matches` (`DoseWeekRepository.kt:299-305`). Test `separateRequestsOnTheSameDaySurviveAndChangedRetryNeverOverwrites` (`:71`).
- Neither merges by date or value.
- Edge difference: changed input after an attempt whose commit outcome is unknown.
  - Android: `recordId` is fixed for the whole dialog (`DoseWeekViewModel.kt:4026`, reused `:4194`). If a row with that ID already exists and the input differs, the repo throws (`DoseWeekRepository.kt:299-302`), and this maps to `SaveFailed` (`DoseWeekViewModel.kt:4316`). The dialog then fails on every retry until it is closed and reopened, which gets a new ID. The trigger is rare because the whole write is one transaction (`DoseWeekRepository.kt:297-395`).
  - iOS: a new `requestID` is created when the input differs from the last attempt (`RecordFlowViewModel.swift:602-603`, matcher `:42-50`). If the first attempt had committed, a second fact is saved. The actor replays only an exact match (`DoseDayModelActor.swift:1606-1621`). The post-commit reanchor never throws (`:1560-1580`).
  - Both satisfy "no silent merge or overwrite", but the rules differ (reject and get stuck, versus a new fact). Pick one rule and add a changed-input-after-unknown-commit test on both. Verdict unchanged.

### PR12: volume / migration / backup
- iOS: month-page fetch. If the page is incomplete it shows `history.error.tooManyRecords` rather than a partial list (`HistoryViewModel.swift:203-209`). V5 migration and backup readers 1-6 tests (coverage).
- Android: `historyKeepsAllAdministrationAndSkippedFactsPastLegacyHundredRowBoundary`, V10/V11 migration tests, backups 1-7 (coverage).
- UNVERIFIABLE: the iOS page limit value and large-backfill performance on both sides were not exercised or read. On iOS an over-limit month becomes unviewable (though honestly labelled), which affects the ability to find and edit records at high volume.

## Divergence fix list (minimal)
0. ED01b iOS: visible Restore/Delete on the History administration card.
1. ED04 iOS: `HistoryViewModel.updateEvent`: jump to the new date and always give feedback on a date move.
2. ED11 iOS (+ Android scope note): persist the edit draft in protected, non-backup local storage; clear it on save, discard, delete-all and restore.
3. PR03 iOS: `RecordFlowViewModel.loadData`: no medicine preselect when no segment covers the backfill date.
4. PR06 Android: propagate `scheduleChanged` to a specific post-save notice.
5. PR10 iOS: visible Record / Mark skipped / Reopen on missed and skipped rows.
6. PR09 iOS: a past-day backfill cannot be saved at an untouched 00:00; require a chosen time before the confirmation toggle or Save.
7. PR11 both (edge, optional): one rule for changed input after an unknown commit, plus a test.
8. ED09 both (polish, optional): add "correct in the original app" to the in-context imported-data notes.

## Coverage-map corrections
- ED02 iOS: UI test exists (`AuditHistoryCorrectionUITests.swift:164`, CI 4c3e594 8/8). Upgrade the evidence note.
- ED02 Android: add `SameDayAdministrationEditUiTest` to testRefs.
- ED11 both: the owner decision is now RESOLVED (2026-09-15). The note still says PENDING. iOS does not implement it; Android does so only via SavedState.
- ED04 iOS marked DONE_VERIFIED, but its planless and aligned date-move cases give no feedback or jump.
- PR09 iOS marked DONE_VERIFIED, but an untouched midnight prefill can be confirmed and saved.
- ED01 iOS DONE_VERIFIED is correct for Edit. The deleted-state Restore/Delete gap (ED01b) is not tracked.
- iOS HEAD drift: the notes cite 7e8681b, but HEAD is now 93ae0e2. The CI evidence is still from 4c3e594.

## Review log (rev 2)

Every verifier issue was rechecked against the code at iOS 93ae0e2 and Android 79bb210.

| Issue | Result | What changed / why |
|---|---|---|
| PR09-misclass | CONFIRMED | Reclassified to DIVERGENCE (iOS). The midnight chain is proven: `CalendarMonthView.swift:141-143,250` → `HistoryViewModel.swift:34-39` → `RecordFlowViewModel.swift:297-300`, toggle-only gate `RecordFlowView.swift:679-683`. Fix and UI test added. |
| ED09-shared-gap | PARTIAL | Rejected "neither copy says correct in source app": the in-app Edit guide says it on both (iOS `settings.guide.edit.body`; Android `values-en/strings.xml:771`), reachable from History help on both (`HistoryView.swift:96` + `RecordHelpView.swift:40-43`; `HistoryScreen.kt:115` + `RecordHelpSheet.kt:93-94`). Rejected "iOS hide swipe-only": a visible hide button exists in the Body imported sheet (`ImportedMeasurementsSheet.swift:96-102`). Rejected the REQ_GAP relabel. Accepted as optional polish: the in-context notes lack the source-app wording. Verdict stays ALLOWED. The verifier's `strings.xml:515` is the ko default; en is `values-en/strings.xml:524`. |
| ED01-restore-swipe | CONFIRMED | Added row ED01b (DIVERGENCE, iOS UI): `HistoryView.swift:524-538` swipe-only, deleted card badge only `:747-752`, Edit hidden when deleted `:773-777`; Android visible `HistoryScreen.kt:520-551`. Fix list item 0. |
| PR11-retry-edge | CONFIRMED (edge) | The rule difference is real (Android fixed `recordId` → mismatch throw → stuck `SaveFailed`; iOS new `requestID` → second fact). The Android trigger is rare (single transaction). Added an edge note and an optional fix. PR11 stays PARITY_OK, since both meet "operation 1건, no merge". |
| ED11-wording | CONFIRMED | Reworded: partial = SavedState survives only a system kill; no-backup is met. Android clearing verified: reset `DoseWeekViewModel.kt:6640-6644`, restore `:7023` → non-preserving render `:3110/:3452`, store rewrite `:484-495`. |
| PR04-stale-unverified | CONFIRMED (cite corrected) | Removed the caveat. The caller uses the bounded overload `BoundedClinicalFetching.swift:166`, sorted `:181-184`. The verifier's `DoseDayModelActor.swift:2547-2561` is the unbounded overload, same order but not called here. |

Also fixed: rev 1's totals line said 14 PARITY_OK while its table had 15.
