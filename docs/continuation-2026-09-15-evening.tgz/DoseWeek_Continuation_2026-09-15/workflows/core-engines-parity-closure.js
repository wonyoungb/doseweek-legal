export const meta = {
  name: 'core-engines-parity-closure',
  description: 'Extend shared engine fixtures to v3 with missing parity cases, adopt them on iOS and Android, implement personal-target membership, align occupancy, pin fixture SHAs, parity-review',
  phases: [{ title: 'Fixtures' }, { title: 'Adopt' }, { title: 'Review' }, { title: 'Refix' }],
}
const S = '/private/tmp/claude-501/-Users-wonyoungchoi-Documents-Coding-Work/13de090a-e5e7-4ced-81d4-62d99d8291cf/scratchpad'
const B = '/private/tmp/doseweek-v11-20260913'
const CONT = '/Users/wonyoungchoi/Documents/Coding Work/DoseWeek_Continuation_2026-09-15'
const D = CONT + '/designs'
const DEC = `Decisions (confirmed; never re-ask): all DESIGN-20260915-01..20 in ${CONT}/STATE.json, plus coordinator parity decisions CORE-20260915-01 (personal target "My target" cue inclusive at both bounds; value and bounds compared in the chart unit after unit/percent conversion and rounded to the rule's display decimals, same as official bands §4.3; lower==upper draws a single line) and CORE-20260915-02 (explicit-date proposals: only completed and skipped rows occupy a chosen slot; scheduled, due, needs-review and cancelled rows do not; existing interval-schedule behaviour unchanged). Prior results and open items: ${CONT}/COORDINATOR_LOG.md section "Core engines completed".`
const RULES = `Never weaken guards/tests, loosen assertions, regenerate expected values from app output, skip tests, reset --hard/clean/stash others' files, force-push, or kill processes you did not start. Commit messages: normal prose ending with "Co-Authored-By: Claude Opus 5 (1M context) <noreply@anthropic.com>". Temp files under ${S}/<your-label>/. Host is shared with an iOS full CI and build agents: never run xcodebuild, simulators, emulators or the repo app test runners; narrow tests first, full package/unit suite once at the end. Returned strings: terse caveman-ultra fragments with exact numbers, paths, SHAs.`
const RESULT = { type: 'object', properties: {
  summary: { type: 'string' }, head: { type: 'string' }, pushed: { type: 'boolean' }, fixtureShas: { type: 'array', items: { type: 'string' } },
  tests: { type: 'array', items: { type: 'string' } }, questions: { type: 'array', items: { type: 'string' } }, nextSteps: { type: 'array', items: { type: 'string' } },
}, required: ['summary', 'head', 'pushed', 'fixtureShas', 'tests', 'questions', 'nextSteps'] }
const REVIEW = { type: 'object', properties: {
  verdict: { type: 'string', enum: ['ok', 'issues'] },
  issues: { type: 'array', items: { type: 'object', properties: {
    severity: { type: 'string', enum: ['blocker', 'major', 'minor'] }, platform: { type: 'string', enum: ['ios', 'android', 'both', 'fixtures'] }, file: { type: 'string' },
    problem: { type: 'string' }, evidence: { type: 'string' }, fix: { type: 'string' } }, required: ['severity', 'platform', 'problem', 'evidence'] } },
}, required: ['verdict', 'issues'] }

phase('Fixtures')
const fx = await agent(`${DEC}\n${RULES}\nShared fixture owner. Work only in ${D}/ (not a git repo; keep v2/v1 files untouched). Reference generators: ${D}/fixtures/gen_calendar_sync_fixture.py, ${D}/fixtures/body_chart_references_v2.generator.py, and the schedule generator ${S}/schedule-explicit-dates/gen.py (copy it into ${D}/fixtures/ as the durable generator). Produce v3 fixtures that keep every v2/v1 case byte-for-byte semantically identical and ADD cases for: schedule — occupancy by row status (completed, skipped occupy; scheduled, due, needsReview, cancelled do not, while the gate is still evaluated over the full list); declared last-injection floor; body — samples with kg 0 or negative dropped, zoom with scale 0 or negative leaves span unchanged, band membership at -0.004 rounding boundaries, personal-target membership per CORE-20260915-01 in kg and percent modes (including a percent target shown in kg mode and lower==upper); calendar — unusable gate hours (0, negative) behaviour matching both platforms' implemented policyUnavailable handling, and empty eventId/markerKey treated as absent. Read both implementations (${B}/ios-core Packages/DoseDayCore, ${B}/android-core domain) to find every behaviour they had to guess because the fixture had no case (the core results listed guards like non-finite hours, resolver order unknown-official-id before metric mismatch); add a case for each where JSON can express it and list the rest. Update the Python reference generators first so expected values come from the reference, never from app output; regenerate; write SHA-256 of each v3 file; update the three design docs' fixture sections and review logs to reference v3 and the two coordinator decisions.`,
  { label: 'fixtures-v3', phase: 'Fixtures', schema: RESULT, effort: 'xhigh' })
if (!fx) return { fx: null }

const LANES = [
  { key: 'ios', prompt: `iOS lane. Continue in ${B}/ios-core on branch feat/core-engines (head 7274d52). Read ${B}/ios/AGENTS.md. Adopt the v3 fixtures from ${D}/fixtures (byte-identical copies replacing v2/v1 in Packages/DoseDayCore/Tests/DoseDayCoreTests/Fixtures, SHA assertions updated to: ${JSON.stringify(fx.fixtureShas)}), implement BodyPersonalTarget membership per CORE-20260915-01, make every new case pass without changing expected values, add SHA pins for the three fixtures in scripts/check_invariants.py (a strengthening pin; follow the script's existing style), update docs/ANDROID_PARITY_NOTES.md with the shared engine rules. Test: swift test --package-path Packages/DoseDayCore (narrow filters, then full once); swiftlint lint --strict on changed files; python3 scripts/check_invariants.py. Commit, push.` },
  { key: 'android', prompt: `Android lane. Continue in ${B}/android-core on branch feat/core-engines (head a0c3398). Read ${B}/android/AGENTS.md. Adopt the v3 fixtures from ${D}/fixtures byte-identically (update SHA assertions to: ${JSON.stringify(fx.fixtureShas)}), align explicit-date occupancy to CORE-20260915-02 (cancelled no longer occupies for explicit-date proposals; interval behaviour unchanged, prove with existing interval tests), implement personal-target membership per CORE-20260915-01, make every new case pass, add fixture SHA pins in scripts/check_invariants.py following its style, update docs/IOS_UPDATE_NOTES_CODE3.md with the shared engine rules. Test: JAVA_HOME="/Applications/Android Studio.app/Contents/jbr/Contents/Home" ANDROID_HOME="$HOME/Library/Android/sdk" ./gradlew testDebugUnitTest --tests '<classes>' then the full testDebugUnitTest once; python3 scripts/check_invariants.py. Commit, push.` },
]
phase('Adopt')
const adopted = await parallel(LANES.map(l => () => agent(`${l.prompt}\n${DEC}\n${RULES}\nFixture result: ${JSON.stringify(fx)}`, { label: `adopt:${l.key}`, phase: 'Adopt', schema: RESULT, effort: 'xhigh' })))

phase('Review')
const review = await agent(`Adversarial parity reviewer. Fixtures: ${D}/fixtures v3 (result ${JSON.stringify(fx)}). iOS ${B}/ios-core feat/core-engines (result ${JSON.stringify(adopted[0])}). Android ${B}/android-core feat/core-engines (result ${JSON.stringify(adopted[1])}). ${DEC} Do not edit or commit; you may run the narrow test commands to confirm findings. Check: v3 keeps all earlier cases; expected values come from the Python reference; both platforms load identical bytes with matching SHAs and pins; every case asserted (none skipped); identical semantics for occupancy, personal-target membership, guards; interval behaviour unchanged on Android. Report only issues with evidence.`,
  { label: 'review:parity-v3', phase: 'Review', schema: REVIEW, effort: 'high' })
const issues = (review && review.issues) || []
phase('Refix')
const refix = await parallel(LANES.map((l, i) => () => {
  const mine = issues.filter(x => x.platform === l.key || x.platform === 'both' || x.platform === 'fixtures')
  if (!mine.length) return Promise.resolve(null)
  return agent(`${l.prompt}\n${DEC}\n${RULES}\nFOLLOW-UP. Your earlier result ${JSON.stringify(adopted[i])}. Reviewer issues (unverified): ${JSON.stringify(mine)}. Verify each; fix confirmed ones in your repository (for fixture-level issues, fix the Python generator and regenerate in ${D}/fixtures only if you are the ios lane; the android lane then re-copies — coordinate by checking the fixture SHA before committing); re-run narrow then full tests; push; list rejected findings with reasons.`,
    { label: `refix:${l.key}`, phase: 'Refix', schema: RESULT, effort: 'xhigh' })
}))
return { fx, adopted, review, refix }