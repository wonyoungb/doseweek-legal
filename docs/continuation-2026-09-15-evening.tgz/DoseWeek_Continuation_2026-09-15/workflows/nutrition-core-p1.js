export const meta = {
  name: 'nutrition-core-p1',
  description: 'Nutrition P1 pure core on iOS DoseDayCore and Android domain: reuse prepared exact calculators, contract assets with hash tests, presentation rules, decimal input, formatter, text normalizer; parity review',
  phases: [{ title: 'Implement' }, { title: 'Review' }, { title: 'Refix' }],
}
const S = '/private/tmp/claude-501/-Users-wonyoungchoi-Documents-Coding-Work/13de090a-e5e7-4ced-81d4-62d99d8291cf/scratchpad'
const B = '/private/tmp/doseweek-v11-20260913'
const PKG = '/Users/wonyoungchoi/Documents/Coding Work/DoseWeek_Final_v11_2026-09-13'
const CONT = '/Users/wonyoungchoi/Documents/Coding Work/DoseWeek_Continuation_2026-09-15'
const D = CONT + '/designs'
const CTX = `Design: ${D}/nutrition-app.md (revision 2; phase P1 only) and its fixtures in ${D}/fixtures (nutrition-day-presentation-cases.v1.json etc.). Specs: ${PKG}/specs/GLOBAL_NUTRITION_AND_STORAGE.md sections 2 and 3.5-3.8; contracts in ${PKG}/contracts (nutrition_contract_v3, nutrition_golden_v3, nutrition_semantics_v1, nutrition_semantic_golden_v1, food_localization_contract_v2) — copy them byte-identically, never edit. Prepared calculators to REUSE, not rewrite: ${B}/nutrition-prep/swift-calculator and ${B}/nutrition-prep/kotlin-calculator (READMEs, integration notes ${B}/nutrition-prep/calculation/integration-notes.md). Data release (read-only reference for the text normalizer rules): ${B}/android-nutrition-data branch feat/nutrition-data, docs/NUTRITION_DATA_RELEASE.md and nutrition-data/pipeline. Owner decisions: ${CONT}/STATE.json (NUTRITION-20260915-01..03, NUTRITION-DATA-20260915-01..03 — note MFDS calculated dishes are search/display-only and must never reach the calculator: add a core guard type for that usage flag).`
const SCOPE = `P1 scope only (pure code, no persistence, UI, catalog bundling or search ranking): (1) port the prepared exact calculator and semantic aggregation into the app's pure layer, loading the four contracts as test resources with SHA-256 assertions and running all golden cases C01-C40 and S01-S08; test goldens must stay test-only (never shipped in the app bundle); (2) day presentation rules per the design and nutrition-day-presentation-cases.v1.json (no_records vs unknown vs partial vs complete, definition-separated totals, null key + null value handling); (3) NutritionDecimalInput: locale-aware decimal text to the contract's ASCII decimal wire form without Double, rejecting ambiguous input; (4) exact display formatter (HALF_UP, integer kcal, 1-dp macros) consistent with the contract; (5) search text normalizer rev1 exactly as the data pipeline defines it (NFC/NFKC handling, casing incl. Turkish and Greek final sigma notes, kana/Hangul handling) with vectors taken from the pipeline's unit tests, documenting any unavoidable platform difference; (6) a calculation-usage guard so records flagged search/display-only cannot produce calculator input. No ranking, no index, no DB.`
const RULES = `PHYSICAL PHONE SAFETY: the owner's real phone (adb serial R3CX804JPJX, Galaxy SM-S928N) is attached to this Mac. Never target it: never run adb, installDebug, connectedDebugAndroidTest or any instrumentation without ANDROID_SERIAL set to an emulator you own (emulator-5560/emulator-5570 per the repo runner), never uninstall/clear/install on it, never read its data. Only the coordinator touches that phone. Never weaken guards/tests, loosen assertions, regenerate expected values from implementation output, skip tests, reset --hard/clean/stash others' files, force-push, or kill processes you did not start. Commit messages: normal prose ending with "Co-Authored-By: Claude Opus 5 (1M context) <noreply@anthropic.com>". Temp files under ${S}/<your-label>/. Host is shared with other build agents: never run xcodebuild, simulators, emulators or the app test runners; narrow tests first, full package/unit suite once at the end. If a design point is ambiguous in product meaning, implement the independent parts and return the question. Returned strings: terse caveman-ultra fragments with counts and SHAs.`
const RESULT = { type: 'object', properties: {
  summary: { type: 'string' }, branch: { type: 'string' }, head: { type: 'string' }, pushed: { type: 'boolean' },
  tests: { type: 'array', items: { type: 'string' } }, notRun: { type: 'array', items: { type: 'string' } },
  questions: { type: 'array', items: { type: 'string' } }, nextSteps: { type: 'array', items: { type: 'string' } },
}, required: ['summary', 'branch', 'head', 'pushed', 'tests', 'notRun', 'questions', 'nextSteps'] }
const REVIEW = { type: 'object', properties: {
  verdict: { type: 'string', enum: ['ok', 'issues'] },
  issues: { type: 'array', items: { type: 'object', properties: {
    severity: { type: 'string', enum: ['blocker', 'major', 'minor'] }, platform: { type: 'string', enum: ['ios', 'android', 'both'] }, file: { type: 'string' },
    problem: { type: 'string' }, evidence: { type: 'string' }, fix: { type: 'string' } }, required: ['severity', 'platform', 'problem', 'evidence'] } },
}, required: ['verdict', 'issues'] }
const LANES = [
  { key: 'ios', prompt: `iOS lane. Create worktree: git -C ${B}/ios worktree add ${B}/ios-nutrition-core -b feat/nutrition-core codex/v11-bugfix . Read ${B}/ios/AGENTS.md (binding; no third-party dependencies, Swift 6 strict concurrency). Implement in Packages/DoseDayCore only. Test with swift test --package-path Packages/DoseDayCore (narrow filters, then full once); swiftlint lint --strict on changed files; python3 scripts/check_invariants.py. Note the feat/core-engines branch also adds test resources in Package.swift; keep your Package.swift change minimal for an easy merge. Commit in units, push, do not merge.` },
  { key: 'android', prompt: `Android lane. Create worktree: git -C ${B}/android fetch origin && git -C ${B}/android worktree add ${B}/android-nutrition-core -b feat/nutrition-core origin/main . Read ${B}/android/AGENTS.md (binding; no new runtime dependencies; BigDecimal from the JDK is fine). Implement in the pure domain layer only; contracts and goldens as test resources only. Test with JAVA_HOME="/Applications/Android Studio.app/Contents/jbr/Contents/Home" ANDROID_HOME="$HOME/Library/Android/sdk" ./gradlew testDebugUnitTest --tests '<classes>' then full testDebugUnitTest once; python3 scripts/check_invariants.py. Commit in units, push, do not merge.` },
]
const RESUME = ' RESUME NOTE: the worktree already exists from an interrupted attempt (ios-nutrition-core has an untracked Fixtures folder); do not recreate it; inspect and continue.'
phase('Implement')
const impl = await parallel(LANES.map(l => () => agent(`${l.prompt}\n${CTX}\n${SCOPE}\n${RULES}${RESUME}`, { label: `nutrition-core:${l.key}`, phase: 'Implement', schema: RESULT, effort: 'xhigh' })))
phase('Review')
const LENSES = [
  { key: 'contract-parity', focus: 'Both platforms reproduce all golden cases from byte-identical contracts with SHA checks; identical results and error precedence; decimal input and formatter parity across locales; normalizer parity on the pipeline vectors; goldens not shipped in app bundles.' },
  { key: 'reuse-safety', focus: 'Prepared calculators were reused, not rewritten (diff against nutrition-prep sources); no binary floating point in arithmetic; search/display-only guard enforced; no persistence/UI/network leakage; AGENTS hard rules.' },
]
const reviews = await parallel(LENSES.map(l => () => agent(`Adversarial read-only reviewer (${l.key}) for nutrition P1. iOS ${B}/ios-nutrition-core feat/nutrition-core (result ${JSON.stringify(impl[0])}); Android ${B}/android-nutrition-core feat/nutrition-core (result ${JSON.stringify(impl[1])}). ${CTX} Do not edit or commit; narrow test commands allowed to confirm findings. Focus: ${l.focus} Report only issues with evidence.`, { label: `review:${l.key}`, phase: 'Review', schema: REVIEW, effort: 'high' })))
const issues = reviews.filter(Boolean).flatMap(r => r.issues)
phase('Refix')
const refix = await parallel(LANES.map((l, i) => () => {
  const mine = issues.filter(x => x.platform === l.key || x.platform === 'both')
  if (!mine.length || !impl[i]) return Promise.resolve(null)
  return agent(`${l.prompt}\n${CTX}\n${SCOPE}\n${RULES}\nFOLLOW-UP in the existing worktree. Earlier result ${JSON.stringify(impl[i])}. Reviewer issues (unverified): ${JSON.stringify(mine)}. Verify, fix confirmed ones with tests, re-run narrow then full tests, push, list rejected ones.`, { label: `refix:${l.key}`, phase: 'Refix', schema: RESULT, effort: 'xhigh' })
}))
return { impl, reviews, refix }