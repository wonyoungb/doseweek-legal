export const meta = {
  name: 'ios-history-import-integration',
  description: 'Integrate prepared Swift import parsers into the iOS app (UI, ModelActor, protected staging, migration, backup), review, fix',
  phases: [{ title: 'Implement' }, { title: 'Review' }, { title: 'Fix' }],
}
const S = '/private/tmp/claude-501/-Users-wonyoungchoi-Documents-Coding-Work/13de090a-e5e7-4ced-81d4-62d99d8291cf/scratchpad'
const B = '/private/tmp/doseweek-v11-20260913'
const PKG = '/Users/wonyoungchoi/Documents/Coding Work/DoseWeek_Final_v11_2026-09-13'
const HANDOFF = '/Users/wonyoungchoi/Documents/Coding Work/DoseWeek_Continuation_2026-09-15/HANDOFF.md'
const RULES = `Owner rules (confirmed; never ask again): edits, commits, pushes, PRs and builds are pre-approved; never ask permission. If product/data meaning is genuinely ambiguous, do not guess: do the independent parts and return the question (facts, two options, recommendation). Missing administration time: the importing user must supply/confirm the real time; never invent midnight/noon; never add a date-only administration model. Plan-free record-only use must keep working. Imports only append reviewed records (never overwrite, never use backup restore), no inventory deduction by default, no automatic HealthKit consent. Simple design, no missing capability. Tests may pin dates; product code uses Clock/user input. Never weaken guards/tests, loosen assertions, skip tests, reset --hard/clean/stash others' files, force-push, or kill processes/simulators you did not start. Commit messages: normal prose ending with "Co-Authored-By: Claude Opus 5 (1M context) <noreply@anthropic.com>". Temp files only under ${S}/<your-label>/. If context gets tight: commit+push a checkpoint, update docs/CURRENT_HANDOFF.md, return the exact next step. Returned strings: terse caveman-ultra fragments with exact numbers, paths, SHAs.`
const RESULT = { type: 'object', properties: {
  summary: { type: 'string' }, branch: { type: 'string' }, head: { type: 'string' },
  commits: { type: 'array', items: { type: 'string' } }, pushed: { type: 'boolean' },
  tests: { type: 'array', items: { type: 'string' } }, notRun: { type: 'array', items: { type: 'string' } },
  questions: { type: 'array', items: { type: 'string' } }, nextSteps: { type: 'array', items: { type: 'string' } },
}, required: ['summary', 'branch', 'head', 'commits', 'pushed', 'tests', 'notRun', 'questions', 'nextSteps'] }
const REVIEW = { type: 'object', properties: {
  verdict: { type: 'string', enum: ['ok', 'issues'] },
  issues: { type: 'array', items: { type: 'object', properties: {
    severity: { type: 'string', enum: ['blocker', 'major', 'minor'] }, file: { type: 'string' }, line: { type: 'integer' },
    problem: { type: 'string' }, evidence: { type: 'string' }, fix: { type: 'string' } }, required: ['severity', 'problem', 'evidence'] } },
}, required: ['verdict', 'issues'] }

const IMPL = `iOS history-import integration lane for DoseWeek (repo folder DoseDay, remote https://github.com/wonyoungb/DoseWeek.git). Base: branch codex/v11-bugfix (HEAD 4c3e59405250870b7b358e10bde8914fa976e793; another agent is adding a small calendar-bound fix there in ${B}/ios, so never edit that worktree). Create and use your own worktree: git -C ${B}/ios worktree add ${B}/ios-import -b feat/history-import codex/v11-bugfix
${RULES}
Read first: ${B}/ios/AGENTS.md completely (binding; especially generated pbxproj, 17-locale catalog, no logging/networking/dependencies, DoseDayModelActor-only persistence, atomic transactions with rollback discard, ScheduleRefreshCoordinator.sync, ThemePalette, @Observable, protected storage, backup validation before deletion, build concurrency), docs/ARCHITECTURE.md, ${PKG}/specs/HISTORY_INPUT_AND_FILE_IMPORT.md, ${PKG}/contracts/history_import_contract_v1.json, ${PKG}/requirements/owner_import_cases_v1.json, sections 5-6 of ${HANDOFF}.
Android reference for behavioural parity (not file layout): ${B}/android-import (branch feat/history-import; docs/HISTORY_IMPORT_HANDOFF.md, app/src/main/java/com/wonyoungchoi/doseweek/features/historyimport/*, data/historyimport/*). Android sub-lanes are concurrently adding: phase back navigation that keeps corrections, Add Row cap and draft byte budget, localized mapping descriptions with machine headers secondary, generic decimal label, unsupported JSON row (symptom/unclassified) explanation plus required deselection, provenance on history detail, and a standardized export using exactly the contract header (UTF-8 CSV/TSV, formula-injection protection that re-import reverses, stable source_record_id so re-import classifies already-imported vs conflict). Implement the same behaviours on iOS; the export format must be byte-compatible across platforms (check feat/history-import-data in ${B}/android-import-data later in your run for the exact documented format and align).
Reuse, don't rewrite: ${B}/history-import-prep/Sources/HistoryImportPreparation/TabularHistoryParser.swift and HistoryExtractionParser.swift (+12 tests in Tests/), localization candidates ${B}/history-import-prep/localizations.json and ${B}/transfer-research/ (record-only-ios-localizations.json, import time confirmation material), UI guide candidate ${B}/import-guide-app-prep/ImportGuideSheet.swift.

RESUME NOTE: an earlier attempt of this step was interrupted. Its worktree may already contain commits and uncommitted changes (run git status and git log first, read the handoff docs there); review that work with git diff, keep what is correct, finish it, and never discard it blindly. The worktree ${B}/ios-import already exists on feat/history-import with 8 pushed commits (head 86c2a52, docs/HISTORY_IMPORT_HANDOFF.md written there); do not recreate it.
Build the full vertical slice: entry points in onboarding (including the record-only path) and Settings/History data management, separate from encrypted restore; fileImporter with security-scoped read-only access and a streamed 10 MiB bound; empty template save via fileExporter; explicit paste; manual multiple rows with native date/time pickers honoring the system 12/24-hour setting; mapping with confirmation of date order, decimal separator, time zone/offset and units; review with row correction and mandatory real-time confirmation for rows missing time; source-id already-imported vs conflict and possible duplicates that are never auto-merged; selected atomic append through DoseDayModelActor in ONE transaction together with provenance and import receipts, idempotent retry via session/operation/store generation, invalidation after delete-all/restore; protected staging (complete file protection, excluded from device backup, not in the App Group, not UserDefaults) with draft resume after termination; result screen that opens the imported date; body records from JSON (height, weight, body fat, lean mass) without inventing weight; SwiftData schema migration following the repo's existing versioned pattern; next backup payload version including committed provenance and independent body composition while keeping every older reader; ScheduleRefreshCoordinator.sync after append; standardized export plus roundtrip; catalog entries in all 17 locales (format specifiers preserved); regenerate the project with scripts/generate_project.py.
Tests: unit tests for parser integration, row resolver, store transaction/rollback/idempotency, migration, backup roundtrip for new and old versions, export roundtrip; UI tests for the main English journey plus one RTL (ar) and one long-text locale.
Build rules: another agent runs the shared-DerivedData runners and later a multi-hour full CI. Never run scripts/run_app_unit_tests.sh, scripts/run_app_ui_tests.sh or scripts/run_ci.sh while "pgrep -x xcodebuild" is non-empty. For compile checks use your own DerivedData, for example: xcodebuild -project DoseDay.xcodeproj -scheme DoseDay -destination 'generic/platform=iOS Simulator' -derivedDataPath ${S}/ios-import/DerivedData build (and build-for-testing likewise; find the real scheme names first). swift test for any touched local package. Run simulator unit/UI tests only when no other xcodebuild is running; otherwise list them in notRun with exact commands. swiftlint lint --strict and python3 scripts/check_invariants.py must pass.
Commit in meaningful units; push feat/history-import to the iOS remote; do not merge. Add docs/HISTORY_IMPORT_HANDOFF.md and update docs/CURRENT_HANDOFF.md.`

phase('Implement')
const impl = await agent(IMPL, { label: 'ios-import-impl', phase: 'Implement', schema: RESULT, effort: 'xhigh' })
if (!impl) return { impl: null }

const LENSES = [
  { key: 'persistence-security', focus: 'AGENTS.md hard rules 1-3, 7-9, 12, 14, 15: ModelActor-only writes, one save with rollback discard, schema migration safety, backup version compatibility and validation before replacement, protected staging location/protection/backup exclusion, no PHI in logs/UserDefaults/App Group, security-scoped access released, idempotency and invalidation after delete-all/restore.' },
  { key: 'contract-parity-ux', focus: 'IM01-IM30 and owner decisions (missing time confirmation, append-only, no inventory/consent side effects, conflicts/duplicates, limits streamed), parity with Android behaviours and the exact standardized export format, 17-locale completeness and format specifiers, simple UI, accessibility, tests genuinely exercising claims (no vacuous tests).' },
]
phase('Review')
const reviews = await parallel(LENSES.map(l => () => agent(
  `Adversarial read-only reviewer (${l.key}) for iOS history import in ${B}/ios-import (branch feat/history-import, diff against codex/v11-bugfix). Implementation result: ${JSON.stringify(impl)}. Read ${B}/ios/AGENTS.md and ${PKG}/specs/HISTORY_INPUT_AND_FILE_IMPORT.md first. Do not edit, commit, or run xcodebuild. Try to refute correctness and completeness. Focus: ${l.focus} Report only issues with concrete evidence (file:line). Terse caveman-ultra strings.`,
  { label: `review:${l.key}`, phase: 'Review', schema: REVIEW, effort: 'high' })))
const issues = reviews.filter(Boolean).flatMap(r => r.issues)
let fixed = null
if (issues.length) {
  phase('Fix')
  fixed = await agent(`${IMPL}\n\nFOLLOW-UP: implementation pass done (${JSON.stringify(impl)}); continue in the existing worktree ${B}/ios-import. Reviewers reported these unverified issues: ${JSON.stringify(issues)}. Verify each against code; fix confirmed ones with tests; also finish any nextSteps/notRun items that are now possible under the build rules; push; list rejected findings with reasons in summary.`,
    { label: 'ios-import-fix', phase: 'Fix', schema: RESULT, effort: 'xhigh' })
}
return { impl, reviews, fixed }