export const meta = {
  name: 'nutrition-data-release-decisions',
  description: 'Apply owner decisions to the nutrition data release (MEXT macro columns, documentation-based definition keys, MFDS calculated dishes search-only), rebuild, verify',
  phases: [{ title: 'Apply' }, { title: 'Verify' }, { title: 'Fix' }],
}
const S = '/private/tmp/claude-501/-Users-wonyoungchoi-Documents-Coding-Work/13de090a-e5e7-4ced-81d4-62d99d8291cf/scratchpad'
const B = '/private/tmp/doseweek-v11-20260913'
const PKG = '/Users/wonyoungchoi/Documents/Coding Work/DoseWeek_Final_v11_2026-09-13'
const W = B + '/android-nutrition-data'
const DEC = `Owner decisions (answered 2026-09-15, confirmed, never re-ask): NUTRITION-DATA-20260915-01 — MEXT macros use the conventional columns PROT- (protein), FAT- (fat) and CHOCDF- (carbohydrate by difference) for every food, keeping parenthesized/estimate qualifiers (set provider_mext.MACRO_SELECTION accordingly). NUTRITION-DATA-20260915-02 — provider-scoped definition keys in nutrition-data/config/definition-keys.json, mapped from official documentation, may group totals; record their status as documentation-based mapping accepted by the product owner (not expert/native review; never write "reviewed by nutrition expert"); grouping only within the same provider-scoped definition key. NUTRITION-DATA-20260915-03 — the 3,140 MFDS calculated ("산출", basis "100ml") dishes are released for SEARCH AND DISPLAY ONLY: include them with their raw provider values and an explicit basis-unverified qualifier, a machine-readable usage flag that forbids calculation, no calculator DTO template, excluded from any golden/total path, with the proximate-closure diagnostics kept in the manifest; the analysed dishes stay fully usable.`
const RULES = `Work only in ${W} on branch feat/nutrition-data (head c019a52, pushed). Read docs/NUTRITION_DATA_RELEASE.md, the pipeline, config and tests first, plus ${PKG}/specs/GLOBAL_NUTRITION_AND_STORAGE.md and ${PKG}/contracts/food_localization_contract_v2.json / nutrition contracts where the flag or statuses must fit. Never fake PASS or review status; never change contracts; Python stdlib; keep processes light (host overloaded by an iOS full CI). Commit messages: normal prose ending with "Co-Authored-By: Claude Opus 5 (1M context) <noreply@anthropic.com>". Temp files under ${S}/<your-label>/. Returned strings: terse caveman-ultra fragments with exact numbers and hashes.`
const RESULT = { type: 'object', properties: {
  summary: { type: 'string' }, head: { type: 'string' }, dataReleaseId: { type: 'string' }, pushed: { type: 'boolean' },
  tests: { type: 'array', items: { type: 'string' } }, questions: { type: 'array', items: { type: 'string' } }, nextSteps: { type: 'array', items: { type: 'string' } },
}, required: ['summary', 'head', 'dataReleaseId', 'pushed', 'tests', 'questions', 'nextSteps'] }
const REVIEW = { type: 'object', properties: {
  verdict: { type: 'string', enum: ['ok', 'issues'] },
  issues: { type: 'array', items: { type: 'object', properties: {
    severity: { type: 'string', enum: ['blocker', 'major', 'minor'] }, file: { type: 'string' }, problem: { type: 'string' }, evidence: { type: 'string' }, fix: { type: 'string' } },
    required: ['severity', 'problem', 'evidence'] } },
}, required: ['verdict', 'issues'] }

phase('Apply')
const applied = await agent(`${DEC}\n${RULES}\nApply the three decisions: update pipeline/config, add tests (MEXT column selection per food incl. estimate qualifiers; definition-key status wording; MFDS calculated dishes present with usage flag, no DTO template, rejected by any calculation/golden/total path and by the validator if a DTO is produced), rebuild the release (new dataReleaseId; manifest supersedes chain and config/release-history.json updated), run all unit/integrity tests, validator, determinism check, calculator golden runs unchanged, update fixture query results and docs/NUTRITION_DATA_RELEASE.md (decisions, counts, statuses, app-integration notes for the search-only flag). Commit and push.`,
  { label: 'apply-decisions', phase: 'Apply', schema: RESULT, effort: 'xhigh' })
if (!applied) return { applied: null }
phase('Verify')
const review = await agent(`Adversarial verifier for the updated DoseWeek nutrition release in ${W} (branch feat/nutrition-data). Result: ${JSON.stringify(applied)}. ${DEC} Do not edit or commit. Independently check with your own throwaway scripts under ${S}/nutrition-verify2/: MEXT values for at least 15 foods equal the PROT-/FAT-/CHOCDF- source cells (qualifiers kept); definition-key statuses never claim expert review; every MFDS calculated dish carries the search/display-only flag and basis-unverified qualifier and cannot yield a calculator DTO, and no total/golden path includes them; analysed dishes unaffected; determinism; docs match. Report only issues with evidence.`,
  { label: 'verify-decisions', phase: 'Verify', schema: REVIEW, effort: 'high' })
let fixed = null
if (review && review.verdict === 'issues' && review.issues.length) {
  phase('Fix')
  fixed = await agent(`${DEC}\n${RULES}\nFOLLOW-UP. Earlier result ${JSON.stringify(applied)}. Verifier issues (unverified): ${JSON.stringify(review.issues)}. Verify each, fix confirmed ones, rebuild/validate if data changes, push, list rejected ones with reasons.`,
    { label: 'fix-decisions', phase: 'Fix', schema: RESULT, effort: 'xhigh' })
}
return { applied, review, fixed }