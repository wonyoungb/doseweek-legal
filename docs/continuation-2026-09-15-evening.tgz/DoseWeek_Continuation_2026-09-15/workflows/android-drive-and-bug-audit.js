export const meta = {
  name: 'android-drive-and-bug-audit',
  description: 'Read-only Android bug hunt: Google Drive authorization status 8 root-cause analysis plus multi-lens bug finders with adversarial verification on verified main',
  phases: [{ title: 'Find' }, { title: 'Verify' }, { title: 'Synthesize' }],
}
const S = '/private/tmp/claude-501/-Users-wonyoungchoi-Documents-Coding-Work/13de090a-e5e7-4ced-81d4-62d99d8291cf/scratchpad'
const B = '/private/tmp/doseweek-v11-20260913'
const CONT = '/Users/wonyoungchoi/Documents/Coding Work/DoseWeek_Continuation_2026-09-15'
const OUT = CONT + '/designs'
const COMMON = `READ-ONLY bug hunt on the DoseWeek Android app at verified main ${B}/android (79bb210). Do not edit repositories, commit, build, run Gradle, or use adb/emulators/devices (another lane owns them; a real phone may be attached and must never be touched by you). Read ${B}/android/AGENTS.md, docs/ARCHITECTURE.md and docs/CURRENT_HANDOFF.md first. Write temp files only under ${S}/<your-label>/. Facts: the owner's Play-installed latest build shows "다시 연결해야 합니다 / Google 응답 코드 8" on the Google Drive backup screen (status 8 = INTERNAL_ERROR); PR3 only fixed the message classification; the real cause is unconfirmed. Earlier history: DEVELOPER_ERROR was seen before a consent-screen fix; Google Cloud project doseweek-507313 has consent screen in production, brand verified, four Android OAuth clients (classical and post-quantum Play app-signing SHA-1s, upload key, debug key); Drive is reached with play-services-auth AuthorizationClient (OAuth grant only) plus hand-written HTTPS in data/drive/HttpsDriveTransport.kt. The owner also still reports recent Health Connect records missing (HEALTH-20260913-06). Cite file:line and primary Google/Android documentation URLs (WebSearch/WebFetch via ToolSearch) for any API behaviour claim. Report only real defects or concrete risks with a reproduction path; no style nits. Returned strings: terse caveman-ultra fragments.`
const FINDINGS = { type: 'object', properties: {
  findings: { type: 'array', items: { type: 'object', properties: {
    id: { type: 'string' }, severity: { type: 'string', enum: ['critical', 'high', 'medium', 'low'] }, area: { type: 'string' },
    title: { type: 'string' }, evidence: { type: 'string' }, reproduction: { type: 'string' }, deviceCheck: { type: 'string' }, fix: { type: 'string' } },
    required: ['id', 'severity', 'area', 'title', 'evidence', 'reproduction', 'fix'] } },
}, required: ['findings'] }
const VERDICT = { type: 'object', properties: {
  real: { type: 'boolean' }, confidence: { type: 'string', enum: ['high', 'medium', 'low'] }, reasoning: { type: 'string' }, correctedSeverity: { type: 'string' },
}, required: ['real', 'confidence', 'reasoning'] }
const LENSES = [
  { key: 'drive-auth', prompt: 'Google Drive connect/authorization/token lifecycle: every AuthorizationClient/Identity call site, request parameters (scopes, account, offline access, server client id), PendingIntent/ActivityResult handling, process death during consent, Play services availability/version checks, retry and state classification, token expiry/revocation, upload/list/download/restore paths. Enumerate every documented way status 8 INTERNAL_ERROR (and 4, 10, 13, 16, 17) can arise for this configuration, rank root-cause hypotheses for the owner report with the exact device log lines (logcat tags/components) that would confirm or refute each, and list configuration checks (package name, SHA-1 per signing key, consent screen publishing, Drive API enabled, scope sensitivity) that can be verified from repository docs.' },
  { key: 'health-connect', prompt: 'Health Connect import freshness: permission checks, changes tokens and expiry, back-fill windows, paging, time-range filters and time zones, foreground/launch triggers, single-flight, provider/origin filtering, dedup, normalizer and display filters; find why recent records can be missing on a real device and what device evidence would confirm it.' },
  { key: 'reminders-widgets', prompt: 'Reminders, exact alarms, notifications permission (API 33+), boot/time-zone/time change receivers, Doze, WorkManager, Glance widget refresh and snapshot correctness across process death and updates.' },
  { key: 'data-integrity', prompt: 'SQLite schema/migrations, transactions, backup create/restore (file and Drive), encryption/KDF, drafts, concurrent edits, delete-all, and data loss or duplication risks.' },
  { key: 'lifecycle-ui', prompt: 'Activity/ViewModel lifecycle, configuration changes, process death restoration, dialogs and pickers, back handling, deep links from notifications/widgets, locale/RTL/font scale, and crash risks (unchecked casts, !!, index errors) on user paths.' },
  { key: 'security-release', prompt: 'Manifest exported components, intents, FileProvider, FLAG_SECURE/app lock, PHI in logs or crash surfaces, R8/ProGuard keep rules that could break reflection, JSON codecs or Play services in release builds only (a release-only failure could explain Drive status 8).' },
]
phase('Find')
const verified = await pipeline(LENSES,
  (l) => agent(`${COMMON}\nLens ${l.key}: ${l.prompt}`, { label: `find:${l.key}`, phase: 'Find', schema: FINDINGS, effort: 'high' }),
  async (res, l) => {
    if (!res) return []
    const keep = res.findings.filter(f => f.severity !== 'low')
    if (res.findings.length !== keep.length) log(`${l.key}: ${res.findings.length - keep.length} low-severity findings not verified`)
    const judged = await parallel(keep.map(f => () => agent(`${COMMON}\nAdversarial verifier. Try to REFUTE this finding by reading the actual code paths and documentation; default to real=false if the evidence does not hold. Finding: ${JSON.stringify(f)}`,
      { label: `verify:${f.id}`, phase: 'Verify', schema: VERDICT, effort: 'high' }).then(v => ({ ...f, verdict: v }))))
    return judged.filter(Boolean)
  })
const all = verified.flat().filter(Boolean)
phase('Synthesize')
const report = await agent(`${COMMON}\nSynthesize the verified Android bug audit into ${OUT}/android-bug-audit.md and ${OUT}/android-bug-audit.json. Input (each with an adversarial verdict): ${JSON.stringify(all)}. Keep only real=true findings in the main table (ordered by severity and user impact), list refuted ones briefly with reasons. For Google Drive status 8: a ranked hypothesis table and an exact device debugging script (adb logcat filters, which screens to tap, what each outcome means) that the coordinator can run once the phone is authorized, without installing or uninstalling anything on the phone. Same for Health Connect freshness. Return a short summary.`,
  { label: 'synthesize', phase: 'Synthesize', effort: 'high' })
return { count: all.length, real: all.filter(f => f.verdict && f.verdict.real).length, report }