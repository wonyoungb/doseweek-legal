export const meta = {
  name: 'android-history-import-finish',
  description: 'Finish Android history import (UI + data sub-lanes, native journeys, adversarial review, official gates, merge)',
  phases: [{ title: 'Build' }, { title: 'Integrate' }, { title: 'Review' }, { title: 'Gate' }],
}
const S = '/private/tmp/claude-501/-Users-wonyoungchoi-Documents-Coding-Work/13de090a-e5e7-4ced-81d4-62d99d8291cf/scratchpad'
const B = '/private/tmp/doseweek-v11-20260913'
const PKG = '/Users/wonyoungchoi/Documents/Coding Work/DoseWeek_Final_v11_2026-09-13'
const HANDOFF = '/Users/wonyoungchoi/Documents/Coding Work/DoseWeek_Continuation_2026-09-15/HANDOFF.md'
const ENV = 'JAVA_HOME="/Applications/Android Studio.app/Contents/jbr/Contents/Home" ANDROID_HOME="$HOME/Library/Android/sdk"'
const RUNNER = '/var/folders/rm/5ghnhsk55zj7yvxl08yhwjrw0000gn/T/opencode/run-import-store-tests.command'
const RULES = `PHYSICAL PHONE SAFETY: the owner's real phone (adb serial R3CX804JPJX, Galaxy SM-S928N) is attached to this Mac. Never target it: never run adb, installDebug, connectedDebugAndroidTest or any instrumentation without ANDROID_SERIAL set to an emulator you own (emulator-5560/emulator-5570 per the repo runner), never uninstall/clear/install on it, never read its data. Only the coordinator touches that phone. Owner rules (confirmed; never ask again): edits, commits, pushes, PRs, merging verified work to main and builds are pre-approved; never ask permission. If product/data meaning is genuinely ambiguous, do not guess: do the independent parts and return the question (facts, two options, recommendation). Missing administration time: the importing user must supply/confirm the real time in review; never invent midnight/noon; never add a date-only administration model. Plan-free record-only use must keep working. Imports only append reviewed records (never overwrite, never use backup restore), no inventory deduction by default, no automatic Health Connect/Drive consent. Simple design, no missing capability. Tests may pin dates; product code uses Clock/user input. Never weaken guards/tests, delete/loosen assertions, skip tests, regenerate expected values from output, reset --hard/clean/stash others' files, force-push, bypass branch protection, or kill processes/emulators you did not start. Physical-device-only checks: BLOCKED/NOT_RUN and continue. Don't re-run already-passed suites for unrelated changes. Commit messages: normal prose ending with "Co-Authored-By: Claude Opus 5 (1M context) <noreply@anthropic.com>". Update docs/CURRENT_HANDOFF.md and docs/HISTORY_IMPORT_HANDOFF.md with exact commands/results before returning. Temp files only under ${S}/<your-label>/. Host: 24 GB RAM shared with an iOS agent (simulator/Xcode) and Python agents; never run two emulators yourself. Anything longer than about 10 minutes (official run_ci.sh, instrumentation matrix) goes in a .command file started with "open -a /System/Applications/Utilities/Terminal.app <file>" while you poll its log (the harness kills long background jobs). If context gets tight: commit+push a checkpoint, update handoff docs, return the exact next step. Returned strings: terse caveman-ultra fragments with exact numbers, paths, SHAs.`
const READ = `Read first: AGENTS.md (binding), docs/HISTORY_IMPORT_HANDOFF.md, docs/CURRENT_HANDOFF.md, ${PKG}/specs/HISTORY_INPUT_AND_FILE_IMPORT.md, ${PKG}/contracts/history_import_contract_v1.json, ${PKG}/requirements/owner_import_cases_v1.json (IM01-IM30, VIS, DL) and section 5 of ${HANDOFF}.`
const RESULT = { type: 'object', properties: {
  summary: { type: 'string' }, branch: { type: 'string' }, head: { type: 'string' },
  commits: { type: 'array', items: { type: 'string' } }, pushed: { type: 'boolean' }, merged: { type: 'boolean' },
  tests: { type: 'array', items: { type: 'string' } }, notRun: { type: 'array', items: { type: 'string' } },
  questions: { type: 'array', items: { type: 'string' } }, nextSteps: { type: 'array', items: { type: 'string' } },
}, required: ['summary', 'branch', 'head', 'commits', 'pushed', 'tests', 'notRun', 'questions', 'nextSteps'] }
const REVIEW = { type: 'object', properties: {
  verdict: { type: 'string', enum: ['ok', 'issues'] },
  issues: { type: 'array', items: { type: 'object', properties: {
    severity: { type: 'string', enum: ['blocker', 'major', 'minor'] }, file: { type: 'string' }, line: { type: 'integer' },
    problem: { type: 'string' }, evidence: { type: 'string' }, fix: { type: 'string' } }, required: ['severity', 'problem', 'evidence'] } },
}, required: ['verdict', 'issues'] }

const UI = `Android history-import UI sub-lane. Repo DoseweekPlayStore (remote https://github.com/wonyoungb/DoseweekPlayStore.git). Base branch feat/history-import (HEAD 197d9f397e630462f223daa1a774c31dbe2b1986, pushed, worktree ${B}/android-import). Do NOT edit that worktree. Create and use your own: git -C ${B}/android-import worktree add ${B}/android-import-ui -b feat/history-import-ui feat/history-import
${READ}
${RULES}
Scope (mainly features/historyimport/*, res/values*/history_import.xml, their tests):
1. Explicit backward navigation between source, mapping, review and confirmation phases, including system back, never losing raw input, mapping or manual row corrections; the protected draft stays consistent.
2. Mapping labels: localized human description per field with the fixed machine header as secondary text; the decimal-separator label must be generic (manual entry and files). All 17 locales, same tone as existing strings, placeholders valid.
3. Limits: Add Row cap consistent with contract maxRows (or a stricter justified cap) and a serialized draft/snapshot byte budget with explicit localized rejection before persisting; never truncate; boundary tests.
4. JSON extraction rows other than administration/body measurement (symptom/unclassified): keep original text visible, explain in localized copy why they cannot be saved in this version, require explicit deselection; never claim support. Return this as an open product question (import symptoms later or not).
5. Check all in-app import copy so nothing claims more than this build does.
Verify: ${ENV} ./gradlew testDebugUnitTest lintDebug (report discovered test count), python3 scripts/check_invariants.py, git diff --check. Do NOT start an emulator (the data sub-lane owns it now). Add instrumented/Compose tests for new UI behaviour where appropriate but leave executing them to the integration step (list in notRun). Commit in meaningful units, push feat/history-import-ui, do not merge.`

const DATA = `Android history-import data sub-lane. Repo DoseweekPlayStore. Base branch feat/history-import (HEAD 197d9f397e630462f223daa1a774c31dbe2b1986, worktree ${B}/android-import). Do NOT edit that worktree. Create and use your own: git -C ${B}/android-import worktree add ${B}/android-import-data -b feat/history-import-data feat/history-import
${READ}
${RULES}
Scope (DoseWeekDatabase/DoseWeekRepository/backup/export/history detail and tests):
1. Frozen v11 to v12 native migration test in androidTest following the existing pattern (DatabaseMigrationV11Test, CurrentDatabaseVersion.kt), including injected-failure rollback that leaves v11 data intact and reopenable. Narrowly update existing migration tests whose only change is the latest opened version; frozen source schemas and preservation assertions stay unchanged.
2. Show committed import provenance (recorded source name/type, imported-at, preserved original values) on the ordinary history detail surfaces for imported administrations and body records; 17 locales; no PHI in logs.
3. Standardized history table export using exactly the contract header (source_record_id,administration_date,administration_time,time_zone,utc_offset,medication_name,dose,dose_unit,site_code,note), UTF-8, CSV and TSV, reachable from the existing History export entry in addition to the existing exports. Apply spec section 8 CSV formula-injection protection with a documented policy that re-import restores the original text; stable source_record_id so re-importing the same export classifies rows as already imported and changed rows as conflicts. Prove export then import roundtrip (JVM plus one native test). This is the cross-platform exchange format; iOS will implement the identical format, so document it precisely in docs/HISTORY_IMPORT_HANDOFF.md.
4. Backup payload 9 stays compatible; staging and drafts never enter backup.
Verify: ${ENV} ./gradlew testDebugUnitTest lintDebug, python3 scripts/check_invariants.py; native on an owned API 24 emulator then API 36 (existing runner pattern ${RUNNER}; storage suite com.wonyoungchoi.doseweek.data.HistoryImportStoreTest has 8 cases) for the new migration and roundtrip tests. You own the emulator during this phase; shut down only what you start. Commit, push feat/history-import-data, do not merge.`

phase('Build')
const [ui, data] = await parallel([
  () => agent(UI, { label: 'android-import-ui', phase: 'Build', schema: RESULT, effort: 'xhigh' }),
  () => agent(DATA, { label: 'android-import-data', phase: 'Build', schema: RESULT, effort: 'xhigh' }),
])

phase('Integrate')
const integ = await agent(`Android history-import integration. Work in ${B}/android-import on branch feat/history-import.
${READ}
${RULES}
Sub-lane results: UI ${JSON.stringify(ui)} ; DATA ${JSON.stringify(data)}. (Null means that sub-lane died; then finish its scope yourself from its branch state.)

RESUME NOTE: an earlier attempt of this step was interrupted. Its worktree may already contain commits and uncommitted changes (run git status and git log first, read the handoff docs there); review that work with git diff, keep what is correct, finish it, and never discard it blindly. Current state of ${B}/android-import: both sub-lanes are already merged (6ac7623, e9483cb) and about 34 uncommitted files (new native journey tests incl. HistoryImportFilePickerJourneyTest, SystemDocumentPicker, locale sheet test, controller/sheet edits, libs.versions.toml) were left by the interrupted attempt.
1. Merge feat/history-import-ui and feat/history-import-data into feat/history-import (already done if the merge commits exist) with merge commits, resolving conflicts so both intents survive; JVM tests, lint, invariants.
2. Native journeys on owned emulators (API 24 then API 36, one at a time): real system document picker (ACTION_OPEN_DOCUMENT/DocumentsUI driven by UiAutomator with test files pushed to the emulator: select and cancel); CSV and TSV with non-template headers through mapping; row correction including missing-time confirmation supplied by the user; already-imported versus changed-content conflict; potential duplicate acknowledgement keeping separate real events; back navigation preserving corrections; close with draft, process death, resume; completion recovery; new limit rejections; unsupported JSON rows deselection; standardized export then re-import roundtrip; provenance on history detail.
3. 17-locale pass: for every shipped locale exercise the import sheet states (source, mapping, review, confirm, result) asserting resolved localized text and no clipping, following the repo's existing localization test patterns.
4. Fix product bugs found (not the tests), commit, push. Do not run the official full CI or matrix and do not merge to main (the gate step does).`,
  { label: 'android-import-integrate', phase: 'Integrate', schema: RESULT, effort: 'xhigh' })

const LENSES = [
  { key: 'contract', focus: 'IM01-IM30 and owner decisions: missing-time confirmation, append-only, no inventory/consent side effects, source-id already-imported vs conflict, duplicate handling, retry receipts/idempotency, limits streamed not metadata-only, standardized export format exactness and roundtrip, no over-claiming copy.' },
  { key: 'persistence', focus: 'DB v12 migration and rollback, single-transaction selected append, store generation/session invalidation after delete-all or restore, backup payload 9 and legacy 1-8 compatibility, staging/draft protection and backup exclusion, process death recovery, concurrency.' },
  { key: 'ux-l10n-tests', focus: '17 locales complete and natural, placeholders, no English fallback, simple UI, back navigation, accessibility labels, error messages; tests actually exercise claimed flows (no vacuous or skipped tests), native tests really drive DocumentsUI.' },
]
phase('Review')
const reviews = await parallel(LENSES.map(l => () => agent(
  `Adversarial read-only reviewer (${l.key}) for Android history import in ${B}/android-import, branch feat/history-import, diff against origin/main. Integration result: ${JSON.stringify(integ)}. ${READ} Do not edit, commit, or start Gradle/emulators. Try to refute that the feature is correct and complete. Focus: ${l.focus} Report only issues with concrete evidence (file:line, reasoning). Terse caveman-ultra strings.`,
  { label: `review:${l.key}`, phase: 'Review', schema: REVIEW, effort: 'high' })))
const issues = reviews.filter(Boolean).flatMap(r => r.issues)

phase('Gate')
const gate = await agent(`Android history-import gate. Work in ${B}/android-import on branch feat/history-import.
${READ}
${RULES}
Integration result: ${JSON.stringify(integ)}. Reviewer findings (unverified): ${JSON.stringify(issues)}.
1. Verify each finding against code; fix confirmed ones with tests; list rejected ones with reasons.
2. On the final clean pushed candidate run the official ./scripts/run_ci.sh and then ./scripts/run_instrumentation_matrix.sh via Terminal .command files, sequentially, polling logs, no guard or selection overrides. On failure: diagnose, fix real defects honestly, re-run affected focused suites, then the gates again.
3. Run python3 scripts/check_play_metadata.py. If a Play listing screenshot surface changed, follow the repository capture/frame procedure in AGENTS.md; otherwise record why recapture is not needed.
4. When every gate passes on the exact final SHA: open a PR feat/history-import to main with gh, merge with a merge commit (no force, no protection bypass), verify origin/main SHA equals the tested tree, and make sure docs/CURRENT_HANDOFF.md on main is accurate. Also remove the two sub-lane worktrees (${B}/android-import-ui, ${B}/android-import-data) only if clean and fully merged. Never touch Play Console.
If the gates cannot pass, do not merge; return failures and next steps.`,
  { label: 'android-import-gate', phase: 'Gate', schema: RESULT, effort: 'xhigh' })
return { ui, data, integ, reviews, gate }