# Coordinator log — 2026-09-15 (Claude Code session 13de090a)

The full request is still unfinished. This log records what the coordinating session launched, so a later session can find the parallel work.

## State found at session start

- iOS full CI run `full-ci-launcher/run-oyRImc0x` (candidate 4c3e594) is not running. iPhone and iPad legs each ended with one failure, `HistoryExportFeedbackUITests.testNativeExportCalendarEnforcesBothBoundsAndAcceptsOneDay()` at line 133. The AX5 leg ended with `BUILD INTERRUPTED`; no exit code was written. The three booted CI simulators from that dead run were shut down by UDID.
- Diagnosis of the iOS failure: a product bug, not a test bug. The recording frame shows the Through date editor with September 1–14, 2025 disabled while From had already been confirmed as September 1, 2025. The Through lower bound still used the old default start (one year before today). The test only catches it when today's day of month is 15 or later. Evidence frames are in the session scratchpad under `iosfail/`.

## Parallel workflows launched (ultracode, owner request)

| Workflow | Run ID | Work location | Scope |
|---|---|---|---|
| ios-export-calendar-fix | wf_9834594e-959 | `ios` on `codex/v11-bugfix` | Fix stale date bounds, date-independent regression, focused UI legs, two reviewers, refix. Does not launch the full CI; the coordinator launches it. |
| android-history-import-finish | wf_66648d52-299 | `android-import` plus sub-lane worktrees `android-import-ui`, `android-import-data` | Back navigation, localized mapping labels, limits, unsupported JSON rows; v11→v12 migration and rollback, provenance on history detail, standardized contract-format export and roundtrip; merge; native SAF/CSV/TSV/conflict/resume journeys and a 17-locale pass; three reviewers; official CI and matrix; PR and merge to main when green. |
| nutrition-data-release | wf_5f2cbfe0-1eb | new `android-nutrition-data` on `feat/nutrition-data` | Deterministic data release from USDA, CoFID, MEXT (MFDS only if licensable without account or key), localization status for 17 locales, validation, two verifiers, fix. Not merged. |
| ios-history-import-integration | wf_04af2895-19d | new `ios-import` on `feat/history-import` (from `codex/v11-bugfix`) | Reuse prepared Swift parsers; UI, ModelActor transaction, protected staging, migration, backup, export parity, 17 locales; compile with its own DerivedData while other iOS runs are active; two reviewers, fix. |
| feature-designs-wave2 | wf_a5a8d127-6e6 | read-only; output in `designs/` in this folder | Explicit schedule dates, calendar sync, body chart references, SDK/adaptive scope, each with a reviewer and revision. |
| designs-wave3-nutrition-coverage | wf_2af890d7-81d | read-only; output in `designs/` | Nutrition app feature design for both platforms; requirement coverage audit of every registry ID and owner decision against real code, tests and evidence. |

Legal: the uncommitted `/import/` guide candidate (status `preparation_only`, render and site checks passed) is preserved on the unpublished branch `candidate/import-guide` of doseweek-legal. It is not merged to main and not published.

Workflow scripts and transcripts: `~/.claude/projects/-Users-wonyoungchoi-Documents-Coding-Work/13de090a-e5e7-4ced-81d4-62d99d8291cf/workflows/scripts/` and `.../subagents/workflows/<run id>/`. A killed workflow can be resumed with its script path and run ID.

## Coordinator next actions

1. When the iOS fix workflow completes, review its result, then launch the full iOS CI outside the harness with `full-ci-launcher/Run-Full-CI.command` after updating `expected-head.txt`.
2. When the designs complete, relay open product questions to the owner and start implementation workflows for the remaining features in dependency order (explicit dates, then calendar sync; charts; nutrition app integration on both platforms; SDK/adaptive; legal and store; final integrated verification).

## Owner decision recorded 2026-09-15

- HEALTH-20260915-01. Question: Apple Health and Health Connect have no body fat mass (kg) type; should the app calculate it from weight and body fat percentage? Answer: "계산해서 표시 (추천)". Scope: show body fat mass calculated as weight × body fat percentage only when both values come from the same measurement (same timestamp and source, or the same manual record); label it as calculated in all 17 locales; never write it to HealthKit/Health Connect and never store or back it up as an imported sample; identical rule on iOS and Android. Trigger: a user of InBody → Apple Health reported that BMI and body fat mass / lean body mass were not imported while weight and body fat percentage were.
- Workflow health-body-composition-fix (first run wf_4ecfcf54-68f stopped during diagnosis; relaunched with this decision as wf_648bd756-160, script copy in `workflows/health-body-composition-fix.js`) diagnoses and fixes the iOS BMI and lean body mass import, adds the calculated body fat mass, and checks Android parity. Its branch `fix/health-body-composition` is to be folded into `codex/v11-bugfix` before the full iOS CI.

## iOS calendar fix completed; full CI launched

- Workflow wf_9834594e-959 finished. Root cause: HistoryView passed the export bounds as closures that read its `@State` lazily inside the editor's body. There SwiftUI returned the last-rendered value and recorded no dependency, and HistoryView's body never read either endpoint. So the Through minimum stayed at the old default (one year ago), and in the Through-first order the From maximum stayed at today. Fix: HistoryView's body reads both endpoints and passes them to the export sheet; `.now` stays live.
- Commits on `codex/v11-bugfix`: 7e8681b (fix, date-independent regression, new Through-first test) and 93ae0e2 (month navigation asserts the arrow is enabled, naming the blocking bound). Both pushed; draft PR #7 is 24 commits ahead of origin/main.
- Proof: red on unfixed product (iPhone standard); green `HistoryExportFeedbackUITests` 8/8 on iPhone, iPad and AX5 at 7e8681b, and 8/8 on iPhone and iPad at 93ae0e2; swiftlint strict 0 findings; invariants passed. Two reviewers: one minor diagnostic finding, fixed.
- Full CI started from Terminal on 93ae0e2: `full-ci-launcher/run-r4Cu9gqn`. It serves as the discovery run for the whole bugfix branch. The health body-composition fix is not in it; a final gate run follows once that fix is folded in.

## Designs wave 2 completed (wf_a5a8d127-6e6)

Four designs, each reviewed (8, 9, 9 and 11 issues) and revised: `designs/schedule-explicit-dates.md`, `designs/calendar-sync.md`, `designs/body-chart-references.md`, `designs/sdk-adaptive.md`, with shared fixtures under `designs/fixtures/`. The revisions carry 20 open product questions (schedule 3, calendar 6, charts 6, adaptive 5), each with a recommendation; they were put to the owner in one batch.

Version sequencing to respect when implementing: persistence changes are serialized per platform (history import first, then explicit dates, charts, calendar sync device-local state, nutrition), each taking the next free schema/DB and backup payload number. The iOS explicit-dates review found that SchemaV3–V5 share the live `PlanSegmentEntity`, so any new attribute needs frozen nested V5 copies first.

## Owner decisions DESIGN-20260915-01..20

The owner accepted all 20 recommendations ("권장안 전부 적용"). Scopes are in STATE.json decisions DESIGN-20260915-01 to -20:

1. [SCHEDULE] After the last chosen date the plan stays active with a 'no upcoming scheduled dates' card and an add-dates action; no automatic end.
2. [SCHEDULE] Future chosen dates closer than the policy-pack minimum interval are blocked at save; past facts are never blocked.
3. [SCHEDULE] Android multiple-date selection uses a custom month grid extracted from the History calendar (exception to the system-dialog default), matching iOS MultiDatePicker.
4. [CALENDAR] Events the user edited or deleted in the calendar app are detached: never overwritten or recreated.
5. [CALENDAR] When a slot is completed or skipped, delete its future event and keep past events.
6. [CALENDAR] No alerts on calendar events; app notifications remain the reminder channel.
7. [CALENDAR] Title: private generic default; user may opt in to a descriptive 'injection day' title.
8. [CALENDAR] Play Data safety: declare calendar events shared (plus health info if the descriptive title is enabled).
9. [CALENDAR] Sync window: next 84 days, at most 24 events.
10. [CHART] Percent mode shows the official kg/lb band converted to percent with an explanatory note.
11. [CHART] Cumulative goals (e.g., 5-10% in 6 months) get no band in version 1.
12. [CHART] Bands show range and source only, no category words.
13. [CHART] iPhone landscape only in the full-screen chart.
14. [CHART] No default reference; the user picks from a region-sorted list.
15. [CHART] NICE lower BMI thresholds for specific ethnic groups: threshold line at 23 only, no green fill.
16. [ADAPTIVE] Wide screens keep the floating bottom tab bar; switch to sidebar/rail only if the probe shows overlap with system bars.
17. [ADAPTIVE] Tabletop posture: avoid the hinge only.
18. [ADAPTIVE] No multiple scenes on an iPhone foldable.
19. [ADAPTIVE] iPhone stays portrait-only with size-class layout.
20. [ADAPTIVE] Narrow History/Body stay one inline screen (no list-detail push).

## Core engines workflow launched

- core-engines-wave2, run wf_ac87966e-b7d: pure engines only (explicit schedule dates, body chart references, calendar sync planner) against the shared design fixtures, with byte-identical fixture copies and SHA assertions. iOS lane in `ios-core` on `feat/core-engines` (from `codex/v11-bugfix` 93ae0e2, `swift test` on DoseDayCore only). Android lane in `android-core` on `feat/core-engines` (from origin/main, narrow JVM tests). Three reviewers (parity, iOS, Android) and a refix pass. Persistence, backup, UI and localization for these features follow later on stacked branches after history import merges, taking the next free schema/DB and payload numbers.

## Designs wave 3 completed (wf_2af890d7-81d)

- `designs/nutrition-app.md` revision 2 (10 review issues accepted): content-addressed backup split plus gated limit raises (Android envelope 16→32 MiB, iOS maxTotalRows 50k→150k) with a TOO_LARGE path; five iOS schema-bump touch points; symbolic version numbers with an integrator ledger across all five stage-2 designs; test goldens excluded from app binaries; phases P0–P7.
- `designs/requirements-coverage.md` / `.json` revision 2: 655 rows. iOS DONE 53, IMPLEMENTED_UNVERIFIED 59, lane 60, MISSING 129, BLOCKED 4. Android DONE 71, IMPLEMENTED_UNVERIFIED 61, lane 54, MISSING 126, BLOCKED 3. Unowned gaps: iOS bugfix merge and BUGFIX_BASELINE; legal/FAQ alignment and publication; bugfix scenario-variant tests on both platforms; BUGFIX_PARITY comparison; import items IM17, IM18, IM24/IMPORT_PARITY, IM27; SDK targets; store assets; VIS07 human check. The calculated body fat mass gap is now owned by the health fix workflow launched after the audit snapshot.
- Six more product questions (nutrition prefs in backup, meal edit history, personal foods, ED11 edit draft after process kill, formats beyond CSV/TSV/JSON, JSON symptom rows) were put to the owner in one batch.

## Owner decisions 2026-09-15 (second batch, all recommendations accepted)

- NUTRITION-20260915-01: Nutrition market and search-language preferences are included in backups; on restore they apply only when the device has no confirmed market, otherwise they are shown in the restore preview.
- NUTRITION-20260915-02: Meal edit/delete: confirmed hard delete, no per-meal revision history (administration audit history unchanged).
- NUTRITION-20260915-03: Personal foods: this release reuses favorites and directly entered foods only; a separate My-foods nutrient editor is deferred to a later version.
- RECORD-DRAFT-PROCESS-EXIT: ED11: keep an unfinished administration edit as a protected local draft across process death until Save or Discard; exclude it from backup; clear it on delete-all and restore.
- IMPORT-FORMATS-20260915: IM30: import supports CSV, TSV and JSON only; other files (XLSX, PDF, …) get a specific localized error advising to save as CSV; no new parsing libraries.
- IMPORT-SYMPTOMS-20260915: JSON symptom rows are importable after review and explicit selection; unclassified rows must be deselected; until implemented, the interim notice-and-exclude behaviour stays.

- bugfix-parity-audit launched, run wf_6fb1ed83-c66 (read-only; output `designs/bugfix-parity-*.md`).

## Launch queue (held while the iOS full CI UI phase loads the host: swap 6.6/8 GB, three simulators, load average up to 27)

Launch these when the CI UI phase ends or the Android import sub-lanes finish:
1. iOS bugfix follow-ups onto `codex/v11-bugfix` before the final iOS gate: fold `fix/health-body-composition`; ED11 protected edit draft (RECORD-DRAFT-PROCESS-EXIT); bugfix scenario-variant tests from `designs/requirements-coverage.md` gap 3; fixes for any divergences from the parity audit; then the final full CI, a Release build, merging PR #7 to main and writing BUGFIX_BASELINE.json.
2. Android bugfix follow-ups on a branch from main: ED11 edit draft, variant tests (gap 3), parity divergences, HC12 trace rerun, and PLAY_ASSETS re-verification.
3. Import follow-ups on both platforms after the import lanes land: symptom rows (IMPORT-SYMPTOMS-20260915), unsupported-format error (IMPORT-FORMATS-20260915), IM17 inventory opt-in net effect, IM18 schedule-impact preview, IM27 Drive dirty revision, IM24 cross-platform CSV roundtrip and IMPORT_PARITY.
4. Nutrition P1 (pure core on both platforms) per `designs/nutrition-app.md`, applying NUTRITION-20260915-01..03, then P2–P7 after the version ledger reserves numbers.
5. Stacked feature branches on top of the core engines: explicit dates, then charts, then calendar sync (persistence, backup, view models, UI, 17 locales), taking the next free version numbers from a shared VERSION_LEDGER.
6. Legal/FAQ alignment and publication once the app behaviour is merged; SDK/adaptive implementation; store assets; final integrated verification.

## Bugfix parity audit completed (wf_6fb1ed83-c66)

Output: `designs/bugfix-parity-temporal-input.md`, `designs/bugfix-parity-edit-backfill.md`, `designs/bugfix-parity-health-sites-help.md` (each verified and revised).

Divergences to fix before the bugfix baseline:
- Android DT06 (major): Body time in a repeated fall-back hour silently takes the earlier offset; iOS requires a choice. Fix mirrors `resolveRecordTime` with offset options and a selection-required state.
- Android UX02 (parity): History calendar has arrows only; iOS has a month/year jump.
- Android: manual-entry toggle accessibility label is the generic "Edit"; PR06 schedule-change notice is dropped after a past record.
- Android ED11: SavedState survives only system-initiated death; the owner decision requires a protected draft across force close.
- iOS PR09 (major): adding a past administration on a tapped empty day can save local midnight when the time is untouched.
- iOS ED01b/PR10: restore/delete and missed/skipped actions are swipe-only; ED04 has no jump or notice after a date move; PR03 preselects the active plan's medicine for pre-plan dates; ED11 edit draft is view state only.
- iOS HC11/HK03: no last-check time or unfinished catch-up signal on the Body health card.
- PR11 (both): the retry rule after an unknown commit differs (Android rejects until reopen; iOS creates a new fact).
- Test gaps: iOS SM04/SM05/SM10; evidence gaps DT03, UX04, DT08, UX10, UX08/DT10 IME composition.
Eight related product questions were put to the owner in one batch.

## Owner decisions BUGFIX-PARITY-20260915-01..08 (all recommendations accepted)

- BUGFIX-PARITY-20260915-01: PR09 iOS: adding a past administration on an empty day starts with no time; saving requires a user-chosen time (Android parity); never store an untouched midnight.
- BUGFIX-PARITY-20260915-02: PR11 both: after an unknown commit result, a changed-input save first checks whether the earlier commit landed; if it did, open that record for editing; if not, save as new; no duplicate and no stuck state.
- BUGFIX-PARITY-20260915-03: UX02 Android: add month/year jump to the History calendar in this bugfix release (iOS parity).
- BUGFIX-PARITY-20260915-04: HC11/HK03 iOS: Body health card shows last check time and an unfinished historical import state (Android parity).
- BUGFIX-PARITY-20260915-05: DT08 both: on app lock the temporary picker value is discarded while the edit draft is kept (current behaviour accepted).
- BUGFIX-PARITY-20260915-06: Android export range with calendar start/end like iOS is deferred to the new-features stage.
- BUGFIX-PARITY-20260915-07: iOS web FAQ and in-app online help links extend from ko/en/ja to all 17 locales (Android parity).
- BUGFIX-PARITY-20260915-08: Injection-site view English name unified as 'Front view' on both platforms.

## Bugfix follow-ups authoring launched (wf_6e1197b1-cdb)

Author-only mode while the host is overloaded: no xcodebuild, Gradle, simulators or emulators. Six lanes, each with its own worktree, a reviewer and a revision:
- iOS `fix/history-visible-actions` (`ios-history-actions`): ED01b, PR10, ED04.
- iOS `fix/record-flow-past-drafts` (`ios-record-flow`): PR09, PR03, ED11, PR11.
- iOS `test/bugfix-variants` (`ios-variant-tests`): variant tests from coverage gap 3; "Front view" copy.
- Android `fix/temporal-parity` (`android-temporal`): DT06, UX02, manual-entry toggle label.
- Android `fix/record-drafts-retry` (`android-drafts-retry`): ED11, PR06, PR11.
- Android `test/bugfix-variants` (`android-variant-tests`): variant tests; HC12 trace test.

A verification workflow (compile, red-then-green focused tests, fixes) must follow when the iOS full CI finishes. Then fold the verified iOS branches plus `fix/health-body-composition` into `codex/v11-bugfix` for the final iOS gate, and rebase the Android branches after history import merges. Still queued: iOS HC11/HK03 health card after the health fix, and iOS 17-locale online help via the legal pages.

## Nutrition data release completed (wf_5f2cbfe0-1eb)

- Branch `feat/nutrition-data` in `android-nutrition-data`, head c019a52 (pushed, not merged). Current release 5e329a7e5a689112644dc7782d29050087ca5d0d035c8686df98d0738a62b9b9 supersedes 335758d0… after two verifiers raised 10 findings, all confirmed and fixed.
- 6,773 records: USDA Foundation 346, CoFID 2021 2,885, MEXT 2023 2,538, MFDS 1,004 analysed dishes (3,140 calculated "100ml" dishes quarantined because the basis is undefined and proximates do not close). 8,456 official aliases (en 3,231, ja 3,733, ko 1,492). About 6.9 MB raw, 1.0 MB deflated. The release lives in `nutrition-data/`, not in `app/src/main`, because the Play screenshot freshness gate counts all of `app/src/main`.
- Validation: 47 pipeline unit tests, 8 integrity tests, 231k validator checks, determinism check, unchanged Kotlin and Swift calculators 40/40 C + 8/8 S goldens. Host-only performance numbers; device performance NOT_RUN.
- Honest status: localized search is blocked in 14 locales (no reviewed aliases); es, it, nl, pt-BR and tr markets are blocked by source terms; pt-PT is unreachable; the remaining markets are NOT_RUN. Rights caveats: the MFDS 공공누리 prior-consultation clause is unmet (clearance rests on data.go.kr "이용허락범위 제한 없음"), and the CoFID licence text appears only in the GOV.UK footer.
- Owner questions asked: MEXT macro columns, whether documentation-based definition keys may group totals, and what to do with the MFDS calculated dishes.

## Owner decisions on the nutrition data release

- NUTRITION-DATA-20260915-01 ("일반 표시 기준 열 (추천)"): MEXT macros use the conventional columns PROT- (protein), FAT- (fat) and CHOCDF- (carbohydrate by difference) for every food, keeping estimate qualifiers.
- NUTRITION-DATA-20260915-02 ("공식 문서 기반 매핑으로 합산 (추천)"): Provider-scoped definition keys mapped from official documentation may group totals; label them as documentation-based, never as expert-reviewed; group only within the same provider definition.
- NUTRITION-DATA-20260915-03 ("검색·표시만 허용"): MFDS calculated dishes (3,140, undocumented 100 mL basis) are released for search and display only, labeled basis unverified, and are never used in calculations, DTOs or totals.
- The nutrition app implementation must honour the MFDS search/display-only flag: show the basis-unverified label and never feed those records into the calculator.
- nutrition-data-release-decisions launched, run wf_fa63557b-bad: applies the three decisions, rebuilds a new dataReleaseId, adversarial verification, fix.

## Core engines completed (wf_ac87966e-b7d)

- iOS `feat/core-engines` (`ios-core`) head 7274d52: ScheduleCadence explicit-dates shape plus ExplicitDateSchedule, BodyChartReferences, CalendarSyncPlanner in DoseDayCore; byte-identical fixtures with pure-Swift SHA-256 checks; 108 package tests green; mutation runs proved the tests bite; the refix fixed occupancy (only completed/skipped facts occupy a chosen slot), declared last-injection floor and non-finite guards.
- Android `feat/core-engines` (`android-core`) head a0c3398: WeeklySchedule explicit dates, ScheduleEngine.nextOccurrenceOrNull (OccurrenceHorizonPlanner no longer throws on exhausted lists), BodyChartReferences, CalendarSyncPlanner; full testDebugUnitTest 746/746 green once; 8 review items fixed.
- Reviews: parity 7 issues, iOS 4, Android 4; all handled or turned into two open items.

Coordinator decisions (technical parity within already-approved designs, no new product meaning):
- CORE-20260915-01: a personal target ("My target") cue is inclusive at both bounds; value and bounds are compared in the chart unit after conversion, rounded to the rule's display decimals (same rule as official bands, design §4.3; a single-line target requires inclusive bounds).
- CORE-20260915-02: for explicit-date proposals only completed and skipped rows occupy a chosen slot (design §3.3). Scheduled, due, needs-review and cancelled rows do not; existing interval-schedule behaviour is unchanged. Android aligns to this.
- Shared fixtures move to v3 with the missing cases (occupancy by status, kg ≤ 0 samples, invalid zoom scale, rounding at −0.004, personal-target membership, unusable calendar gate hours), and both repositories pin fixture SHAs in their invariant scripts.
- core-engines-parity-closure launched, run wf_d4d6b1db-c2e: fixtures v3 from the Python reference generators, adoption on both platforms, personal-target membership, occupancy alignment, SHA pins in check_invariants, parity review and refix.

## Discovery CI run-r4Cu9gqn stopped (14:05 KST)

The run on 93ae0e2 had completed about a third of each UI leg (iPhone 106, iPad 108, AX5 92 of about 324 test launches each) after 62 minutes. It then slowed to about 3 minutes per launch while swap sat at 8.2 of 9.2 GB under the parallel development lanes (Android emulator, Gradle, SwiftPM, iOS import compiles). Results under that thrash would be unreliable (timeouts), and a final gate is required anyway after the health fix and the bugfix follow-ups are folded in. The coordinator sent SIGTERM to its own `run_ci.sh` so the runner's EXIT trap released its simulators and background jobs. It is not a pass and not a product failure.

Plan: finish authoring and verification lanes; fold verified branches into `codex/v11-bugfix`; then hold new heavy lanes and run the final full CI in a quiet window.
- Stop confirmed: wrapper recorded exit 143 (SIGTERM), final git status clean, the three leg subshells and their xcodebuild processes ended, all three CI simulators shut down, swap back to 2.2 GB.

## Health body-composition fix completed (wf_648bd756-160)

Diagnosis:
- BMI: iOS never requested or read `HKQuantityTypeIdentifierBodyMassIndex`. Three gates also dropped Health-origin "bmi" rows (validator default, actor live range, bounded fetch). Health Connect has no BMI record type.
- Lean body mass: no code defect. It has been requested and read since the first shipped build. InBody's own release note (InBody app v2.9.31, 2026-08-04) enables lean body mass in Apple Health only in the US and Canada, so a Korean InBody user most likely has no lean body mass samples. The other possible cause is that the per-type toggle is off. Which types InBody+ writes is unconfirmed by any primary source.
- Body fat mass: no HealthKit or Health Connect type. It is now calculated per HEALTH-20260915-01.

Branches (pushed, not merged):
- iOS `fix/health-body-composition` (`ios-health`) head 5f82a69. BMI import (unitless 5–100) through validator, actor, bounded fetch, Body/History/export/backup. Same-instant precedence: manual > imported > calculated. HealthKit purpose string and privacy copy list BMI in 17 locales; the guard's approved text was updated deliberately and still says "never writes". After an explicit import, a notice names each metric Apple Health returned nothing for. A new-type access review uses `statusForAuthorizationRequest`. Calculated fat mass only from the same Apple Health measurement (identical start time and same app); manual entries never pair on iOS. fr/it "body fat %" labels retitled. 1170/1170 unit tests on a private simulator and DerivedData; swiftlint and invariants passed. UI tests, AX5/iPad and device checks NOT_RUN; no UI tests yet for the new chip, access-review prompt or missing-metric notice.
- Android `fix/health-body-composition` (`android-health`) head 394952b. Calculated fat mass (same instant and origin package, or the same manual body record), chip and note; screen only; nothing persisted. JVM tests, lint and androidTest compile passed; reviewer found no issues. Emulator UI tests NOT_RUN.

Five follow-up owner questions asked (export inclusion, iOS combined manual entry, BMI tie precedence, further calculated values, fr/it label rename).

## Owner decisions HEALTH-20260915-02..06 (all recommendations accepted)

- HEALTH-20260915-02: Calculated body fat mass is shown only on app screens (Body, History); it is not included in CSV/PDF exports or visit-prep summaries, which keep measured and entered values only.
- HEALTH-20260915-03: iOS adds a combined manual entry for weight plus body fat percentage (Android ManualBodyRecord parity); values entered together yield calculated body fat mass; separately entered values never pair.
- HEALTH-20260915-04: When a manually entered BMI and an Apple Health BMI share the same instant, the manual value is shown first.
- HEALTH-20260915-05: No further calculated values: Android BMI stays computed only from manually entered height and weight (Health Connect has no BMI type); lean body mass is shown only when a source app provides it (never weight minus fat mass).
- HEALTH-20260915-06: French and Italian body-fat-percentage labels become 'Taux de masse grasse' / 'Percentuale di grasso' to avoid confusion with body fat mass.
- health-body-composition-followup launched, run wf_6fd62259-31f: iOS combined weight + body fat manual entry, export-exclusion and tie-precedence proofs, UI tests for the fat-mass chip, access review and missing-metric notice (iOS on a private simulator; Android compile-only), rule 9 wording, reviews and refix.
- nutrition-core-p1 launched, run wf_ceee2365-c5c: pure nutrition core on iOS DoseDayCore and Android domain (reused calculators, contract goldens, presentation rules, decimal input, formatter, text normalizer, search-only usage guard) in `ios-nutrition-core` / `android-nutrition-core` on `feat/nutrition-core`, with two reviewers and a refix pass.

## Android real-device debugging requested (owner, 2026-09-15)

- At request time the phone was not visible to adb or USB (only emulator-5560 listed; no Android device in the USB tree). The owner was given the macOS steps (no driver needed): data cable, Developer options, USB debugging, accept the RSA prompt; or wireless debugging pairing. A background watcher waits for a non-emulator device.
- Safety for the owner's phone: never install, uninstall, clear data or run instrumented tests on it; read-only logcat/dumpsys only; every command uses an explicit `-s <serial>`. All repository instrumentation runners target emulators via `ANDROID_SERIAL` (emulator-5560 / emulator-5570).
- android-drive-and-bug-audit launched, run wf_b1e39ec6-9f3: read-only multi-lens bug hunt on Android main (Drive authorization status 8 root cause, Health Connect freshness, reminders/widgets, data integrity, lifecycle/UI, security/release), each finding adversarially verified, synthesized into `designs/android-bug-audit.md` with a device debugging script.

## Session restart 2026-09-15 ~14:30 KST

The previous session ended with the weekly usage limit (reset 13:00 KST). Interrupted workflows and their state:
- android-history-import-finish wf_66648d52-299: UI lane (b928898) and data lane (930cadf) done; both merged into feat/history-import (6ac7623, e9483cb); the integrate step was mid-work (34 uncommitted files: native journey tests incl. system document picker, locale sheet test). Resumed with a resume note.
- ios-history-import-integration wf_04af2895-19d: 8 commits pushed on feat/history-import (head 86c2a52) before interruption. Resumed.
- bugfix-followups-author wf_6e1197b1-cdb: all six author lanes and reviews done; android-temporal (fee00cc) and ios-history-actions (d1760b8) revised; revisions for ios-record-flow, ios-variant-tests (has an in-progress merge from the record-flow lane), android-drafts-retry, android-variant-tests were interrupted. Resumed.
- nutrition-data-release-decisions wf_fa63557b-bad: decisions applied (release 914a2e20…, head 769e1e9); verifier found minor issues; fix stage resumed.
- nutrition-core-p1 wf_ceee2365-c5c, android-drive-and-bug-audit wf_b1e39ec6-9f3: little or no progress; resumed.
- core-engines-parity-closure wf_d4d6b1db-c2e: fixtures v3 produced (designs/fixtures, v3.sha256) with six open technical questions; adoption not started. To be relaunched as v4 after the coordinator decides the questions.
- health-body-composition-followup wf_6fd62259-31f: no results; android-health holds uncommitted test files. Held until the iOS import lane finishes (simulator memory).
Script copies with resume notes and a physical-phone safety rule live in `workflows/`.

## Owner's phone attached (read-only diagnostics approved)

- adb serial R3CX804JPJX, Galaxy SM-S928N, Android 16 (API 36), build BP4A.251205.006.S928NKSS6DZH2, Google Play services 26.33.32. DoseWeek installed from Play: versionCode 9, versionName 1.0.0, installed 2026-09-12 18:02. No DoseWeek crash or ANR entries in dropbox.
- Installed APK signer (apksigner, v3 only, one signer, RSA 4096, CN=Android/Google Inc.): SHA-1 6D:FB:8E:7B:7D:37:D8:F6:2E:30:62:CA:74:D6:79:82:31:45:61:23, SHA-256 94:60:91:EE:24:88:2D:29:D0:ED:05:7B:87:BA:64:73:97:60:90:9A:D6:05:1E:F2:DF:8A:8C:DB:1F:BE:9E:B6. Only one signer is present, so the "post-quantum second signer" hypothesis in PLAY_CONSOLE_ANSWER_SHEET.md does not apply to this delivered APK. The Android OAuth client must carry exactly this SHA-1 (owner checks in Cloud Console; console pages are owner-only).
- A 15-minute logcat capture is running while the owner taps Google Drive connect; output `scratchpad/device/logcat-drive-session.txt`.

## Google Drive status 8: root cause found on the owner's phone (14:38 KST)

Captured while the owner tapped Connect (excerpt `evidence/device-drive-20260915/auth-flow-excerpt.txt`, full log `logcat-full.txt`):
- 14:38:30.472 GMS `AuthorizeOperation` succeeded → the app received a resolution and launched `com.google.android.gms/.auth.api.credentials.authorization.ui.AuthorizationActivity` (so the app-side call and the consent launch work).
- 14:38:31.978 inside that activity: `AccountReauth_flowRunner Flow failed … cqfg: [8] Unknown error [status=UNREGISTERED_ON_API_CONSOLE]`, then `AuthorizationChimeraActivity Activity finished with error` with the same status. Google Play services 26.33.32.
- Meaning: Google's auth backend has no OAuth client for package `com.wonyoungchoi.doseweek` with the certificate that signed the installed APK (SHA-1 `6D:FB:8E:7B:7D:37:D8:F6:2E:30:62:CA:74:D6:79:82:31:45:61:23`, the only signer, RSA 4096). Status 8 is not a transient INTERNAL_ERROR here; the app's classification (retry guidance) is therefore misleading for this sub-status. Not a network, consent-screen, scope or Drive API problem.
- Fix (owner, console pages are owner-only): in Cloud project doseweek-507313 → APIs & Services → Credentials → Android OAuth clients, confirm one client has exactly that SHA-1; if not, create it (Play Console → Test and release → Setup → App signing → App signing key certificate should show the same SHA-1). Then retry Connect; the capture can be repeated.
- App follow-up: classify status 8 with status message `UNREGISTERED_ON_API_CONSOLE` as MISCONFIGURED (existing copy "이 앱 빌드는 Google 계정 연결에 등록되어 있지 않습니다") and surface the Google status text; workflow launched below.

## OAuth client created for the installed signing certificate (owner-approved, via Chrome, ~15:00 KST)

- Cloud project doseweek-507313 had four Android OAuth clients; none carried the installed APK's SHA-1. Observed: "Doseweek-Google-Drive" (Sep 8) = 20:74:0D:42:BB:0C:3C:AD:6D:BA:95:1A:DF:32:4D:44:AE:D0:10:0E; "Doseweek-Google-Drive-pqc-signing-key" (Sep 10) = 6F:BD:1A:3D:25:FF:4F:83:41:CB:C3:CB:6F:1D:B6:B8:2B:0A:56:74; upload-key and debug-key clients are for local builds. So the Play-delivered APK (signer 6D:FB:8E:7B:…:61:23) matched no client, which is exactly Google's UNREGISTERED_ON_API_CONSOLE.
- Created Android client "Doseweek-Google-Drive-play-signing-installed": package com.wonyoungchoi.doseweek, SHA-1 6D:FB:8E:7B:7D:37:D8:F6:2E:30:62:CA:74:D6:79:82:31:45:61:23, client ID 1031604954781-2hnn1ia01ooplbp7ur9k7g3vrhd487ad.apps.googleusercontent.com. Google notes 5 minutes to a few hours before it takes effect. Nothing else was changed or deleted.
- Open question for the owner: which key Play Console shows as "App signing key certificate" (whether 20:74:0D… or 6F:BD:1A… was copied from there). The delivered APK is what matters and now has a client.
- Next: owner retries Connect after a few minutes; the coordinator captures logcat again. If Google still returns status 8, capture the new status token.
- Owner asked to remove unnecessary clients. Deleted three Android OAuth clients (restorable for 30 days from the console's "Restore deleted OAuth clients"): "Doseweek-Google-Drive" (20:74:0D…, Sep 8), "Doseweek-Google-Drive-pqc-signing-key" (6F:BD:1A…, Sep 10), "Doseweek-Google-Drive-upload-key-local-builds" (A4:4A:E8…, Sep 10). Kept two: "Doseweek-Google-Drive-play-signing-installed" (Play-delivered APK) and "Doseweek-Google-Drive-debug-key-local-builds" (debug builds on this Mac's emulators). No API keys or service accounts exist in the project.

## Play app signing vs OAuth clients: reconciled (~15:20 KST)

Play Console → App signing (read via the console's copy buttons):
- Current app signing key, in use, "Quantum-ready (beta)", upgraded 29 August 2026 (next upgrade allowed 29 August 2027): classical SHA-1 20:74:0D:42:BB:0C:3C:AD:6D:BA:95:1A:DF:32:4D:44:AE:D0:10:0E (SHA-256 44:C9:81:FE:…:AC:B3); post-quantum SHA-1 6F:BD:1A:3D:25:FF:4F:83:41:CB:C3:CB:6F:1D:B6:B8:2B:0A:56:74.
- Previous app signing key (last used Aug 2026, console install-base figure 0%): SHA-1 6D:FB:8E:7B:7D:37:D8:F6:2E:30:62:CA:74:D6:79:82:31:45:61:23 — exactly the signer of the APK on the owner's phone (versionCode 9, installed 2026-09-12). So devices that had the app before the key upgrade keep receiving previous-key builds, while new installs on newer Android get the current key. Both keys are live in the field; the console's 0% is lagging or excludes this case.
- Consequence: the earlier clients "Doseweek-Google-Drive" (20:74…) and "…-pqc-signing-key" (6F:BD…) were correct for new installs and were restored after being deleted at 15:05; the new "…-play-signing-installed" (6D:FB…) covers previous-key installs. The owner confirmed Drive backup works on the phone after the new client was added.
- Deleted for good (restorable 30 days): "…-upload-key-local-builds" (A4:4A:E8…, only for upload-key-signed sideloads) and "…-debug-key-local-builds" (debug builds on this Mac; Drive cannot be exercised on emulators without a Google account anyway). Final set: three Android clients, no API keys, no service accounts. Android OAuth clients carry no secret.

## Drive connection confirmed on the owner's phone (14:49 KST)

Retry capture `evidence/device-drive-20260915/auth-flow-retry-excerpt.txt`: AuthorizeOperation succeeded, `AuthorizationChimeraActivity Activity finished successfully`, UpdateDefaultAccountOperation succeeded, no UNREGISTERED_ON_API_CONSOLE. The owner confirmed backup works. Owner decision: keep the three Android OAuth clients.

## Coordinator parity decisions CORE-20260915-03..08 (fixture v3 open questions)

- CORE-20260915-03: Calendar sync: a user-edited event whose slot has resolved keeps its detached link until the event's end time passes; cleanupOrphans never deletes a user-modified event (DESIGN-20260915-04); reconcile status stays idempotent.
- CORE-20260915-04: Calendar sync: cleanupOrphans is an explicit user action and may run while sync is disabled; the reported status afterwards is disabled, never synced.
- CORE-20260915-05: Explicit dates: lifecycle after the last chosen date is computed from materialised rows only (design §4.1); iOS aligns to Android.
- CORE-20260915-06: Explicit dates: a completed or skipped occurrence row occupies its chosen slot regardless of the local day on which the fact was recorded; iOS aligns for explicit-date proposals.
- CORE-20260915-07: Body chart: zoom span at or below zero clamps to the 7-day minimum (no throw); a percent-per-week target converted to kg with interval start weight at or below zero is unavailable (no throw); a kg-per-week target shown in percent mode converts symmetrically with the interval-start denominator. Same on both platforms.
- CORE-20260915-08: Calendar sync: the iOS 'restricted' access state maps to the shared planner's permissionLost; Android has no such state (documented).
- Launched core-engines-parity-v4 (wf_78273b7b-fc2: fixtures v4 with CORE-03..08, adoption on both platforms, SHA pins, parity review) and resumed health-body-composition-followup (wf_6fd62259-31f). Running concurrently: android-history-import-finish, ios-history-import-integration, bugfix-followups-author (4 revisions), nutrition-core-p1 (iOS lane), android-drive-and-bug-audit (verify stage), android-drive-unregistered-status (review).

## Token thrift (owner, ~15:40 KST)
Usage limit nearly exhausted. Rule: let the 8 running lanes finish; no new lanes until then; single reviewer per lane from now on; resume instead of relaunch; batch owner questions. Priority order after current lanes: verify bugfix follow-ups (compile + red/green) → fold iOS branches → final iOS full CI → Android import merge → nutrition P2 and stacked features.

## Drive status classification done (wf_295ad5fb-49b)

Android branch `fix/drive-unregistered-status` head f75b661 (pushed, not merged; worktree `android-drive-status`). Status 8 with a registration token (UNREGISTERED_ON_API_CONSOLE, INVALID_AUDIENCE, INVALID_SCOPE, RESTRICTED_CLIENT; names verified in play-services-auth-base) → MISCONFIGURED on both the silent and consent paths; sheet shows "Google 응답 코드 %1$d (%2$s)" in 17 locales; no disconnect. 708 JVM tests green, red proof done. Reviewer: the app-side statusMessage token is inferred from the Play services log, not captured from the app (needs a device check with a build of this branch before relying on the wording); check_play_metadata fails on the branch because UI bytes changed (17-locale recapture required before merge, per AGENTS.md). Docs corrected. Do not merge until the recapture is bundled with a code-10 release candidate.

## Android bug audit done (wf_b1e39ec6-9f3) — designs/android-bug-audit.md/.json

13 real findings after adversarial verification (1 refuted). High: LIFECYCLE-01 app-lock bypass (sheet windows created after the shield; no lock gate on route/draft replay); DRIVE-AUTH-01 three Play signing certificates (now all registered as OAuth clients — resolved today). Medium: HC-01 Play code 9 has no automatic Health Connect import (already fixed on main; ships with code 10 — this explains the owner's "recent records missing" report); DRIVE-AUTH-03 401 never clears the token → reconnect loop; DI-01 clock-rollback tombstone breaks all backups; DI-02 live-row natural-key re-keying lets a duplicate deletion erase a row; RW-02 supply nudge re-arms hourly and ignores its toggle (iOS same); RW-03 Doze defers setWindow alarms (use setAndAllowWhileIdle); LIFECYCLE-02 recovery-code dialog unsecured first frames when lock is off; DRIVE-AUTH-02 status-8 stage unrecorded (covered by fix/drive-unregistered-status). Low: HC-03, HC-04, SECREL-02.
Queued (single lane + single reviewer, after current lanes finish): Android `fix/audit-2026-09-15` for LIFECYCLE-01/02, DRIVE-AUTH-03, DI-01, DI-02, RW-02, RW-03, HC-03/04, SECREL-02; iOS `fix/audit-2026-09-15` for the RW-02 sibling and an app-lock window check.

## Bugfix follow-ups authored (wf_6e1197b1-cdb) — all six branches pushed, reviewed, revised; nothing compiled yet

- iOS `fix/history-visible-actions` 7e87079 (ED01b, PR10, ED04; reviewer blocker about the Arabic Hijri calendar in the new localization test was fixed in revision).
- iOS `fix/record-flow-past-drafts` 283832e (PR09, PR03, ED11 protected draft, PR11 retry rule).
- iOS `test/bugfix-variants` d9661a3 (variant tests + "Front view"); the `ios-variant-tests` worktree is still mid-merge from the record-flow lane — the verification lane must fast-forward it to d9661a3 or cherry-pick the four test-only commits (per the lane's note).
- Android `fix/temporal-parity` a8460dc (DT06, UX02, toggle label); `fix/record-drafts-retry` 37ab427 (ED11, PR06, PR11); `test/bugfix-variants` 819e558 (16 variant tests, HC12 trace).
- Open owner questions (defaults implemented, adjustable later): PR06 Android Today path notice parity with iOS; PR11 whether the correction sheet should carry the changed values after a landed commit; ED11 draft discarded across a real app update (new versionCode) but kept across config splits.
- Next: verification lane (compile, red→green focused suites on the shared iOS runner and an owned emulator) once the iOS import/health lanes release the simulators and the Android import lane releases the emulator.

## Core engines parity v4 done (wf_78273b7b-fc2)

- Fixtures v4 in `designs/fixtures` (v4.sha256): schedule f884682a…2b96 (37 proposals + 13 lifecycle cases), body 7ce4e84f…e474, calendar e4b0c5df…b481 (84 cases; one v3 case changed under CORE-03, documented in changedFromV3). Generators v4 regenerate v1–v3 byte-identically.
- iOS `feat/core-engines` head 450c104: 122/122 package tests, mutation proof 9/9, check_invariants pins the 6 SHAs and rejects superseded copies; STATE.json now also carries CORE-01/02 (the refix added them).
- Android `feat/core-engines` head 998a101: 755/755 unit tests; lifecycle zone resolved from the schedule's time-zone policy (reviewer major fixed); CORE-08 documented as DENIED mapping (no RESTRICTED enum on Android).
- Reviewer's remaining note: CORE-03 protection of user-edited events relies on the retained detached link; after a reinstall with no baseline, cleanupOrphans may still delete an edited marker event. Accepted as documented (heuristics not wanted).
- Persistence lanes for explicit dates must feed propose() from occurrence rows via ExplicitDateSchedule.occupiedInstants (Android) / the status-only helper (iOS), not resolvedOccurrenceExistsAt.

## Nutrition P1 core done (wf_ceee2365-c5c)

- iOS `feat/nutrition-core` head 5013e92 (10 commits on codex/v11-bugfix; Packages/DoseDayCore only; 147/147 package tests; merge-tree clean against feat/core-engines). Android `feat/nutrition-core` head 3bdda12 (12 commits on origin/main; domain/common only). Both: contracts byte-identical with raw+canonical SHA pins, C01-C40 40/40, S01-S08 8/8, presentation 12/12, decimal input, formatter, normalizer r1 with Final_Sigma, usage guard refusing search/display-only records (type-bound after review). Two reviewers: 18 findings handled; iOS added tooManyItems kind and formatter; Android bound the clearance token to values.
- Coordinator decisions CORE-20260915-09 (Arabic U+066B accepted on both platforms; iOS aligns in P2) and -10 (release rule r1 Final_Sigma supersedes design §10.1). Normalizer vector sets differ between lanes (18/63 overlap); P2 must adopt the iOS 63-vector fixture on Android too.
- P2 (persistence + UI) waits for the version ledger after history import merges.

## Version ledger (reserved 2026-09-15 16:25 for stage 2)

iOS (SwiftData schema / backup payload): import V6/p8 (feat/history-import) → explicit dates V7/p9 → charts personal targets V8/p10 → calendar sync device-local links V9/no payload change → nutrition V10/p11. Android (DB / payload): import 12/9 → explicit dates 13/10 → charts 14/11 → calendar links 15/no payload change → nutrition 16/12. Each lane implements "next after its base" behind named constants; the integrator renumbers in merge order. Stage-2 iOS base = merge(feat/history-import e7b973b, feat/core-engines 450c104, feat/nutrition-core 5013e92) — the last pair conflicts trivially in Package.swift/test SHA helpers; Android base = merge(origin/main, feat/core-engines 998a101, feat/nutrition-core 3bdda12); import branch merges later (integrate lane still running).

## Stage 2 launched now (owner: everything today) — wf_3361d0dd-0c0

Base branches feat/stage2-base per platform (iOS = import + core engines + nutrition core; Android = main + core engines + nutrition core), then 8 lanes in parallel (explicit dates, body charts, calendar sync, nutrition P2 × iOS/Android), one reviewer + revision each, then integrators renumbering versions in merge order. Resource locks: iOS private DerivedData + own simulators with a wait loop on xcodebuild count/swap; Android instrumented tests only on emulator-5570 behind a mkdir lock (5560 stays with the import lane). Coordinator runs the final gates (iOS run_ci.sh from Terminal, Android run_ci.sh + matrix) after integration.

## iOS history import done (wf_04af2895-19d)

`feat/history-import` head 5d542d7 (pushed, not merged; base codex/v11-bugfix 93ae0e2 merged in). Full vertical slice verified on the shared runners: 88/88 focused unit tests (twice), HistoryImportUITests 3/3 on iPhone, AX5 and iPad (iPad form-sheet driver fix bc908b8), 11/11 with the export suite post-merge. Two reviewers: 14 findings; 12 confirmed and fixed (in-batch duplicate source ids → repeatedInBatch, Close disabled while busy, fileImporter failure surfaced, mixed-case UUID ids lowercased, row editor reuses ConfirmedDateTimePicker, in-app guide/README parity, parse strictness, blank trailing lines tolerated, decimal-separator accessibility labels, …). Red proofs for five guards are documented in docs/HISTORY_IMPORT_HANDOFF.md but not executed (the permission classifier refused temporary guard mutations); the verification lane runs them. Decisions IMPORT-20260915-01..03 recorded. Android parity to-dos for the Android import gate: in-batch source-id check, paste newline trimming, offset-only UTC export as +00:00, manual namespace machine id.
Note: stage-2 iOS base was cut from e7b973b; the integrator must merge 5d542d7 before final gates.

## Health body-composition follow-up done (wf_6fd62259-31f)

- iOS `fix/health-body-composition` head 6c5312e: combined weight + body fat manual entry (one transaction, linked ids, no schema change), tie precedence, export/visit-prep exclusion proofs, DEBUG canned-HealthKit and seed hooks, BodyCompositionUITests 5/5 on iPhone/AX5/iPad, 1130+58 unit tests green, fr/it terminology aligned. Pending: full CI as part of the bugfix gate.
- Android `fix/health-body-composition` head 6bada41: JVM proofs for -02/-05 (red proofs done), 4 new Compose device tests compiled (not run; matrix pin 581 must be re-discovered when the Android release candidate is assembled).
- Owner-visible: pending items from this lane now sit in the iOS bugfix gate and the Android release candidate.
- bugfix-verify-and-fold launched now (wf_101ba8aa-b18, owner: no waiting): iOS lane verifies history-actions/record-flow/variants with private DerivedData + own sims, runs red proofs, then folds those plus health into codex/v11-bugfix; Android lane verifies temporal/drafts/variants on emulator-5570 (mkdir lock) and folds five branches into release/candidate-2026-09-15. Full CI cannot start while any xcodebuild runs (runner refuses); coordinator launches it at the first quiet window.
